def readCredoEye():
	ctleVal=[]
	eyeVal=[]
	dfeVal=[]
	ctle1=device.JESD.SERDES[0].laneRegisters[0].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle2=device.JESD.SERDES[0].laneRegisters[1].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle3=device.JESD.SERDES[0].laneRegisters[2].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle4=device.JESD.SERDES[0].laneRegisters[3].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle5=device.JESD.SERDES[1].laneRegisters[0].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle6=device.JESD.SERDES[1].laneRegisters[1].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle7=device.JESD.SERDES[1].laneRegisters[2].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	ctle8=device.JESD.SERDES[1].laneRegisters[3].CTLE_OVERWRITE._CTLE_OVERRIDE_VAL.getValue()
	
	ctleVal.append(ctle1)
	ctleVal.append(ctle2)
	ctleVal.append(ctle3)
	ctleVal.append(ctle4)
	ctleVal.append(ctle5)
	ctleVal.append(ctle6)
	ctleVal.append(ctle7)
	ctleVal.append(ctle8)
	

	eye1=device.JESD.SERDES[0].laneRegisters[0].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye2=device.JESD.SERDES[0].laneRegisters[1].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye3=device.JESD.SERDES[0].laneRegisters[2].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye4=device.JESD.SERDES[0].laneRegisters[3].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye5=device.JESD.SERDES[1].laneRegisters[0].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye6=device.JESD.SERDES[1].laneRegisters[1].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye7=device.JESD.SERDES[1].laneRegisters[2].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	eye8=device.JESD.SERDES[1].laneRegisters[3].EYE_MARGIN_VALUE._EYE_MARGIN_VAL.getValue()
	
	eyeVal.append(eye1)
	eyeVal.append(eye2)
	eyeVal.append(eye3)
	eyeVal.append(eye4)
	eyeVal.append(eye5)
	eyeVal.append(eye6)
	eyeVal.append(eye7)
	eyeVal.append(eye8)
	
	
	dfe1=device.JESD.SERDES[0].laneRegisters[0].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe2=device.JESD.SERDES[0].laneRegisters[1].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe3=device.JESD.SERDES[0].laneRegisters[2].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe4=device.JESD.SERDES[0].laneRegisters[3].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe5=device.JESD.SERDES[1].laneRegisters[0].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe6=device.JESD.SERDES[1].laneRegisters[1].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe7=device.JESD.SERDES[1].laneRegisters[2].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfe8=device.JESD.SERDES[1].laneRegisters[3].DFE_F1_VALUE._DFE_F1_VALUE.getValue()
	dfeVal.append(dfe1)
	dfeVal.append(dfe2)
	dfeVal.append(dfe3)
	dfeVal.append(dfe4)
	dfeVal.append(dfe5)
	dfeVal.append(dfe6)
	dfeVal.append(dfe7)
	dfeVal.append(dfe8)
	
	
	
	log("CTLE Lane1: %d Eye Lane1: %d DFE Lane1: %d"%(ctle1,eye1,dfe1))
	log("CTLE Lane2: %d Eye Lane2: %d DFE Lane2: %d"%(ctle2,eye2,dfe2))
	log("CTLE Lane3: %d Eye Lane3: %d DFE Lane3: %d"%(ctle3,eye3,dfe3))
	log("CTLE Lane4: %d Eye Lane4: %d DFE Lane4: %d"%(ctle4,eye4,dfe4))
	log("CTLE Lane5: %d Eye Lane5: %d DFE Lane5: %d"%(ctle5,eye5,dfe5))
	log("CTLE Lane6: %d Eye Lane6: %d DFE Lane6: %d"%(ctle6,eye6,dfe6))
	log("CTLE Lane7: %d Eye Lane7: %d DFE Lane7: %d"%(ctle7,eye7,dfe7))
	log("CTLE Lane8: %d Eye Lane8: %d DFE Lane8: %d"%(ctle8,eye8,dfe8))

	return ctleVal,eyeVal,dfeVal
	
def enableDFE():	
	for i in range(2):
		for j in range(4):
			device.JESD.SERDES[i].laneRegisters[j].DFE_INIT_VALUE_1._DFE_MODE.getValue()
			device.JESD.SERDES[i].laneRegisters[j].DFE_INIT_VALUE_1.DFE_MODE=0
	credoLogicReset()
	delay(1)
	AFE.adcDacSync()
			
def credoLogicReset(credoId=0x3):
	if(credoId & 0x1):
# 		device.JESD.CREDO[0].Common.FIRMWARE_CONTROL_2.COMMAND=0xD
		device.JESD.SERDES[0].Common.SOFTWARE_RESET.DOMAIN_RESET=0x777
		device.JESD.SERDES[0].Common.SOFTWARE_RESET.DOMAIN_RESET=0x0
# 		device.JESD.CREDO[0].Common.SOFTWARE_RESET.DOMAIN_RESET=0xAAA
# 		device.JESD.CREDO[0].Common.SOFTWARE_RESET.DOMAIN_RESET=0x0

		
	if(credoId & 0x2):
# 		device.JESD.CREDO[1].Common.FIRMWARE_CONTROL_2.COMMAND=0xD
		device.JESD.SERDES[1].Common.SOFTWARE_RESET.DOMAIN_RESET=0x777
		device.JESD.SERDES[1].Common.SOFTWARE_RESET.DOMAIN_RESET=0x0
# 		device.JESD.CREDO[1].Common.SOFTWARE_RESET.DOMAIN_RESET=0xAAA
# 		device.JESD.CREDO[1].Common.SOFTWARE_RESET.DOMAIN_RESET=0x0



def forceSync(syncLow=1):
	if(syncLow==1):
		device.currentPageSelected.setValue(0)
		device.writeReg(0x15,0x80)
		device.writeReg(0x555,0xAA)  #SyncB=0
		device.writeReg(0x15,0x00)
	else:
		device.currentPageSelected.setValue(0)
		device.writeReg(0x15,0x80)
		device.writeReg(0x555,0xFF)  #SyncB=1
		device.writeReg(0x15,0x00)

def readAlarms():
	device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG368.alarms_mask=0
	log("alarm1="+str(hex(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG352._alarms.getValue())))
	device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG368.alarms_mask=0
	log("alarm1="+str(hex(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG352._alarms.getValue())))
	
	
def readFcounter():
	log("fan1 ="+str(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG312._f_counter_any_lane_ready.getValue()))
	log("fal1 ="+str(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG312._f_counter_all_lanes_ready.getValue()))
	
	log("fan2 ="+str(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG312._f_counter_any_lane_ready.getValue()))
	log("fal2 ="+str(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG312._f_counter_all_lanes_ready.getValue()))
	
	
	log("laneSkw0="+str(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG306._lane_skew_tx0.getValue()))
	log("laneSkw1="+str(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG306._lane_skew_tx0.getValue()))
	
	
def readLinkStatus():
	AFE.JESDRX[0].getJesdAlarms(0)
	AFE.JESDRX[0].getJesdAlarms(1)
	
	
def setRbd(rbd=10):
	device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG126.rbd_m1=rbd
	device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG126.rbd_m1=rbd
	AFE.adcDacSync()
	
	
def readSyncReqEna():
	log("sync_req_ena0+"+str(hex(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG139._sync_request_ena.getValue())))
	log("sync_req_ena1+"+str(hex(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG139._sync_request_ena.getValue())))
	
def setSyncReqEna(ena=0xdb):
	device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG139.sync_request_ena=ena
	device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG139.sync_request_ena=ena