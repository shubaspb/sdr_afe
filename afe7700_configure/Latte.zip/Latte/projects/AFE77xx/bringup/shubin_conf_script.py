



def forceSync(syncLow=1):
	if(syncLow==1):
		device.currentPageSelected.setValue(0)
		device.writeReg(0x15,0x80)
		device.writeReg(0x555,0xAA)  #SyncB=0
		device.writeReg(0x15,0x00)
	else:
		device.currentPageSelected.setValue(0)
		device.writeReg(0x15,0x80)
		device.writeReg(0x555,0xFF)  #SyncB=1
		device.writeReg(0x15,0x00)



sequencer_custom()

### reset jesd204b phy fpga

#forceSync(1)
#forceSync(0)