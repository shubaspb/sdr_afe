all_path= "C:\\Users\\d.shubin\\Documents\\Texas Instruments\\Latte\\"
path_seq = all_path+"projects\\AFE77xx\\bringup\\sequencer_custom.py"
ff = open ( all_path+"lib\\configCustom2.txt", "r" )
ff_lmk = open ( all_path+"lib\\lmk_conf_log.txt", "r" )

Fout = open ( path_seq, "w" )

with open(path_seq, 'a') as file: file.write("def sequencer_custom():\n")


cnt=0
old_time=0
lmk_done=0

for line in ff.readlines():
    #print(line)
    i_end = line.find("\n")
    i_wr = line.find("SPIWrite", 0, i_end)
    i_rd = line.find("SPIRead", 0, i_end)
    i_wait = line.find("WAIT", 0, i_end)
    i_poll = line.find("SPIPoll", 0, i_end)

    lmk_flag = line.find("\\Doing LMK config")
    if ((lmk_flag>=0)&(lmk_done==0)) :
        #print("LMK!!!!!!!!!!!!!!!")
        for line_lmk in ff_lmk.readlines():
            command = "    "+line_lmk
            with open(path_seq, 'a') as file: file.write(command)
        lmk_done=1

    if (i_wr>=0) :
        i0 = line.find(" ",4,i_end)
        i1 = line.find(",", i0+2, i_end)
        i2 = line.find(",", i1+2, i_end)
        i3 = line.find(",", i2+1, i_end)
        addr = line[i0+1:i1]
        data = line[i1+1:i2]
        lsb = line[i2+1:i3]
        msb = line[i3+1:i3+2]
        command = "    device.writeReg(" + "0x" + addr + ",0x" + data + "," + lsb + "," + msb + ")" + "\n"
        with open(path_seq, 'a') as file: file.write(command)

    if (i_rd>=0) :
        i0 = line.find(" ",4,i_end)
        i1 = line.find(",", i0+2, i_end)
        i2 = line.find(",", i1+2, i_end)
        addr = line[i0+1:i1]
        lsb = line[i1+1:i2]
        msb = line[i2+1:i2+2]
        command = "    device.readReg(" + "0x" + addr + "," + lsb + "," + msb + ")" + "\n"
        with open(path_seq, 'a') as file: file.write(command)

    if (i_wait>=0) :
        i0 = line.find(" ",0,i_end)
        i1 = line.find("\n",0, i_end)
        delay = line[i0+1:i1]
        command = "    time.sleep(" + delay + ")" + "\n"
        with open(path_seq, 'a') as file: file.write(command)

    if (i_poll>=0) :
        i0 = line.find(" ",4,i_end)
        i1 = line.find(",", i0+1, i_end)
        i2 = line.find(",", i1 + 1, i_end)
        i3 = line.find(",", i2 + 1, i_end)

        addr = line[i0+1:i1]
        lsb = line[i1+1:i2]
        msb = line[i2+1:i3]
        val = line[i3+1:i_end]

        #print("("+addr+")")
        #print("("+val+")")

        command = "    device.readReg(" + "0x" + addr + "," + lsb + "," + msb + "," + val + ")" + "\n"
        with open(path_seq, 'a') as file: file.write(command)
        with open(path_seq, 'a') as file: file.write("    time.sleep(0.01)\n")
        with open(path_seq, 'a') as file: file.write(command)
        with open(path_seq, 'a') as file: file.write("    time.sleep(0.01)\n")
        with open(path_seq, 'a') as file: file.write(command)
        with open(path_seq, 'a') as file: file.write("    time.sleep(0.01)\n")
        with open(path_seq, 'a') as file: file.write(command)
        with open(path_seq, 'a') as file: file.write("    time.sleep(0.01)\n")
        with open(path_seq, 'a') as file: file.write(command)

