def setCo(fInBaseBand):
	fsBaseBand=2949.12
	NumberOfSamples=2**16
	bits=16
	n = int(NumberOfSamples/2)
	m = int((fInBaseBand/fsBaseBand)*n)	
	if (m%2) == 0 :
		m = m+1
	fInBaseBand=(m/float(n)*fsBaseBand)
	return(fInBaseBand)


engine.inputFrequency=(engine.DDCNCOFreqWord*engine.clockFrequency*1.0/2**32)+(process.complexfftParam.spurFreq*1e6)
	#engine.clockFrequency+

AFE.FPGA.txTddEn(0,0)
AFE.FPGA.txTddEn(1,1)
AFE.FPGA.fbTddEn(0,0)
AFE.FPGA.fbTddEn(1,1)
AFE.FPGA.rxTddEn(0,0)
AFE.FPGA.rxTddEn(1,1)

fin=20
backoff=8
AFE.FPGA.sendSingleTone(0,fin,-backoff,fin,-backoff)
AFE.FPGA.sendSingleTone(1,fin,-backoff,fin,-backoff)

AFE.TOP.DSA[0].setTxDsa(0,0)	#TX ChA ; Atten from 0 to 40
AFE.TOP.DSA[0].setTxDsa(1,0)	#TX ChB ; Atten from 0 to 40
AFE.TOP.DSA[1].setTxDsa(0,0)	#TX ChC ; Atten from 0 to 40
AFE.TOP.DSA[1].setTxDsa(1,0)	#TX ChD ; Atten from 0 to 40

AFE.TOP.DSA[0].setRxDsa(0,0)	#RX ChA ; Atten from 0 to 28
AFE.TOP.DSA[0].setRxDsa(1,0)	#RX ChB ; Atten from 0 to 28
AFE.TOP.DSA[1].setRxDsa(0,0)	#RX ChC ; Atten from 0 to 28
AFE.TOP.DSA[1].setRxDsa(1,0)	#RX ChD ; Atten from 0 to 28

AFE.TOP.DSA[0].setFbDsa(0)		#FB ChA ; Atten from 0 to 16
AFE.TOP.DSA[1].setFbDsa(0)		#FB ChB ; Atten from 0 to 16

AFE.selectCh(rxFbTx,chNo)

AFE.selectCh(0,0)		#To selct RxChA
AFE.selectCh(0,1)		#To selct RxChB
AFE.selectCh(0,2)		#To selct RxChC
AFE.selectCh(0,3)		#To selct RxChD

AFE.selectCh(1,0)		#To selct RxChAB
AFE.selectCh(1,1)		#To selct RxChCD

NCO_freq=3500
AFE.setFbNcoWord(0,NCO_freq)	#To set the NCO  frequency of FbAB

# NCO_freq=4900
NCO_freq=2600
AFE.setFbNcoWord(1,NCO_freq)	#To set the NCO  frequency of FbCD

AFE.TOP.requestPllSpiAccess(1)
sysParams.pllLo[0]=3510
AFE.PLL[0].configurePll()		#To set LO frequency for Rx and Tx

myfpga.saveDataToFile(r"\\Mac\Home\Documents\backup\converterWiseData.xls")
AFE.FPGA.sendLteData(0,Globals.libFolderPath+"\\resourceFiles\\LTE_20MHz.tsw")		#To send LTE pattern on TxA and TxB
AFE.FPGA.sendLteData(1,Globals.libFolderPath+"\\resourceFiles\\output_LTE.tsw")		#To send LTE pattern on TxC and TxD

AFE.FPGA.sendLteData(0,Globals.libFolderPath+"\\resourceFiles\\output_LTE_2.tsw")		#To send LTE pattern on TxA and TxB
AFE.FPGA.sendLteData(1,Globals.libFolderPath+"\\resourceFiles\\output_LTE_2.tsw")		#To send LTE pattern on TxC and TxD


## For TX IQMC Steady State Calibration
AFE.TOP.TIMINGCTRL.txToFbSelectCh(overrideEn,channelSelect)
""" overrideEn=True to override the Pins 
	In single FB mode, channelSelect values of 0-3 selects channels A-D. 4 means No TX is connected to FB 
	In dual FB mode, channelSelect values 
				0 selects channels TXA to FBAB and TXC to FBCD 
				1 selects channels TXB to FBAB and TXD to FBCD 
				2/3 means no channel is connected to FB. """ 

