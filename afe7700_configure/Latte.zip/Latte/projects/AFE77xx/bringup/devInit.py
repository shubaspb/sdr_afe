from mDevice import Device
from HSCEngines import HSCEngineWithILDDCDGC
from HSCProcesses import HSCProcessWithILDDCDGC
from mConnect import Connect

import mCPLD_Device
reload(mCPLD_Device)
import sys
import mAnupam_PG1
reload(mAnupam_PG1)
from mAnupam_PG1 import ANUPAM
import mlmkDevice
reload(mlmkDevice)
import globalDefs as Globals

if boardType in ("BENCH","HSC1330"):# or simulationMode==True:
	if simulationMode==False:
		adcregProg.addressLen=16
		adcregProg.packetLen=24
		adcregProg.packetOrder=0
		adcregProg.msbFirst=1
		adcregProg.clkEdge=1
		if boardType in ("BENCH",):
			adcregProg.pin0=5#0#
			adcregProg.pin1=5#1#
			adcregProg.pin2=5#6#
			adcregProg.pin3=5#2#
			adcregProg.pin4=0#5#
			adcregProg.pin5=1#5#
			adcregProg.pin6=6#5#
			adcregProg.pin7=2#5#
		else:
			adcregProg.pin0=0#
			adcregProg.pin1=1#
			adcregProg.pin2=6#
			adcregProg.pin3=2#
			adcregProg.pin4=5#
			adcregProg.pin5=5#
			adcregProg.pin6=5#
			adcregProg.pin7=3#
			boardType="BENCH"
		adcregProg.readClkEdge=1
		
		if jesdH==True:
			fpgaregProg.addressLen=16
			fpgaregProg.packetLen=24
			fpgaregProg.packetOrder=0
			fpgaregProg.msbFirst=1
			fpgaregProg.clkEdge=1
			fpgaregProg.pin0=5
			fpgaregProg.pin1=1
			fpgaregProg.pin2=2
			fpgaregProg.pin3=0
			fpgaregProg.pin4=6
			fpgaregProg.pin5=5
			fpgaregProg.pin6=5
			fpgaregProg.pin7=5
		else:			
			fpgaregProg.addressLen=7
			fpgaregProg.packetLen=39
			fpgaregProg.packetOrder=0
			fpgaregProg.msbFirst=1
			fpgaregProg.clkEdge=1
			fpgaregProg.pin0=5
			fpgaregProg.pin1=0
			fpgaregProg.pin2=6
			fpgaregProg.pin3=2
			fpgaregProg.pin4=3
			fpgaregProg.pin5=5
			fpgaregProg.pin6=5
			fpgaregProg.pin7=1
		
		lmkregProg.addressLen=16
		lmkregProg.packetLen=24
		lmkregProg.packetOrder=0
		lmkregProg.msbFirst=1
		lmkregProg.clkEdge=1
		lmkregProg.pin0=5
		lmkregProg.pin1=5
		lmkregProg.pin2=5
		lmkregProg.pin3=5
		lmkregProg.pin4=3
		lmkregProg.pin5=2
		lmkregProg.pin6=0
		lmkregProg.pin7=1
		
		gpioProg.pin0=3
		gpioProg.pin1=3
		gpioProg.pin2=3
		gpioProg.pin3=3
		gpioProg.pin4=3
		gpioProg.pin5=3
		gpioProg.pin6=3
		gpioProg.pin7=3
		
		jtagregProg.pin0=5
		jtagregProg.pin1=5
		jtagregProg.pin2=5
		jtagregProg.pin3=5
		jtagregProg.pin4=5
		jtagregProg.pin5=5
		jtagregProg.pin6=5
		jtagregProg.pin7=5
		
	device=ANUPAM(fileName=Globals.libFolderPath+"//"+"resourceFiles//"+Afe77xxLibraries.folderDirDict[folderName]['dmlName'],regProgDevice=adcregProg,name='DONOT_OPEN_'+Afe77xxLibraries.folderDirDict[folderName]['dmlName'][:-4]+'_FULL')
	if jesdH==True:
		from JESD204H import JESD204H
		myfpga=JESD204H(name="JESD204H_FPGA",fileName=Globals.libFolderPath+"\\resourceFiles\\JESD204H.dml", regProgDevice=fpgaregProg,captureDevice=capDev)
		info("Loading JESD 204H FPGA DML")
	else:
		import ANUPAM_FPGA
		reload(ANUPAM_FPGA)
		myfpga=ANUPAM_FPGA.ANUPAM_FPGA(regProgDevice=fpgaregProg,fileName=Globals.libFolderPath+"\\resourceFiles\\AFE77xx_FPGA.dml",captureDevice=capDev)
		myfpga.setResetProperty(myfpga.head.page.Common.Reset._Reset_all)
		info("Loading JESD 204B FPGA DML")

elif boardType=='HSC1320':
	if simulationMode==False:
		dut0_spia.addressLen=16
		dut0_spia.packetLen = 24
		dut0_spia.pin0 = 0
		dut0_spia.pin1 = 1 
		dut0_spia.pin2 = 5
		dut0_spia.pin3 = 5
		dut0_spia.pin4 = 6
		dut0_spia.pin5 = 2
		dut0_spia.pin6 = 5
		dut0_spia.pin7 = 5
		dut0_spia.clkEdge=1
		dut0_spia.msbFirst = 1
		
		dut1_spia.addressLen=16
		dut1_spia.packetLen = 24
		dut1_spia.pin0 = 0
		dut1_spia.pin1 = 1
		dut1_spia.pin2 = 6
		dut1_spia.pin3 = 2
		dut1_spia.pin4 = 5
		dut1_spia.pin5 = 5
		dut1_spia.pin6 = 5
		dut1_spia.pin7 = 5
		dut1_spia.clkEdge=1
		dut1_spia.msbFirst = 1
		
		dut0_spib.addressLen=16
		dut0_spib.packetLen = 24
		dut0_spib.pin0 = 0
		dut0_spib.pin1 = 1
		dut0_spib.pin2 = 5
		dut0_spib.pin3 = 5
		dut0_spib.pin4 = 6
		dut0_spib.pin5 = 2
		dut0_spib.pin6 = 5
		dut0_spib.pin7 = 5
		dut0_spib.clkEdge=1
		dut0_spib.msbFirst = 1
		
		dut1_spib.addressLen=16
		dut1_spib.packetLen = 24
		dut1_spib.pin0 = 0
		dut1_spib.pin1 = 1
		dut1_spib.pin2 = 6
		dut1_spib.pin3 = 2
		dut1_spib.pin4 = 5
		dut1_spib.pin5 = 5
		dut1_spib.pin6 = 5
		dut1_spib.pin7 = 5
		dut1_spib.clkEdge=1
		dut1_spib.msbFirst = 1
		
		lmkregProg.addressLen=16
		lmkregProg.packetLen = 24
		lmkregProg.pin0 = 6
		lmkregProg.pin1 = 2
		lmkregProg.pin2 = 0
		lmkregProg.pin3 = 1
		lmkregProg.pin4 = 5
		lmkregProg.pin5 = 5
		lmkregProg.pin6 = 5
		lmkregProg.pin7 = 5
		lmkregProg.msbFirst = 1
		lmkregProg.clkEdge = 1
		

	
	import j58Wrapper
	reload(j58Wrapper)
	from j58Wrapper import j58WrapperClass
	try:
		myfpga=j58WrapperClass()
	except:
		error("Reset the FPGA and rerun devInit.py")
		raise
	device0=ANUPAM(fileName=Globals.libFolderPath+"//"+"resourceFiles//"+Afe77xxLibraries.folderDirDict[folderName]['dmlName'],regProgDevice=dut0_spib,name='DONOT_OPEN_'+Afe77xxLibraries.folderDirDict[folderName]['dmlName'][:-4]+'_FULL1')
	device1=ANUPAM(fileName=Globals.libFolderPath+"//"+"resourceFiles//"+Afe77xxLibraries.folderDirDict[folderName]['dmlName'],regProgDevice=dut1_spib,name='DONOT_OPEN_'+Afe77xxLibraries.folderDirDict[folderName]['dmlName'][:-4]+'_FULL2')
	cpld=mCPLD_Device.CPLD(fileName=Globals.libFolderPath+"//"+"resourceFiles//EvmCpld.dml",regProgDevice="",name='CPLD')
elif boardType in ('EVM-1Device',"EVM-1DeviceJ58"):
		lmkregProg.addressLen=16
		lmkregProg.packetLen = 24
		lmkregProg.pin0 = 6
		lmkregProg.pin1 = 2
		lmkregProg.pin2 = 0
		lmkregProg.pin3 = 1
		lmkregProg.pin4 = 5
		lmkregProg.pin5 = 5
		lmkregProg.pin6 = 5
		lmkregProg.pin7 = 5
		lmkregProg.msbFirst = 1
		lmkregProg.clkEdge = 1
		if MPSSE==True:
			adcregProg.chipSelect = 0
		else:
			adcregProg.addressLen=16
			adcregProg.packetLen=24
			adcregProg.packetOrder=0
			adcregProg.msbFirst=1
			adcregProg.clkEdge=1
			adcregProg.pin0=0
			adcregProg.pin1=1
			adcregProg.pin2=6
			adcregProg.pin3=2
			adcregProg.pin4=5
			adcregProg.pin5=5
			adcregProg.pin6=5
			adcregProg.pin7=5
			adcregProg.readClkEdge=1
		
		cpldRegProg.addressLen=16
		cpldRegProg.packetLen = 24
		cpldRegProg.pin0 = 5
		cpldRegProg.pin1 = 5
		cpldRegProg.pin2 = 5
		cpldRegProg.pin3 = 5
		cpldRegProg.pin4 = 0
		cpldRegProg.pin5 = 1
		cpldRegProg.pin6 = 6
		cpldRegProg.pin7 = 2
		cpldRegProg.msbFirst = 1
		cpldRegProg.clkEdge = 1
		
		cpld=mCPLD_Device.CPLD(fileName=Globals.libFolderPath+"//"+"resourceFiles//EvmCpld.dml", regProgDevice=cpldRegProg,name='CPLD')
		device=ANUPAM(fileName=Globals.libFolderPath+"//"+"resourceFiles//"+Afe77xxLibraries.folderDirDict[folderName]['dmlName'],regProgDevice=adcregProg,name='DONOT_OPEN_'+Afe77xxLibraries.folderDirDict[folderName]['dmlName'][:-4]+'_FULL')
		if boardType == "EVM-1DeviceJ58":
			import j58Wrapper
			reload(j58Wrapper)
			from j58Wrapper import j58WrapperClass
			try:
				myfpga=j58WrapperClass()
			except:
				error("Reset the FPGA and rerun devInit.py")
				raise
		else:
			myfpga=None
		
else:
	info(boardType)
	if simulationMode==False:
		if MPSSE==False:
			dut0_spia.addressLen=16
			dut0_spia.packetLen = 24
			dut0_spia.pin0 = 0
			dut0_spia.pin1 = 1 
			dut0_spia.pin2 = 6
			dut0_spia.pin3 = 2
			dut0_spia.pin4 = 4
			dut0_spia.pin5 = 4
			dut0_spia.pin6 = 4
			dut0_spia.pin7 = 4
			
			dut1_spia.addressLen=16
			dut1_spia.packetLen = 24
			dut1_spia.pin0 = 0
			dut1_spia.pin1 = 1
			dut1_spia.pin2 = 6
			dut1_spia.pin3 = 4
			dut1_spia.pin4 = 2
			dut1_spia.pin5 = 4
			dut1_spia.pin6 = 4
			dut1_spia.pin7 = 4
			
			dut0_spia.clkEdge=1
			dut1_spia.clkEdge=1
			
			dut0_spia.msbFirst = 1
			dut1_spia.msbFirst = 1
			
			dut0_spib.addressLen=16
			dut0_spib.packetLen = 24
			dut0_spib.pin0 = 0
			dut0_spib.pin1 = 1
			dut0_spib.pin2 = 6
			dut0_spib.pin3 = 4
			dut0_spib.pin4 = 4
			dut0_spib.pin5 = 2
			dut0_spib.pin6 = 4
			dut0_spib.pin7 = 4
			
			dut1_spib.addressLen=16
			dut1_spib.packetLen = 24
			dut1_spib.pin0 = 0
			dut1_spib.pin1 = 1
			dut1_spib.pin2 = 6
			dut1_spib.pin3 = 4
			dut1_spib.pin4 = 4
			dut1_spib.pin5 = 4
			dut1_spib.pin6 = 2
			dut1_spib.pin7 = 4
			
			
			dut0_spib.clkEdge=1
			dut1_spib.clkEdge=1
			
			dut0_spib.msbFirst = 1
			dut1_spib.msbFirst = 1
		else:
			dut0_spia.chipSelect = 0
			dut1_spia.chipSelect = 1
			dut0_spib.chipSelect = 2
			dut1_spib.chipSelect = 3
				
		lmkregProg.addressLen=16
		lmkregProg.packetLen = 24
		lmkregProg.pin0 = 6
		lmkregProg.pin1 = 2
		lmkregProg.pin2 = 0
		lmkregProg.pin3 = 1
		lmkregProg.pin4 = 5
		lmkregProg.pin5 = 5
		lmkregProg.pin6 = 5
		lmkregProg.pin7 = 5
		lmkregProg.msbFirst = 1
		lmkregProg.clkEdge = 1
		
		cpldRegProg.addressLen=16
		cpldRegProg.packetLen = 24
		cpldRegProg.pin0 = 5
		cpldRegProg.pin1 = 5
		cpldRegProg.pin2 = 5
		cpldRegProg.pin3 = 5
		cpldRegProg.pin4 = 0
		cpldRegProg.pin5 = 1
		cpldRegProg.pin6 = 6
		cpldRegProg.pin7 = 2
		cpldRegProg.msbFirst = 1
		cpldRegProg.clkEdge = 1
		
		import j58Wrapper
		reload(j58Wrapper)
		from j58Wrapper import j58WrapperClass
		try:
			myfpga=j58WrapperClass()
		except:
			error("Reset the FPGA and rerun devInit.py")
			raise
	else:
		myfpga=None
	device0=ANUPAM(fileName=Globals.libFolderPath+"//"+"resourceFiles//"+Afe77xxLibraries.folderDirDict[folderName]['dmlName'],regProgDevice=dut0_spib,name='DONOT_OPEN_'+Afe77xxLibraries.folderDirDict[folderName]['dmlName'][:-4]+'_FULL1')
	device1=ANUPAM(fileName=Globals.libFolderPath+"//"+"resourceFiles//"+Afe77xxLibraries.folderDirDict[folderName]['dmlName'],regProgDevice=dut1_spib,name='DONOT_OPEN_'+Afe77xxLibraries.folderDirDict[folderName]['dmlName'][:-4]+'_FULL2')
	cpld=mCPLD_Device.CPLD(fileName=Globals.libFolderPath+"//"+"resourceFiles//EvmCpld.dml",regProgDevice=cpldRegProg,name='CPLD')

lmk=mlmkDevice.LMK(name="LMK Clock Divider",fileName=ASTERIX_DIR+DEVICES_DIR+"LMK04828_form_new.dml",regProgDevice=lmkregProg)
lmk.setResetProperty(lmk.head.page.System.Top_Modes._SW_RESET)

if simulationMode==True:
	cpld=Device(fileName=Globals.libFolderPath+"//"+"resourceFiles//EvmCpld.dml",regProgDevice="",name='CPLD')

#### clk sources

DevClkSource.frequency=368.64e6
DevClkSource.amplitude=0
DevClkSource.frequencySynth=2949.12e6/2
DevClkSource.on=1
DevClkSource.onSynth=1

sigSource00.amplitude=-10
sigSource00.on=1

process=HSCProcessWithILDDCDGC()
engine=HSCEngineWithILDDCDGC(device=myfpga,process=process,clockVariable=clkSource._frequency,inputVariable=sigSource00._frequency)
if boardType!="EVM-1Device":
	myfpga.byte_swap=0
if simulationMode==True:
	if boardType!="EVM-1Device":
		myfpga.delay_time=0
	if boardType in ("BENCH","EVM-1Device","EVM-1DeviceJ58"):
		device.delay_time=0
	else:
		device0.delay_time=0
		device1.delay_time=0
else:
	if boardType!="EVM-1Device":
		if jesdH==True:
			myfpga.delay_time=0.05
		else:
			myfpga.delay_time=0.2
	if boardType in ("BENCH","EVM-1Device","EVM-1DeviceJ58"):
		if MPSSE==False:
			device.delay_time=0.02
		else:
			device.delay_time=0.005
	else:
		if MPSSE==False:
			device0.delay_time=0.02
			device1.delay_time=0.02
		else:
			device0.delay_time=0.004
			device1.delay_time=0.004

if boardType=="HSC1357":
	boardType="HSC1320"

	
import mLogDump
reload(mLogDump)
if boardType in ("BENCH","EVM-1Device","EVM-1DeviceJ58"):
	logDumpInst=mLogDump.logDump(ASTERIX_DIR+DEVICES_DIR+r"\config.txt")
	device.logClassInst=logDumpInst
	if boardType=="BENCH":
		myfpga.logClassInst=logDumpInst
	lmk.logClassInst=logDumpInst
else:
	logDumpInst0=mLogDump.logDump(ASTERIX_DIR+DEVICES_DIR+r"\configDevice0.txt")
	logDumpInst1=mLogDump.logDump(ASTERIX_DIR+DEVICES_DIR+r"\configDevice1.txt")
	device0.logClassInst=logDumpInst0
	device1.logClassInst=logDumpInst1
	myfpga.logClassInst=logDumpInst0
	lmk.logClassInst=logDumpInst0
	
########### Loading the Libraries

import mSetupParams
reload(mSetupParams)
from mSetupParams import setupParams
if boardType=="EVM":
	setupParams.boardType="HSC1320"
else:
	setupParams.boardType=boardType
setupParams.fpgaWriter=writer
setupParams.engine=engine
setupParams.process=process

if simulationMode==True or setupParams.boardType=="EVM-1Device":
	setupParams.skipFpga=True
	setupParams.skipLmk=True
else:
	setupParams.skipFpga=False
	setupParams.skipLmk=False

from mSetupParams import fpgaParamsClass
fpgaParams=fpgaParamsClass()
from mSetupParams import lmkParamsClass
LMKParams=lmkParamsClass()

import mLmk
reload(mLmk)
from mLmk import lmkLib
LMKlibInst=lmkLib(lmk,LMKParams)

if boardType=="BENCH":
	import mFpga
	reload(mFpga)
	from mFpga import fpgaLib
	FPGAlibInst=fpgaLib(myfpga,fpgaParams)
else:
	import mFPGA_J58
	reload(mFPGA_J58)
	from mFPGA_J58 import fpgaLib_J58
	FPGAlibInst=fpgaLib_J58(myfpga,fpgaParams)

if boardType not in ("BENCH","EVM-1Device","EVM-1DeviceJ58","EVM"):
	import CurrentSenseAFE77xx
	reload(CurrentSenseAFE77xx)
	currSensor=CurrentSenseAFE77xx.CurrentSensor(currSenseI2C)
	setupParams.currSensor=currSensor
	
setupParams.fpgaLib=FPGAlibInst
setupParams.lmkLib=LMKlibInst
if boardType not in ("HSC1320","BENCH","HSC1330"):
	setupParams.cpld=cpld

import mFuncDecorator
reload(mFuncDecorator)
from mFuncDecorator import *
def loadLibs(device,dutNo=0):
	import mAfeLibrary
	reload(mAfeLibrary)
	from mAfeLibrary import afeLibrary
	import mAfeParameters
	reload(mAfeParameters)
	from mAfeParameters import systemParams
	from mAfeParameters import systemStatus
	import numpy
	
	device1Refs=deviceRefs()
	sysParams=systemParams()
	sysStatus=systemStatus()
	
	sysParams.chipType=0x10
	device1Refs.device=device
	device1Refs.engine=engine
	device1Refs.process=process
	device1Refs.systemParams=sysParams
	device1Refs.systemStatus=sysStatus
	device1Refs.gpioProg=gpioProg
	device1Refs.lmkParams=LMKParams
	
	sysParams.chipId=chipId
	sysParams.chipVersion=chipVersion
	sysParams.simulationMode=simulationMode
	
	afeInst=afeLibrary(device1Refs,dutNo)
	if len(setupParams.dutInstances)<dutNo:
		setupParams.dutInstances[dutNo]=afeInst
	else:
		setupParams.dutInstances.append(afeInst)
	return (sysParams,sysStatus,afeInst)
	
if boardType in ("BENCH","EVM-1Device","EVM-1DeviceJ58"):
	(sysParams,sysStatus,AFE)=loadLibs(device,0)
else:
	(sysParams0,sysStatus,AFE0)=loadLibs(device0,0)
	(sysParams1,sysStatus,AFE1)=loadLibs(device1,1)
	AFE=AFE1
from common.mMACROConst import MACROConst

####################		
######################
if chipVersion>0x10:
	try:
		if boardType in ("BENCH","EVM-1DeviceJ58","EVM-1Device"):
			imlPath = Globals.libFolderPath+r"\\resourceFiles\\afeiGui\\iGuiTreeBench.iml"
		elif boardType in ("HSC1373"):
			imlPath = Globals.libFolderPath+r"\\resourceFiles\\afeiGui\\iGuiTree.iml"
		
		imlFile=open(imlPath,'r')
		imlFileLines= imlFile.readlines()
		imlFile.close()
		
		libFolderPath = Globals.libFolderPath.split("Afe77xxLibraries")[0]
		
		imlFile=open(imlPath,'w')
		imlFile.close()
		
		imlFile = open(imlPath,'a')
		
		for line in imlFileLines:
			if "Afe77xxLibraries" in line:
				split = line.split("Afe77xxLibraries")
				prefix = split[0].split("path")[0] + 'path="'
				split[0] = libFolderPath
				new = 'Afe77xxLibraries'.join(split)
				new = prefix + new
				imlFile.write(new)
			else:
				imlFile.write(line)
				
		imlFile.close()
		
		
		from iGui import iGui
		import afeiGui
		reload(afeiGui)
		import afeiGui.mAfe77xxSystemParamsiGui
		reload(afeiGui.mAfe77xxSystemParamsiGui)
		from afeiGui.mAfe77xxSystemParamsiGui import afe77xxSystemParamsiGui
		import afeiGui.afe77xxSystemStatusRegs
		reload(afeiGui.afe77xxSystemStatusRegs)
		from afeiGui.afe77xxSystemStatusRegs import afe77xxSystemStatusRegs
		import afeiGui.afe77xxCustomConfig
		reload(afeiGui.afe77xxCustomConfig)
		from afeiGui.afe77xxCustomConfig import afe77xxCustomConfig

		import afeiGui.mAfe77xxPowerMeasurements
		reload(afeiGui.mAfe77xxPowerMeasurements) 
		from afeiGui.mAfe77xxPowerMeasurements import afe77xxCurrentSense
		import afeiGui.mAfe77xxGpioExternalAgc
		reload(afeiGui.mAfe77xxGpioExternalAgc)
		from afeiGui.mAfe77xxGpioExternalAgc import afe77xxGpioExternalAgc
		import afeiGui.mAfe77xxGpioInternalAgc
		reload(afeiGui.mAfe77xxGpioInternalAgc)
		from afeiGui.mAfe77xxGpioInternalAgc import afe77xxGpioInternalAgc
		import afeiGui.afe77xxAdditionalConfig
		reload(afeiGui.afe77xxAdditionalConfig)
		from afeiGui.afe77xxAdditionalConfig import afe77xxAdditionalConfig

		from mAfeConstants import gpioConstants

		import afeiGui.mAfeGuiController
		reload(afeiGui.mAfeGuiController)
		from afeiGui.mAfeGuiController import afeGuiControllerClass

		import afeiGui.afe77xxGpioFinalMapGuiCode
		reload(afeiGui.afe77xxGpioFinalMapGuiCode)
		from afeiGui.afe77xxGpioFinalMapGuiCode import gpioMap

		import afeiGui.genericSelection
		reload(afeiGui.genericSelection)
		from afeiGui.genericSelection import genericSelection

		import afeiGui.gpioTop 
		reload(afeiGui.gpioTop)
		from afeiGui.gpioTop import gpioTop

		import afeiGui.mAfeGuiParams
		reload(afeiGui.mAfeGuiParams)
		from afeiGui.mAfeGuiParams import guiParams


		from PySide import QtGui

		if boardType in ("BENCH","EVM-1DeviceJ58","EVM-1Device","HSC1373"):
			guiCache = guiParams()
			afeiGuiController = afeGuiControllerClass(AFE,gpioConstants) 
			gpioGenericSeliGuiClass = genericSelection(libInstance=AFE,guiControllerInstance=afeiGuiController)
			gpioStatusiGuiClass =gpioMap(libInstance=AFE,guiControllerInstance=afeiGuiController,cpld=cpld)
			afeiGuiController.gpioStatusiGuiClass = gpioStatusiGuiClass
			afeiGuiController.gpioGenericSeliGuiClass = gpioGenericSeliGuiClass
			afeiGuiController.gpioStatusiGuiClass = gpioStatusiGuiClass
			gpioGroupSelection = gpioTop(libInstance=AFE,guiControllerInstance=afeiGuiController)
			
			systemParamClassiGui = afe77xxSystemParamsiGui(libInstance=AFE, cache=guiCache, gpio=cpld,guiControllerInstance=afeiGuiController,lmkParams=LMKParams,FPGA=myfpga)
			afeiGuiController.sysParamClassInst = systemParamClassiGui
			customConfig=afe77xxCustomConfig(libInstance=AFE, cache=guiCache,guiControllerInstance=afeiGuiController)
			additionalConfig = afe77xxAdditionalConfig(libInstance=AFE, cache = guiCache,guiControllerInstance=afeiGuiController)
			statusRegisters=afe77xxSystemStatusRegs(libInstance=AFE,guiControllerInstance=afeiGuiController)
			afe77xxiGui= iGui(fileName = Globals.libFolderPath+"//"+"resourceFiles//"+r"/afeiGui/iGuiTreeBench.iml")
			guiCache.guiInst = afe77xxiGui
			afeiGuiController.guiInstance = afe77xxiGui
			
			for i in [1,2,3,4,5,6]:
				eval("afe77xxiGui.mainWindow.changeTab("+str(i)+")")
				eval("afe77xxiGui.mainWindow.stackWidget.currentWidget().svgWidget.resize(1600,950)")
			# 	eval("afe77xxiGui.mainWindow.resize(1642,992)")
				afe77xxiGui.mainWindow.stackWidget.currentWidget().scrollArea.setWidgetResizable(False)
			Globals.mainWindowOpen=True
			def closeMainWindow():
				if Globals.mainWindowOpen:
					mainWindow.hide()
					Globals.mainWindowOpen = False
				else:
					mainWindow.show()
					Globals.mainWindowOpen = True
			a = QtGui.QAction(afe77xxiGui.mainWindow)
			a.setShortcut("ctrl+L")
			a.triggered.connect(closeMainWindow)
			afe77xxiGui.mainWindow.listWidget.hide()
			afe77xxiGui.mainWindow.resize(1642,992)
			afe77xxiGui.mainWindow.setMaximumWidth(1643)
			afe77xxiGui.mainWindow.setMaximumHeight(992)
			afe77xxiGui.mainWindow.changeTab(2)
			afe77xxiGui.mainWindow.setWindowTitle("AFE77xx iGui")
			afe77xxiGui.mainWindow.addAction(mainWindow.actionClearLog)
			afe77xxiGui.mainWindow.addAction(a)
			afe77xxiGui.show()
			
		elif boardType in ("HSC1373",):
			guiCache0 = guiParams()
			guiCache1 = guiParams()
			
			afeiGuiController = afeGuiControllerClass(AFE0,gpioConstants) 
			gpioGenericSeliGuiClass = genericSelection(libInstance=AFE0,guiControllerInstance=afeiGuiController)
			gpioStatusiGuiClass =gpioMap(libInstance=AFE0,guiControllerInstance=afeiGuiController)
			afeiGuiController.gpioStatusiGuiClass = gpioStatusiGuiClass
			afeiGuiController.gpioGenericSeliGuiClass = gpioGenericSeliGuiClass
			
			systemParamClassiGui0 = afe77xxSystemParamsiGui(libInstance=AFE0, cache=guiCache0, gpio=cpld)
			systemParamClassiGui1 = afe77xxSystemParamsiGui(libInstance=AFE1, cache=guiCache1, gpio=cpld)
			additionalConfig0 = afe77xxAdditionalConfig(libInstance=AFE0, cache = guiCache0)
			additionalConfig1 = afe77xxAdditionalConfig(libInstance=AFE1, cache = guiCache1)
			customConfig0=afe77xxCustomConfig(libInstance=AFE0, cache=guiCache0)
			customConfig1=afe77xxCustomConfig(libInstance=AFE1, cache=guiCache1)
			statusRegisters0=afe77xxSystemStatusRegs(libInstance=AFE0)
			statusRegisters1=afe77xxSystemStatusRegs(libInstance=AFE1)
			powerMeasurements = afe77xxCurrentSense(cache=guiCache0)
			gpioInternal = afe77xxGpioInternalAgc(libInstance=AFE0,gpio=cpld)
			gpioExternal = afe77xxGpioExternalAgc(libInstance=AFE0,gpio=cpld)
			gpioStatusiGuiClass =gpioMap(fileName = r"PATH_TO_SVG_FILE",libInstance=AFE0,guiControllerInstance=afeiGuiController)
			gpioGroupSelection = gpioTop(libInstance=AFE0,guiControllerInstance=afeiGuiController)
			afe77xxiGui= iGui(fileName = Globals.libFolderPath+"//resourceFiles//"+r"\\afeiGui\iGuiTree.iml")
			afeiGuiController.guiInstance = afe77xxiGui
	

	
	except:
		error("Couldn't load iGui")
###########


if boardType in ("BENCH",):
	mainWindow.restoreSession(PROJECTS_DIR+r"\AFE77xx\bringup\customGui.astx")
elif boardType in ("EVM-1DeviceJ58","EVM-1Device"):
	mainWindow.restoreSession(PROJECTS_DIR+r"\AFE77xx\bringup\customGui1XEvm.astx")
else:
	mainWindow.restoreSession(PROJECTS_DIR+r"\AFE77xx\bringup\customGuiEvm.astx")

Connect(process.fftImdParams._fin1,sigSource00._frequency,1,1)
engine.sampleNo=32768
process.complexfftParam.ignoreImdBinsForSnr=1
process.complexfftParam.finSkipBins=200

process.complexfftParam.ignoreBinsAroundFin1AndFin2ForSnr=1
process.complexfftParam.ignoreImdBinsForSnr=1
process.complexfftParam.finSkipBins=200
process.complexfftParam.ignoreFinImage=1
process.complexfftPlot.harmonicsNo=1

info(gc.collect())
device.rawWriteLogsFile=ASTERIX_DIR+DEVICES_DIR+r"\test.txt"#"D:\AFE77xx_config/testBroadcast.txt"
#myfpga.rawWriteLogsFile=device.rawWriteLogsFile
#lmk.rawWriteLogsFile=device.rawWriteLogsFile
