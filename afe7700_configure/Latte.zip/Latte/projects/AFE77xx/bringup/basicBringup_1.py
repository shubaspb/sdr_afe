setupParams.selectedDut=1
if boardType in ("EVM","HSC1373"):
	if setupParams.selectedDut==1:
		AFE=AFE1
		device=device1
		logDumpInst=logDumpInst1
	else:
		AFE=AFE0
		device=device0
		logDumpInst=logDumpInst0
else:
	setupParams.selectedDut=0
	
sysParams=AFE.systemParams
device.hardReadAlways=False
##### System Parameters
sysParams.FRef                    = 491.52#368.64#
sysParams.Fs                      = 2949.12#56*61.44#3440.64#
sysParams.pllMuxModes			= 0	
										#0: 4T4R Mode with PLL0 as Master. PLL 0 for all the LOs.
										#1: 4T4R Mode with PLL2 as Master. PLL 2 for all the LOs.
										#2: 4T4R FDD Mode. PLL0 for TX and PLL2 for RX.
										#3: 2*2T2R FDD Mode: PLL0 AB-TX;PLL3 AB-RX; PLL2 CD TX; PLL4 CD RX
										#4: 2T2R FDD - TDD Mode: PLL0 AB-TX; PLL3-AB-RX; PLL2 CD
sysParams.useSpiSysref			= True#False#
# LO Settings
sysParams.pllLo					= [3500.01,sysParams.Fs,3501.06,1800.24,3400.0]	#PLL Frequencies for PLLs [0,1,2,3,4]#4899.9825
sysParams.jesdLoopbackEn			= 0		#Make it 1 to Enable the JESDTX to JESDRX internal loopback

## In below parameters, first in the array is for first 2T2R1F and second 2T2R1F.
# JESD and Serdes Parameters
sysParams.LMFSHdRx                = ["24410","24410"] 
sysParams.LMFSHdFb                = ["22420","22420"]
sysParams.LMFSHdTx                = ["44210","44210"]#["24410","24410"]
sysParams.systemMode              = [1,1]					# 0-Identical, 1-FDD, 2-TDD
sysParams.dedicatedLaneMode       = [0,0]
sysParams.jesdProtocol            = 0#1#0				# -0:B; 1:H; 2:C
sysParams.serdesFirmware			 =""#r"\\Mac\Home\Documents\Texas Instruments\Latte\lib\Afe77xxLibrary\resourceFiles\with_rom.fw.d04a4d.bin"False#True#""					# If you want to lead any firmware, please speify the path here. Otherwise it will not write any firmware
sysParams.jesdTxLaneMux			= [0,1,2,3,4,5,6,7]	# Enter which lanes you want in each location. 
															# Note that across 2T Mux is not possible in 0.5.
															# For example, if you want to exchange the first two lines of each 2T, this should be [1,0,2,3,5,4,6,7]
sysParams.jesdRxLaneMux			= [0,1,2,3,4,5,6,7]	# Enter which lanes you want in each location.
															# Note that across 2R Mux is not possible in 0.5.
															# For example, if you want to exchange the first two lines of each 2R, this should be [1,0,2,3,5,4,6,7]
sysParams.jesdRxRbd				= [15, 15]
sysParams.jesdScr				= [True,True]		# Does the Same config for JESD TX and RX

sysParams.lowIfNcoRx			=	[0,0]
sysParams.lowIfNcoTx			=	[0,0]
sysParams.lowIfNcoFb			=	[0,0]

# Decimation and interpolation Parameters
sysParams.ddcFactorRx				= [8, 8]#[14, 14]#
sysParams.ddcFactorFb				= [4, 4]#[7, 7]#
sysParams.fbNco						= [3500.01,3500.01]#[4899.9825, 4899.9825]
sysParams.ducFactorTx				= [4, 4]#[14, 14]#[28./3,28./3]#[7, 7]#
sysParams.setTxLoFbNcoFreqForTxCalib	= True#False#		# Note that if this is True, the fbNcoValues entered above will be overwritten and fbNCO and LO values will be chosen to the closest supported values.
sysParams.txIqMcCalibMode=0		# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
sysParams.customerConfig			= False#True

LMKParams.pllEn			=	False#True#					# If this is True, it takes the onboard oscillator as input to PLL and all clocks are generated from it. If it is False, it takes the external clock input of frequency - lmkParams.inputClk and generates the required clocks through dividers (No LMK PLL will be used).
LMKParams.lmkFrefClk	=	False#True
LMKParams.inputClk		=	1474.56#1290.24#
LMKParams.sysrefFreq	=	2949.12/1536.0
sysParams.bitFileType=0			#0-Regular. 1- Same clock rate to FPGA 2 inputs. 2-8-Lane codes

if simulationMode==False:
	setupParams.skipFpga=0
	setupParams.skipLmk=0
AFE.skipRxConfig=0
AFE.skipFbConfig=0
AFE.skipTxConfig=0
AFE.skipAgc=0

sysParams.enableRxDsaFactoryCal 		= False
sysParams.enableTxDsaFactoryCal 		= False
sysParams.enableTxIqmcLolTrackingCorr = False
sysParams.enableRxIqmcLolTrackingCorr = True

logDumpInst.setFileName(ASTERIX_DIR+DEVICES_DIR+r"\config.txt")
logDumpInst.logFormat=0x07
logDumpInst.rewriteFile=1
logDumpInst.rewriteFileFormat4=1

device.optimizeWrites=0
device.rawWriteLogEn=1
device.rewriteFile=1
device.rawWriteLogsFile=ASTERIX_DIR+DEVICES_DIR+r"\test.txt"#"D:\AFE77xx_config/testBroadcast.txt"
myfpga.rawWriteLogEn=0
lmk.rawWriteLogEn=0
myfpga.rawWriteLogsFile=device.rawWriteLogsFile
lmk.rawWriteLogsFile=device.rawWriteLogsFile


# AFE.initializeConfig()
AFE.deviceBringup()

device.rawWriteLogEn=1
myfpga.rawWriteLogEn=0
lmk.rawWriteLogEn=0

engine.sampleNo=32768