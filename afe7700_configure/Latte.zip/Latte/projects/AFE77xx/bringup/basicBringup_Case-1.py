'''
Latte Version: 2.13

Case			RX					TX						   FB						CLK					Notes
----	-----------------	  -----------------			-----------------			-----------			------------
1		245.76Msps, 24410     491.52Msps, 44210			491.52Msps, 22210			FS=2949.12M 
		SerDes=9830.4Mbps     SerDes=9830.4Mbps			SerDes=9830.4Mbps			REF=491.52M
		PLL0, LO=3500M		  PLL0, LO=3500M			NCO=3500M
		
2		245.76Msps, 24410     245.76Msps, 24410			245.76Msps, 12410			FS=2949.12M 
		SerDes=9830.4Mbps     SerDes=9830.4Mbps			SerDes=9830.4Mbps			REF=491.52M
		PLL0, LO=3500M		  PLL0, LO=3500M			NCO=3500M

3		245.76Msps, 24410     737.28Msps, 44210			737.28Msps, 22210			FS=2949.12M 		For HSDC RX ADC Capture, run "lmk.writeReg(256,0xc)" in Cmd Line
		SerDes=9830.4Mbps     SerDes=14745.6Mbps		SerDes=14745.6Mbps			REF=491.52M			For HSDC FB ADC Capture & DAC Send, run "lmk.writeReg(256,0x8)" in Cmd Line
		PLL0, LO=3500M		  PLL0, LO=3500M			NCO=3500M

4		245.76Msps, 24410     491.52Msps, 44210			491.52Msps, 22210			FS=3317.76M 		
		SerDes=9830.4Mbps     SerDes=9830.4Mbps			SerDes=9830.4Mbps			REF=491.52M			
		PLL0, LO=2600M		  PLL0, LO=2600M			NCO=2600M
'''
setupParams.selectedDut=1
if boardType in ("EVM","HSC1373"):
	if setupParams.selectedDut==1:
		AFE=AFE1
		device=device1
		logDumpInst=logDumpInst1
	else:
		AFE=AFE0
		device=device0
		logDumpInst=logDumpInst0
else:
	setupParams.selectedDut=0
	
sysParams=AFE.systemParams
device.hardReadAlways=False
##### PLL & LO
sysParams.FRef                    = 491.52
sysParams.Fs                      = 2949.12
sysParams.pllMuxModes			= 0	
										#0: 4T4R Mode with PLL0 as Master. PLL 0 for all the LOs.
										#1: 4T4R Mode with PLL2 as Master. PLL 2 for all the LOs.
										#2: 4T4R FDD Mode. PLL0 for TX and PLL2 for RX.
										#3: 2*2T2R FDD Mode: PLL0 AB-TX;PLL3 AB-RX; PLL2 CD TX; PLL4 CD RX
										#4: 2T2R FDD - TDD Mode: PLL0 AB-TX; PLL3-AB-RX; PLL2 CD
sysParams.pllLo					= [1030.01,sysParams.Fs,1031.06,1030.24,1030.0]	#PLL Frequencies for PLLs [0,1,2,3,4]
sysParams.setTxLoFbNcoFreqForTxCalib	= True

## In below parameters, first in the array is for first 2T2R1F and second 2T2R1F.
# JESD and Serdes Parameters
sysParams.useSpiSysref			= False
sysParams.LMFSHdRx              = ["24410","24410"] 
sysParams.LMFSHdFb              = ["22210","22210"]
sysParams.LMFSHdTx              = ["44210","44210"]
sysParams.systemMode            = [1,1]					# 0-Identical, 1-FDD, 2-TDD
sysParams.dedicatedLaneMode     = [1,1]
sysParams.jesdProtocol          = 0#1#0				# -0:B; 1:H; 2:C
sysParams.serdesFirmware		= True
sysParams.jesdTxLaneMux			= [0,1,4,5,2,3,6,7]	# RX1,RX2,RX3,RX4,FB1,FB2
sysParams.jesdRxLaneMux			= [0,1,2,3,4,5,6,7]	
sysParams.jesdRxRbd				= [15, 15]
sysParams.jesdScr				= [True,True]		
sysParams.serdesTxLanePolarity	= [False,False,False,False,True,True,True,True] 
sysParams.serdesRxLanePolarity	= [False,False,False,False,True,True,True,True] 
sysParams.jesdK					= [16,16] 
sysParams.syncLoopBack			= True
sysParams.jesdLoopbackEn		= 0
sysParams.jesdTxRxABSyncMux		= 0 
sysParams.jesdTxRxCDSyncMux		= 0 
sysParams.jesdTxFBABSyncMux		= 0 
sysParams.jesdTxFBCDSyncMux		= 0 
sysParams.jesdRxABSyncMux		= 0 
sysParams.jesdRxCDSyncMux		= 0 
sysParams.jesdABLvdsSync		= 1
sysParams.jesdCDLvdsSync		= 1

# Decimation and interpolation Parameters
sysParams.ddcFactorRx			= [12,12]
sysParams.ddcFactorFb			= [6,6]
sysParams.ducFactorTx			= [6,6]

sysParams.fbNco					= [1030.01,1030.01]
sysParams.lowIfNcoRx			= [0,0]
sysParams.lowIfNcoTx			= [0,0]
sysParams.lowIfNcoFb			= [0,0]

LMKParams.pllEn			=	True
LMKParams.lmkFrefClk	=	True
#LMKParams.inputClk		=	1474.56
LMKParams.sysrefFreq	=	7.68

if simulationMode==False:
	setupParams.skipFpga=1
	setupParams.skipLmk=0
AFE.skipRxConfig=0
AFE.skipFbConfig=0
AFE.skipTxConfig=0
AFE.skipAgc=0

sysParams.gpioConfigMode=1

'''
#PAP Config
sysParams.txDsaUpdateMode=1
for i in range(4):
	sysParams.srConfigParams[i]['GainStepSize']=38
	sysParams.srConfigParams[i]['AttnStepSize']=38
	sysParams.srConfigParams[i]['AmplUpdateCycles']=6
	sysParams.srConfigParams[i]['threshold']=30
	sysParams.srConfigParams[i]['enable']=True
	sysParams.srConfigParams[i]['mode']=10

#Ext AGC Config
for i in range(4):
	sysParams.agcRegConfigParams[i]['enableIa']=0
	sysParams.agcRegConfigParams[i]['phmOvrEn']=1
	sysParams.agcRegConfigParams[i]['enableSa']=0
	sysParams.agcRegConfigParams[i]['enableSd']=0
	sysParams.agcRegConfigParams[i]['enableBa']=1
	sysParams.agcRegConfigParams[i]['gainControl']=4
	sysParams.agcRegConfigParams[i]['fdsaOffset']=6
	
#INT Pins
sysParams.intPinsParams[0]['JESD']=True
sysParams.intPinsParams[0]['SPI']=True
sysParams.intPinsParams[0]['SRTXA']=True
sysParams.intPinsParams[0]['SRTXB']=True
sysParams.intPinsParams[0]['SRTXC']=True
sysParams.intPinsParams[0]['SRTXD']=True
sysParams.intPinsParams[0]['PLL0']=True
sysParams.intPinsParams[0]['PLL1']=True
sysParams.intPinsParams[0]['PLL2']=True
sysParams.intPinsParams[0]['PLL3']=True
sysParams.intPinsParams[0]['PLL4']=True
'''

#Calibrations
sysParams.enableRxDsaFactoryCal 	  = False
sysParams.enableTxDsaFactoryCal 	  = False
sysParams.enableTxIqmcLolTrackingCorr = True
sysParams.enableRxIqmcLolTrackingCorr = True
sysParams.txIqMcCalibMode			  = 0		# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
sysParams.txDsaCalibMode			  = 0
sysParams.rxDsaCalibMode			  = 0

logDumpInst.setFileName(ASTERIX_DIR+DEVICES_DIR+r"\config.txt")
logDumpInst.logFormat=0x4
logDumpInst.rewriteFile=1
logDumpInst.rewriteFileFormat4=1

device.optimizeWrites=0
device.rawWriteLogEn=1
device.rewriteFile=1
device.rawWriteLogsFile=ASTERIX_DIR+DEVICES_DIR+r"\test.txt"#"D:\AFE77xx_config/testBroadcast.txt"
lmk.rawWriteLogEn=1
lmk.rawWriteLogsFile=device.rawWriteLogsFile

# AFE.initializeConfig()
AFE.deviceBringup()

device.rawWriteLogEn=1
lmk.rawWriteLogEn=1

engine.sampleNo=32768

AFE.TOP.overrideTdd(1, 1, 1)