


U32 getJesdRxLaneErrors(int fd, U32 ulLaneno){
	int ulRegValue,a;
	const char *laneErrorBits[8];
	if ((ulLaneno&0x4)==0){
		AFE77xx_RegWrite(fd,0x0015,0x02);
	}
	else
	{
		AFE77xx_RegWrite(fd,0x0015,0x20);
	}
	AFE77xx_RegRead(fd,0x164+(ulLaneno&0x3),&ulRegValue);
	AFE77xx_RegWrite(fd,0x0015,0x00);
	laneErrorBits[7] = "multiframe alignment error";
	laneErrorBits[6] = "frame alignment error";
	laneErrorBits[5] = "link configuration error";
	laneErrorBits[4] = "elastic buffer overflow (bad RBD value)";
	laneErrorBits[3] = "elastic buffer match error. The first no-/K/ does not match 'match_ctrl' and 'match_data' programmed values";
	laneErrorBits[2] = "code synchronization error";
	laneErrorBits[1] = "JESD 204B: 8b/10b not-in-table code error. JESD 204C: sync_header_invalid_err";
	laneErrorBits[0] = "JESD 204B: 8b/10b disparty error. JESD 204C: sync_header_parity_err";
		for( a = 0; a < 8; a = a + 1 ){
			if (((ulRegValue>>a)&1)==1){
				printf("JESD RX Lane Error for lane %d seen: %s\n", ulLaneno,laneErrorBits[a]);
			}
		}
	return 0;
}


U32 getJesdRxLaneFifoErrors(int fd, U32 ulLaneno){
	int ulRegValue,a;
	const char *fifoErrorBits[4];
	if ((ulLaneno&0x4)==0){
		AFE77xx_RegWrite(fd,0x0015,0x02);
	}
	else
	{
		AFE77xx_RegWrite(fd,0x0015,0x20);
	}
	AFE77xx_RegRead(fd,0x162+((ulLaneno&3)>>1),&ulRegValue);
	AFE77xx_RegWrite(fd,0x0015,0x00);
	ulRegValue=(ulRegValue>>(4*(ulLaneno&1)));
	ulRegValue=ulRegValue&0xf;
	fifoErrorBits[3] = "write_error : High if write request and FIFO is full (NOTE: only released when JESD block is initialized with init_state)";
	fifoErrorBits[2] = "write_full : FIFO is FULL";
	fifoErrorBits[1] = "read_error : High if read request with empty FIFO (NOTE: only released when JESD block is initialized with init_state)";
	fifoErrorBits[0] = "read_empty : FIFO is empty";
	for( a = 0; a < 4; a = a + 1 ){
		if (((ulRegValue>>a)&1)==1){
			printf("JESD RX Lane Fifo Error for lane %d seen: %s\n", ulLaneno,fifoErrorBits[a]);
		}
	}
	return 0;
}



U32 getJesdRxMiscSerdesErrors(int fd, U32 jesdNo){
	/* jesdNo is 0 for top 4 lanes and 1 for bottom 4 lanes */
	int ulRegValue,a,ulLaneno,ulErrorValue;
	const char *serdesErrorBits[2],*miscErrorBits[4];
	if (jesdNo==0){
		AFE77xx_RegWrite(fd,0x0015,0x02);
	}
	else
	{
		AFE77xx_RegWrite(fd,0x0015,0x20);
	}
	miscErrorBits[0]="JESD sysref error";
	miscErrorBits[1]="JESD shorttest alarm";
	miscErrorBits[2]="NA";
	miscErrorBits[3]="SERDES PLL loss of lock";
	AFE77xx_RegRead(fd,0x160,&ulRegValue);
		for( a = 0; a < 4; a = a + 1 ){
			if (((ulRegValue>>a)&1)==1){
				printf("JESD RX Serdes Error seen: %s\n",miscErrorBits[a]);
			}
		}
	AFE77xx_RegRead(fd,0x161,&ulRegValue);
	AFE77xx_RegWrite(fd,0x0015,0x00);
	
	serdesErrorBits[1] = "read_error : High if read request with empty FIFO (NOTE: only released when JESD block is initialized with init_state)";
	serdesErrorBits[0] = "read_empty : FIFO is empty";
		for (ulLaneno=0;ulLaneno<4;ulLaneno=ulLaneno+1){
		ulErrorValue=((ulRegValue>>(ulLaneno*2))&3);
			for( a = 0; a < 2; a = a + 1 ){
				if (((ulErrorValue>>a)&1)==1){
					printf("JESD RX Lane Serdes Error for lane %d seen: %s\n", ulLaneno+(jesdNo<<1),serdesErrorBits[a]);
				}
			}
		}
	return 0;
}




U32 getJesdRxAlarms(int fd){
	U32 ulLaneno;
	for (ulLaneno=0;ulLaneno<8;ulLaneno=ulLaneno+1){
		getJesdRxLaneErrors(fd,ulLaneno);
		getJesdRxLaneFifoErrors(fd,ulLaneno);
	}
	for (ulLaneno=0;ulLaneno<2;ulLaneno=ulLaneno+1){
		getJesdRxMiscSerdesErrors(fd,ulLaneno);
	}
}



U32 getJesdRxLinkStatus(int fd){
	#/* Reads the lane enables and accordingly returns the status of the link
	#Return Value is 4 bits. 2 bits for top 4 lanes and 2 bits for bottom 4 lanes.
	#=0 Idle state. No change in state.
	#=1 CGS Passed. Still in K characters mode.
	#=2 Link is up.
	#*/
	int laneEna0,laneEna1;
	int csState0,csState1;
	int expectedCsState0,expectedCsState1;
	int expectedFsState0,expectedFsState1;
	int fsState0,fsState1;
	int linkStatus0,linkStatus1;
	AFE77xx_RegWrite(fd,0x0015,0x02);
	AFE77xx_RegRead(fd,0x7c,&laneEna0);
	AFE77xx_RegRead(fd,0x12a,&csState0);
	AFE77xx_RegRead(fd,0x12c,&fsState0);
	AFE77xx_RegWrite(fd,0x0015,0x00);
	expectedCsState0=0;
	expectedFsState0=0;
	for (i=0;i<4;i++){
		if (((laneEna0>>i)&1)!=0){
			expectedCsState0=expectedCsState0+(2<<(i<<1));
			expectedFsState0=expectedFsState0+(1<<(i<<1));
		}
	}
	if (expectedCsState0==csState0){
		if (expectedFsState0==fsState0){
			linkStatus0=2;
		}
		else{
			linkStatus0=1;
		}
	}
	else{
		linkStatus0=0;
	}

	AFE77xx_RegWrite(fd,0x0015,0x20);
	AFE77xx_RegRead(fd,0x7c,&laneEna1);
	AFE77xx_RegRead(fd,0x12a,&csState1);
	AFE77xx_RegRead(fd,0x12c,&fsState1);
	AFE77xx_RegWrite(fd,0x0015,0x00);
	expectedCsState1=0;
	
	
	expectedFsState1=0;
	for (i=0;i<4;i++){
		if (((laneEna1>>i)&1)!=0){
			expectedCsState1=expectedCsState1+(2<<(i<<1));
			expectedFsState1=expectedFsState1+(1<<(i<<1));
		}
	}
	if (expectedCsState1==csState1){
		if (expectedFsState1==fsState1){
			linkStatus1=2;
		}
		else{
			linkStatus1=1;
		}
	}
	else{
		linkStatus1=0;
	}
	return ((linkStatus1<<2)+linkStatus0);
}


U32 getJesdTxFifoErrors(int fd, U32 jesdNo){
	U32 ulLaneno;
	U32 ulRegValue=0;
	if (jesdNo==0){
		AFE77xx_RegWrite(fd,0x0015,0x01);
	}
	else
	{
		AFE77xx_RegWrite(fd,0x0015,0x10);
	}
	AFE77xx_RegRead(fd,0x005e,&ulRegValue);
	for (ulLaneno=0;ulLaneno<4;ulLaneno=ulLaneno+1){
		if (((ulRegValue>>ulLaneno)&1)==1){
			printf("JESD TX Lane Serdes FIFO Error for lane %d.\n", ulLaneno);
		}
	}
	AFE77xx_RegWrite(fd,0x0015,0x00);
}

U32 jesdTxSetSyncOverride(int fd, int override, int sendData){
	#/* overrideWhen override is 1, the sync pin will be overridden.
	#In this case, if sendData is 0, K28.5 characters will be sent by ASIC on the lanes, else data will be sent.
	#*/
	AFE77xx_RegWrite(fd,0x0015,0x11);
	if (override==1 && sendData==1){
		AFE77xx_RegWrite(fd,0x0072,0xFF);
	}
	else if (override==1 && sendData==0){
		AFE77xx_RegWrite(fd,0x0072,0xF0);
	}
	else{
		AFE77xx_RegWrite(fd,0x0072,0x00);
	}
	AFE77xx_RegWrite(fd,0x0015,0x00);
	return 0;
}












