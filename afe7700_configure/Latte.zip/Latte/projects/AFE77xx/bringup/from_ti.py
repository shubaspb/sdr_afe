
#please do the following writes in latte and let us know what you see in log

log("fan1 ="+str(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG312._f_counter_any_lane_ready.getValue()))

log("fal1 ="+str(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG312._f_counter_all_lanes_ready.getValue()))

fal1=device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG312._f_counter_all_lanes_ready.getValue()

log("fan2 ="+str(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG312._f_counter_any_lane_ready.getValue()))

log("fal2 ="+str(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG312._f_counter_all_lanes_ready.getValue()))

log("laneSkw0="+str(device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG306._lane_skew_tx0.getValue()))

log("laneSkw1="+str(device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG306._lane_skew_tx0.getValue()))

#test1:

#Please do the following writes

rbd=(fal1+12)%32

device.JESD.DAC_RX[1].DAC_RX.TXDUC_REG126.rbd_m1=rbd

device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG126.rbd_m1=rbd

#send k28.5 and then ILAs and check for link
