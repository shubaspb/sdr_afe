from mDevice import *

class HSCDevice(Device):
	ADCRes = Object(typ=Integer,label="ADC Resolution",default=13)
	offset = Object(typ=Integer,label="Offset Bits")
	avdd = Object(typ=Voltage,label="AVDD Supply Voltage")