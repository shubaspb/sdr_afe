from mInstrument import *
from mInstrumentController import USBController
from HSCProgrammer import QPortController,QPort
import globalDefs as Globals
	
class USBQPortController(QPortController):
	def __init__(self,parent,addr=0):
		#To make it compatible with hobbes interface. All QPorts have description of the format: "QPort x" where x is the "address" of the QPort.
		usbDescription= str(addr)
		# super(USBQPortController,self).__init__(parent,usbDescription)
		USBController.__init__(self,parent,usbDescription)
		self.instrument.setUSBParameters(65536, 65536)
		self.instrument.setChars('a', 0, 'a', 0)
		self.instrument.setTimeouts(2000, 2000) 
		self.instrument.setLatencyTimer(16)	
		Globals.delay(1)
		self.reset(init=True)
			
	
class USBQPort(QPort):
	controller=USBQPortController

class I2CQportController(QPortController):
	def __init__(self, parent, addr, CLK_pin, SDAI_pin, SDAO_pin):
		usbDescription = str(addr)
		USBController.__init__(self,parent,usbDescription)
		self.instrument.setUSBParameters(65536,65536)
		self.instrument.setChars('a',0,'a',0)
		self.instrument.setTimeouts(2000,2000)
		self.instrument.setLatencyTimer(16)
		Globals.delay(1)
		self.reset(init=True)
		self.CLK_pin = CLK_pin
		self.SDAI_pin = SDAI_pin
		self.SDAO_pin = SDAO_pin
		
class i2cPort(QPort):
	controller=I2CQportController
	pattern = ''
	
	def i2c_start(self):
		data_series = [1,0,0]
		clk_series = [1,1,0]
		self.pattern = ''
		for data,clk in zip(data_series, clk_series):
			self.pattern = self.pattern + chr((clk<<self._controller.CLK_pin) + (data<<self._controller.SDAO_pin))
		return 1
		
	def i2c_stop(self):
		data_series = [0,0,1]
		clk_series = [0,1,1]
		for data,clk in zip(data_series, clk_series):
			self.pattern = self.pattern + chr((clk<<self._controller.CLK_pin) + (data<<self._controller.SDAO_pin))
		return 1
		
	def i2c_write_8b(self,packet):
		clk_series = []
		data_series = []
		for item in packet:
			clk_series.append(0)
			data_series.append(item)
			clk_series.append(1)
			data_series.append(item)
			clk_series.append(1)
			data_series.append(item)
			clk_series.append(0)
			data_series.append(item)
		for data,clk in zip(data_series, clk_series):
			self.pattern = self.pattern + chr((clk<<self._controller.CLK_pin) + (data<<self._controller.SDAO_pin))
		return 1
		
	def i2c_ack(self):
		clk_series = [0,1,1,0]
		data_series = [0,0,0,0]
		for data,clk in zip(data_series, clk_series):
			self.pattern = self.pattern + chr((clk<<self._controller.CLK_pin) + (data<<self._controller.SDAO_pin))
		return 1
		
	def formatData(self,data):
		data = data&0xFF
		arr = []
		for bit in range(8):
			extractedBit = (data&(2**bit))>>bit
			arr.append(extractedBit)
		return arr[::-1]
		
	def formatAddr(self,addr,R_nW):
		addr = ((addr&0x7F)<<1) + R_nW
		return self.formatData(addr)
		
	def writeReg(self, slave_addr, *data):
		self.pattern = ''
		self.i2c_start()
		self.i2c_write_8b(self.formatAddr(slave_addr,0))
		self.i2c_ack()
		if data:
			for d in data:
				self.i2c_write_8b(self.formatData(d))
				self.i2c_ack()
		self.i2c_stop()
		self._controller.instrument.write(self.pattern)
		self.pattern = ''
		return 1
		
	def readReg(self, slave_addr, bits_to_read):
		if bits_to_read%8 != 0:
			critical("bits to read should be a multiple of 8")
		self.pattern = ''
		self.i2c_start()
		self.i2c_write_8b(self.formatAddr(slave_addr,1))
		self.i2c_ack()
		for i in range(bits_to_read/8):
			d = 0xff
			self.i2c_write_8b(self.formatData(d))
			self.i2c_ack()
		self.i2c_stop()
		self._controller.instrument.purge()
		readSize = self._controller.instrument.write(self.pattern)
		data = self._controller.instrument.read(readSize)
		count = 0
		clk_string = ''
		data_string = ''
		data_final = 0
		arr = []
		neglectArr = [0,1,2,3,4,5,6]
		for i in range((bits_to_read/8)-1):
			neglectArr = neglectArr + [neglectArr[-1]+32, neglectArr[-1]+33, neglectArr[-1]+34, neglectArr[-1]+35]
		for byte in data[::-1]:
			count = count + 1
			if count in neglectArr:
				pass
			elif count<(6+32*(bits_to_read/8)):
				if ((count-8)%4)==0:
					data_byte = ord(byte)
					data_retrieved = (data_byte&0x80)>>7
					arr.append(data_retrieved)
		for item in arr[::-1]:
			data_final = (data_final<<1) + item
		return data_final