from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class topAnaControlLib(projectBaseClass):
	"""Contains TOP Analog specific functions. self.regs=device.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		#self.fieldNameToRegisterList={}
		#for register in self.regs.entities.keys():
		#	for field in self.regs.entities[register].stateVariables.keys():
		#		if field in self.fieldNameToRegisterList:
		#			error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
		#		else:
		#			self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
		
		#__init__
		
		
		
	@funcDecorator
	def randomFunc(self):
		"""randomFunc() -> (sum of 2 random integers)
			Sample Function"""
		print "\n\t\t"
		print "\t\t In RandomFunc in DDC of: In Top " + str(self.topno) + "  In ChNo: " + str(self.chno)
		a=random.randint(0,10)
		b=random.randint(0,10)
		info("\t\t a is :" + str(a))
		info("\t\t b is :" + str(b))
		#print self.muladd(a,b)
		print "\t\t randomtest in DDC End########################################"
		return(a+b)
		#randomFunc
		
		
		#ddcLib
