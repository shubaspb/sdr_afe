import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

from mFuncDecorator import *
from common.mDeviceConstants import *
from mTxTopConst import *
from common.mMemConst import *

import random
from globalDefs import *
import math
class TxIqmcEstim(projectBaseClass):
	"""Contains TXIQMC Estim specific functions self.regs=device.TX.TXIQMC.tx_iqmc"""
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.errorList=['','']
		#__init__
		
	@funcDecorator
	def enable_tx_iqmc(self):
		"""enable_tx_iqmc"""
		self.regs.Register38524_20h.Property_20h_0_0=1
		#enable_tx_iqmc
		
	@funcDecorator
	def disable_tx_iqmc(self):
		"""disable_tx_iqmc"""
		self.regs.Register38524_20h.Property_20h_0_0=0
		#enable_tx_iqmc
		
	@funcDecorator
	def start_tx_iqmc_estimation(self):
		"""start_tx_iqmc_estimation"""
		self.regs.Register38524_20h.Property_100h_0_0=1
		#start_tx_iqmc_estimation
		
	@funcDecorator
	def stop_tx_iqmc_estimation(self):
		"""stop_tx_iqmc_estimation"""
		self.regs.Register38524_20h.Property_100h_0_0=0
		#stop_tx_iqmc_estimation
		
	@funcDecorator
	def set_block_count_switch_value(self,val):
		"""set_block_count_switch_value"""
		self.regs.Register38524_20h.Property_2ch_31_16=val
		#set_block_count_switch_value
		
	@funcDecorator
	def set_block_length_fixed(self,val):
		"""set_block_length_fixed"""
		self.regs.Register38524_20h.Property_28h_15_0=val
		#set_block_length_fixed
		
	@funcDecorator
	def set_iqmc_estimation_length(self,val):
		"""set_iqmc_estimation_length"""
		self.regs.Register38524_20h.Property_38h_31_0=val
		#set_iqmc_estimation_length
		
	@funcDecorator
	def restart_tx_iqmc_estimation(self):
		"""restart_tx_iqmc_estimation"""
		info("//*** RESTARTING IQMC ESTIMATION")
		self.regs.Register38524_20h.Property_100h_0_0=0
		self.regs.Register38524_20h.Property_100h_0_0=1
		info ("iqmc_estimation_restart done")
		#restart_tx_iqmc_estimation
		
	@funcDecorator
	def check_estimation_done_status(self,flag=0,wait_for_estimation_done=0):
		"""check_estimation_done_status"""
		err_cnt=0
		status = self.regs.Register38631_4Bh.Property_4ch_0_0

		if (wait_for_estimation_done==1):
			while(status!=1):
				status = self.regs.Register38631_4Bh.Property_4ch_0_0

				info("//status="+str(status))
		if(flag==0):
			if(status):
				info("//PASS:Estimation is done")
			else:
				error("//FAIL:Estimation is NOT done")
				err_cnt=err_cnt+1
		else:
			if(status):
				error("//FAIL:Estimation is done")
				err_cnt=err_cnt+1
			else:
				info("//PASS:Estimation is NOT done")		
		self.regs.Register38631_4Bh.Property_48h_11_11 = 1
		self.regs.Register38631_4Bh.Property_48h_11_11 = 0
		status = self.regs.Register38631_4Bh.Property_4ch_0_0

		if(status==0):
			info("//PASS:Estimation is done")
		else:
			error("//FAIL:Estimation is NOT done")
			err_cnt=err_cnt+1
		info("////Disabling fw start for reading the aggregation memories")
		self.regs.Register38524_20h.Property_100h_0_0=0
		return(status,err_cnt)
		#check_estimation_done_status
		
	@funcDecorator
	def poll_estimation_done_status(self,count=5):
		"""poll_estimation_done_status"""
		for i in range(count):
			self.check_estimation_done_status()
			#poll_estimation_done_status
			
	@funcDecorator
	def enable_iqmc_estimation(self,ch):
		"""enable_iqmc_estimation"""
		if ch==0:
			self.regs.Register38524_20h.Property_20h_20_20=1
		if ch==1:
			self.regs.Register38524_20h.Property_20h_21_21=1
		if ch==2:
			self.regs.Register38524_20h.Property_20h_22_22=1
		if ch==3:
			self.regs.Register38524_20h.Property_20h_23_23=1
			#enable_iqmc_estimation
			
	@funcDecorator
	def disable_iqmc_estimation(self,ch):
		"""disable_iqmc_estimation"""
		if ch==0:
			self.regs.Register38524_20h.Property_20h_20_20=0
		if ch==1:
			self.regs.Register38524_20h.Property_20h_21_21=0
		if ch==2:
			self.regs.Register38524_20h.Property_20h_22_22=0
		if ch==3:
			self.regs.Register38524_20h.Property_20h_23_23=0
			#disable_iqmc_estimation
			
			
	@funcDecorator
	def enable_windowing(self,ch):
		"""enable_windowing"""
		if ch==0:
			self.regs.Register38574_31h.Property_30h_12_12=1
		if ch==1:
			self.regs.Register38574_31h.Property_30h_13_13=1
		if ch==2:
			self.regs.Register38574_31h.Property_30h_14_14=1
		if ch==3:
			self.regs.Register38574_31h.Property_30h_15_15=1
			#enable_windowing
			
	@funcDecorator
	def disable_windowing(self,ch):
		"""disable_windowing"""
		if ch==0:
			self.regs.Register38574_31h.Property_30h_12_12=0
		if ch==1:                                                           
			self.regs.Register38574_31h.Property_30h_13_13=0
		if ch==2:                                                           
			self.regs.Register38574_31h.Property_30h_14_14=0
		if ch==3:                                                           
			self.regs.Register38574_31h.Property_30h_15_15=0
			#disable_windowing
			
	@funcDecorator
	def configureAveragingWindow(self,ch,averagingOrWIndow):
		"""configureAveragingWindow"""
		if ch==0:
			self.regs.Register38574_31h.Property_30h_28_28=averagingOrWIndow
		if ch==1:                                                           
			self.regs.Register38574_31h.Property_30h_29_29=averagingOrWIndow
		if ch==2:                                                           
			self.regs.Register38574_31h.Property_30h_30_30=averagingOrWIndow
		if ch==3:                                                           
			self.regs.Register38574_31h.Property_30h_31_31=averagingOrWIndow
			#configureAveragingWindow
			
			
	@funcDecorator
	def selectFbTxPair(self,txCh,fbCh):
		"""selectFbTxPair"""
		if txCh==0:
			self.regs.Register38524_20h.Property_2ch_0_0=fbCh
		if txCh==1:                                                           
			self.regs.Register38524_20h.Property_2ch_1_1=fbCh
		if txCh==2:                                                           
			self.regs.Register38524_20h.Property_2ch_2_2=fbCh
		if txCh==3:                                                           
			self.regs.Register38524_20h.Property_2ch_3_3=fbCh
			#disable_windowing
			
	@funcDecorator
	def set_window_type_for_tx_and_fb(self,ch,win_type_tx,win_type_fb):
		"""set_window_type_for_tx_and_fb
			0: Black man Harris
			1: Hanning
			2: Decimated black man Harris
			3: Decimated Hanning
		"""
		if ch==0:
			self.regs.Register38574_31h.Property_30h_2_0=win_type_tx
			self.regs.Register38574_31h.Property_30h_18_16=win_type_fb
			
		if ch==1:                                                            
			self.regs.Register38574_31h.Property_30h_5_3=win_type_tx
			self.regs.Register38574_31h.Property_30h_21_19=win_type_fb
		if ch==2:                                                            
			self.regs.Register38574_31h.Property_30h_8_6=win_type_tx
			self.regs.Register38574_31h.Property_30h_24_22=win_type_fb
		if ch==3:                                                            
			self.regs.Register38574_31h.Property_30h_11_9=win_type_tx
			self.regs.Register38574_31h.Property_30h_27_25=win_type_fb
			#set_window_type_for_tx_and_fb
			
	@funcDecorator
	def txiqmc_estimation_init_sequence(self):
		"""txiqmc_estimation_init_sequence"""
		self.set_block_count_switch_value(10)
		self.set_block_length_fixed(2000)
		self.set_iqmc_estimation_length(10000)
		self.enable_windowing(0);
		self.enable_windowing(1);
		self.enable_windowing(2);
		self.enable_windowing(3);
		self.disable_windowing(0)
		self.disable_windowing(1)
		self.disable_windowing(2)
		self.disable_windowing(3)
		self.set_window_type_for_tx_and_fb(0, 0, 0);
		self.set_window_type_for_tx_and_fb(1, 0, 0);
		self.set_window_type_for_tx_and_fb(2, 0, 0);
		self.set_window_type_for_tx_and_fb(3, 0, 0);
		self.enable_tx_iqmc()
		self.enable_iqmc_estimation(0)
		#txiqmc_estimation_init_sequence
		
	@funcDecorator
	def setTxIqmcCommonConfig(self,txIqmcConfigSettings):
		"""setTxIqmcCommonConfig"""
		self.regs.Register38598_6Ah.Property_68h_0_0=txIqmcConfigSettings["EstClkDitherModeEn"]
		self.regs.Register38598_6Ah.Property_68h_2_1=txIqmcConfigSettings["EstClkDitherDivVal"]
		self.set_block_count_switch_value(txIqmcConfigSettings["blkSwitchCount"])
		self.setAggregatorMode(txIqmcConfigSettings["aggrMode"])
		if(txIqmcConfigSettings["blockLengthRandEn"]):
			self.enableBlockLengthRandom()
			self.setBlockLengthRandom(txIqmcConfigSettings["blockLenRand"])
		else:
			self.disableBlockLengthRandom()
		self.set_block_length_fixed(txIqmcConfigSettings["blockLength"])
		self.set_iqmc_estimation_length(txIqmcConfigSettings["estimLength"])
		self.enable_tx_iqmc()
		#setTxIqmcCommonConfig
		
	@funcDecorator
	def setTxIqmcPerChannelConfig(self,txch,txIqmcPerChannelSettings):
		"""setTxIqmcPerChannelConfig"""
		if(txIqmcPerChannelSettings["IqmcEstimEn"]):
			self.enable_iqmc_estimation(txch)
			if(txIqmcPerChannelSettings["windowingEn"]):
				self.enable_windowing(txch)
			else:
				self.disable_windowing(txch)
			self.set_window_type_for_tx_and_fb(txch,txIqmcPerChannelSettings["windowTypeTx"],txIqmcPerChannelSettings["windowTypeFb"])
			self.configureAveragingWindow(txch,txIqmcPerChannelSettings["averagingEn"])
		else:
			self.disable_iqmc_estimation(txch)
			#setTxIqmcPerChannelConfig
			
	@funcDecorator
	def setTxIqmcAllChannelConfig(self,txIqmcAllChannelSettings):
		"""setTxIqmcAllChannelConfig"""
		self.regs.Register38524_20h.Property_20h_16_16=txIqmcAllChannelSettings["SampleDropEnTxAB"]
		info("//SampleDropEnTxAB="+str(txIqmcAllChannelSettings["SampleDropEnTxAB"]))
		self.regs.Register38524_20h.Property_20h_17_17=txIqmcAllChannelSettings["SampleDropEnTxCD"]
		info("//SampleDropEnTxCD="+str(txIqmcAllChannelSettings["SampleDropEnTxCD"]))
		self.regs.Register38524_20h.Property_20h_18_18=txIqmcAllChannelSettings["SampleDropEnFbAB"]
		info("//SampleDropEnFbAB="+str(txIqmcAllChannelSettings["SampleDropEnFbAB"]))
		self.regs.Register38524_20h.Property_20h_19_19=txIqmcAllChannelSettings["SampleDropEnFbCD"]
		info("//SampleDropEnFbCD="+str(txIqmcAllChannelSettings["SampleDropEnFbCD"]))
		txIqmcPerChannelSettings={}
		for txch in range(4):
			txIqmcPerChannelSettings["txch"]				=txch
			txIqmcPerChannelSettings["IqmcEstimEn"]			=txIqmcAllChannelSettings["IqmcEstimEn"][txch]
			txIqmcPerChannelSettings["windowingEn"]			=txIqmcAllChannelSettings["windowingEn"][txch]
			txIqmcPerChannelSettings["windowTypeTx"]		=txIqmcAllChannelSettings["windowTypeTx"][txch]
			txIqmcPerChannelSettings["windowTypeFb"]		=txIqmcAllChannelSettings["windowTypeFb"][txch]
			txIqmcPerChannelSettings["averagingEn"]			=txIqmcAllChannelSettings["averagingEn"][txch]
			if(txIqmcPerChannelSettings["IqmcEstimEn"]):
				self.enable_iqmc_estimation(txch)
				if(txIqmcPerChannelSettings["windowingEn"]):
					self.enable_windowing(txch)
				else:
					self.disable_windowing(txch)
				self.set_window_type_for_tx_and_fb(txch,txIqmcPerChannelSettings["windowTypeTx"],txIqmcPerChannelSettings["windowTypeFb"])
				self.configureAveragingWindow(txch,txIqmcPerChannelSettings["averagingEn"])
			else:
				self.disable_iqmc_estimation(txch)
				#setTxIqmcAllChannelConfig
				
	def set_addr_read_data_shift_val(self,val):
		"""set_addr_read_data_shift_val"""
		self.regs.Register38631_4Bh.Property_48h_2_0=val
		#set_addr_read_data_shift_val
		
		
	def readAggregatorMemBytes(self,base_address,tx_index,bin_index,param_offset,noOfBytes,isReal):
		"""readAggregatorMemBytes"""
		byteArray = np.zeros(noOfBytes,dtype=np.long)
		if param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XMF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_XF_XMF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XSTARF_OFFSET:
			#info("//param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XMF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_XF_XMF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XSTARF_OFFSET")
			self.set_addr_read_data_shift_val(0)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[0]=self.readMem8(read_addr)
			read_addr=int(base_address + 1 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[1]=self.readMem8(read_addr)
			read_addr=int(base_address + 2 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[2]=self.readMem8(read_addr)
			read_addr=int(base_address + 3 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[3]=self.readMem8(read_addr)
			self.set_addr_read_data_shift_val(7)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[4]=self.readMem8(read_addr)
			
			self.set_addr_read_data_shift_val(0)
			read_addr=int(base_address + 4 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[5]=self.readMem8(read_addr)
			read_addr=int(base_address + 5 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[6]=self.readMem8(read_addr)
			read_addr=int(base_address + 6 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[7]=self.readMem8(read_addr)
			read_addr=int(base_address + 7 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[8]=self.readMem8(read_addr)
			self.set_addr_read_data_shift_val(7)
			read_addr=int(base_address + 4 + tx_index*1024*4 + bin_index*8 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[9]=self.readMem8(read_addr)
			
		if param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_YF_XSTARF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_XSTARF_XSTARMINUSF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_YFXMINUSF_OFFSET:
			#info("//param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_YF_XSTARF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_XSTARF_XSTARMINUSF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_YFXMINUSF_OFFSET")
			self.set_addr_read_data_shift_val(0)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[0]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			read_addr=int(base_address + 1 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[1]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			read_addr=int(base_address + 2 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[2]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			read_addr=int(base_address + 3 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[3]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			self.set_addr_read_data_shift_val(7)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[4]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			self.set_addr_read_data_shift_val(0)
			read_addr=int(base_address + 4 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[5]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			read_addr=int(base_address + 5 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[6]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			read_addr=int(base_address + 6 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[7]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			read_addr=int(base_address + 7 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[8]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			self.set_addr_read_data_shift_val(7)
			read_addr=int(base_address + 4 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[9]=self.readMem8(read_addr)
			#warning("//read_addr = "+str(hex(read_addr)))
			
		if param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_YSQUAREF_XSQUAREF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_YSQUAREF_XSQUAREF_OFFSET:
			#info("//param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_YSQUAREF_XSQUAREF_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_YSQUAREF_XSQUAREF_OFFSET")
			self.set_addr_read_data_shift_val(0)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[0]=self.readMem8(read_addr)
			read_addr=int(base_address + 1 + tx_index*1024*4 + bin_index*4 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[1]=self.readMem8(read_addr)
			read_addr=int(base_address + 2 + tx_index*1024*4 + bin_index*4 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[2]=self.readMem8(read_addr)
			read_addr=int(base_address + 3 + tx_index*1024*4 + bin_index*4 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[3]=self.readMem8(read_addr)
			self.set_addr_read_data_shift_val(7)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[4]=self.readMem8(read_addr)
			
			self.set_addr_read_data_shift_val(0)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset+256)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[5]=self.readMem8(read_addr)
			read_addr=int(base_address + 1 + tx_index*1024*4 + bin_index*4 + param_offset+256)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[6]=self.readMem8(read_addr)
			read_addr=int(base_address + 2 + tx_index*1024*4 + bin_index*4 + param_offset+256)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[7]=self.readMem8(read_addr)
			read_addr=int(base_address + 3 + tx_index*1024*4 + bin_index*4 + param_offset+256)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[8]=self.readMem8(read_addr)
			self.set_addr_read_data_shift_val(7)
			read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset+256)
			#warning("//read_addr = "+str(hex(read_addr)))
			byteArray[9]=self.readMem8(read_addr)
			
		if param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_MOD_XMINUSF_SQR_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_XMINUSSQUAREF_OFFSET :
			#info("//param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_MOD_XMINUSF_SQR_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_XMINUSSQUAREF_OFFSET")
			self.set_addr_read_data_shift_val(0)
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[0]=self.readMem8(int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset))
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[1]=self.readMem8(int(base_address + 1 + tx_index*1024*4 + bin_index*4 + param_offset))
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[2]=self.readMem8(int(base_address + 2 + tx_index*1024*4 + bin_index*4 + param_offset))
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[3]=self.readMem8(int(base_address + 3 + tx_index*1024*4 + bin_index*4 + param_offset))
			self.set_addr_read_data_shift_val(7)
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[4]=self.readMem8(int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset))
			
			
		if param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_NBINS_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_NBINS_OFFSET:
			#info("//param_offset==MemConst.TX_IQMC_AGGRAGATOR_MIS_NBINS_OFFSET or param_offset==MemConst.TX_IQMC_AGGRAGATOR_CHA_NBINS_OFFSET")
			self.set_addr_read_data_shift_val(0)
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[0]=self.readMem8(int(base_address + 0 + tx_index*1024*4 + bin_index*4 + param_offset))
			#read_addr=int(base_address + 0 + tx_index*1024*4 + bin_index*8 + param_offset)
			byteArray[1]=self.readMem8(int(base_address + 1 + tx_index*1024*4 + bin_index*4 + param_offset))
			
		info("//byteArray="+str(byteArray))
		
		(real_part,img_part)= self.getRealPartImgPart(byteArray,isReal)
		info("//real_part="+str(real_part))
		info("//img_part="+str(img_part))
		return(real_part,img_part)
		#readAggregatorMemBytes
		
	def getRealPartImgPart(self,byteArray,isReal):
		N=len(byteArray)
		real_part=long(0)
		img_part=long(0)
		if(isReal==0):
			Nmod=N/2
			for i in range(Nmod):
				#real_part = np.bitwise_or((byteArray[i+Nmod]<<(8*i)),real_part)
				#img_part  = np.bitwise_or((byteArray[i]<<(8*i)),img_part)
				real_part  = long(real_part+(2**(8*i))*byteArray[i+Nmod])
				img_part   = long(img_part+(2**(8*i))*byteArray[i])
		else:
			Nmod= N
			for i in range(Nmod):
				#real_part = np.bitwise_or((byteArray[i]<<(8*i)),real_part)
				real_part  = long(real_part+(2**(8*i))*byteArray[i])
			img_part  = 0
		return(real_part,img_part)
		
	def readYfXminusfMismatch(self, txCh, bin, scale_enable=0):
		""" Read Y(f)X(-f) """
		info("//readYfXminusfMismatch")
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XMF_OFFSET
		isReal=0
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XMF_NUM_BYTES,isReal)
		info ("real_part_before_bitwise_and_readYfXminusfMismatch="+str(real_part))
		info ("imag_part_before_bitwise_and_readYfXminusfMismatch="+str(img_part))
		#real_part = np.bitwise_and(real_part,0x3FFFFFFFFF)
		#img_part = np.bitwise_and(img_part,0x3FFFFFFFFF)
		real_part = (real_part&0x3FFFFFFFFF) 
		img_part  = (img_part &0x3FFFFFFFFF)
		info ("real_part_before_scale_enable_readYfXminusfMismatch="+str(real_part))
		info ("imag_part_before_scale_enable_readYfXminusfMismatch="+str(img_part))
		real_part=self.twos_comp(real_part,38)
		img_part=self.twos_comp(img_part,38)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(48.0)))
		powrDb_real = 5.0*np.log10(((float(real_part)**2.0))/(2.0**(48.0)))
		powrDb_img = 5.0*np.log10(((float(img_part)**2.0))/(2.0**(48.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		info ("real_part_after_scale_enable_readYfXminusfMismatch="+str(real_part))
		info ("imag_part_after_scale_enable_readYfXminusfMismatch="+str(img_part))
		return(real_part,img_part,powrDb,powrDb_real,powrDb_img)
		#readYfXminusfMismatch
		
	def readXfXminusfMismatch(self, txCh, bin,scale_enable=0):
		""" Read X(f)X(-f) """
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_MIS_XF_XMF_OFFSET
		isReal=0
		
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_MIS_XF_XMF_NUM_BYTES,isReal)
		#real_part = np.bitwise_and(real_part,0x3FFFFFFFFF)
		#img_part = np.bitwise_and(img_part,0x3FFFFFFFFF)
		real_part = (real_part&0x3FFFFFFFFF) 
		img_part  = (img_part &0x3FFFFFFFFF)
		real_part=self.twos_comp(real_part,38)
		img_part=self.twos_comp(img_part,38)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(48.0)))
		powrDb_real = 5.0*np.log10(((float(real_part)**2.0))/(2.0**(48.0)))
		powrDb_img = 5.0*np.log10(((float(img_part)**2.0))/(2.0**(48.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		return(real_part,img_part,powrDb,powrDb_real,powrDb_img)
		#readXfXminusfMismatch
		
	def readXminusfSquareMismatch(self, txCh, bin,scale_enable=0):
		""" Read |X(-f)|^2 """
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_MIS_MOD_XMINUSF_SQR_OFFSET
		isReal=1
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_MIS_MOD_XMINUSF_SQR_NUM_BYTES,isReal)
		real_part = (real_part&0x1FFFFFFFFF) 
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(48.0)))
		powrDb_real = 5.0*np.log10(((float(real_part)**2.0))/(2.0**(48.0)))
		powrDb_img = 5.0*np.log10(((float(img_part)**2.0))/(2.0**(48.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		return(real_part,img_part,powrDb)
		#readXminusfSquareMismatch
		
	def readYfSquareXfSquareMismatch(self, txCh, bin, scale_enable=0):
		""" Read |Y(f)|^2 |X(f)^2"""
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_MIS_YSQUAREF_XSQUAREF_OFFSET
		isReal=0
		
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_MIS_YSQUAREF_XSQUAREF_NUM_BYTES,isReal)
		
		powrDbXf = 10.0*np.log10(((float(img_part)**1.0))/(2.0**(24.0)))
		powrDbYf = 10.0*np.log10(((float(real_part)**1.0))/(2.0**(24.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		return(real_part,img_part,powrDbXf,powrDbYf)
		#readYfSquareXfSquareMismatch
		
		
		
	def readYfXstarfMismatch(self, txCh, bin, scale_enable=0):
		""" Read Y(f)X*(f) """
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XSTARF_OFFSET
		isReal=0
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_MIS_YF_XSTARF_NUM_BYTES,isReal)
		#real_part = np.bitwise_and(real_part,0x3FFFFFFFFF)
		#img_part = np.bitwise_and(img_part,0x3FFFFFFFFF)
		real_part = (real_part&0x3FFFFFFFFF) 
		img_part  = (img_part &0x3FFFFFFFFF)
		real_part=self.twos_comp(real_part,38)
		img_part=self.twos_comp(img_part,38)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(48.0)))
		powrDb_real = 5.0*np.log10(((float(real_part)**2.0))/(2.0**(48.0)))
		powrDb_img = 5.0*np.log10(((float(img_part)**2.0))/(2.0**(48.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		return(real_part,img_part,powrDb,powrDb_real,powrDb_img)
		#readYfXstarfMismatch
		
	def readNBinsMismatch(self, txCh, bin):
		""" Read Nbins """
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_MIS_NBINS_OFFSET
		isReal=1
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_MIS_NBINS_NUM_BYTES,isReal)
		warning("//txCh = "+str(txCh));
		warning("//bin = "+str(bin));
		return(real_part)
		
	def readYfXstarfChannel(self, txCh, bin, scale_enable=0):
		""" Read Y(f)X*(f) """
		#info("//inside readYfXstarfChannel")
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_CHA_YF_XSTARF_OFFSET
		isReal=0
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_CHA_YF_XSTARF_NUM_BYTES,isReal)
		#real_part = np.bitwise_and(real_part,0x3FFFFFFFFF)
		#img_part = np.bitwise_and(img_part,0x3FFFFFFFFF)
		real_part = (real_part&0x3FFFFFFFFF) 
		img_part  = (img_part &0x3FFFFFFFFF)
		real_part=self.twos_comp(real_part,38)
		img_part=self.twos_comp(img_part,38)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(48.0)))
		powrDb_real = 5.0*np.log10((float(real_part)**2.0)/(2.0**(48.0)))
		powrDb_img =  5.0*np.log10((float(img_part)**2.0)/(2.0**(48.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		return(real_part,img_part,powrDb,powrDb_real,powrDb_img)
		#readYfXstarfChannel
		
	def readXstarfXstarminusfChannel(self, txCh, bin, scale_enable=0):
		""" Read X*(f)X*(-f) """
		#info("//inside readXstarfXstarminusfChannel")
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_CHA_XSTARF_XSTARMINUSF_OFFSET
		isReal=0
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_CHA_XSTARF_XSTARMINUSF_NUM_BYTES,isReal)
		#real_part = np.bitwise_and(real_part,0x00FFFFFFFF)
		#img_part = np.bitwise_and(img_part,0x00FFFFFFFF)
		real_part = (real_part&0x00FFFFFFFF) 
		img_part  = (img_part &0x00FFFFFFFF)
		real_part=self.twos_comp(real_part,32)
		img_part=self.twos_comp(img_part,32)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2**(36.0)))
		powrDb_real = 5.0*np.log10(((float(real_part)**2.0))/(2.0**(36.0)))
		powrDb_img =  5.0*np.log10(((float(img_part)**2.0))/(2.0**(36.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**18.0)
			img_part=img_part/(2.0**18.0)
		return(real_part,img_part,powrDb,powrDb_real,powrDb_img)
		#readXstarfXstarminusfChannel
		
	def readYfSquareXfSquareChannel(self, txCh, bin, scale_enable=0):
		""" Read |Y(f)|^2 |X(f)^2"""
		#info("//inside readYfSquareXfSquareChannel")
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_CHA_YSQUAREF_XSQUAREF_OFFSET
		isReal=0
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_CHA_YSQUAREF_XSQUAREF_NUM_BYTES,isReal)
		real_part = (real_part&0x3FFFFFFFFF) 
		img_part  = (img_part &0x3FFFFFFFFF)
		info("//real_part="+str(real_part))
		info("//img_part="+str(img_part))
		powrDbXf = 10.0*np.log10(((float(img_part)**1.0))/(2.0**(24.0)))
		powrDbYf = 10.0*np.log10(((float(real_part)**1.0))/(2.0**(24.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**24.0)
			img_part=img_part/(2.0**24.0)
		return(real_part,img_part,powrDbXf,powrDbYf)
		#readYfSquareXfSquareMismatch
		
	def readXminusfSquareChannel(self, txCh, bin, scale_enable=0):
		""" Read |X(-f)|^2 """
		#info("//inside readXminusfSquareChannel")
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_CHA_XMINUSSQUAREF_OFFSET
		isReal=1
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_CHA_XMINUSSQUAREF_NUM_BYTES,isReal)
		real_part = (real_part&0x0007FFFFFF) 
		img_part  = (img_part &0x0007FFFFFF)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(24.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**12.0)
			img_part=img_part/(2.0**12.0)
		return(real_part,img_part,powrDb)
		#readXminusfSquareChannel
		
	def readYfXminusfChannel(self, txCh, bin, scale_enable=0):
		""" Read Y(f)X(-f) """
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_CHA_YFXMINUSF_OFFSET
		isReal=0
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_CHA_YFXMINUSF_NUM_BYTES,isReal)
		#real_part = np.bitwise_and(real_part,0x00FFFFFFFF)
		#img_part = np.bitwise_and(img_part,0x00FFFFFFFF)
		real_part = (real_part&0x00FFFFFFFF) 
		img_part  = (img_part &0x00FFFFFFFF)
		real_part=self.twos_comp(real_part,32)
		img_part=self.twos_comp(img_part,32)
		powrDb = 5.0*np.log10(((float(real_part)**2.0)+(float(img_part)**2.0))/(2.0**(36.0)))
		powrDb_real = 5.0*np.log10(((float(real_part)**2.0))/(2.0**(36.0)))
		powrDb_img =  5.0*np.log10(((float(img_part)**2.0))/(2.0**(36.0)))
		if (scale_enable==1):
			real_part=real_part/(2.0**18.0)
			img_part=img_part/(2.0**18.0)
		return(real_part,img_part,powrDb,powrDb_real,powrDb_img)
		#readYfXminusfChannel
		
	def readNBinsChannel(self, txCh, bin):
		""" Read N bins """
		base_address = MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS+0x20
		tx_index=txCh
		bin_index=bin
		parameter_offset = MemConst.TX_IQMC_AGGRAGATOR_CHA_NBINS_OFFSET
		isReal=1
		(real_part,img_part)=self.readAggregatorMemBytes(base_address,tx_index,bin_index,parameter_offset,MemConst.TX_IQMC_AGGRAGATOR_CHA_NBINS_NUM_BYTES,isReal)
		warning("//txCh = "+str(txCh));
		warning("//bin = "+str(bin));
		return(real_part)
		#readNBinsChannel
		
	def readMismatchEstimates(self, txCh, actualBin,db_enable=1,scale_enable=0):
		"""Read Mismatch Estimates"""
		if(actualBin>=0):
			bin=actualBin+32
		else:
			bin=actualBin+31
		(real_part1,img_part1,powrDb1,powrDb_real1,powrDb_img1)=self.readYfXminusfMismatch(txCh, bin,scale_enable)
		(real_part2,img_part2,powrDb2,powrDb_real2,powrDb_img2)=self.readXfXminusfMismatch(txCh, bin,scale_enable)
		(real_part3,img_part3,powrDb3)=self.readXminusfSquareMismatch(txCh, bin,scale_enable)
		(real_part4,img_part4,powrDbXf,powrDbYf)=self.readYfSquareXfSquareMismatch(txCh, bin,scale_enable)
		(real_part5,img_part5,powrDb4,powrDb_real4,powrDb_img4)=self.readYfXstarfMismatch(txCh, bin,scale_enable)
		(Nbins)=self.readNBinsMismatch(txCh, bin)
		
		if (Nbins!=0):
			powrDb1			=	powrDb1			-	10*math.log10(Nbins)	
			powrDb_real1    =	powrDb_real1    -	10*math.log10(Nbins)
			powrDb_img1     =	powrDb_img1     -	10*math.log10(Nbins)
			powrDb2         =	powrDb2         -	10*math.log10(Nbins)
			powrDb_real2    =	powrDb_real2    -	10*math.log10(Nbins)
			powrDb_img2     =	powrDb_img2     -	10*math.log10(Nbins)
			powrDb3         =	powrDb3         -	10*math.log10(Nbins)
			powrDbXf        =	powrDbXf        -	10*math.log10(Nbins)
			powrDbYf        =	powrDbYf        -	10*math.log10(Nbins)
			powrDb4         =	powrDb4         -	10*math.log10(Nbins)
			powrDb_real4    =	powrDb_real4    -	10*math.log10(Nbins)
			powrDb_img4     =	powrDb_img4     -	10*math.log10(Nbins)
			
		powrDb1			=	powrDb1			*	2.0		     
		powrDb_real1    =	powrDb_real1    *	2.0
		powrDb_img1     =	powrDb_img1     *	2.0
		powrDb2         =	powrDb2         *	2.0
		powrDb_real2    =	powrDb_real2    *	2.0
		powrDb_img2     =	powrDb_img2     *	2.0
		powrDb4         =	powrDb4         *	2.0
		powrDb_real4    =	powrDb_real4    *	2.0
		powrDb_img4     =	powrDb_img4     *	2.0
		
		info("//********MISMATCH ESTIMATE********************")
		info("//TX Channel  			= "+str(txCh))
		info("//Bin Index  			= "+str(actualBin))
		info("//Y[f]X[-f] YfXminusfMismatch  	= "+str(powrDb1)+" powrDb_real = "+str(powrDb_real1)+" powrDb_img = "+str(powrDb_img1))
		info("//X[f]X[-f] XfXminusfMismatch  	= "+str(powrDb2)+" powrDb_real = "+str(powrDb_real2)+" powrDb_img = "+str(powrDb_img2))
		info("//X[-f]^2 XminusfSquareMismatch = "+str(powrDb3))
		info("//X[f]^2 XfSquareMismatch  	= "+str(powrDbXf))
		info("//Y[f]^2 YfSquareMismatch  	= "+str(powrDbYf))
		info("//Y[f]X*[f] YfXstarfMismatch  	= "+str(powrDb4)+" powrDb_real = "+str(powrDb_real4)+" powrDb_img = "+str(powrDb_img4))
		info("//NBinsMismatch 		= "+str(Nbins))
		info("//**********************************************")
		
		if (db_enable==0):
			
			powrDb1		=np.abs(real_part1+img_part1*1j)
			powrDb_real1=real_part1
			powrDb_img1 =img_part1
			powrDb2     =np.abs(real_part2+img_part2*1j)
			powrDb_real2=real_part2
			powrDb_img2 =img_part2
			powrDb4     =np.abs(real_part5+img_part5*1j)
			powrDb_real4=real_part5
			powrDb_img4 =img_part5
			powrDbXf    =img_part4
			powrDbYf    =real_part4
			powrDb3		=np.abs(real_part3+img_part3*1j)
			
		return(powrDb1,powrDb_real1,powrDb_img1,powrDb2,powrDb_real2,powrDb_img2,powrDb3,powrDbXf,powrDbYf,powrDb4,powrDb_real4,powrDb_img4,Nbins)
		#readMismatchEstimates
		
	def readChannelEstimates(self, txCh, actualBin, db_enable=1,scale_enable=0):
		"""Read Channel Estimates"""
		if(actualBin>=0):
			bin=actualBin+32
		else:
			bin=actualBin+31
		(real_part1,img_part1,powrDb1,powrDb_real1,powrDb_img1)=self.readYfXstarfChannel(txCh, bin, scale_enable)
		(real_part2,img_part2,powrDb2,powrDb_real2,powrDb_img2)=self.readXstarfXstarminusfChannel(txCh, bin, scale_enable)
		(real_part3,img_part3,powrDb3)=self.readXminusfSquareChannel(txCh, bin, scale_enable)
		(real_part4,img_part4,powrDbXf,powrDbYf)=self.readYfSquareXfSquareChannel(txCh, bin, scale_enable)
		(real_part5,img_part5,powrDb4,powrDb_real4,powrDb_img4)=self.readYfXminusfChannel(txCh, bin, scale_enable)
		(Nbins)=self.readNBinsChannel(txCh, bin)
		info("//powrDbXf_without_sub="+str(powrDbXf))
		if (Nbins!=0):
			powrDb1			=	powrDb1			-	10*math.log10(Nbins)	
			powrDb_real1    =	powrDb_real1    -	10*math.log10(Nbins)
			powrDb_img1     =	powrDb_img1     -	10*math.log10(Nbins)
			powrDb2         =	powrDb2         -	10*math.log10(Nbins)
			powrDb_real2    =	powrDb_real2    -	10*math.log10(Nbins)
			powrDb_img2     =	powrDb_img2     -	10*math.log10(Nbins)
			powrDb3         =	powrDb3         -	10*math.log10(Nbins)
			powrDbXf        =	powrDbXf        -	10*math.log10(Nbins)
			powrDbYf        =	powrDbYf        -	10*math.log10(Nbins)
			powrDb4         =	powrDb4         -	10*math.log10(Nbins)
			powrDb_real4    =	powrDb_real4    -	10*math.log10(Nbins)
			powrDb_img4     =	powrDb_img4     -	10*math.log10(Nbins)
		powrDb1			=	powrDb1			*	2.0		     
		powrDb_real1    =	powrDb_real1    *	2.0
		powrDb_img1     =	powrDb_img1     *	2.0
		powrDb2         =	powrDb2         *	2.0
		powrDb_real2    =	powrDb_real2    *	2.0
		powrDb_img2     =	powrDb_img2     *	2.0
		powrDb4         =	powrDb4         *	2.0
		powrDb_real4    =	powrDb_real4    *	2.0
		powrDb_img4     =	powrDb_img4     *	2.0
		info("//************CHANNEL ESTIMATE*****************")
		info("//TX Channel  				= "+str(txCh))
		info("//Bin Index  				= "+str(actualBin))
		info("//Y[f]X*[f] YfXstarfChannel  			= "+str(powrDb1)+" powrDb_real = "+str(powrDb_real1)+" powrDb_img = "+str(powrDb_img1))
		info("//X*[f]X*[-f] XstarfXstarminusfChannel  = "+str(powrDb2)+" powrDb_real = "+str(powrDb_real2)+" powrDb_img = "+str(powrDb_img2))
		info("//X[-f]^2 XminusfSquareChannel 		= "+str(powrDb3))
		info("//X[f]^2 XfSquareChannel  		= "+str(powrDbXf))
		info("//Y[f]^2 YfSquareChannel  		= "+str(powrDbYf))
		info("//Y[f]X[-f] YfXminusfChannel  		= "+str(powrDb4)+" powrDb_real = "+str(powrDb_real4)+" powrDb_img = "+str(powrDb_img4))
		info("//NBinsChannel 				= "+str(Nbins))
		info("//**********************************************")
		if (db_enable==0):
			
			powrDb1		=np.abs(real_part1+img_part1*1j)
			powrDb_real1=real_part1
			powrDb_img1 =img_part1
			powrDb2     =np.abs(real_part2+img_part2*1j)
			powrDb_real2=real_part2
			powrDb_img2 =img_part2
			powrDb4     =np.abs(real_part5+img_part5*1j)
			powrDb_real4=real_part5
			powrDb_img4 =img_part5
			powrDbXf    =img_part4
			powrDbYf    =real_part4
			powrDb3		=np.abs(real_part3+img_part3*1j)
			
		return(powrDb1,powrDb_real1,powrDb_img1,powrDb2,powrDb_real2,powrDb_img2,powrDb3,powrDbXf,powrDbYf,powrDb4,powrDb_real4,powrDb_img4,Nbins)
		#readChannelEstimates
		
	def displayValidEstimates(self,allChFlag,txCh,onlyValidFlag):
		"""Read all valid estimates"""
		if(allChFlag):
			info("//************DISPLAYING ALL CHANNEL DATA*****************")
		else:
			info("//************DISPLAYING CHANNEL "+str(txCh)+" DATA*****************")		
		if(onlyValidFlag):
			info("//************DISPLAYING ONLY VALID DATA*****************")
		else:
			info("//************DISPLAYING ALL BIN DATA*****************")
		for i in range(64):
			if(actualBin>=32):
				bin=actualBin-32
			else:
				bin=actualBin-31
			if(allChFlag):
				if(onlyValidFlag==0):
					for ch in range(4):
						self.readChannelEstimates(ch,actualBin)
						self.readMismatchEstimates(ch,actualBin)
				else:
					for ch in range(4):
						if(self.readNBinsChannel(ch,i)>0):
							self.readChannelEstimates(ch,actualBin)
						if(self.readNBinsMismatch(ch,i)>0):	
							self.readMismatchEstimates(ch,actualBin)
							
			else:
				if(onlyValidFlag==0):
					self.readChannelEstimates(txCh,actualBin)
					self.readMismatchEstimates(txCh,actualBin)
				else:
					if(self.readNBinsChannel(txCh,i)>0):
						self.readChannelEstimates(txCh,actualBin)
					if(self.readNBinsMismatch(txCh,i)>0):
						self.readMismatchEstimates(txCh,actualBin)
						
	def checkValidEstimatesPerChannel(self,txCh,flag=0):
		"""Check if valid estimates are present"""
		info("//************DISPLAYING CHANNEL "+str(txCh)+" DATA*****************")		
		info("//************DISPLAYING ONLY VALID DATA*****************")
		validChEstimFlag=0
		validMisEstimFlag=0
		for i in range(64):
			if(i>=32):
				bin=i-32
			else:
				bin=i-31
			if(self.readNBinsChannel(txCh,i)>0):
				self.readChannelEstimates(txCh,bin)
				validChEstimFlag=1
			if(self.readNBinsMismatch(txCh,i)>0):
				self.readMismatchEstimates(txCh,bin)
				validMisEstimFlag=1
		if(flag==0):
			if(validChEstimFlag):
				info("//PASS:Valid Channel estimates are present")
			else:
				error("//FAIL:Valid Channel estimates are NOT present")
			if(validMisEstimFlag):
				info("//PASS:Valid Mismatch estimates are present")
			else:
				error("//FAIL:Valid Mismatch estimates are NOT present")
		else:
			if(validChEstimFlag):
				error("//FAIL:Valid Channel estimates are present")
			else:
				info("//PASS:Valid Channel estimates are NOT present")
			if(validMisEstimFlag):
				error("//FAIL:Valid Mismatch estimates are present")
			else:
				info("//PASS:Valid Mismatch estimates are NOT present")	
		return(validChEstimFlag,validMisEstimFlag)
		#checkValidEstimatesPerChannel
		
	def checkValidChannelEstimatesPerChannel(self,txCh,flag=0):
		"""Check if valid channel estimates are present"""
		info("//************DISPLAYING CHANNEL "+str(txCh)+" DATA*****************")		
		info("//************DISPLAYING ONLY VALID DATA*****************")
		validChEstimFlag=0
		for i in range(64):
			if(i>=32):
				bin=i-32
			else:
				bin=i-31
			if(self.readNBinsChannel(txCh,i)>0):
				self.readChannelEstimates(txCh,bin)
				validChEstimFlag=1
		if(flag==0):
			if(validChEstimFlag):
				info("//PASS:Valid Channel estimates are present")
			else:
				error("//FAIL:Valid Channel estimates are NOT present")
		else:
			if(validChEstimFlag):
				error("//FAIL:Valid Channel estimates are present")
			else:
				info("//PASS:Valid Channel estimates are NOT present")
				
		return(validChEstimFlag)
		#checkValidEstimatesPerChannel
		
	def checkValidMismatchEstimatesPerChannel(self,txCh,flag=0):
		"""Check if valid mismatch estimates are present"""
		info("//************DISPLAYING CHANNEL "+str(txCh)+" DATA*****************")		
		info("//************DISPLAYING ONLY VALID DATA*****************")
		validMisEstimFlag=0
		for i in range(64):
			if(i>=32):
				bin=i-32
			else:
				bin=i-31
			if(self.readNBinsMismatch(txCh,i)>0):
				self.readMismatchEstimates(txCh,bin)
				validMisEstimFlag=1
		if(flag==0):
			if(validMisEstimFlag):
				info("//PASS:Valid Mismatch estimates are present")
			else:
				error("//FAIL:Valid Mismatch estimates are NOT present")
		else:
			if(validMisEstimFlag):
				error("//FAIL:Valid Mismatch estimates are present")
			else:
				info("//PASS:Valid Mismatch estimates are NOT present")	
		return(validMisEstimFlag)
		#checkValidEstimatesPerChannel
		
	def fwDoneDisable(self):
		"""FW done disable"""
		self.regs.Register38631_4Bh.Property_100h_8_8=0
		#fwDoneDisable
		
	def fwDoneEnable(self):
		"""FW done disable"""
		self.regs.Register38631_4Bh.Property_100h_8_8=1
		#fwDoneDisable
		
	@funcDecorator
	def waitForCalibrationSettling(self,calibrationTimeInMilliSec):
		"""Wait time"""
		self.timerWaitForMilliSec(calibrationTimeInMilliSec)
		#waitForCalibrationSettling
		
	def estimaorThresholdSettings(self,txIqmcConfigSettings):
		"""Basic threshold settings for txiqmc estimator"""
		
		self.regs.Register38554_74h.Property_74h_23_0	=txIqmcConfigSettings["MisStatRefSigTh"]
		self.regs.Register38554_74h.Property_78h_23_0	=txIqmcConfigSettings["MisStatRefImgTh"]
		self.regs.Register38554_74h.Property_7ch_23_0		=txIqmcConfigSettings["MisStatFbSigTh"]
		self.regs.Register38554_74h.Property_80h_9_0		=txIqmcConfigSettings["MisStatRatioTh"]
		self.regs.Register38554_74h.Property_80h_25_16		=txIqmcConfigSettings["ChEstRatioTh"]
		self.regs.Register38554_74h.Property_84h_23_0		=txIqmcConfigSettings["ChEstRefSigTh"]
		self.regs.Register38554_74h.Property_88h_23_0		=txIqmcConfigSettings["ChEstRefImgTh"]
		self.regs.Register38554_74h.Property_8ch_23_0		=txIqmcConfigSettings["ChEstFbSigTh"]
		self.regs.Register38554_74h.Property_90h_30_16			=txIqmcConfigSettings["TxSigTh"]
		self.regs.Register38544_B4h.Property_b4h_10_0			=txIqmcConfigSettings["SigMagThTx"]
		self.regs.Register38544_B4h.Property_b4h_26_16			=txIqmcConfigSettings["SigMagThFb"]
		
	def setSigMaxThTx(self,thresholdDb):
		"""setSigMaxThTx"""
		threshold = int((10**(thresholdDb/20))*(2**11))
		self.regs.Register38544_B4h.Property_b4h_10_0=threshold
		#setSigMaxThTx
		
	def setSigMaxThFb(self,thresholdDb):
		"""setSigMaxThFb"""
		threshold = int((10**(thresholdDb/20))*(2**11))
		self.regs.Register38544_B4h.Property_b4h_26_16=threshold
		#setSigMaxThFb
		
	def setTxSigTh(self,thresholdDb):
		"""setTxSigTh"""
		threshold = int((10**(thresholdDb/20))*(2**15))
		self.regs.Register38554_74h.Property_90h_30_16=threshold
		#setTxSigTh
		
	def setChEstFbSigTh(self,thresholdDb):
		"""setChEstFbSigTh"""
		threshold = int((10**(thresholdDb/10))*(2**24))
		self.regs.Register38554_74h.Property_8ch_23_0=threshold
		#setChEstFbSigTh
		
	def setChEstRefImgTh(self,thresholdDb):
		"""setChEstRefImgTh"""
		threshold = int((10**(thresholdDb/10))*(2**24))
		self.regs.Register38554_74h.Property_88h_23_0=threshold
		#setChEstRefImgTh
		
	def setChEstRefSigTh(self,thresholdDb):
		"""setChEstRefSigTh"""
		threshold = int((10**(thresholdDb/10))*(2**24))
		self.regs.Register38554_74h.Property_84h_23_0=threshold
		#setChEstRefSigTh
		
	def setChEstRatioTh(self,threshold):
		"""setChEstRatioTh"""
		threshold = int(np.log2(threshold)*(2**4))
		self.regs.Register38554_74h.Property_80h_25_16=threshold
		#setChEstRatioTh
		
	def setMisStatFbSigTh(self,thresholdDb):
		"""setMisStatFbSigTh"""
		threshold = int((10**(thresholdDb/10))*(2**24))
		self.regs.Register38554_74h.Property_7ch_23_0=threshold
		#setMisStatFbSigTh
		
	def setMisStatRefImgTh(self,thresholdDb):
		"""setMisStatRefImgTh"""
		threshold = int((10**(thresholdDb/10))*(2**24))
		self.regs.Register38554_74h.Property_78h_23_0=threshold
		#setMisStatRefImgTh
		
	def setMisStatRefSigTh(self,thresholdDb):
		"""setMisStatRefSigTh"""
		threshold = int((10**(thresholdDb/10))*(2**24))#thresholdDb has to be float
		self.regs.Register38554_74h.Property_74h_23_0=threshold
		#setMisStatRefSigTh
		
	def setMisStatRatioTh(self,threshold):
		"""setMisStatRatioTh"""
		threshold = int(np.log2(threshold)*(2**4))
		self.regs.Register38554_74h.Property_80h_9_0=threshold
		#setMisStatRatioTh
		
	def setAggregatorMode(self,mode):
		"""setAggregatorMode"""
		self.regs.Register38554_74h.Property_90h_1_0=mode
		#setAggregatorMode
		
	def setBlockLengthRandom(self,blkLengthRand):
		"""setBlockLengthRandom"""
		self.regs.Register38524_20h.Property_28h_31_16=blkLengthRand
		#setBlockLengthRandom
		
	def enableBlockLengthRandom(self):
		"""enableBlockLengthRandom"""
		self.regs.Register38524_20h.Property_20h_8_8=1
		#enableBlockLengthRandom
		
	def disableBlockLengthRandom(self):
		"""disableBlockLengthRandom"""
		self.regs.Register38524_20h.Property_20h_8_8=0
		#disableBlockLengthRandom
		
	def getChannelEstimate(self,txCh,actualBin):
		"""getChannelEstimate"""
		if(actualBin>=0):
			bin=actualBin+32
		else:
			bin=actualBin+31
		(real_part,img_part,powrDb1,powrDb_real1,powrDb_img1)=self.readYfXstarfChannel(txCh, bin)
		(real_part1,img_part1,powrDbXf,powrDbYf)=self.readYfSquareXfSquareChannel(txCh, bin)
		(Nbins)=self.readNBinsChannel(txCh, bin)
		#(Nbins)=self.readNBinsChannel(txCh, bin)
		info("//real_part_ideal_channel_est					= "+str(real_part))
		info("//img_part_ideal_channel_est					= "+str(img_part))
		info("//power X[f]^2								= "+str(img_part1))
		info("//Nbins										= "+str(Nbins))
		YfXStarF = 10.0**(powrDb1/20.0)
		YfXStarF_real = 10.0**(powrDb_real1/20.0)
		YfXStarF_img = 10.0**(powrDb_img1/20.0)
		XSquareF = 10.0**(powrDbXf/10.0)
		#channelEstimate = float(YfXStarF)/float(XSquareF)
		#channelEstimate_real = float(YfXStarF_real)/float(XSquareF)
		#channelEstimate_img = float(YfXStarF_img)/float(XSquareF)
		if(img_part1!=0):
			real_part	=	(1.0*real_part)/(1.0*img_part1)
			img_part	=	(1.0*img_part)/(1.0*img_part1)
		else:
			real_part	=	(1.0*real_part)
			img_part	=	(1.0*img_part)
		channelEstimate = 2.0*(powrDb1-powrDbXf)
		channelEstimate_real = 2.0*(powrDb_real1-powrDbXf)
		channelEstimate_img = 2.0*(powrDb_img1-powrDbXf)
		info("//TX Channel  				= "+str(txCh))
		info("//Bin Index  				= "+str(actualBin))
		info("//channelEstimate 			= "+str(channelEstimate))
		info("//channelEstimate_real  	= "+str(channelEstimate_real))
		info("//channelEstimate_img		= "+str(channelEstimate_img))
		info("//real_part					= "+str(real_part))
		info("//img_part					= "+str(img_part))
		return(channelEstimate,channelEstimate_real,channelEstimate_img,real_part,img_part)
		#getChannelEstimate
		
	def getMismatchEstimate(self,txCh,actualBin):# To be modified
		"""getMismatchEstimate"""
		if(actualBin>=0):
			bin=actualBin+32
		else:
			bin=actualBin+31
		(real_part,img_part,powrDb1,powrDb_real1,powrDb_img1)=self.readYfXminusfMismatch(txCh, bin)
		(real_part1,img_part1,powrDbXminusf)=self.readXminusfSquareMismatch(txCh, bin)
		YfXminusF = 10.0**(powrDb1/20.0)
		YfXminusF_real = 10.0**(powrDb_real1/20.0)
		YfXminusF_img = 10.0**(powrDb_img1/20.0)
		XSquareF = 10.0**(powrDbXminusf/10.0)
		#mismatchEstimate = float(YfXminusF)/float(XSquareF)
		#mismatchEstimate_real = float(YfXminusF)/float(XSquareF)
		#mismatchEstimate_img = float(YfXminusF)/float(XSquareF)
		if (real_part1==0):
			real_part	=	(1.0*real_part)/(1.0);
			img_part	=	(1.0*img_part)/(1.0);
		else:
			real_part	=	(1.0*real_part)/(1.0*real_part1);
			img_part	=	(1.0*img_part)/(1.0*real_part1);
		mismatchEstimate = 2.0*(powrDb1-powrDbXminusf)
		mismatchEstimate_real = 2.0*(powrDb_real1-powrDbXminusf)
		mismatchEstimate_img = 2.0*(powrDb_img1-powrDbXminusf)
		info("//TX Channel  				= "+str(txCh))
		info("//Bin Index  				= "+str(actualBin))
		info("//mismatchEstimate  		= "+str(mismatchEstimate))
		info("//mismatchEstimate_real  	= "+str(mismatchEstimate_real))
		info("//mismatchEstimate_img  	= "+str(mismatchEstimate_img))
		info("//real_part  				= "+str(real_part))
		info("//img_part  				= "+str(img_part))
		return(mismatchEstimate,mismatchEstimate_real,mismatchEstimate_img,real_part,img_part)
		#getMismatchEstimate
		
	def estimatePowerCheck(self,chList,binList,fundAmplDbfsTx,fundAmplDbfsFb,iqmcSpurDbcFb,iqmcSpurDbfsFb\
	,txIqmcAllChannelSettings,txIqmcConfigSettings):
		"""estimatePowerCheck"""
		err_cnt=0
		txiqmc_return={}
		window_type=txIqmcAllChannelSettings["window_type"]
		Numbins=1
		ERROR_FACTOR_BLACKMAN_P25=0.8176
		ERROR_FACTOR_BLACKMAN_P50=3.3169
		ERROR_FACTOR_BLACKMAN_P75=7.6209
		ERROR_FACTOR_BLACKMAN_1P0=13.9961
		ERROR_FACTOR_BLACKMAN_1P25=22.9279
		ERROR_FACTOR_BLACKMAN_1P75=54.4357
		ERROR_FACTOR_HANNING_P25=1.4296
		ERROR_FACTOR_HANNING_P50=6.0670
		ERROR_FACTOR_HANNING_P75=15.5560
		ERROR_FACTOR_HANNING_1P0=57.7731
		ERROR_FACTOR_HANNING_1P25=32.4139
		ERROR_FACTOR_HANNING_1P75=40.9218
		bins_used=txIqmcConfigSettings["bins_used"];
		bins_offset=txIqmcConfigSettings["bins_offset"];
		#if (txIqmcConfigSettings["aggrMode"]==TxTopConst.aggr_bin_select_63_63):
		if(window_type==TxTopConst.WINDOW_BLACKMAN):
			ESTIMATE_POWER_CORRECTION_DBFS=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_BLACKMAN
			#ESTIMATE_POWER_CORRECTION_DBFS_MIN=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_BLACKMAN_MIN
		elif(window_type==TxTopConst.WINDOW_HANNING):
			ESTIMATE_POWER_CORRECTION_DBFS=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_HANNING
			#ESTIMATE_POWER_CORRECTION_DBFS_MIN=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_HANNING_MIN
		elif(window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
			ESTIMATE_POWER_CORRECTION_DBFS=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_BLACKMAN-6.0
			#ESTIMATE_POWER_CORRECTION_DBFS_MIN=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_BLACKMAN_MIN
		elif(window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
			ESTIMATE_POWER_CORRECTION_DBFS=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_HANNING-6.0
			#ESTIMATE_POWER_CORRECTION_DBFS_MIN=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_HANNING_MIN
		elif(window_type==TxTopConst.AVERAGING):
			ESTIMATE_POWER_CORRECTION_DBFS=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_AVERAGING
			#ESTIMATE_POWER_CORRECTION_DBFS_MIN=TxTopConst.ESTIMATE_POWER_CORRECTION_DBFS_AVERAGING_MIN
		signal_noise_correlation_level=txIqmcAllChannelSettings["signal_noise_correlation_level"]
		signal_signal_correlation_level=txIqmcAllChannelSettings["signal_signal_correlation_level"]
		noise_level=txIqmcAllChannelSettings["noise_level"]
		signal_mismatch_correlation_level=txIqmcAllChannelSettings["signal_mismatch_correlation_level"]
		mismatch_noise_correlation_level=txIqmcAllChannelSettings["mismatch_noise_correlation_level"]
		for ch in chList:
			bin_id			= binList[ch]
			if (bins_offset[ch]!=0):
				Numbins=2
				bin_id1=bins_used[ch]
				bin_id2=bins_used[ch]+1
				bin_offset1=bins_offset[ch]
				bin_offset2=1-bins_offset[ch]
				if (bin_offset1==0.25):
					if(window_type==TxTopConst.WINDOW_BLACKMAN or window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
						ESTIMATE_POWER_CORRECTION_DBFS1=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_BLACKMAN_P25
					elif(window_type==TxTopConst.WINDOW_HANNING or window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
						ESTIMATE_POWER_CORRECTION_DBFS1=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_HANNING_P25
				elif (bin_offset1==0.5):
					if(window_type==TxTopConst.WINDOW_BLACKMAN or window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
						ESTIMATE_POWER_CORRECTION_DBFS1=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_BLACKMAN_P50
					elif(window_type==TxTopConst.WINDOW_HANNING or window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
						ESTIMATE_POWER_CORRECTION_DBFS1=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_HANNING_P50
				elif (bin_offset1==0.75):
					if(window_type==TxTopConst.WINDOW_BLACKMAN or window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
						ESTIMATE_POWER_CORRECTION_DBFS1=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_BLACKMAN_P75
					elif(window_type==TxTopConst.WINDOW_HANNING or window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
						ESTIMATE_POWER_CORRECTION_DBFS1=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_HANNING_P75
				if (bin_offset2==0.25):
					if(window_type==TxTopConst.WINDOW_BLACKMAN or window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
						ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_BLACKMAN_P25
					elif(window_type==TxTopConst.WINDOW_HANNING or window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
						ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_HANNING_P25
				elif (bin_offset2==0.5):
					if(window_type==TxTopConst.WINDOW_BLACKMAN or window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
						ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_BLACKMAN_P50
					elif(window_type==TxTopConst.WINDOW_HANNING or window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
						ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_HANNING_P50
				elif (bin_offset2==0.75):
					if(window_type==TxTopConst.WINDOW_BLACKMAN or window_type==TxTopConst.WINDOW_DECIMATED_BLACKMAN):
						ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_BLACKMAN_P75
					elif(window_type==TxTopConst.WINDOW_HANNING or window_type==TxTopConst.WINDOW_DECIMATED_HANNING):
						ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS-ERROR_FACTOR_HANNING_P75
				(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
				XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
				YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(ch,bin_id1)	
				(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
				XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
				YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(ch,(-1*bin_id1))
				if (txIqmcAllChannelSettings["window_based_checks"]==1):
					#(YfXminusf,XstarfXstarminusf,YfSquareChannel,powrDbXminusf,powrDbYminusf,YfXminusf,NBinsChannel)=self.readMismatchEstimates(ch,(-1*bin_id))
					#ESTIMATE_POWER_CORRECTION_DBFS=ESTIMATE_POWER_CORRECTION_DBFS1
					difference=XfSquareChannel-fundAmplDbfsTx[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS1)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for TX CHANNEL "+str(ch)+" is correct"+" XfSquareChannel="+str(XfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
					else:
						error("//FAIL: Signal Power estimate for TX CHANNEL "+str(ch)+" is incorrect"+" XfSquareChannel="+str(XfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
						err_cnt=err_cnt+1
					difference=XminusfSquareMismatch-fundAmplDbfsTx[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS1)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for TX CHANNEL "+str(ch)+" is correct"+" XminusfSquareMismatch="+str(XminusfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
					else:
						error("//FAIL: Signal Power estimate for TX CHANNEL "+str(ch)+" is incorrect"+" XminusfSquareMismatch="+str(XminusfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
						err_cnt=err_cnt+1
					difference=YfSquareChannel-fundAmplDbfsFb[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS1)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for FB CHANNEL "+str(ch)+" is correct"+" YfSquareChannel="+str(YfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
					else:
						error("//FAIL: Signal Power estimate for FB CHANNEL "+str(ch)+" is incorrect"+" YfSquareChannel="+str(YfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
						err_cnt=err_cnt+1
					difference=YfSquareMismatch-iqmcSpurDbfsFb[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS1)
					if(error_val<=0.1):
						info("//PASS: Mismatch Power estimate for FB CHANNEL "+str(ch)+" is correct"+" YfSquareMismatch="+str(YfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
					else:
						error("//FAIL: Mismatch Power estimate for FB CHANNEL "+str(ch)+" is incorrect"+" YfSquareMismatch="+str(YfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS1"+str(ESTIMATE_POWER_CORRECTION_DBFS1))
						err_cnt=err_cnt+1
				(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
				XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
				YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(ch,bin_id2)	
				(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
				XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
				YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(ch,(-1*bin_id2))
				if (txIqmcAllChannelSettings["window_based_checks"]==1):
					#(YfXminusf,XstarfXstarminusf,YfSquareChannel,powrDbXminusf,powrDbYminusf,YfXminusf,NBinsChannel)=self.readMismatchEstimates(ch,(-1*bin_id))
					#ESTIMATE_POWER_CORRECTION_DBFS2=ESTIMATE_POWER_CORRECTION_DBFS2
					difference=XfSquareChannel-fundAmplDbfsTx[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS2)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for TX CHANNEL "+str(ch)+" is correct"+" XfSquareChannel="+str(XfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
					else:
						error("//FAIL: Signal Power estimate for TX CHANNEL "+str(ch)+" is incorrect"+" XfSquareChannel="+str(XfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
						err_cnt=err_cnt+1
					difference=XminusfSquareMismatch-fundAmplDbfsTx[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS2)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for TX CHANNEL "+str(ch)+" is correct"+" XminusfSquareMismatch="+str(XminusfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
					else:
						error("//FAIL: Signal Power estimate for TX CHANNEL "+str(ch)+" is incorrect"+" XminusfSquareMismatch="+str(XminusfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
						err_cnt=err_cnt+1
					difference=YfSquareChannel-fundAmplDbfsFb[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS2)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for FB CHANNEL "+str(ch)+" is correct"+" YfSquareChannel="+str(YfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
					else:
						error("//FAIL: Signal Power estimate for FB CHANNEL "+str(ch)+" is incorrect"+" YfSquareChannel="+str(YfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
						err_cnt=err_cnt+1
					difference=YfSquareMismatch-iqmcSpurDbfsFb[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS2)
					if(error_val<=0.1):
						info("//PASS: Mismatch Power estimate for FB CHANNEL "+str(ch)+" is correct"+" YfSquareMismatch="+str(YfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
					else:
						error("//FAIL: Mismatch Power estimate for FB CHANNEL "+str(ch)+" is incorrect"+" YfSquareMismatch="+str(YfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS2"+str(ESTIMATE_POWER_CORRECTION_DBFS2))
						err_cnt=err_cnt+1
						
						#info("//************CHANNEL ESTIMATE*****************")
						#info("//TX Channel  				= "+str(txCh))
						#info("//Bin Index  				= "+str(actualBin))
						#info("//Y[f]X*[f] YfXstarfChannel  			= "+str(powrDb1)+" powrDb_real = "+str(powrDb_real1)+" powrDb_img = "+str(powrDb_img1))
						#info("//X*[f]X*[-f] XstarfXstarminusfChannel  = "+str(powrDb2)+" powrDb_real = "+str(powrDb_real2)+" powrDb_img = "+str(powrDb_img2))
						#info("//X[-f]^2 XminusfSquareChannel 		= "+str(powrDb3))
						#info("//X[f]^2 XfSquareChannel  		= "+str(powrDbXf))
						#info("//Y[f]^2 YfSquareChannel  		= "+str(powrDbYf))
						#info("//Y[f]X[-f] YfXminusfChannel  		= "+str(powrDb4)+" powrDb_real = "+str(powrDb_real4)+" powrDb_img = "+str(powrDb_img4))
						#info("//NBinsChannel 				= "+str(Nbins))
						#info("//**********************************************")
			else:
				if (txIqmcAllChannelSettings["channel_image_threhold_check"]==1):
					(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
					XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
					YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(ch,(-1*bin_id),txIqmcAllChannelSettings["db_enable"],txIqmcAllChannelSettings["scale_enable"])
				else:
					(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
					XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
					YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(ch,bin_id,txIqmcAllChannelSettings["db_enable"],txIqmcAllChannelSettings["scale_enable"])
					
				txiqmc_return['YfXstarfChannel_f']=YfXstarfChannel
				txiqmc_return['YfXstarfChannel_real_f']=YfXstarfChannel_real
				txiqmc_return['YfXstarfChannel_img_f']=YfXstarfChannel_img
				txiqmc_return['XstarfXstarminusfChannel_f']=XstarfXstarminusfChannel
				txiqmc_return['XstarfXstarminusfChannel_real_f']=XstarfXstarminusfChannel_real
				txiqmc_return['XstarfXstarminusfChannel_img_f']=XstarfXstarminusfChannel_img
				txiqmc_return['XminusfSquareChannel_f']=XminusfSquareChannel
				txiqmc_return['XfSquareChannel_f']=XfSquareChannel
				txiqmc_return['YfSquareChannel_f']=YfSquareChannel
				txiqmc_return['YfXminusfChannel_f']=YfXminusfChannel
				txiqmc_return['YfXminusfChannel_real_f']=YfXminusfChannel_real
				txiqmc_return['YfXminusfChannel_img_f']=YfXminusfChannel_img
				txiqmc_return['Nbins_ch_f']=Nbins_ch
				
				if (txIqmcAllChannelSettings["read_f_and_mf"]==1):
					(YfXstarfChannel_mf,YfXstarfChannel_real_mf,YfXstarfChannel_img_mf,XstarfXstarminusfChannel_mf,XstarfXstarminusfChannel_real_mf,\
					XstarfXstarminusfChannel_img_mf,XminusfSquareChannel_mf,XfSquareChannel_mf,YfSquareChannel_mf,YfXminusfChannel_mf,YfXminusfChannel_real_mf,\
					YfXminusfChannel_img_mf,Nbins_ch_mf)=self.readChannelEstimates(ch,(-1*bin_id),txIqmcAllChannelSettings["db_enable"],txIqmcAllChannelSettings["scale_enable"])
					
					txiqmc_return['YfXstarfChannel_mf']=YfXstarfChannel_mf
					txiqmc_return['YfXstarfChannel_real_mf']=YfXstarfChannel_real_mf
					txiqmc_return['YfXstarfChannel_img_mf']=YfXstarfChannel_img_mf
					txiqmc_return['XstarfXstarminusfChannel_mf']=XstarfXstarminusfChannel_mf
					txiqmc_return['XstarfXstarminusfChannel_real_mf']=XstarfXstarminusfChannel_real_mf
					txiqmc_return['XstarfXstarminusfChannel_img_mf']=XstarfXstarminusfChannel_img_mf
					txiqmc_return['XminusfSquareChannel_mf']=XminusfSquareChannel_mf
					txiqmc_return['XfSquareChannel_mf']=XfSquareChannel_mf
					txiqmc_return['YfSquareChannel_mf']=YfSquareChannel_mf
					txiqmc_return['YfXminusfChannel_mf']=YfXminusfChannel_mf
					txiqmc_return['YfXminusfChannel_real_mf']=YfXminusfChannel_real_mf
					txiqmc_return['YfXminusfChannel_img_mf']=YfXminusfChannel_img_mf
					txiqmc_return['Nbins_ch_mf']=Nbins_ch_mf
					
				if (txIqmcAllChannelSettings["check_for_dead_dead"]==1):
					if (Nbins_ch==7853):
						info("//DEAD DEAD")
					else:
						Nbins_ch_error=np.abs(Nbins_ch-txIqmcAllChannelSettings["Nbins_Expected"])
						if (Nbins_ch_error<=3):
							error("//Expected to be dead till now")
							err_cnt=err_cnt+1
							
				if (txIqmcAllChannelSettings["channel_signal_threhold_check_tx"]==1):
					if (txIqmcAllChannelSettings["channel_signal_threhold_check_tx_pos"]==1):
						if (XfSquareChannel==-np.inf):
							error("//Signal theshold check in tx is failing channel_signal_threhold_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in tx is passing channel_signal_threhold_check_tx")
					else:
						if (XfSquareChannel!=-np.inf):
							error("//Signal theshold check in tx is failing channel_signal_threhold_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in tx is passing channel_signal_threhold_check_tx")
							
				if (txIqmcAllChannelSettings["channel_signal_threhold_check_fb"]==1):
					if (txIqmcAllChannelSettings["channel_signal_threhold_check_fb_pos"]==1):
						if (YfSquareChannel==-np.inf):
							error("//Signal theshold check in fb is failing channel_signal_threhold_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in fb is passing channel_signal_threhold_check_fb")
					else:
						if (YfSquareChannel!=-np.inf):
							error("//Signal theshold check in fb is failing channel_signal_threhold_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in fb is passing channel_signal_threhold_check_fb")
							
				if (txIqmcAllChannelSettings["channel_image_threhold_check"]==1):
					if (txIqmcAllChannelSettings["channel_image_threhold_check_pos"]==1):
						if (XminusfSquareChannel==-np.inf):
							error("//Image theshold check in fb is failing channel_image_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Image threshold check in fb is passing channel_image_threhold_check")
					else:
						if (XminusfSquareChannel!=-np.inf):
							error("//Image theshold check in fb is failing channel_image_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Image threshold check in fb is passing channel_image_threhold_check")
							
				if (txIqmcAllChannelSettings["channel_ratio_threhold_check"]==1):
					if (txIqmcAllChannelSettings["channel_ratio_threhold_check_pos"]==1):
						if (XfSquareChannel==-np.inf):
							error("//Ratio theshold check is failing channel_ratio_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Ratio threshold check in is passing channel_ratio_threhold_check")
					else:
						if (XfSquareChannel!=-np.inf):
							error("//Ratio theshold check in is failing channel_ratio_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Ratio threshold check in is passing channel_ratio_threhold_check")
							
				if (txIqmcAllChannelSettings["saturation_check_tx"]==1):
					if (txIqmcAllChannelSettings["saturation_check_tx_pos"]==1):
						if (XfSquareChannel==-np.inf):
							error("//Ratio theshold check is failing saturation_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Ratio threshold check in is passing saturation_check_tx")
					else:
						if (XfSquareChannel!=-np.inf):
							error("//Saturation theshold check in is failing saturation_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_tx")
							
				if (txIqmcAllChannelSettings["saturation_check_fb"]==1):
					if (txIqmcAllChannelSettings["saturation_check_fb_pos"]==1):
						if (YfSquareChannel==-np.inf):
							error("//Saturation theshold check is failing saturation_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_fb")
					else:
						if (YfSquareChannel!=-np.inf):
							error("//Saturation theshold check in is failing saturation_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_fb")
							
							#(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
							#XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
							#YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(ch,bin_id)
							
				Channel=fundAmplDbfsFb[ch]-fundAmplDbfsTx[ch]
				Channel_estimate=YfXstarfChannel-2.0*XfSquareChannel
				
				#info("//********MISMATCH ESTIMATE********************")
				#info("//TX Channel  			= "+str(txCh))
				#info("//Bin Index  			= "+str(actualBin))
				#info("//Y[f]X[-f] YfXminusfMismatch  	= "+str(powrDb1)+" powrDb_real = "+str(powrDb_real1)+" powrDb_img = "+str(powrDb_img1))
				#info("//X[f]X[-f] XfXminusfMismatch  	= "+str(powrDb2)+" powrDb_real = "+str(powrDb_real2)+" powrDb_img = "+str(powrDb_img2))
				#info("//X[-f]^2 XminusfSquareMismatch = "+str(powrDb3))
				#info("//X[f]^2 XfSquareMismatch  	= "+str(powrDbXf))
				#info("//Y[f]^2 YfSquareMismatch  	= "+str(powrDbYf))
				#info("//Y[f]X*[f] YfXstarfMismatch  	= "+str(powrDb4)+" powrDb_real = "+str(powrDb_real4)+" powrDb_img = "+str(powrDb_img4))
				#info("//NBinsMismatch 		= "+str(Nbins))
				#info("//**********************************************")
				#return(powrDb1,powrDb_real1,powrDb_img1,powrDb2,powrDb_real2,powrDb_img2,powrDb3,powrDbXf,powrDbYf,powrDb4,powrDb_real4,powrDb_img4,Nbins)
				
				if (txIqmcAllChannelSettings["mismatch_image_threhold_check"]==1 or txIqmcAllChannelSettings["mismatch_signal_threhold_check_fb"]==1 or txIqmcAllChannelSettings["saturation_check_tx"]==1 or txIqmcAllChannelSettings["saturation_check_fb"]):
					(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
					XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
					YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(ch,bin_id,txIqmcAllChannelSettings["db_enable"],txIqmcAllChannelSettings["scale_enable"])
				else:
					(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
					XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
					YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(ch,(-1*bin_id),txIqmcAllChannelSettings["db_enable"],txIqmcAllChannelSettings["scale_enable"])
					
				txiqmc_return['YfXminusfMismatch_mf']=YfXminusfMismatch
				txiqmc_return['YfXminusfMismatch_real_mf']=YfXminusfMismatch_real
				txiqmc_return['YfXminusfMismatch_img_mf']=YfXminusfMismatch_img
				txiqmc_return['XfXminusfMismatch_mf']=XfXminusfMismatch
				txiqmc_return['XfXminusfMismatch_real_mf']=XfXminusfMismatch_real
				txiqmc_return['XfXminusfMismatch_img_mf']=XfXminusfMismatch_img
				txiqmc_return['XminusfSquareMismatch_mf']=XminusfSquareMismatch
				txiqmc_return['XfSquareMismatch_mf']=XfSquareMismatch
				txiqmc_return['YfSquareMismatch_mf']=YfSquareMismatch
				txiqmc_return['YfXstarfMismatch_mf']=YfXstarfMismatch
				txiqmc_return['YfXstarfMismatch_real_mf']=YfXstarfMismatch_real
				txiqmc_return['YfXstarfMismatch_img_mf']=YfXstarfMismatch_img
				txiqmc_return['Nbins_mis_mf']=Nbins_ch
				
				if (txIqmcAllChannelSettings["read_f_and_mf"]==1):
					(YfXminusfMismatch_f,YfXminusfMismatch_real_f,YfXminusfMismatch_img_f,XfXminusfMismatch_f,XfXminusfMismatch_real_f,\
					XfXminusfMismatch_img_f,XminusfSquareMismatch_f,XfSquareMismatch_f,YfSquareMismatch_f,YfXstarfMismatch_f,YfXstarfMismatch_real_f,\
					YfXstarfMismatch_img_f,Nbins_ch)=self.readMismatchEstimates(ch,bin_id,txIqmcAllChannelSettings["db_enable"],txIqmcAllChannelSettings["scale_enable"])
					
					txiqmc_return['YfXminusfMismatch_f']=YfXminusfMismatch_f
					txiqmc_return['YfXminusfMismatch_real_f']=YfXminusfMismatch_real_f
					txiqmc_return['YfXminusfMismatch_img_f']=YfXminusfMismatch_img_f
					txiqmc_return['XfXminusfMismatch_f']=XfXminusfMismatch_f
					txiqmc_return['XfXminusfMismatch_real_f']=XfXminusfMismatch_real_f
					txiqmc_return['XfXminusfMismatch_img_f']=XfXminusfMismatch_img_f
					txiqmc_return['XminusfSquareMismatch_f']=XminusfSquareMismatch_f
					txiqmc_return['XfSquareMismatch_f']=XfSquareMismatch_f
					txiqmc_return['YfSquareMismatch_f']=YfSquareMismatch_f
					txiqmc_return['YfXstarfMismatch_f']=YfXstarfMismatch_f
					txiqmc_return['YfXstarfMismatch_real_f']=YfXstarfMismatch_real_f
					txiqmc_return['YfXstarfMismatch_img_f']=YfXstarfMismatch_img_f
					txiqmc_return['Nbins_mis_f']=Nbins_ch
					
				if (txIqmcAllChannelSettings["check_for_dead_dead"]==1):
					if (Nbins_ch==7853):
						info("//DEAD DEAD")
					else:
						Nbins_ch_error=np.abs(Nbins_ch-txIqmcAllChannelSettings["Nbins_Expected"])
						if (Nbins_ch_error<=3):
							error("//Expected to be dead till now")
							err_cnt=err_cnt+1
							
				if (txIqmcAllChannelSettings["mismatch_signal_threhold_check_tx"]==1):
					if (txIqmcAllChannelSettings["mismatch_signal_threhold_check_tx_pos"]==1):
						if (XminusfSquareMismatch==-np.inf):
							error("//Signal theshold check in tx is failing mismatch_signal_threhold_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in tx is passing mismatch_signal_threhold_check_tx")
					else:
						if (XminusfSquareMismatch!=-np.inf):
							error("//Signal theshold check in tx is failing mismatch_signal_threhold_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in tx is passing mismatch_signal_threhold_check_tx")
							
				if (txIqmcAllChannelSettings["mismatch_signal_threhold_check_fb"]==1):
					if (txIqmcAllChannelSettings["mismatch_signal_threhold_check_fb_pos"]==1):
						if (YfSquareMismatch==-np.inf):
							error("//Signal theshold check in fb is failing mismatch_signal_threhold_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in fb is passing mismatch_signal_threhold_check_fb")
					else:
						if (YfSquareMismatch!=-np.inf):
							error("//Signal theshold check in fb is failing mismatch_signal_threhold_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Signal threshold check in fb is passing mismatch_signal_threhold_check_fb")
							
				if (txIqmcAllChannelSettings["mismatch_image_threhold_check"]==1):
					if (txIqmcAllChannelSettings["mismatch_image_threhold_check_pos"]==1):
						if (XfSquareMismatch==-np.inf):
							error("//Image theshold check in fb is failing mismatch_image_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Image threshold check in fb is passing mismatch_image_threhold_check")
					else:
						if (XfSquareMismatch!=-np.inf):
							error("//Image theshold check in fb is failing mismatch_image_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Image threshold check in fb is passing mismatch_image_threhold_check")
							
				if (txIqmcAllChannelSettings["mismatch_ratio_threhold_check"]==1):
					if (txIqmcAllChannelSettings["mismatch_ratio_threhold_check_pos"]==1):
						if (XminusfSquareMismatch==-np.inf):
							error("//Ratio theshold check in fb is failing mismatch_ratio_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Ratio threshold check in fb is passing mismatch_ratio_threhold_check")
					else:
						if (XminusfSquareMismatch!=-np.inf):
							error("//Ratio theshold check in fb is failing mismatch_ratio_threhold_check")
							err_cnt=err_cnt+1
						else:
							info("//PASS Ratio threshold check in fb is passing mismatch_ratio_threhold_check")
							
				if (txIqmcAllChannelSettings["saturation_check_tx"]==1):
					if (txIqmcAllChannelSettings["saturation_check_tx_pos"]==1):
						if (XfSquareMismatch==-np.inf):
							error("//Saturation theshold check is failing saturation_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_tx")
					else:
						if (XfSquareMismatch!=-np.inf):
							error("//Saturation theshold check in is failing saturation_check_tx")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_tx")
							
				if (txIqmcAllChannelSettings["saturation_check_fb"]==1):
					if (txIqmcAllChannelSettings["saturation_check_fb_pos"]==1):
						if (YfSquareMismatch==-np.inf):
							error("//Saturation theshold check is failing saturation_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_fb")
					else:
						if (YfSquareMismatch!=-np.inf):
							error("//Saturation theshold check in is failing saturation_check_fb")
							err_cnt=err_cnt+1
						else:
							info("//PASS Saturation threshold check in is passing saturation_check_fb")
							
							#(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
							#XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
							#YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(ch,(-1*bin_id))
							
				Mismatch=iqmcSpurDbcFb[ch]
				Mismatch_estimate=YfXminusfMismatch-2.0*XminusfSquareMismatch-Channel_estimate
				
				if (txIqmcAllChannelSettings["window_based_checks"]==1):
					#(YfXminusf,XstarfXstarminusf,YfSquareChannel,powrDbXminusf,powrDbYminusf,YfXminusf,NBinsChannel)=self.readMismatchEstimates(ch,(-1*bin_id))
					difference=XfSquareChannel-fundAmplDbfsTx[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for TX CHANNEL "+str(ch)+" is correct"+" XfSquareChannel="+str(XfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
					else:
						error("//FAIL: Signal Power estimate for TX CHANNEL "+str(ch)+" is incorrect"+" XfSquareChannel="+str(XfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
						err_cnt=err_cnt+1
					difference=XminusfSquareMismatch-fundAmplDbfsTx[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for TX CHANNEL "+str(ch)+" is correct"+" XminusfSquareMismatch="+str(XminusfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
					else:
						error("//FAIL: Signal Power estimate for TX CHANNEL "+str(ch)+" is incorrect"+" XminusfSquareMismatch="+str(XminusfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
						err_cnt=err_cnt+1
					difference=YfSquareChannel-fundAmplDbfsFb[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS)
					if(error_val<=0.1):
						info("//PASS: Signal Power estimate for FB CHANNEL "+str(ch)+" is correct"+" YfSquareChannel="+str(YfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
					else:
						error("//FAIL: Signal Power estimate for FB CHANNEL "+str(ch)+" is incorrect"+" YfSquareChannel="+str(YfSquareChannel)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
						err_cnt=err_cnt+1
					difference=YfSquareMismatch-iqmcSpurDbfsFb[ch]
					error_val=math.fabs(difference-ESTIMATE_POWER_CORRECTION_DBFS)
					if(error_val<=0.1):
						info("//PASS: Mismatch Power estimate for FB CHANNEL "+str(ch)+" is correct"+" YfSquareMismatch="+str(YfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))
					else:
						error("//FAIL: Mismatch Power estimate for FB CHANNEL "+str(ch)+" is incorrect"+" YfSquareMismatch="+str(YfSquareMismatch)+" difference="+str(difference)\
						+" error_val="+str(error_val)+" ESTIMATE_POWER_CORRECTION_DBFS"+str(ESTIMATE_POWER_CORRECTION_DBFS))	
						err_cnt=err_cnt+1
						
					Channel_estimate_error=math.fabs(Channel-Channel_estimate)
					if(Channel_estimate_error<=0.1):
						info("//PASS: Channel_estimate is correct Channel_estimate_error="+str(Channel_estimate_error))
					else:
						error("//FAIL: Channel_estimate is incorrect Channel_estimate_error="+str(Channel_estimate_error))
						err_cnt=err_cnt+1
						
					Mismatch_estimate_error=math.fabs(Mismatch-Mismatch_estimate)
					if(Mismatch_estimate_error<=0.1):
						info("//PASS: Mismatch_estimate is correct Mismatch_estimate_error="+str(Mismatch_estimate_error))
					else:
						error("//FAIL: Mismatch_estimate is incorrect Mismatch_estimate_error="+str(Mismatch_estimate_error))	
						err_cnt=err_cnt+1
						
					if (YfXstarfChannel>=signal_signal_correlation_level):
						info("//PASS: Mismatch Power estimate for CHANNEL "+str(ch)+" is correct"+" YfXstarfChannel="+str(YfXstarfChannel)+" signal_signal_correlation_level="+str(signal_signal_correlation_level))
					else:
						error("//FAIL: Mismatch Power estimate for CHANNEL "+str(ch)+" is incorrect"+" YfXstarfChannel="+str(YfXstarfChannel)+" signal_signal_correlation_level="+str(signal_signal_correlation_level))
						err_cnt=err_cnt+1
						
						#if (YfXstarfChannel_real>=signal_signal_correlation_level):
						#	info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXstarfChannel_real="+str(YfXstarfChannel_real)+" signal_signal_correlation_level="+str(signal_signal_correlation_level))
						#else:
						#	error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXstarfChannel_real="+str(YfXstarfChannel_real)+" signal_signal_correlation_level="+str(signal_signal_correlation_level))
						#
						#if (YfXstarfChannel_img>=signal_signal_correlation_level):
						#	info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXstarfChannel_img="+str(YfXstarfChannel_img)+" signal_signal_correlation_level="+str(signal_signal_correlation_level))
						#else:
						#	error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXstarfChannel_img="+str(YfXstarfChannel_img)+" signal_signal_correlation_level="+str(signal_signal_correlation_level))
					if (XstarfXstarminusfChannel<=signal_noise_correlation_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XstarfXstarminusfChannel="+str(XstarfXstarminusfChannel)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XstarfXstarminusfChannel="+str(XstarfXstarminusfChannel)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						err_cnt=err_cnt+1
						#if (XstarfXstarminusfChannel_real<=signal_noise_correlation_level):
						#	info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XstarfXstarminusfChannel_real="+str(XstarfXstarminusfChannel_real)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						#else:
						#	error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XstarfXstarminusfChannel_real="+str(XstarfXstarminusfChannel_real)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						#if (XstarfXstarminusfChannel_img<=signal_noise_correlation_level):
						#	info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XstarfXstarminusfChannel_img="+str(XstarfXstarminusfChannel_img)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						#else:
						#	error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XstarfXstarminusfChannel_img="+str(XstarfXstarminusfChannel_img)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
					if (XminusfSquareChannel<=noise_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XminusfSquareChannel="+str(XminusfSquareChannel)+" noise_level="+str(noise_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XminusfSquareChannel="+str(XminusfSquareChannel)+" noise_level="+str(noise_level))
						err_cnt=err_cnt+1
					if (YfXminusfChannel<=signal_noise_correlation_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXminusfChannel="+str(YfXminusfChannel)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXminusfChannel="+str(YfXminusfChannel)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						err_cnt=err_cnt+1
						# if (YfXminusfChannel_real<=signal_noise_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXminusfChannel_real="+str(YfXminusfChannel_real)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXminusfChannel_real="+str(YfXminusfChannel_real)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						# if (YfXminusfChannel_img<=signal_noise_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXminusfChannel_img="+str(YfXminusfChannel_img)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXminusfChannel_img="+str(YfXminusfChannel_img)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
					if (YfXminusfMismatch>=signal_mismatch_correlation_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXminusfMismatch="+str(YfXminusfMismatch)+" signal_mismatch_correlation_level="+str(signal_mismatch_correlation_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXminusfMismatch="+str(YfXminusfMismatch)+" signal_mismatch_correlation_level="+str(signal_mismatch_correlation_level))
						err_cnt=err_cnt+1
						# if (YfXminusfMismatch_real>=signal_mismatch_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXminusfMismatch_real="+str(YfXminusfMismatch_real)+" signal_mismatch_correlation_level="+str(signal_mismatch_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXminusfMismatch_real="+str(YfXminusfMismatch_real)+" signal_mismatch_correlation_level="+str(signal_mismatch_correlation_level))
						# if (YfXminusfMismatch_img>=signal_mismatch_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXminusfMismatch_img="+str(YfXminusfMismatch_img)+" signal_mismatch_correlation_level="+str(signal_mismatch_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXminusfMismatch_img="+str(YfXminusfMismatch_img)+" signal_mismatch_correlation_level="+str(signal_mismatch_correlation_level))
					if (XfXminusfMismatch<=signal_noise_correlation_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XfXminusfMismatch="+str(XfXminusfMismatch)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XfXminusfMismatch="+str(XfXminusfMismatch)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						err_cnt=err_cnt+1
						# if (XfXminusfMismatch_real<=signal_noise_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XfXminusfMismatch_real="+str(XfXminusfMismatch_real)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XfXminusfMismatch_real="+str(XfXminusfMismatch_real)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						# if (XfXminusfMismatch_img<=signal_noise_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XfXminusfMismatch_img="+str(XfXminusfMismatch_img)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XfXminusfMismatch_img="+str(XfXminusfMismatch_img)+" signal_noise_correlation_level="+str(signal_noise_correlation_level))
					if (XfSquareMismatch<=noise_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" XfSquareMismatch="+str(XfSquareMismatch)+" noise_level="+str(noise_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" XfSquareMismatch="+str(XfSquareMismatch)+" noise_level="+str(noise_level))
						err_cnt=err_cnt+1
					if (YfXstarfMismatch<=mismatch_noise_correlation_level):
						info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXstarfMismatch="+str(YfXstarfMismatch)+" mismatch_noise_correlation_level="+str(mismatch_noise_correlation_level))
					else:
						error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXstarfMismatch="+str(YfXstarfMismatch)+" mismatch_noise_correlation_level="+str(mismatch_noise_correlation_level))
						err_cnt=err_cnt+1
						# if (YfXstarfMismatch_real<=mismatch_noise_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXstarfMismatch_real="+str(YfXstarfMismatch_real)+" mismatch_noise_correlation_level="+str(mismatch_noise_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXstarfMismatch_real="+str(YfXstarfMismatch_real)+" mismatch_noise_correlation_level="+str(mismatch_noise_correlation_level))
						# if (YfXstarfMismatch_img<=mismatch_noise_correlation_level):
						# info("//PASS: Mismatch Power estimate for  CHANNEL "+str(ch)+" is correct"+" YfXstarfMismatch_img="+str(YfXstarfMismatch_img)+" mismatch_noise_correlation_level="+str(mismatch_noise_correlation_level))
						# else:
						# error("//FAIL: Mismatch Power estimate for  CHANNEL "+str(ch)+" is incorrect"+" YfXstarfMismatch_img="+str(YfXstarfMismatch_img)+" mismatch_noise_correlation_level="+str(mismatch_noise_correlation_level))
		txiqmc_return["err_cnt"]=err_cnt
		return(txiqmc_return)
		#estimatePowerCheck
		
	def estimateConsistencyCheck(self,chList,binList,noOfEstimations,txIqmcAllChannelSettings):
		"""estimateConsistencyCheck"""
		err_cnt=0
		txiqmc_return={}
		Numofchannels=4
		channelEstimate		=np.zeros(Numofchannels)
		mismatchEstimate	=np.zeros(Numofchannels)
		channelEstimate1	=np.zeros(Numofchannels)
		mismatchEstimate1	=np.zeros(Numofchannels)
		
		channelEstimate_real	=np.zeros(Numofchannels)
		mismatchEstimate_real	=np.zeros(Numofchannels)
		channelEstimate1_real	=np.zeros(Numofchannels)
		mismatchEstimate1_real	=np.zeros(Numofchannels)
		
		channelEstimate_real_raw	=np.zeros(Numofchannels)
		mismatchEstimate_real_raw	=np.zeros(Numofchannels)
		channelEstimate1_real_raw	=np.zeros(Numofchannels)
		mismatchEstimate1_real_raw	=np.zeros(Numofchannels)
		
		channelEstimate_img		=np.zeros(Numofchannels)
		mismatchEstimate_img	=np.zeros(Numofchannels)
		channelEstimate1_img	=np.zeros(Numofchannels)
		mismatchEstimate1_img	=np.zeros(Numofchannels)
		
		channelEstimate_img_raw		=np.zeros(Numofchannels)
		mismatchEstimate_img_raw	=np.zeros(Numofchannels)
		channelEstimate1_img_raw	=np.zeros(Numofchannels)
		mismatchEstimate1_img_raw	=np.zeros(Numofchannels)
		
		#if(window_type==WINDOW_BLACKMAN):
		#	ESTIMATE_POWER_CORRECTION_DBFS_HANNING_MAX
		
		for ch in chList:
			bin_id			= binList[ch]
			(channelEstimate[ch],channelEstimate_real[ch],channelEstimate_img[ch],channelEstimate_real_raw[ch],channelEstimate_img_raw[ch])\
			=self.getChannelEstimate(ch,bin_id)
			(mismatchEstimate[ch],mismatchEstimate_real[ch],mismatchEstimate_img[ch],mismatchEstimate_real_raw[ch],mismatchEstimate_img_raw[ch])\
			=self.getMismatchEstimate(ch,(-1*bin_id))
			channel_est_absolute=math.sqrt(channelEstimate_real_raw[ch]**2.0+channelEstimate_img_raw[ch]**2.0)
			mismatch_est_absolute=math.sqrt(mismatchEstimate_real_raw[ch]**2.0+mismatchEstimate_img_raw[ch]**2.0)
		if (txIqmcAllChannelSettings["run_consistency_sequence"]==1):
			for i in range(noOfEstimations):
				if (txIqmcAllChannelSettings["fb_capture_delay_enable"]==1):
					self.regs.Register38524_20h.Property_3ch_15_0=txIqmcAllChannelSettings["FBDataCapOffTxA"]
					self.regs.Register38524_20h.Property_3ch_31_16=txIqmcAllChannelSettings["FBDataCapOffTxB"]
					self.regs.Register38524_20h.Property_40h_15_0=txIqmcAllChannelSettings["FBDataCapOffTxC"]
					self.regs.Register38524_20h.Property_40h_31_16=txIqmcAllChannelSettings["FBDataCapOffTxD"]
				if (txIqmcAllChannelSettings["fractional_delay_enable"]==1):
					self.regs.Register38574_31h.Property_44h_2_0=txIqmcAllChannelSettings["FracDelCfgTxA"]
					self.regs.Register38574_31h.Property_44h_5_3=txIqmcAllChannelSettings["FracDelCfgTxB"]
					self.regs.Register38574_31h.Property_44h_10_8=txIqmcAllChannelSettings["FracDelCfgTxC"]
					self.regs.Register38574_31h.Property_44h_13_11=txIqmcAllChannelSettings["FracDelCfgTxD"]
				self.restart_tx_iqmc_estimation()
				self.waitForCalibrationSettling(TxTopConst.ESTIMATION_WAIT_TIME_MS)
				self.check_estimation_done_status()	
				for ch in chList:
					bin_id			= binList[ch]
					(channelEstimate1[ch],channelEstimate1_real[ch],channelEstimate1_img[ch],channelEstimate1_real_raw[ch],channelEstimate1_img_raw[ch])\
					=self.getChannelEstimate(ch,bin_id)
					(mismatchEstimate1[ch],mismatchEstimate1_real[ch],mismatchEstimate1_img[ch],mismatchEstimate1_real_raw[ch],mismatchEstimate1_img_raw[ch])\
					=self.getMismatchEstimate(ch,(-1*bin_id))
					
					#error_mag_db_channel_real_raw=20.0*np.log10(math.fabs(channelEstimate1_real_raw[ch]-channelEstimate_real_raw[ch])/channelEstimate_real_raw[ch])
					#error_mag_db_channel_img_raw=20.0*np.log10(math.fabs(channelEstimate1_img_raw[ch]-channelEstimate_img_raw[ch])/channelEstimate_img_raw[ch])
					
					error_mag_db_channel_real_raw=20.0*np.log10(math.fabs(channelEstimate1_real_raw[ch]-channelEstimate_real_raw[ch]))
					error_mag_db_channel_img_raw=20.0*np.log10(math.fabs(channelEstimate1_img_raw[ch]-channelEstimate_img_raw[ch]))
					if (txIqmcAllChannelSettings["fb_capture_delay_enable"]==1 or txIqmcAllChannelSettings["fractional_delay_enable"]==1):
						phase_before_fb_cap_offset_ch=math.degrees(math.atan2(channelEstimate_img_raw[ch],channelEstimate_real_raw[ch]))
						phase_after_fb_cap_offset_ch=math.degrees(math.atan2(channelEstimate1_img_raw[ch],channelEstimate1_real_raw[ch]))
						phase_before_fb_cap_offset_mis=math.degrees(math.atan2(mismatchEstimate_img_raw[ch],mismatchEstimate_real_raw[ch]))
						phase_after_fb_cap_offset_mis=math.degrees(math.atan2(mismatchEstimate1_img_raw[ch],mismatchEstimate1_real_raw[ch]))
						txiqmc_return['phase_before_fb_cap_offset_ch']=phase_before_fb_cap_offset_ch
						txiqmc_return['phase_after_fb_cap_offset_ch']=phase_after_fb_cap_offset_ch
						txiqmc_return['phase_after_fb_cap_offset_mis']=phase_after_fb_cap_offset_mis
						txiqmc_return['phase_after_fb_cap_offset_mis']=phase_after_fb_cap_offset_mis
						if (phase_before_fb_cap_offset_ch<0.0):
							phase_before_fb_cap_offset_ch=phase_before_fb_cap_offset_ch+360.0
						if (phase_after_fb_cap_offset_ch<0.0):
							phase_after_fb_cap_offset_ch=phase_after_fb_cap_offset_ch+360.0
						if (phase_before_fb_cap_offset_mis<0.0):
							phase_before_fb_cap_offset_mis=phase_before_fb_cap_offset_mis+360.0
						if (phase_after_fb_cap_offset_mis<0.0):
							phase_after_fb_cap_offset_mis=phase_after_fb_cap_offset_mis+360.0
						info("//phase_before_fb_cap_offset_ch="+str(phase_before_fb_cap_offset_ch))
						info("//phase_after_fb_cap_offset_ch="+str(phase_after_fb_cap_offset_ch))
						info("//phase_before_fb_cap_offset_mis="+str(phase_before_fb_cap_offset_mis))
						info("//phase_after_fb_cap_offset_mis="+str(phase_after_fb_cap_offset_mis))
						
						if (ch==0):
							capture_offset=txIqmcAllChannelSettings["FBDataCapOffTxA"]
							if (txIqmcAllChannelSettings["fractional_delay_enable"]==1):
								capture_offset=capture_offset-txIqmcAllChannelSettings["FracDelCfgTxA"]/4.0
						elif (ch==1):
							capture_offset=txIqmcAllChannelSettings["FBDataCapOffTxB"]
							if (txIqmcAllChannelSettings["fractional_delay_enable"]==1):
								capture_offset=capture_offset-txIqmcAllChannelSettings["FracDelCfgTxB"]/4.0
						elif (ch==2):
							capture_offset=txIqmcAllChannelSettings["FBDataCapOffTxC"]
							if (txIqmcAllChannelSettings["fractional_delay_enable"]==1):
								capture_offset=capture_offset-txIqmcAllChannelSettings["FracDelCfgTxC"]/4.0
						elif (ch==3):
							capture_offset=txIqmcAllChannelSettings["FBDataCapOffTxD"]
							if (txIqmcAllChannelSettings["fractional_delay_enable"]==1):
								capture_offset=capture_offset-txIqmcAllChannelSettings["FracDelCfgTxD"]/4.0
								
						phase_expected_after_fb_cap_offset_ch=(phase_before_fb_cap_offset_ch+360.0/128.0*capture_offset*bin_id)
						
						# if (phase_expected_after_fb_cap_offset_ch>360.0 or phase_expected_after_fb_cap_offset_ch<0.0):
						# phase_expected_after_fb_cap_offset_ch=\
						# phase_expected_after_fb_cap_offset_ch-(int((phase_expected_after_fb_cap_offset_ch)/360.0))*360.0
						
						if (phase_expected_after_fb_cap_offset_ch>360.0):
							phase_expected_after_fb_cap_offset_ch=\
							phase_expected_after_fb_cap_offset_ch-(int((phase_expected_after_fb_cap_offset_ch)/360.0))*360.0
						elif (phase_expected_after_fb_cap_offset_ch<0.0):
							phase_expected_after_fb_cap_offset_ch=\
							phase_expected_after_fb_cap_offset_ch-(int((phase_expected_after_fb_cap_offset_ch)/360.0)-1.0)*360.0
							#elif (phase_expected_after_fb_cap_offset_ch<-180):
							#phase_expected_after_fb_cap_offset_ch=\
							#phase_expected_after_fb_cap_offset_ch+(int((phase_expected_after_fb_cap_offset_ch+180.0)/360.0))*360.0
							
						phase_expected_after_fb_cap_offset_mis=(phase_before_fb_cap_offset_mis-360.0/128.0*capture_offset*bin_id)
						
						if (phase_expected_after_fb_cap_offset_mis>360.0):
							phase_expected_after_fb_cap_offset_mis=\
							phase_expected_after_fb_cap_offset_mis-(int((phase_expected_after_fb_cap_offset_mis)/360.0))*360.0
						elif (phase_expected_after_fb_cap_offset_mis<0.0):
							phase_expected_after_fb_cap_offset_mis=\
							phase_expected_after_fb_cap_offset_mis-(int((phase_expected_after_fb_cap_offset_mis)/360.0)-1.0)*360.0
							
						phase_error_channel=math.fabs(phase_expected_after_fb_cap_offset_ch-phase_after_fb_cap_offset_ch)
						phase_error_mismatch=math.fabs(phase_expected_after_fb_cap_offset_mis-phase_after_fb_cap_offset_mis)
						info("//phase_expected_after_fb_cap_offset_ch="+str(phase_expected_after_fb_cap_offset_ch))
						info("//phase_expected_after_fb_cap_offset_mis="+str(phase_expected_after_fb_cap_offset_mis))
					else:
						phase_error_channel=math.fabs(math.degrees(math.atan2(channelEstimate1_img_raw[ch],channelEstimate1_real_raw[ch]))\
						-math.degrees(math.atan2(channelEstimate_img_raw[ch],channelEstimate_real_raw[ch])))
						phase_error_mismatch=math.fabs(math.degrees(math.atan2(mismatchEstimate1_img_raw[ch],mismatchEstimate1_real_raw[ch]))\
						-math.degrees(math.atan2(mismatchEstimate_img_raw[ch],mismatchEstimate_real_raw[ch])))
					phase_comparison_channel=(10.0**(-55.0/20.0))/math.sqrt(channelEstimate_real_raw[ch]**2.0+channelEstimate_img_raw[ch]**2.0)
					phase_comparison_mismatch=(10.0**(-55.0/20.0))/math.sqrt(mismatchEstimate_real_raw[ch]**2.0+mismatchEstimate_img_raw[ch]**2.0)
					
					if(phase_error_channel < phase_comparison_channel):
						info("//PASS: phase_error_channel is consistent for channel "+str(ch)+" in iteration = "+str(i)+\
						" phase_error_channel="+str(phase_error_channel)+" phase_comparison_channel="+str(phase_comparison_channel))
					else:
						error("//FAIL: phase_error_channel is not consistent for channel "+str(ch)+" in iteration = "+str(i)+\
						" phase_error_channel="+str(phase_error_channel)+" phase_comparison_channel="+str(phase_comparison_channel))
						err_cnt=err_cnt+1
						
					if(phase_error_mismatch < phase_comparison_mismatch):
						info("//PASS: phase_error_mismatch is consistent for channel "+str(ch)+" in iteration = "+str(i)+\
						" phase_error_mismatch="+str(phase_error_mismatch)+" phase_comparison_mismatch="+str(phase_comparison_mismatch))
					else:
						error("//FAIL: phase_error_mismatch is not consistent for channel "+str(ch)+" in iteration = "+str(i)+\
						" phase_error_mismatch="+str(phase_error_mismatch)+" phase_comparison_mismatch="+str(phase_comparison_mismatch))
						err_cnt=err_cnt+1
					if (txIqmcAllChannelSettings["fb_capture_delay_enable"]==0):
						if(error_mag_db_channel_real_raw < -80.0):
							info("//PASS: error_mag_db_channel_real_raw is consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_channel_real_raw="+str(error_mag_db_channel_real_raw))
						else:
							error("//FAIL: error_mag_db_channel_real_raw is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_channel_real_raw="+str(error_mag_db_channel_real_raw))
							err_cnt=err_cnt+1
							
						if(error_mag_db_channel_img_raw < -80.0):
							info("//PASS: error_mag_db_channel_img_raw is consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_channel_img_raw="+str(error_mag_db_channel_img_raw))
						else:
							error("//FAIL: error_mag_db_channel_img_raw is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_channel_img_raw="+str(error_mag_db_channel_img_raw))
							err_cnt=err_cnt+1
							
					error_mag_db_mismatch_real_raw=20.0*np.log10(math.fabs(mismatchEstimate1_real_raw[ch]-mismatchEstimate_real_raw[ch]))
					error_mag_db_mismatch_img_raw=20.0*np.log10(math.fabs(mismatchEstimate1_img_raw[ch]-mismatchEstimate_img_raw[ch]))
					if (txIqmcAllChannelSettings["fb_capture_delay_enable"]==0):
						if(error_mag_db_mismatch_real_raw < -80.0):
							info("//PASS: error_mag_db_mismatch_real_raw is consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_mismatch_real_raw="+str(error_mag_db_mismatch_real_raw))
						else:
							error("//FAIL: error_mag_db_channel_real_raw is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_channel_real_raw="+str(error_mag_db_channel_real_raw))
							err_cnt=err_cnt+1
							
						if(error_mag_db_mismatch_img_raw < -80.0):
							info("//PASS: error_mag_db_mismatch_img_raw is consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_mismatch_img_raw="+str(error_mag_db_mismatch_img_raw))
						else:
							error("//FAIL: error_mag_db_mismatch_img_raw is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" error_mag_db_mismatch_img_raw="+str(error_mag_db_mismatch_img_raw))
							err_cnt=err_cnt+1
							
							#errorDbChannel=self.errorinDb(channelEstimate[ch],channelEstimate1[ch])
							#errorDbChannel_real=self.errorinDb(channelEstimate_real[ch],channelEstimate1_real[ch])
							#errorDbChannel_img=self.errorinDb(channelEstimate_img[ch],channelEstimate1_img[ch])
							#errorDbMismatch=self.errorinDb(mismatchEstimate[ch],mismatchEstimate1[ch])
							#errorDbMismatch_real=self.errorinDb(mismatchEstimate_real[ch],mismatchEstimate1_real[ch])
							#errorDbMismatch_img=self.errorinDb(mismatchEstimate_img[ch],mismatchEstimate1_img[ch])
							#if(errorDbChannel < -85.0):
							#	info("//PASS: channelEstimate is consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbChannel="+str(errorDbChannel))
							#else:
							#	error("//FAIL: channelEstimate is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbChannel="+str(errorDbChannel))
							#if(errorDbMismatch < -85.0):
							#	info("//PASS: mismatchEstimate is consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbMismatch="+str(errorDbMismatch))
							#else:
							#	error("//FAIL: mismatchEstimate is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbMismatch="+str(errorDbMismatch))
							#
							#if(errorDbChannel_real < -85.0):
							#	info("//PASS: channelEstimate_real is consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbChannel_real="+str(errorDbChannel_real))
							#else:
							#	error("//FAIL: channelEstimate_real is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbChannel_real="+str(errorDbChannel_real))
							#if(errorDbMismatch_real < -85.0):
							#	info("//PASS: mismatchEstimate_real is consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbMismatch_real="+str(errorDbMismatch_real))
							#else:
							#	error("//FAIL: mismatchEstimate_real is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbMismatch_real="+str(errorDbMismatch_real))
							#
							#if(errorDbChannel_img < -85.0):
							#	info("//PASS: channelEstimate_img is consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbChannel_img="+str(errorDbChannel_img))
							#else:
							#	error("//FAIL: channelEstimate_img is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbChannel_img="+str(errorDbChannel_img))
							#if(errorDbMismatch_img < -85.0):
							#	info("//PASS: mismatchEstimate_img is consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbMismatch_img="+str(errorDbMismatch_img))
							#else:
							#	error("//FAIL: mismatchEstimate_img is not consistent for channel "+str(ch)+" in iteration = "+str(i)+" errorDbMismatch_img="+str(errorDbMismatch_img))
							
							#channelEstimate[ch]=channelEstimate1[ch]
							#channelEstimate[ch]=channelEstimate1[ch]
							#channelEstimate[ch]=channelEstimate1[ch]
							#mismatchEstimate[ch]=mismatchEstimate1[ch]
							#mismatchEstimate[ch]=mismatchEstimate1[ch]
							#mismatchEstimate[ch]=mismatchEstimate1[ch]
		else:
			phase_before_fb_cap_offset_ch=math.degrees(math.atan2(channelEstimate_img_raw[ch],channelEstimate_real_raw[ch]))
			phase_after_fb_cap_offset_ch=math.degrees(math.atan2(channelEstimate1_img_raw[ch],channelEstimate1_real_raw[ch]))
			phase_before_fb_cap_offset_mis=math.degrees(math.atan2(mismatchEstimate_img_raw[ch],mismatchEstimate_real_raw[ch]))
			phase_after_fb_cap_offset_mis=math.degrees(math.atan2(mismatchEstimate1_img_raw[ch],mismatchEstimate1_real_raw[ch]))
			txiqmc_return['phase_before_fb_cap_offset_ch']=phase_before_fb_cap_offset_ch
			txiqmc_return['phase_after_fb_cap_offset_ch']=phase_after_fb_cap_offset_ch
			txiqmc_return['phase_before_fb_cap_offset_mis']=phase_before_fb_cap_offset_mis
			txiqmc_return['phase_after_fb_cap_offset_mis']=phase_after_fb_cap_offset_mis
			txiqmc_return['channel_est_absolute']=channel_est_absolute
			txiqmc_return['mismatch_est_absolute']=mismatch_est_absolute
			if (phase_before_fb_cap_offset_ch<0.0):
				phase_before_fb_cap_offset_ch=phase_before_fb_cap_offset_ch+360.0
			if (phase_after_fb_cap_offset_ch<0.0):
				phase_after_fb_cap_offset_ch=phase_after_fb_cap_offset_ch+360.0
			if (phase_before_fb_cap_offset_mis<0.0):
				phase_before_fb_cap_offset_mis=phase_before_fb_cap_offset_mis+360.0
			if (phase_after_fb_cap_offset_mis<0.0):
				phase_after_fb_cap_offset_mis=phase_after_fb_cap_offset_mis+360.0
			info("//phase_before_fb_cap_offset_ch="+str(phase_before_fb_cap_offset_ch))
			info("//phase_after_fb_cap_offset_ch="+str(phase_after_fb_cap_offset_ch))
			info("//phase_before_fb_cap_offset_mis="+str(phase_before_fb_cap_offset_mis))
			info("//phase_after_fb_cap_offset_mis="+str(phase_after_fb_cap_offset_mis))
			info("//channel_est_absolute="+str(channel_est_absolute))
			info("//mismatch_est_absolute="+str(mismatch_est_absolute))
		txiqmc_return["err_cnt"]=err_cnt;
		return(txiqmc_return)
		#estimateConsistencyCheck
		
	def estimateNbinsCheck(self,chList,binList,expectedNbins,error_threshold=1):
		"""estimateNbinsCheck"""
		err_cnt=0
		for ch in chList:
			bin_id			= binList[ch]
			bin_id_mis=(-1*bin_id)
			if(bin_id>=0):
				bin_ch=bin_id+32
			else:
				bin_ch=bin_id+31
			if(bin_id_mis>=0):
				bin_mis=bin_id_mis+32
			else:
				bin_mis=bin_id_mis+31
				#(YfXstarf,XfXminusf,XminusfSquare,powrDbXf,powrDbYf,YfXstarf,NbinsCh)=self.readChannelEstimates(ch,bin_id)
				#(YfXminusf,XstarfXstarminusf,XminusfSquare,powrDbXminusf,powrDbYminusf,YfXminusf,NbinsMis)=self.readMismatchEstimates(ch,(-1*bin_id))
			(NbinsCh)=self.readNBinsChannel(ch, bin_ch)
			(NbinsMis)=self.readNBinsMismatch(ch,bin_mis)
			error_val=math.fabs(NbinsCh-expectedNbins)
			if(error_val<=error_threshold):
				info("//PASS: Channel estimate Nbins for TX CHANNEL "+str(ch)+" is correct "+" NbinsCh="+str(NbinsCh)+" error_val="+str(error_val))
			else:
				error("//FAIL: Channel estimate Nbins for TX CHANNEL "+str(ch)+" is incorrect "+" NbinsCh="+str(NbinsCh)+" error_val="+str(error_val))
				err_cnt=err_cnt+1
			error_val=math.fabs(NbinsMis-expectedNbins)
			if(error_val<=error_threshold):
				info("//PASS: Mismatch estimate Nbins for TX CHANNEL "+str(ch)+" is correct "+" NbinsMis="+str(NbinsMis)+" error_val="+str(error_val))
			else:
				error("//FAIL: Mismatch estimate Nbins for TX CHANNEL "+str(ch)+" is incorrect "+" NbinsMis="+str(NbinsMis)+" error_val="+str(error_val))
				err_cnt=err_cnt+1
		return(err_cnt)
		#estimateNbinsCheck
		
	def estimateNoInvalidBinCheck(self,chList,binList):
		"""estimateNoInvalidBinCheck"""
		err_cnt=0
		for txCh in chList:
			validChEstimFlag=0
			validMisEstimFlag=0
			invalidChEstimFlag=0
			invalidMisEstimFlag=0
			#actualBin=binList[txCh]
			for i in range(64):
				actualBin=i
				if(actualBin>=32):
					bin=actualBin-32
				else:
					bin=actualBin-31
					#readNBinsChannel=self.readNBinsChannel(txCh,actualBin)
					#if(readNBinsChannel>0):
				if(binList[txCh]==bin):
					#warning("//inside if for channel")
					#warning("//readNBinsChannel"+str(readNBinsChannel))
					(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
					XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
					YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(txCh,bin)
					if(YfXstarfChannel!=-np.inf or XstarfXstarminusfChannel!=-np.inf or XminusfSquareChannel!=-np.inf or XfSquareChannel!=-np.inf\
					or YfSquareChannel!=-np.inf or YfXminusfChannel!=-np.inf or Nbins_ch!=0):
						info("//PASS:Valid Channel estimates are present for expected bin "+str(bin)+" for channel "+str(txCh))
						validChEstimFlag=1
					else:
						error("//FAIL:Valid Channel estimates are NOT present for expected bin "+str(bin)+" for channel "+str(txCh))
						validChEstimFlag=0
						err_cnt=err_cnt+1
				else:
					#warning("//inside else for channel")
					#warning("//readNBinsChannel"+str(readNBinsChannel))
					#(powrDb1,powrDb2,powrDb3,powrDbXf,powrDbYf,powrDb4,Nbins)=self.readChannelEstimates(txCh,bin)
					(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
					XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
					YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(txCh,bin)
					if(YfXstarfChannel!=-np.inf or XstarfXstarminusfChannel!=-np.inf or XminusfSquareChannel!=-np.inf or  XfSquareChannel!=-np.inf\
					or YfSquareChannel!=-np.inf or YfXminusfChannel!=-np.inf or Nbins_ch!=0):
						error("//FAIL:Some Channel estimates are present for unexpected bin "+str(bin)+" for channel "+str(txCh))
						invalidChEstimFlag=1
						err_cnt=err_cnt+1
					else:
						invalidChEstimFlag=0
						#readNBinsMismatch=self.readNBinsMismatch(txCh,actualBin)
						#if(readNBinsMismatch>0):
				if(binList[txCh]==(-1*bin)):
					#warning("//inside if for mismatch")
					#warning("//readNBinsMismatch"+str(readNBinsMismatch))
					#(powrDb1,powrDb2,powrDb3,powrDbXf,powrDbYf,powrDb4,Nbins)=self.readMismatchEstimates(txCh,bin)
					(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
					XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
					YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(txCh,bin)
					if(YfXminusfMismatch!=-np.inf or XfXminusfMismatch!=-np.inf or XminusfSquareMismatch!=-np.inf or  XfSquareMismatch!=-np.inf\
					or YfSquareMismatch!=-np.inf or YfXstarfMismatch!=-np.inf or Nbins_ch!=0):
						info("//PASS:Valid Mismatch estimates are present for expected bin "+str(bin)+" for channel "+str(txCh))
						validMisEstimFlag=1
					else:
						error("//FAIL:Valid Mismatch estimates are NOT present for expected bin "+str(bin)+" for channel "+str(txCh))
						validMisEstimFlag=0
						err_cnt=err_cnt+1
				else:
					#warning("//inside else for mismatch")
					#warning("//readNBinsMismatch"+str(readNBinsMismatch))
					#(powrDb1,powrDb2,powrDb3,powrDbXf,powrDbYf,powrDb4,Nbins)=self.readMismatchEstimates(txCh,bin)
					(YfXminusfMismatch,YfXminusfMismatch_real,YfXminusfMismatch_img,XfXminusfMismatch,XfXminusfMismatch_real,\
					XfXminusfMismatch_img,XminusfSquareMismatch,XfSquareMismatch,YfSquareMismatch,YfXstarfMismatch,YfXstarfMismatch_real,\
					YfXstarfMismatch_img,Nbins_ch)=self.readMismatchEstimates(txCh,bin)
					if(YfXminusfMismatch!=-np.inf or XfXminusfMismatch!=-np.inf or XminusfSquareMismatch!=-np.inf or  XfSquareMismatch!=-np.inf\
					or YfSquareMismatch!=-np.inf or YfXstarfMismatch!=-np.inf or Nbins_ch!=0):
						error("//FAIL:Some Mismatch estimates are present for unexpected bin "+str(bin)+" for channel "+str(txCh))
						invalidMisEstimFlag=1
						err_cnt=err_cnt+1
					else:
						invalidMisEstimFlag=0	
						
			if(validChEstimFlag==1 and invalidChEstimFlag==0):
				info("//Valid Channel estimates are present at the expected bin only for channel "+str(txCh))
			else:
				error("//InValid Channel estimates are present for channel "+str(txCh))
				err_cnt=err_cnt+1
			if(validMisEstimFlag==1 and invalidMisEstimFlag==0):
				info("//Valid Mismatch estimates are present at the expected bin only for channel "+str(txCh))
			else:
				error("//InValid Mismatch estimates are present for channel "+str(txCh))
				err_cnt=err_cnt+1
		return(validChEstimFlag,validMisEstimFlag,invalidChEstimFlag,invalidMisEstimFlag,err_cnt)
		#estimatePowerCheck
		
		#def check_power_level_based_on_windowing(self,chList,binList,window_type):
		#	"""check_power_level_based_on_windowing"""
		#	for ch in chList:
		#		(YfXstarfChannel,YfXstarfChannel_real,YfXstarfChannel_img,XstarfXstarminusfChannel,XstarfXstarminusfChannel_real,\
		#		XstarfXstarminusfChannel_img,XminusfSquareChannel,XfSquareChannel,YfSquareChannel,YfXminusfChannel,YfXminusfChannel_real,\
		#		YfXminusfChannel_img,Nbins_ch)=self.readChannelEstimates(txCh,bin)
		
	def varianceCheck(self,txCh,actualBin):
		"""varianceCheck"""
		#varianceCheck
		
	@funcDecorator
	def twos_comp_rev(val, bits):
		"""compute the 2's complement rev of int value val"""
		if val < -(1 << (bits-1)):
			error("//Cannot be represented over here")
			val=0
		elif val < 0:# if sign bit is set e.g., 8bit: 128-255
			val = (1 << bits) + val# compute negative value
		elif (val==(1 << (bits-1))):
			error("//Cannot be represented over here")
			val=0
		return ((val))
		
	@funcDecorator
	def twos_comp(self, val, bits):
		"""compute the 2's complement of int value val"""
		if (val & (1 << (bits - 1))) != 0:# if sign bit is set e.g., 8bit: 128-255
			val = val - (1 << bits)# compute negative value
		return (val)
		#twos_comp
		
	def blank_txiqmc_with_overrides(self):
		self.regs.Register38544_B4h.Property_c8h_18_18=1
		self.regs.Register38544_B4h.Property_c8h_19_19=1
		self.regs.Register38544_B4h.Property_c8h_20_20=1
		self.regs.Register38544_B4h.Property_c8h_21_21=1
		self.regs.Register38544_B4h.Property_d0h_6_6=1
		self.regs.Register38544_B4h.Property_d0h_7_7=1
		
	def enable_inv_based_jesd_link_error(self):
		self.regs.Register38544_B4h.Property_c8h_10_10=1
		self.regs.Register38544_B4h.Property_c8h_11_11=1
		self.regs.Register38544_B4h.Property_c8h_12_12=1
		self.regs.Register38544_B4h.Property_c8h_13_13=1
		
	def enable_inv_based_tx_duc_ovr(self):
		self.regs.Register38544_B4h.Property_c8h_6_6=1
		self.regs.Register38544_B4h.Property_c8h_7_7=1
		self.regs.Register38544_B4h.Property_c8h_8_8=1
		self.regs.Register38544_B4h.Property_c8h_9_9=1
		
	def enable_inv_based_pa_protection(self):
		self.regs.Register38544_B4h.Property_c8h_14_14=1
		self.regs.Register38544_B4h.Property_c8h_15_15=1
		self.regs.Register38544_B4h.Property_c8h_16_16=1
		self.regs.Register38544_B4h.Property_c8h_17_17=1
		
	def enable_AggrMem3BlkDSEn(self):
		self.regs.Register38554_74h.Property_a0h_4_4=1
		
	def enable_AggrMemPerBlkDSEn(self):
		self.regs.Register38554_74h.Property_a0h_3_3=1
		
	def DSASettingOvrChgPlsTxA(self):
		self.regs.Register38544_B4h.Property_e4h_6_6	=	0
		self.regs.Register38544_B4h.Property_e4h_6_6	=	1
		self.regs.Register38544_B4h.Property_e4h_6_6	=	0
		
	def DSASettingOvrChgPlsTxB(self):
		self.regs.Register38544_B4h.Property_e4h_14_14	=	0
		self.regs.Register38544_B4h.Property_e4h_14_14	=	1
		self.regs.Register38544_B4h.Property_e4h_14_14	=	0
		
	def DSASettingOvrChgPlsTxC(self):
		self.regs.Register38544_B4h.Property_e4h_22_22	=	0
		self.regs.Register38544_B4h.Property_e4h_22_22	=	1
		self.regs.Register38544_B4h.Property_e4h_22_22	=	0
		
	def DSASettingOvrChgPlsTxD(self):
		self.regs.Register38544_B4h.Property_e4h_30_30	=	0
		self.regs.Register38544_B4h.Property_e4h_30_30	=	1
		self.regs.Register38544_B4h.Property_e4h_30_30	=	0
		
		#TxIqmcEstim
