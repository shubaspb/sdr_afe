
class afeConstants(object):
	printValidityErrors=False
	supportedRxInterfaceRates=(0.5,1,1.5,2,3,4,6)
	supportedTxInterfaceRates=(1,2,3,4,6,8,12)
	supportedFbInterfaceRates=(1,2,3,4,6,8,12)
	
	supportedRxLowIfInterfaceRates={}# Supported lowIF Rates for actual interface rates
	supportedRxLowIfInterfaceRates[0.5]=[1,]
	supportedRxLowIfInterfaceRates[1]=[2,3]
	supportedRxLowIfInterfaceRates[1.5]=[3,]
	supportedRxLowIfInterfaceRates[2]=[4,6]
	supportedRxLowIfInterfaceRates[3]=[6,]
	supportedRxLowIfInterfaceRates[4]=[]
	supportedRxLowIfInterfaceRates[6]=[]
	
	supportedTxFbLowIfInterfaceRates={}# Supported lowIF Rates for actual interface rates
	supportedTxFbLowIfInterfaceRates[2]=[4,]
	supportedTxFbLowIfInterfaceRates[3]=[6,]
	supportedTxFbLowIfInterfaceRates[4]=[6,8]
	supportedTxFbLowIfInterfaceRates[6]=[12,]
	supportedTxFbLowIfInterfaceRates[8]=[12,]
	supportedTxFbLowIfInterfaceRates[12]=[]
	
	
class pllConstants(object):
	####### PLL
	pllNfactors=range(12,91)
	pllFfactors=range(2**19)[1:]+[2**19,]
	pllDfactors=range(2**19)[1:]+[2**19,]
	pllIpDivFactors=(1,)#2,3,4,8)
	pllDcPllOpDivFactors=(1,2,3,4,8)#3 is possible only for DC PLL
	pllOpDivFactors=(1,2,3,4,6,8)
	pllVcoRange=(5700.0,12000.0)
	pllCalControlFRefRanges=((0,0),(0,0),(0,0),(0,0),(0,0),(0,0),(1.5,2.0),(3,4),(6,8))
	#pllConstants
	
	
class jesdConstants(object):
	
	#jesdRxClockDivFactors=[1, 4.0/3, 3.0/2, 2, 8.0/3 , 3 , 4, 6, 9.0/8, 27.0/16, 9.0/4, 27.0/8, 9.0/2, 27.0/4, 7.0/6, 14.0/9, 7.0/4, 7.0/3, 28.0/9, 7.0/2, 14.0/3, 7 ]
	#jesdTxClockDivFactors=[2, 3, 4, 6, 8 , 12 , 2.25, 3.375, 4.5, 6.75 , 9, 13.5, 7.0/3, 3.5, 14.0/3, 7, 28.0/3, 14, 2.6, 5.3, 3.1, 6.2]
	#ddcRdClockDivFactorsTc=[12, 27/2, 14, 8, 9, 28/3, 6, 27/4, 7, 4, 9/2, 14/3, 2]
	#ducWrClockDivFactorsTc=[2, 3, 4, 6, 9.0/4, 27.0/8, 9.0/2, 27.0/4, 7.0/3, 7.0/2, 14.0/3, 7]
	#jesdTxModesTc=['24410', '14810', '14610', '24610', '141210', '44210', '28810', '28610', '48610', '42111', '48410', '14810', '14610', '24410', '24310', '44310', '181210', '281210', '44320', '42220', '181610', '182410', '22210_Real', '12310_Real', '22310_Real', '12410_Real', '12610_Real', '24410_Real', '14610_Real', '24610_Real', '14810_Real', '141210_Real']
	#jesdRxModesTc=['24410', '14810', '14610', '24610', '141210', '44210', '28810', '28610', '48610', '42111', '48410', '14810', '14610', '24410', '24310', '44310', '181210', '281210', '44320', '42220', '181610', '182410', '22210', '12310', '22310', '12410', '12610', '22320', '44210']
	#jesdClkRatioFactorsTc=range(16)[1:]+[1.5,]
	
	
	jesdModesRx=['24410', '14810', '14610', '24610', '141210', '44210', 
				'28810', '28610', '48610', '42111', '48410', '12310', 
				'22210', '48310', '24310', '44310', '181210', '281210', 18, '42220', 
				'181610', '182410', '12610', '12410']+ range(24,50)+['22210_TOR',]
	jesdModesFb=['24820', '12810', '24620', '44620', '44420', '22320', 
				'142420', '41240', '41121', 9, '42220', '14810', '121620_DUP', 13,14,
				'42320',16, '12610', '12410', '12310', '121620', '121220', '12820',
				'12620', '22210', '22310', '32411', '32211', '12810_DUP',
				'121210_DUP', '22420', '22620', '122420_DUP', '121640', '22840',
				'122440', '321230', '32830', '32630', '141620', '141220']+range(41,50)+ ['24410_VSWR',]
	jesdModesTx=['24410', '14810', '14610', '24610', '141210', '44210', '12820', 
				'48410', '28810', '28610', '48610', '281210', '24820', '48310', '24310', 
				'44310', '181210', '181610', 18, 19, '34210', '38410']
	
	rootClockDivFactors=range(1,33)+\
					[2.25, 7.0/3, 8.0/3, 28.0/9, 3.375, 3.5, 4.5, 14.0/3,
					16.0/3,0,6.75]+[0]*(51-43)+[1.125, 7.0/6, 4.0/3, 1.5, 52.0/45, 1.6875, 1.75]
	#16.0/3,'41',6.75]+[str(i) for i in range(43,51)]+[1.125, 7.0/6, 4.0/3, 1.5, 52.0/45, 1.6875, 1.75]
	ddcRdClockDivFactors=range(1,17)+[1.5, 2.25, 4.5, 4.0/3, 8.0/3]
	ducWrClockDivFactors=range(1,17)+[1.5, 2.25, 4.5, 4.0/3, 8.0/3]
	jesdClockDivFactors=range(1,17)+[1.5, 2.25, 4.5, 4.0/3, 8.0/3]
	jesdSampleDropModes=(1,2,3,4,6,8,12)
	jesdToSerdesLaneMapping=(3,2,0,1,5,4,6,7)
	serdesIpDivFactors=(1,2,4,-1,2,4,8,-1,3,6,12)
	#serdesSupportedVcoRatesMinMax=((27,32),(25,30),(24,28),(23,26),(22,24),(21,23),(20,22),(18,21))
	serdesSupportedVcoRatesMinMax=((31,33),(27,32),(27,32),(27,32),(25,26),(23,25),(27,32),(27,32),(21,23),(27,32),(27,32),(18,21))#((0,0),(27,32),(27,32),(27,32),(25,26),(23,25),(27,32),(27,32),(27,32),(27,32),(27,32),(27,32),(18,21))
	serdesSupportedSubRateDivs=(1,1,1,1,2,4,8,16)
	serdesSupportedPllMulFactors=range(8,256)
	#jesdConstants
	
	
class gpioConstants():
	
	outputFuncDict = {
			'SPIB1':{
				'spib1_sdo':{'muxSel': 1, 'description': '', 'funcName': 'intpo_spib1_sdo'},
				'intbipo_spib1_sdo':{'muxSel': 3, 'description': '', 'funcName': 'intbipo_spib1_sdo'}},
	
			'INTAGC':{
				'rxd_alc_out_3':{'muxSel': 50, 'description': '', 'funcName': 'intpo_rxd_alc_out_3'},
				'rxb_alc_out_2':{'muxSel': 16, 'description': '', 'funcName': 'intpo_rxb_alc_out_2'},
				'rxb_alc_out_3':{'muxSel': 48, 'description': '', 'funcName': 'intpo_rxb_alc_out_3'},
				'rxb_alc_out_0':{'muxSel': 14, 'description': '', 'funcName': 'intpo_rxb_alc_out_0'},
				'rxb_alc_out_1':{'muxSel': 15, 'description': '', 'funcName': 'intpo_rxb_alc_out_1'},
				'rxa_alc_out_1':{'muxSel': 12, 'description': '', 'funcName': 'intpo_rxa_alc_out_1'},
				'rxa_alc_out_0':{'muxSel': 11, 'description': '', 'funcName': 'intpo_rxa_alc_out_0'},
				'rxa_alc_out_3':{'muxSel': 47, 'description': '', 'funcName': 'intpo_rxa_alc_out_3'},
				'rxa_alc_out_2':{'muxSel': 13, 'description': '', 'funcName': 'intpo_rxa_alc_out_2'},
				'rxc_ext_lnabypass':{'muxSel': 41, 'description': '', 'funcName': 'intpo_rxc_ext_lnabypass'},
				'rxd_ext_lnabypass':{'muxSel': 42, 'description': '', 'funcName': 'intpo_rxd_ext_lnabypass'},
				'rxa_ext_lnabypass':{'muxSel': 39, 'description': '', 'funcName': 'intpo_rxa_ext_lnabypass'},
				'rxc_alc_out_3':{'muxSel': 49, 'description': '', 'funcName': 'intpo_rxc_alc_out_3'},
				'rxd_alc_out_1':{'muxSel': 21, 'description': '', 'funcName': 'intpo_rxd_alc_out_1'},
				'rxd_alc_out_0':{'muxSel': 20, 'description': '', 'funcName': 'intpo_rxd_alc_out_0'},
				'rxc_alc_out_2':{'muxSel': 19, 'description': '', 'funcName': 'intpo_rxc_alc_out_2'},
				'rxc_alc_out_1':{'muxSel': 18, 'description': '', 'funcName': 'intpo_rxc_alc_out_1'},
				'rxc_alc_out_0':{'muxSel': 17, 'description': '', 'funcName': 'intpo_rxc_alc_out_0'},
				'rxd_alc_out_2':{'muxSel': 22, 'description': '', 'funcName': 'intpo_rxd_alc_out_2'},
				'rxb_ext_lnabypass':{'muxSel': 40, 'description': '', 'funcName': 'intpo_rxb_ext_lnabypass'}},
	
			'SPIB2':{
				'intbipo_spib2_sdo':{'muxSel': 4, 'description': '', 'funcName': 'intbipo_spib2_sdo'},
				'spib2_sdo':{'muxSel': 2, 'description': '', 'funcName': 'intpo_spib2_sdo'}},
	
			'MAIN':{
				'alarm_1':{'muxSel': 43, 'description': '', 'funcName': 'intpo_alarm_1'},
				'alarm_2':{'muxSel': 44, 'description': '', 'funcName': 'intpo_alarm_2'},
				'rel_status_c_0':{'muxSel': 63, 'description': '', 'funcName': 'intpo_rel_status_c_0'},
				'dac_sync_n_ab_1':{'muxSel': 46, 'description': '', 'funcName': 'intpo_dac_sync_n_ab_1'},
				'dac_sync_n_ab_0':{'muxSel': 45, 'description': '', 'funcName': 'intpo_dac_sync_n_ab_0'},
				'rel_status_b_0':{'muxSel': 61, 'description': '', 'funcName': 'intpo_rel_status_b_0'},
				'dac_sync_n_cd_1':{'muxSel': 57, 'description': '', 'funcName': 'intpo_dac_sync_n_cd_1'},
				'dac_sync_n_cd_0':{'muxSel': 56, 'description': '', 'funcName': 'intpo_dac_sync_n_cd_0'},
				'rel_status_a_0':{'muxSel': 59, 'description': '', 'funcName': 'intpo_rel_status_a_0'},
				'rel_status_d_0':{'muxSel': 65, 'description': '', 'funcName': 'intpo_rel_status_d_0'}},
	
			'EXTAGC':{
				'rxa_digpkdet_hth':{'muxSel': 25, 'description': '', 'funcName': 'intpo_rxa_digpkdet_hth'},
				'rxc_digpkdet_hth':{'muxSel': 33, 'description': '', 'funcName': 'intpo_rxc_digpkdet_hth'},
				'rxb_digpkdet_hth':{'muxSel': 29, 'description': '', 'funcName': 'intpo_rxb_digpkdet_hth'},
				'rxd_digpkdet_hth':{'muxSel': 37, 'description': '', 'funcName': 'intpo_rxd_digpkdet_hth'}},
	}
	
	
	inputFuncDict = {
			'MAIN':{
				'adc_sync_n_cd_1':{'muxSel': 45, 'description': '', 'funcName': 'intpi_adc_sync_n_cd_1'},
				'adc_sync_n_cd_0':{'muxSel': 44, 'description': '', 'funcName': 'intpi_adc_sync_n_cd_0'},
				'fb_nco_sw':{'muxSel': 75, 'description': '', 'funcName': 'intpi_fb_nco_sw'},
				'adc_sync_n_ab_1':{'muxSel': 43, 'description': '', 'funcName': 'intpi_adc_sync_n_ab_1'},
				'adc_sync_n_ab_0':{'muxSel': 42, 'description': '', 'funcName': 'intpi_adc_sync_n_ab_0'},
				'tx_fb_loop_3':{'muxSel': 69, 'description': '', 'funcName': 'intpi_tx_fb_loop_3'},
				'tdd_2r_en_ab':{'muxSel': 48, 'description': '', 'funcName': 'intpi_tdd_2r_en_ab'},
				'rxdsa_gain_sw':{'muxSel': 78, 'description': '', 'funcName': 'intpi_rxdsa_gain_sw'},
				'tdd_1f_en_cd':{'muxSel': 51, 'description': '', 'funcName': 'intpi_tdd_1f_en_cd'},
				'tdd_2r_en_cd':{'muxSel': 49, 'description': '', 'funcName': 'intpi_tdd_2r_en_cd'},
				'tx_fb_loop_2':{'muxSel': 68, 'description': '', 'funcName': 'intpi_tx_fb_loop_2'},
				'tx_fb_loop_1':{'muxSel': 67, 'description': '', 'funcName': 'intpi_tx_fb_loop_1'},
				'tdd_1f_en_ab':{'muxSel': 50, 'description': '', 'funcName': 'intpi_tdd_1f_en_ab'},
				'tx1dsa_gain_sw_rxtxlo':{'muxSel': 76, 'description': '', 'funcName': 'intpi_tx1dsa_gain_sw_rxtxlo'},
				'tdd_2t_en_cd':{'muxSel': 47, 'description': '', 'funcName': 'intpi_tdd_2t_en_cd'},
				'txiqmc_coeff_update':{'muxSel': 74, 'description': '', 'funcName': 'intpi_txiqmc_coeff_update'},
				'tx2dsa_gain_sw_rxtxlo':{'muxSel': 77, 'description': '', 'funcName': 'intpi_tx2dsa_gain_sw_rxtxlo'},
				'tdd_2t_en_ab':{'muxSel': 46, 'description': '', 'funcName': 'intpi_tdd_2t_en_ab'},
				'global_pdn':{'muxSel': 65, 'description': '', 'funcName': 'intpi_global_pdn'},
				'tx_fb_loop_0':{'muxSel': 66, 'description': '', 'funcName': 'intpi_tx_fb_loop_0'}},
	
			'SPIB1':{
				'intbipi_spib1_sdi':{'muxSel': 38, 'description': '', 'funcName': 'intbipi_spib1_sdi'},
				'spib1_clk':{'muxSel': 41, 'description': '', 'funcName': 'intpi_spib1_clk'},
				'spib1_cs_n':{'muxSel': 40, 'description': '', 'funcName': 'intpi_spib1_cs_n'}},
	
			'SPIB2':{
				'spib2_cs_n':{'muxSel': 0, 'description': '', 'funcName': 'intpi_spib2_cs_n'},
				'intbipi_spib2_sdi':{'muxSel': 39, 'description': '', 'funcName': 'intbipi_spib2_sdi'},
				'spib2_clk':{'muxSel': 1, 'description': '', 'funcName': 'intpi_spib2_clk'}},
	
			'INTAGC':{
				'rxd_alc_input_1':{'muxSel': 63, 'description': '', 'funcName': 'intpi_rxd_alc_input_1'},
				'rxd_agc_pin_freeze':{'muxSel': 92, 'description': '', 'funcName': 'intpi_rxd_agc_pin_freeze'},
				'rxa_alc_input_3':{'muxSel': 79, 'description': '', 'funcName': 'intpi_rxa_alc_input_3'},
				'rxb_agc_pin_freeze':{'muxSel': 90, 'description': '', 'funcName': 'intpi_rxb_agc_pin_freeze'},
				'rxa_agc_pin_freeze':{'muxSel': 89, 'description': '', 'funcName': 'intpi_rxa_agc_pin_freeze'},
				'rxc_alc_input_1':{'muxSel': 60, 'description': '', 'funcName': 'intpi_rxc_alc_input_1'},
				'rxa_alc_input_2':{'muxSel': 55, 'description': '', 'funcName': 'intpi_rxa_alc_input_2'},
				'rxa_alc_input_1':{'muxSel': 54, 'description': '', 'funcName': 'intpi_rxa_alc_input_1'},
				'rxa_alc_input_0':{'muxSel': 53, 'description': '', 'funcName': 'intpi_rxa_alc_input_0'},
				'rxc_agc_pin_freeze':{'muxSel': 91, 'description': '', 'funcName': 'intpi_rxc_agc_pin_freeze'},
				'rxc_alc_input_3':{'muxSel': 81, 'description': '', 'funcName': 'intpi_rxc_alc_input_3'},
				'rxb_alc_input_0':{'muxSel': 56, 'description': '', 'funcName': 'intpi_rxb_alc_input_0'},
				'rxb_alc_input_1':{'muxSel': 57, 'description': '', 'funcName': 'intpi_rxb_alc_input_1'},
				'rxb_alc_input_2':{'muxSel': 58, 'description': '', 'funcName': 'intpi_rxb_alc_input_2'},
				'rxb_alc_input_3':{'muxSel': 80, 'description': '', 'funcName': 'intpi_rxb_alc_input_3'},
				'rxd_alc_input_2':{'muxSel': 64, 'description': '', 'funcName': 'intpi_rxd_alc_input_2'},
				'rxc_alc_input_0':{'muxSel': 59, 'description': '', 'funcName': 'intpi_rxc_alc_input_0'},
				'rxd_alc_input_0':{'muxSel': 62, 'description': '', 'funcName': 'intpi_rxd_alc_input_0'},
				'rxc_alc_input_2':{'muxSel': 61, 'description': '', 'funcName': 'intpi_rxc_alc_input_2'},
				'rxd_alc_input_3':{'muxSel': 82, 'description': '', 'funcName': 'intpi_rxd_alc_input_3'}},
	
			'FSPI':{
				'fspia_clk':{'muxSel': 2, 'description': '', 'funcName': 'intpi_fspia_clk'},
				'fspib_clk':{'muxSel': 3, 'description': '', 'funcName': 'intpi_fspib_clk'},
				'fspid_data_in':{'muxSel': 37, 'description': '', 'funcName': 'intpi_fspid_data_in'},
				'fspia_data_in':{'muxSel': 34, 'description': '', 'funcName': 'intpi_fspia_data_in'},
				'fspib_data_in':{'muxSel': 35, 'description': '', 'funcName': 'intpi_fspib_data_in'},
				'fspic_data_in':{'muxSel': 36, 'description': '', 'funcName': 'intpi_fspic_data_in'},
				'fspid_clk':{'muxSel': 5, 'description': '', 'funcName': 'intpi_fspid_clk'},
				'fspic_clk':{'muxSel': 4, 'description': '', 'funcName': 'intpi_fspic_clk'}},
	
			'EXTAGC_GPIOMode1':{
				'rxcd_dsa_gain_2':{'muxSel': 16, 'description': '', 'funcName': 'intpi_rxcd_dsa_gain_2'},
				'rxcd_dsa_gain_3':{'muxSel': 17, 'description': '', 'funcName': 'intpi_rxcd_dsa_gain_3'},
				'rxcd_dsa_gain_0':{'muxSel': 14, 'description': '', 'funcName': 'intpi_rxcd_dsa_gain_0'},
				'rxcd_dsa_gain_1':{'muxSel': 15, 'description': '', 'funcName': 'intpi_rxcd_dsa_gain_1'},
				'rxab_dsa_gainsel':{'muxSel': 12, 'description': '', 'funcName': 'intpi_rxab_dsa_gainsel'},
				'rxcd_dsa_gain_4':{'muxSel': 18, 'description': '', 'funcName': 'intpi_rxcd_dsa_gain_4'},
				'rxcd_dsa_gain_5':{'muxSel': 19, 'description': '', 'funcName': 'intpi_rxcd_dsa_gain_5'},
				'rxcd_dsa_gainsel':{'muxSel': 20, 'description': '', 'funcName': 'intpi_rxcd_dsa_gainsel'},
				'rxcd_dsa_gainlen':{'muxSel': 21, 'description': '', 'funcName': 'intpi_rxcd_dsa_gainlen'},
				'rxab_dsa_gainlen':{'muxSel': 13, 'description': '', 'funcName': 'intpi_rxab_dsa_gainlen'},
				'rxab_dsa_gain_4':{'muxSel': 10, 'description': '', 'funcName': 'intpi_rxab_dsa_gain_4'},
				'rxab_dsa_gain_5':{'muxSel': 11, 'description': '', 'funcName': 'intpi_rxab_dsa_gain_5'},
				'rxab_dsa_gain_2':{'muxSel': 8, 'description': '', 'funcName': 'intpi_rxab_dsa_gain_2'},
				'rxab_dsa_gain_3':{'muxSel': 9, 'description': '', 'funcName': 'intpi_rxab_dsa_gain_3'},
				'rxab_dsa_gain_0':{'muxSel': 6, 'description': '', 'funcName': 'intpi_rxab_dsa_gain_0'},
				'rxab_dsa_gain_1':{'muxSel': 7, 'description': '', 'funcName': 'intpi_rxab_dsa_gain_1'}},
	
			'EXTAGC_GPIOMode2':{
				'rxd_dsa_gain_2':{'muxSel': 33, 'description': '', 'funcName': 'intpi_rxd_dsa_gain_2'},
				'rxd_dsa_gain_0':{'muxSel': 31, 'description': '', 'funcName': 'intpi_rxd_dsa_gain_0'},
				'rxa_dsa_gain_1':{'muxSel': 23, 'description': '', 'funcName': 'intpi_rxa_dsa_gain_1'},
				'rxd_dsa_gain_1':{'muxSel': 32, 'description': '', 'funcName': 'intpi_rxd_dsa_gain_1'},
				'rxa_dsa_gain_0':{'muxSel': 22, 'description': '', 'funcName': 'intpi_rxa_dsa_gain_0'},
				'rxc_dsa_gain_2':{'muxSel': 30, 'description': '', 'funcName': 'intpi_rxc_dsa_gain_2'},
				'rxb_dsa_gain_2':{'muxSel': 27, 'description': '', 'funcName': 'intpi_rxb_dsa_gain_2'},
				'rxa_dsa_gain_2':{'muxSel': 24, 'description': '', 'funcName': 'intpi_rxa_dsa_gain_2'},
				'rxb_dsa_gain_0':{'muxSel': 25, 'description': '', 'funcName': 'intpi_rxb_dsa_gain_0'},
				'rxb_dsa_gain_1':{'muxSel': 26, 'description': '', 'funcName': 'intpi_rxb_dsa_gain_1'},
				'rxc_dsa_gain_1':{'muxSel': 29, 'description': '', 'funcName': 'intpi_rxc_dsa_gain_1'},
				'rxc_dsa_gain_0':{'muxSel': 28, 'description': '', 'funcName': 'intpi_rxc_dsa_gain_0'}},
	}
	
	
	gpioList = {
			'D14':{
				'gpioNo':78},
	
			'D15':{
				'gpioNo':20},
	
			'D16':{
				'gpioNo':24},
	
			'D10':{
				'gpioNo':64},
	
			'D11':{
				'gpioNo':68},
	
			'D12':{
				'gpioNo':70},
	
			'E18':{
				'gpioNo':28},
	
			'U5':{
				'gpioNo':57},
	
			'U7':{
				'gpioNo':41},
	
			'U6':{
				'gpioNo':45},
	
			'E17':{
				'gpioNo':22},
	
			'E16':{
				'gpioNo':21},
	
			'U18':{
				'gpioNo':4},
	
			'T16':{
				'gpioNo':9},
	
			'T17':{
				'gpioNo':2},
	
			'B18':{
				'gpioNo':32},
	
			'C12':{
				'gpioNo':79},
	
			'U11':{
				'gpioNo':44},
	
			'U10':{
				'gpioNo':50},
	
			'U13':{
				'gpioNo':40},
	
			'U12':{
				'gpioNo':55},
	
			'U15':{
				'gpioNo':0},
	
			'C11':{
				'gpioNo':66},
	
			'U17':{
				'gpioNo':1},
	
			'U16':{
				'gpioNo':17},
	
			'R17':{
				'gpioNo':6},
	
			'C10':{
				'gpioNo':62},
	
			'T18':{
				'gpioNo':5},
	
			'D13':{
				'gpioNo':35},
	
			'A18':{
				'gpioNo':30},
	
			'R18':{
				'gpioNo':7},
	
			'U14':{
				'gpioNo':3},
	
			'C9':{
				'gpioNo':60},
	
			'C8':{
				'gpioNo':75},
	
			'A5':{
				'gpioNo':72},
	
			'V5':{
				'gpioNo':48},
	
			'V6':{
				'gpioNo':43},
	
			'V7':{
				'gpioNo':56},
	
			'V8':{
				'gpioNo':54},
	
			'V9':{
				'gpioNo':52},
	
			'C17':{
				'gpioNo':27},
	
			'C14':{
				'gpioNo':25},
	
			'C7':{
				'gpioNo':71},
	
			'C6':{
				'gpioNo':67},
	
			'C5':{
				'gpioNo':76},
	
			'R5':{
				'gpioNo':59},
	
			'C13':{
				'gpioNo':26},
	
			'T5':{
				'gpioNo':58},
	
			'E13':{
				'gpioNo':77},
	
			'E5':{
				'gpioNo':63},
	
			'F18':{
				'gpioNo':23},
	
			'Y18':{
				'gpioNo':10},
	
			'T13':{
				'gpioNo':8},
	
			'F17':{
				'gpioNo':29},
	
			'V18':{
				'gpioNo':18},
	
			'F5':{
				'gpioNo':65},
	
			'W18':{
				'gpioNo':13},
	
			'V12':{
				'gpioNo':53},
	
			'V13':{
				'gpioNo':51},
	
			'V10':{
				'gpioNo':46},
	
			'V11':{
				'gpioNo':42},
	
			'V16':{
				'gpioNo':12},
	
			'V17':{
				'gpioNo':15},
	
			'V14':{
				'gpioNo':14},
	
			'V15':{
				'gpioNo':11},
	
			'B5':{
				'gpioNo':74},
	
			'W5':{
				'gpioNo':49},
	
			'D6':{
				'gpioNo':69},
	
			'D7':{
				'gpioNo':73},
	
			'D5':{
				'gpioNo':61},
	
			'Y5':{
				'gpioNo':47},
	}
	
	
	fixedFuncToBallName = {
			'adc_sync_n_ab_1':{
				'ballName':'U5',
				'preferredSel':0},
	
			'spib1_clk':{
				'ballName':'U16',
				'preferredSel':0},
	
			'tdd_1f_en_cd':{
				'ballName':'E13',
				'preferredSel':0},
	
			'rxcd_dsa_gainsel':{
				'ballName':'C12',
				'preferredSel':1},
	
			'fspid_clk':{
				'ballName':'C6',
				'preferredSel':0},
	
			'dac_sync_n_cd_1':{
				'ballName':'B5',
				'preferredSel':0},
	
			'dac_sync_n_cd_0':{
				'ballName':'A5',
				'preferredSel':0},
	
			'fspic_data_in':{
				'ballName':'C8',
				'preferredSel':0},
	
			'adc_sync_n_ab_0':{
				'ballName':'V5',
				'preferredSel':0},
	
			'rxa_dsa_gain_2':{
				'ballName':'U6',
				'preferredSel':2},
	
			'rxa_dsa_gain_1':{
				'ballName':'U11',
				'preferredSel':2},
	
			'rxa_dsa_gain_0':{
				'ballName':'V6',
				'preferredSel':2},
	
			'tx2dsa_gain_sw_rxtxlo':{
				'ballName':'D13',
				'preferredSel':0},
	
			'spib2_cs_n':{
				'ballName':'R18',
				'preferredSel':0},
	
			'rxab_dsa_gain_5':{
				'ballName':'Y5',
				'preferredSel':1},
	
			'rxab_dsa_gain_2':{
				'ballName':'V8',
				'preferredSel':1},
	
			'rxab_dsa_gain_3':{
				'ballName':'U6',
				'preferredSel':1},
	
			'rxab_dsa_gain_0':{
				'ballName':'V6',
				'preferredSel':1},
	
			'rxab_dsa_gain_1':{
				'ballName':'U11',
				'preferredSel':1},
	
			'fspia_clk':{
				'ballName':'U10',
				'preferredSel':0},
	
			'rxa_digpkdet_hth':{
				'ballName':'V12',
				'preferredSel':0},
	
			'fspid_data_in':{
				'ballName':'D6',
				'preferredSel':0},
	
			'fspib_data_in':{
				'ballName':'U6',
				'preferredSel':0},
	
			'rxcd_dsa_gainlen':{
				'ballName':'C10',
				'preferredSel':1},
	
			'rel_status_c_0':{
				'ballName':'E5',
				'preferredSel':1},
	
			'rxa_alc_out_1':{
				'ballName':'U11',
				'preferredSel':1},
	
			'rxa_alc_out_0':{
				'ballName':'V9',
				'preferredSel':1},
	
			'rxa_alc_out_3':{
				'ballName':'V12',
				'preferredSel':1},
	
			'rxa_alc_out_2':{
				'ballName':'U12',
				'preferredSel':1},
	
			'rxa_ext_lnabypass':{
				'ballName':'V11',
				'preferredSel':0},
	
			'rel_status_a_0':{
				'ballName':'T5',
				'preferredSel':1},
	
			'global_pdn':{
				'ballName':'E16',
				'preferredSel':0},
	
			'tdd_2r_en_cd':{
				'ballName':'C13',
				'preferredSel':0},
	
			'rxab_dsa_gainsel':{
				'ballName':'W5',
				'preferredSel':1},
	
			'rxc_dsa_gain_1':{
				'ballName':'D11',
				'preferredSel':2},
	
			'rxc_dsa_gain_0':{
				'ballName':'C6',
				'preferredSel':2},
	
			'rxc_dsa_gain_2':{
				'ballName':'D6',
				'preferredSel':2},
	
			'rxb_ext_lnabypass':{
				'ballName':'V10',
				'preferredSel':0},
	
			'fspic_clk':{
				'ballName':'C10',
				'preferredSel':0},
	
			'tx_fb_loop_1':{
				'ballName':'U18',
				'preferredSel':0},
	
			'tx_fb_loop_0':{
				'ballName':'V18',
				'preferredSel':0},
	
			'tx_fb_loop_3':{
				'ballName':'U17',
				'preferredSel':0},
	
			'tx_fb_loop_2':{
				'ballName':'T18',
				'preferredSel':0},
	
			'rxb_digpkdet_hth':{
				'ballName':'V9',
				'preferredSel':0},
	
			'fspib_clk':{
				'ballName':'V6',
				'preferredSel':0},
	
			'intbipi_spib1_sdi':{
				'ballName':'V16',
				'preferredSel':0},
	
			'rxb_alc_out_2':{
				'ballName':'U7',
				'preferredSel':1},
	
			'rxb_alc_out_3':{
				'ballName':'V7',
				'preferredSel':1},
	
			'rxb_alc_out_1':{
				'ballName':'T5',
				'preferredSel':0},
	
			'rxd_ext_lnabypass':{
				'ballName':'D10',
				'preferredSel':0},
	
			'adc_sync_n_cd_1':{
				'ballName':'D5',
				'preferredSel':0},
	
			'adc_sync_n_cd_0':{
				'ballName':'C5',
				'preferredSel':0},
	
			'tdd_2r_en_ab':{
				'ballName':'V13',
				'preferredSel':0},
	
			'rxc_digpkdet_hth':{
				'ballName':'C12',
				'preferredSel':0},
	
			'intbipo_spib1_sdo':{
				'ballName':'V16',
				'preferredSel':0},
	
			'intbipi_spib2_sdi':{
				'ballName':'R17',
				'preferredSel':0},
	
			'fb_nco_sw':{
				'ballName':'D15',
				'preferredSel':0},
	
			'rxd_dsa_gain_0':{
				'ballName':'D7',
				'preferredSel':2},
	
			'rxd_dsa_gain_1':{
				'ballName':'C8',
				'preferredSel':2},
	
			'rxd_dsa_gain_2':{
				'ballName':'C12',
				'preferredSel':2},
	
			'rxab_dsa_gain_4':{
				'ballName':'V10',
				'preferredSel':1},
	
			'rxd_alc_out_1':{
				'ballName':'E5',
				'preferredSel':0},
	
			'dac_sync_n_ab_1':{
				'ballName':'W5',
				'preferredSel':0},
	
			'dac_sync_n_ab_0':{
				'ballName':'Y5',
				'preferredSel':0},
	
			'fspia_data_in':{
				'ballName':'V8',
				'preferredSel':0},
	
			'spib1_sdo':{
				'ballName':'V15',
				'preferredSel':0},
	
			'rel_status_d_0':{
				'ballName':'F5',
				'preferredSel':1},
	
			'spib2_clk':{
				'ballName':'T17',
				'preferredSel':0},
	
			'rxc_alc_out_3':{
				'ballName':'C12',
				'preferredSel':1},
	
			'rxb_dsa_gain_2':{
				'ballName':'W5',
				'preferredSel':2},
	
			'rxb_dsa_gain_0':{
				'ballName':'V10',
				'preferredSel':2},
	
			'rxb_dsa_gain_1':{
				'ballName':'Y5',
				'preferredSel':2},
	
			'rxd_alc_out_0':{
				'ballName':'F5',
				'preferredSel':0},
	
			'rxc_alc_out_2':{
				'ballName':'D12',
				'preferredSel':1},
	
			'rxd_alc_out_2':{
				'ballName':'D7',
				'preferredSel':1},
	
			'rxc_alc_out_0':{
				'ballName':'C9',
				'preferredSel':1},
	
			'rxc_alc_out_1':{
				'ballName':'C11',
				'preferredSel':1},
	
			'spib1_cs_n':{
				'ballName':'V14',
				'preferredSel':0},
	
			'rxd_alc_out_3':{
				'ballName':'C7',
				'preferredSel':1},
	
			'intbipo_spib2_sdo':{
				'ballName':'R17',
				'preferredSel':0},
	
			'rxc_ext_lnabypass':{
				'ballName':'D11',
				'preferredSel':0},
	
			'tdd_1f_en_ab':{
				'ballName':'T13',
				'preferredSel':0},
	
			'rxd_digpkdet_hth':{
				'ballName':'C9',
				'preferredSel':0},
	
			'alarm_1':{
				'ballName':'C17',
				'preferredSel':0},
	
			'alarm_2':{
				'ballName':'E17',
				'preferredSel':0},
	
			'spib2_sdo':{
				'ballName':'T16',
				'preferredSel':0},
	
			'tx1dsa_gain_sw_rxtxlo':{
				'ballName':'U13',
				'preferredSel':0},
	
			'tdd_2t_en_ab':{
				'ballName':'U14',
				'preferredSel':0},
	
			'rxcd_dsa_gain_2':{
				'ballName':'D6',
				'preferredSel':1},
	
			'rxcd_dsa_gain_3':{
				'ballName':'D12',
				'preferredSel':1},
	
			'rxcd_dsa_gain_0':{
				'ballName':'C6',
				'preferredSel':1},
	
			'rxcd_dsa_gain_1':{
				'ballName':'D11',
				'preferredSel':1},
	
			'rxcd_dsa_gain_4':{
				'ballName':'D7',
				'preferredSel':1},
	
			'rxcd_dsa_gain_5':{
				'ballName':'C8',
				'preferredSel':1},
	
			'rxab_dsa_gainlen':{
				'ballName':'U10',
				'preferredSel':1},
	
			'tdd_2t_en_cd':{
				'ballName':'D14',
				'preferredSel':0},
	}
	
	
	#supportedBallNames=[u'C17', u'C13', u'C14', u'D16', u'F18', u'E17', u'E16', u'D15', u'F17', u'E18', u'D5', u'C9', u'E5', u'C10', u'F5', u'D10', u'C6', u'C11', u'D6', u'D11', u'T16', u'V14', u'U16', u'V15', u'Y18', u'W18', u'V16', u'V17', u'V18', u'C12', u'D14', u'C8', u'B5', u'E13', u'C5', u'C7', u'D12', u'D7', u'A5', u'V6', u'V11', u'U7', u'U13', u'Y5', u'V10', u'U6', u'U11', u'W5', u'V5', u'U17', u'U15', u'R5', u'T5', u'T18', u'U18', u'R18', u'R17', u'V12', u'V9', u'V13', u'U10', u'U5', u'V7', u'U12', u'V8', u'U14', u'T17', u'T13', u'B18', u'A18', u'D13']
	supportedBallNames=[u'C17', u'C13', u'F18', u'E17', u'E16', u'D15', u'F17', u'E18', u'D5', u'C9', u'E5', u'C10', u'F5', u'D10', u'C6', u'C11', u'D6', u'D11', u'T16', u'V14', u'U16', u'V15', u'Y18', u'W18', u'V16', u'V18', u'C12', u'D14', u'C8', u'B5', u'E13', u'C5', u'C7', u'D12', u'D7', u'A5', u'V6', u'V11', u'U7', u'U13', u'Y5', u'V10', u'U6', u'U11', u'W5', u'V5', u'U17', u'U15', u'R5', u'T5', u'T18', u'U18', u'R18', u'R17', u'V12', u'V9', u'V13', u'U10', u'U5', u'V7', u'U12', u'V8', u'U14', u'T17', u'T13', u'D13']
	
	
	gpioExternalAgcMode={'A18': 'NA',
						'A5': 'dac_sync_n_cd_0',
						'B18': 'NA',
						'B5': 'dac_sync_n_cd_1',
						'C10': 'fspic_clk',
						'C11': 'intpo_rxc_digpkdet_hth',
						'C12': 'intpo_rxc_rfpkdet_lth',
						'C13': 'tdd_2r_en_cd',
						'C14': 'SPISEN',
						'C15': 'SPISDO',
						'C16': 'SPISDIO',
						'C17': 'alarm_1',
						'C5': 'adc_sync_n_cd_0',
						'C6': 'fspid_clk',
						'C7': 'rxd_rfpkdet_lth',
						'C8': 'fspic_data_in',
						'C9': 'rxd_digpkdet_hth',
						'D10': 'rxd_ext_lnabypass',
						'D11': 'rxc_ext_lnabypass',
						'D12': 'intpo_rxc_rfpkdet_hth',
						'D13': 'tx2dsa_gain_sw_rxtxlo',
						'D14': 'tdd_2t_en_cd',
						'D15': 'fb_nco_sw',
						'D16': 'SPICLK',
						'D5': 'adc_sync_n_cd_1',
						'D6': 'fspid_data_in',
						'D7': 'rxd_rfpkdet_hth',
						'E13': 'tdd_1f_en_cd',
						'E16': 'global_pdn',
						'E17': 'alarm_2',
						'E18': 'NA',
						'E5': 'rel_status_c_0',
						'F17': 'NA',
						'F18': 'NA',
						'F5': 'rel_status_d_0',
						'R17': 'spib2_sdi',
						'R18': 'spib2_cs_n',
						'R5': 'intpo_rel_status_b_0',
						'T13': 'tdd_1f_en_ab',
						'T16': 'spib2_sdo',
						'T17': 'spib2_clk',
						'T18': 'tx_fb_loop_2',
						'T5': 'rel_status_a_0',
						'U10': 'fspia_clk',
						'U11': 'intpo_rxa_digpkdet_hth',
						'U12': 'rxa_rfpkdet_lth',
						'U13': 'tx1dsa_gain_sw_rxtxlo',
						'U14': 'tdd_2t_en_ab',
						'U15': 'intpi_rxdsa_gain_sw',
						'U16': 'spib1_clk',
						'U17': 'tx_fb_loop_3',
						'U18': 'tx_fb_loop_1',
						'U5': 'adc_sync_n_ab_1',
						'U6': 'fspib_data_in',
						'U7': 'intpo_rxb_rfpkdet_lth',
						'V10': 'rxb_ext_lnabypass',
						'V11': 'rxa_ext_lnabypass',
						'V12': 'intpo_rxa_rfpkdet_hth',
						'V13': 'tdd_2r_en_ab',
						'V14': 'spib1_cs_n',
						'V15': 'spib1_sdo',
						'V16': 'spib1_sdi',
						'V17': 'NA',
						'V18': 'tx_fb_loop_0',
						'V5': 'adc_sync_n_ab_0',
						'V6': 'fspib_clk',
						'V7': 'intpo_rxb_rfpkdet_hth',
						'V8': 'fspia_data_in',
						'V9': 'rxb_digpkdet_hth',
						'W18': 'NA',
						'W5': 'dac_sync_n_ab_1',
						'Y18': 'NA',
						'Y5': 'dac_sync_n_ab_0'}
	
	
	gpioInternalAgcMode={'A5': 'dac_sync_n_cd_0',
				'B5': 'dac_sync_n_cd_1',
				'C10': 'NA',
				'C11': 'rxc_alc_out_1',
				'C12': 'rxc_alc_out_3',
				'C13': 'tdd_2r_en_cd',
				'C14': 'SPISEN',
				'C15': 'SPISDO',
				'C16': 'SPISDIO',
				'C17': 'alarm_1',
				'C5': 'adc_sync_n_cd_0',
				'C6': 'NA',
				'C7': 'rxd_alc_out_3',
				'C8': 'NA',
				'C9': 'rxc_alc_out_0',
				'D10': 'rxd_ext_lnabypass',
				'D11': 'rxc_ext_lnabypass',
				'D12': 'rxc_alc_out_2',
				'D13': 'tx2dsa_gain_sw_rxtxlo',
				'D14': 'tdd_2t_en_cd',
				'D15': 'fb_nco_sw',
				'D16': 'SPICLK',
				'D5': 'adc_sync_n_cd_1',
				'D6': 'NA',
				'D7': 'rxd_alc_out_2',
				'E13': 'tdd_1f_en_cd',
				'E16': 'global_pdn',
				'E17': 'alarm_2',
				'E18': 'NA',
				'E5': 'rxd_alc_out_1',
				'F17': 'NA',
				'F18': 'NA',
				'F5': 'rxd_alc_out_0',
				'R17': 'spib2_sdi',
				'R18': 'spib2_cs_n',
				'R5': 'intpo_rxb_alc_out_0',
				'T13': 'tdd_1f_en_ab',
				'T16': 'spib2_sdo',
				'T17': 'spib2_clk',
				'T18': 'tx_fb_loop_2',
				'T5': 'rxb_alc_out_1',
				'U10': 'NA',
				'U11': 'rxa_alc_out_1',
				'U12': 'rxa_alc_out_2',
				'U13': 'tx1dsa_gain_sw_rxtxlo',
				'U14': 'tdd_2t_en_ab',
				'U15': 'intpi_rxdsa_gain_sw',
				'U16': 'spib1_clk',
				'U17': 'tx_fb_loop_3',
				'U18': 'tx_fb_loop_1',
				'U5': 'adc_sync_n_ab_1',
				'U6': 'NA',
				'U7': 'rxb_alc_out_2',
				'V10': 'rxb_ext_lnabypass',
				'V11': 'rxa_ext_lnabypass',
				'V12': 'rxa_alc_out_3',
				'V13': 'tdd_2r_en_ab',
				'V14': 'spib1_cs_n',
				'V15': 'spib1_sdo',
				'V16': 'spib1_sdi',
				'V17': 'NA',
				'V18': 'tx_fb_loop_0',
				'V5': 'adc_sync_n_ab_0',
				'V6': 'NA',
				'V7': 'rxb_alc_out_3',
				'V8': 'NA',
				'V9': 'rxa_alc_out_0',
				'W18': 'NA',
				'W5': 'dac_sync_n_ab_1',
				'Y18': 'NA',
				'Y5': 'dac_sync_n_ab_0'}
	
	gpioCustomMode={'D14': 'tdd_2t_en_ab',
			 'D15': 'fb_nco_sw',
			 'D16': 'NC',
			 'D10': 'rxa_dsa_gain_0',
			 'D11': 'rxc_ext_lnabypass',
			 'D12': 'rxa_digpkdet_hth',
			 'E18': 'NC',
			 'U5': 'adc_sync_n_ab_1',
			 'E13': 'tdd_1f_en_cd',
			 'U6': 'rxc_dsa_gain_0',
			 'E17': 'alarm_2',
			 'E16': 'global_pdn',
			 'U18': 'tx_fb_loop_1',
			 'T16': 'spib2_sdo',
			 'T17': 'spib2_clk',
			 'T13': 'tdd_1f_en_ab',
			 'C13': 'tdd_2r_en_ab',
			 'U10': 'rxd_dsa_gain_0',
			 'U13': 'tx1dsa_gain_sw_rxtxlo',
			 'C10': 'rxa_dsa_gain_1',
			 'U15': 'rxdsa_gain_sw',
			 'U14': 'tdd_2t_en_cd',
			 'U17': 'spib2_cs_n',
			 'U16': 'spib1_clk',
			 'R17': 'intbipi_spib2_sdi',
			 'U11': 'rxa_digpkdet_hth',
			 'T18': 'tx_fb_loop_2',
			 'D13': 'tx2dsa_gain_sw_rxtxlo',
			 'A18': 'NC',
			 'R18': 'spib2_cs_n',
			 'C9': 'rxd_digpkdet_hth',
			 'A5': 'dac_sync_n_cd_0',
			 'B18': 'NC',
			 'V6': 'rxc_dsa_gain_1',
			 'V7': 'rxc_digpkdet_hth',
			 'V8': 'fspia_data_in',
			 'V9': 'rxb_digpkdet_hth',
			 'C17': 'alarm_1',
			 'C14': 'NC',
			 'C6': 'rxb_dsa_gain_1',
			 'C5': 'adc_sync_n_cd_0',
			 'V5': 'adc_sync_n_ab_0',
			 'R5': 'rel_status_c_0',
			 'T5': 'rel_status_d_0',
			 'E5': 'rel_status_a_0',
			 'F18': 'NC',
			 'Y18': 'NC',
			 'F17': 'NC',
			 'V18': 'tx_fb_loop_0',
			 'F5': 'rel_status_b_0',
			 'W18': 'NC',
			 'V12': 'rxd_digpkdet_hth',
			 'V13': 'tdd_2r_en_cd',
			 'V10': 'rxd_dsa_gain_1',
			 'V11': 'rxa_ext_lnabypass',
			 'V16': 'intbipi_spib1_sdi',
			 'V17': 'NC',
			 'V14': 'spib1_cs_n',
			 'V15': 'spib1_sdo',
			 'B5': 'dac_sync_n_cd_1',
			 'W5': 'dac_sync_n_ab_1',
			 'D6': 'rxb_dsa_gain_0',
			 'D7': 'rxb_digpkdet_hth',
			 'D5': 'adc_sync_n_cd_1',
			 'Y5': 'dac_sync_n_ab_0',
			 'C11': 'rxc_digpkdet_hth'}		 
	
	
	
	#gpioConstants
