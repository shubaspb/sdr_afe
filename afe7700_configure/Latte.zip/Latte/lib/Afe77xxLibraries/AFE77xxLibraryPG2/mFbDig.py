from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import random
import math

class fbDigLib(projectBaseClass):
	"""Contains FB DIG specific functions. self.regs=device.FB.FB_DIG.FB_DIG """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
		#__init__
		
		
	@funcDecorator
	def setNcoWord(self,ncoFreq):
		""" "Set FB NCO Word" """
		ncoFreqWord=int(round(ncoFreq*2**32/self.systemParams.Fs))
		ncoFreq=ncoFreqWord*self.systemParams.Fs*1.0/(2**32)
		info("Set FB "+str(self.topno)+" to Freq(MHz): "+str(ncoFreq))
		self.systemParams.fbNco[self.topno]=ncoFreq
		self.regs.Register9719_104h.Property_104h_31_0=ncoFreqWord&(2**32-1)
		#setNcoWord
		
	@funcDecorator
	def configFbDig(self):
		""" "Configuring the FB Digital" "Done configuring the FB Digital" """  
		decimMode      =self.systemParams.ddcFactorFb[self.topno]
		halfRateMode   =self.systemParams.halfRateModeFb
		
		self.regs.Register9708_178h.Property_160h_24_24=0
		self.regs.Register9708_178h.Property_160h_25_25=0
		self.regs.Register9708_178h.Property_160h_26_26=0
		self.regs.Register9708_178h.Property_160h_27_27=0
		self.regs.Register9708_178h.Property_160h_28_28=0
		self.regs.Register9708_178h.Property_160h_29_29=0
		
		if self.systemParams.ddcFactorFb[self.topno]!=1:
			self.regs.Register9678_121h.Property_16ch_1_0=0
		else:
			self.regs.Register9678_121h.Property_16ch_1_0=2
			
		(found,(stage1Setting,stage2Setting,stage3Setting,stage3p5Setting))=self.checkValidityOfDigChain(1,decimMode,halfRateMode)
		if found==False and self.systemParams.ddcFactorFb[self.topno]!=1:
			error(r"Didnt find the Correct Setting for Fb Decim chain: "+str(decimMode))
			
		self.regs.Register9678_121h.Property_120h_8_8=(2,1).index(stage1Setting)
		self.regs.Register9678_121h.Property_120h_9_9=(2.0,3.0).index(stage2Setting)
		self.regs.Register9678_121h.Property_120h_11_10=(1.0,1.0,round(7.0/6,4),round(9.0/8,4)).index(round(stage3Setting,4))		
		self.regs.Register9678_121h.Property_120h_12_12=(2,1).index(stage3p5Setting)
		
		self.regs.Register9678_121h.Property_120h_0_0=halfRateMode
		self.setNcoWord(self.systemParams.fbNco[self.topno])
		
		self.regs.Register9695_15Ah.Property_158h_20_16=0
		self.regs.Register9695_15Ah.Property_170h_7_5=7
		if self.systemStatus.chipVersion>0x10:
			self.regs.Register9695_15Ah.Property_158h_26_24=3
		else:
			self.regs.Register9695_15Ah.Property_158h_26_24=2
			
		self.regs.Register9704_174h.Property_174h_28_0=527284091
		self.regs.Register9704_174h.Property_174h_29_29=0
		self.regs.Register9704_174h.Property_174h_29_29=1
		self.regs.Register9704_174h.Property_174h_29_29=0
		#self.regs.Register9836_1BCh.Property_124h_24_24=0
		self.regs.Register9721_108h.Property_108h_6_0=0
		self.regs.Register9721_108h.Property_108h_10_8=0
		self.regs.Register9721_108h.Property_108h_24_16=0
		self.regs.Register9721_108h.Property_10ch_0_0=0
		self.regs.Register9676_100h.Property_100h_31_0=0
		#configFbDig
		
		
	@funcDecorator
	def setFbDigGain(self,enable,digGain):
		device.FB[0].FB_DIG.FB_DIG.Register9824_124h.Property_124h_0_0=enable
		device.FB[0].FB_DIG.FB_DIG.Register9824_124h.Property_124h_8_8=enable
		if digGain<-3:
			device.FB[0].FB_DIG.FB_DIG.Register9824_124h.Property_124h_19_16=(2*digGain)+17
			device.FB[0].FB_DIG.FB_DIG.Register9836_1BCh.Property_124h_24_24=1
		else:
			device.FB[0].FB_DIG.FB_DIG.Register9824_124h.Property_124h_19_16=(2*digGain)+5
			device.FB[0].FB_DIG.FB_DIG.Register9836_1BCh.Property_124h_24_24=0
			#setFbDigGain
			
			#fbDigLib
