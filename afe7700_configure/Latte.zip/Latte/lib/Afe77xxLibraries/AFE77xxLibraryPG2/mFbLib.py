from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *

import mFbAna
reload(mFbAna)
from mFbAna import fbAnaLib

import mFbDig
reload(mFbDig)
from mFbDig import fbDigLib

import mFbEcDig
reload(mFbEcDig)
from mFbEcDig import fbEcDigLib

class fbLib(projectBaseClass):
	"""Contains FB specific functions. self.regs=device.FB"""
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.FBANA=fbAnaLib(topno,regs.FB_ANA,deviceRefs)
		self.FBDIG=fbDigLib(topno,regs.FB_DIG.FB_DIG,deviceRefs)
		self.FBECDIG=fbEcDigLib(topno,regs.FB_EC_DIG,deviceRefs)
		
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
					
					#__init__
					
					
					#fbLib
