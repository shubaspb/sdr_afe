from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class dsaController(projectBaseClass):
	"""Contains DSA Controller specific functions. self.regs=device.TOP.DSA_CNTRL """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
		self.rxDsaRcCodes=[32736,32545,32386,32291,32196,32133,32070,32039,30984,30953,31946,31915,31884,31885,31854,31855,29808,27761,24690,21619,18548,6261,2166,119,120,4185,90,91,92,19517,15422,15422,15422,15422,15422,15422,15422]
		#__init__
		
		
	@funcDecorator
	def setTxDsa(self,chNo,dsa_setting):
		""" "Setting TX DSA Attenuation" "Done setting TX DSA Attenuation" """
		if chNo==0:
			self.regs.TX_DSA_CTRL.Register6707_100h.spi_dsa=dsa_setting
			self.regs.TX_DSA_CTRL.Register6707_100h.index_update=0
			self.regs.TX_DSA_CTRL.Register6707_100h.index_update=1
			self.regs.TX_DSA_CTRL.Register6707_100h.index_update=0
		else:
			self.regs.TX_DSA_CTRL.Register6728_120h.spi_dsa=dsa_setting
			self.regs.TX_DSA_CTRL.Register6728_120h.index_update=0
			self.regs.TX_DSA_CTRL.Register6728_120h.index_update=1
			self.regs.TX_DSA_CTRL.Register6728_120h.index_update=0
			#setTxDsa
			
	@funcDecorator
	def setRxDsa(self,chNo,dsa_setting):
		if chNo==0:
			self.regs.RX_DSA_CTRL.Register5991_50h.spi_agc_dsa=dsa_setting
		else:
			self.regs.RX_DSA_CTRL.Register6008_B0h.spi_agc_dsa=dsa_setting
			#setRxDsa
			
	@funcDecorator
	def setFbDsa(self,dsa_setting):
		self.regs.FB_DSA_CTRL.Register7013_150h.spi_dsa=dsa_setting
		#setFbDsa
		
	@funcDecorator
	def rxDsaCodesPopulate(self):
		a=self.rxDsaRcCodes
		self.regs.RX_DSA_LUT.Register6220_671h.Property_674h_27_0 = (a[0] & 0x3FF) + ((a[0] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_678h_27_0 = (a[1] & 0x3FF) + ((a[1] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_67ch_27_0 = (a[2] & 0x3FF) + ((a[2] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_680h_27_0 = (a[3] & 0x3FF) + ((a[3] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_684h_27_0 = (a[4] & 0x3FF) + ((a[4] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_688h_27_0 = (a[5] & 0x3FF) + ((a[5] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_68ch_27_0 = (a[6] & 0x3FF) + ((a[6] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_690h_27_0 = (a[7] & 0x3FF) + ((a[7] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_694h_27_0 = (a[8] & 0x3FF) + ((a[8] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_698h_27_0 = (a[9] & 0x3FF) + ((a[9] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_69ch_27_0 = (a[10] & 0x3FF) + ((a[10] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6a0h_27_0 = (a[11] & 0x3FF) + ((a[11] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6a4h_27_0 = (a[12] & 0x3FF) + ((a[12] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6a8h_27_0 = (a[13] & 0x3FF) + ((a[13] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6ach_27_0 = (a[14] & 0x3FF) + ((a[14] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6b0h_27_0 = (a[15] & 0x3FF) + ((a[15] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6b4h_27_0 = (a[16] & 0x3FF) + ((a[16] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6b8h_27_0 = (a[17] & 0x3FF) + ((a[17] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6bch_27_0 = (a[18] & 0x3FF) + ((a[18] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6c0h_27_0 = (a[19] & 0x3FF) + ((a[19] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6c4h_27_0 = (a[20] & 0x3FF) + ((a[20] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6c8h_27_0 = (a[21] & 0x3FF) + ((a[21] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6cch_27_0 = (a[22] & 0x3FF) + ((a[22] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6d0h_27_0 = (a[23] & 0x3FF) + ((a[23] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6d4h_27_0 = (a[24] & 0x3FF) + ((a[24] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6d8h_27_0 = (a[25] & 0x3FF) + ((a[25] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6dch_27_0 = (a[26] & 0x3FF) + ((a[26] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6e0h_27_0 = (a[27] & 0x3FF) + ((a[27] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6e4h_27_0 = (a[28] & 0x3FF) + ((a[28] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6e8h_27_0 = (a[29] & 0x3FF) + ((a[29] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6ech_27_0 = (a[30] & 0x3FF) + ((a[30] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6f0h_27_0 = (a[31] & 0x3FF) + ((a[31] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6f4h_27_0 = (a[32] & 0x3FF) + ((a[32] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6f8h_27_0 = (a[33] & 0x3FF) + ((a[33] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_6fch_27_0 = (a[34] & 0x3FF) + ((a[34] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_700h_27_0 = (a[35] & 0x3FF) + ((a[35] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6220_671h.Property_704h_27_0 = (a[36] & 0x3FF) + ((a[36] & 0x3FC00)<<10)
		
		self.regs.RX_DSA_LUT.Register6181_311h.Property_314h_27_0 = (a[0] & 0x3FF) + ((a[0] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_318h_27_0 = (a[1] & 0x3FF) + ((a[1] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_31ch_27_0 = (a[2] & 0x3FF) + ((a[2] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_320h_27_0 = (a[3] & 0x3FF) + ((a[3] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_324h_27_0 = (a[4] & 0x3FF) + ((a[4] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_328h_27_0 = (a[5] & 0x3FF) + ((a[5] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_32ch_27_0 = (a[6] & 0x3FF) + ((a[6] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_330h_27_0 = (a[7] & 0x3FF) + ((a[7] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_334h_27_0 = (a[8] & 0x3FF) + ((a[8] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_338h_27_0 = (a[9] & 0x3FF) + ((a[9] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_33ch_27_0 = (a[10] & 0x3FF) + ((a[10] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_340h_27_0 = (a[11] & 0x3FF) + ((a[11] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_344h_27_0 = (a[12] & 0x3FF) + ((a[12] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_348h_27_0 = (a[13] & 0x3FF) + ((a[13] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_34ch_27_0 = (a[14] & 0x3FF) + ((a[14] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_350h_27_0 = (a[15] & 0x3FF) + ((a[15] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_354h_27_0 = (a[16] & 0x3FF) + ((a[16] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_358h_27_0 = (a[17] & 0x3FF) + ((a[17] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_35ch_27_0 = (a[18] & 0x3FF) + ((a[18] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_360h_27_0 = (a[19] & 0x3FF) + ((a[19] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_364h_27_0 = (a[20] & 0x3FF) + ((a[20] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_368h_27_0 = (a[21] & 0x3FF) + ((a[21] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_36ch_27_0 = (a[22] & 0x3FF) + ((a[22] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_370h_27_0 = (a[23] & 0x3FF) + ((a[23] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_374h_27_0 = (a[24] & 0x3FF) + ((a[24] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_378h_27_0 = (a[25] & 0x3FF) + ((a[25] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_37ch_27_0 = (a[26] & 0x3FF) + ((a[26] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_380h_27_0 = (a[27] & 0x3FF) + ((a[27] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_384h_27_0 = (a[28] & 0x3FF) + ((a[28] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_388h_27_0 = (a[29] & 0x3FF) + ((a[29] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_38ch_27_0 = (a[30] & 0x3FF) + ((a[30] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_390h_27_0 = (a[31] & 0x3FF) + ((a[31] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_394h_27_0 = (a[32] & 0x3FF) + ((a[32] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_398h_27_0 = (a[33] & 0x3FF) + ((a[33] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_39ch_27_0 = (a[34] & 0x3FF) + ((a[34] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_3a0h_27_0 = (a[35] & 0x3FF) + ((a[35] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register6181_311h.Property_3a4h_27_0 = (a[36] & 0x3FF) + ((a[36] & 0x3FC00)<<10)
		#rxDsaCodesPopulate
		
	@funcDecorator
	def setGainControl(self,gainCntrl):
		self.regs.RX_DSA_CTRL.Register6025_40h.gain_ctrl=gainCntrl
		#setGainControl
		
	@funcDecorator
	def rxDsaRegDefaults(self):
		self.regs.RX_DSA_CTRL.Register6025_40h.Property_180h_0_0=1
		self.regs.RX_DSA_CTRL.Register6147_2F8h.en_byp_dsa_code=0
		self.regs.RX_DSA_CTRL.Register6164_658h.en_byp_dsa_code=0
		self.regs.RX_DSA_CTRL.Register6147_2F8h.en_byp_dsa_idx=0
		self.regs.RX_DSA_CTRL.Register6164_658h.en_byp_dsa_idx=0
		self.regs.RX_DSA_CTRL.Register6147_2F8h.en_bypass_gainphase_fi=0
		self.regs.RX_DSA_CTRL.Register6147_2F8h.en_bypass_gain_gaincorr=0
		self.regs.RX_DSA_CTRL.Register6147_2F8h.en_bypass_coefs_fd=0
		self.regs.RX_DSA_CTRL.Register6164_658h.en_bypass_gainphase_fi=0
		self.regs.RX_DSA_CTRL.Register6164_658h.en_bypass_gain_gaincorr=0
		self.regs.RX_DSA_CTRL.Register6164_658h.en_bypass_coefs_fd=0
		self.regs.RX_DSA_CTRL.Register6025_40h.gain_ctrl=3
		self.regs.RX_DSA_LUT.Register6181_311h.sel10msb=0
		self.regs.RX_DSA_LUT.Register6220_671h.sel10msb=0
		self.regs.RX_DSA_CTRL.Register6025_40h.Property_2c8h_0_0=1
		self.regs.RX_DSA_CTRL.Register5991_50h.Property_2d0h_0_0=1
		self.regs.RX_DSA_CTRL.Register6008_B0h.Property_630h_0_0=1
		self.regs.RX_DSA_CTRL.Register5991_50h.fdsa_offset=self.systemParams.agcRegConfigParams[self.topno*2]['fdsaOffset']
		self.regs.RX_DSA_CTRL.Register6008_B0h.fdsa_offset=self.systemParams.agcRegConfigParams[(self.topno*2)+1]['fdsaOffset']
		#rxDsaRegDefaults
		
	@funcDecorator	
	def fbDsaCodesPopulate(self):
		
		if((self.systemParams.fbNco[self.topno]>2100) & (self.systemParams.fbNco[self.topno]<3000)):
			# #PG1P1 2.6G
			log("FB DSA 2.6G Band")
			Rcode=[	0,	1,	2,	5,	8,	12,	17,	22,	30,	43,	65,	74,	74,	74,	74,	74,	74,	74,	74,	74,	74]+[74]*11
			CserCode=[0,	136,	160,	171,	203,	252,	291,	310,	366,	358,	744,	706,	730,	770,	789,	811,	832,	851,	868,	884,	897]+[897]*11
			CshuntCode=[0,	1,	4,	6,	8,	9,	10,	12,	12,	13,	14,	16,	18,	18,	20,	21,	22,	23,	24,	25,	26]+[26]*11
		elif((self.systemParams.fbNco[self.topno]>4500) & (self.systemParams.fbNco[self.topno]<5500)):	
			# #PG1P1 4.9G
			log("FB DSA 4.9G Band")
			Rcode	=[0,	1,	2,	5,	8,	12,	17,	22,	30,	43,	65,	74,	74,	74,	74,	74,	74,	74,	74,	74,	74]+[74]*11
			CserCode	=[0,	86,	110,	135,	183,	242,	295,	326,	390,	414,	650,	654,	682,	730,	755,	785,	810,	831,	852,	870,	887]+[887]*11
			CshuntCode	=[0,	1,	4,	6,	8,	9,	10,	12,	12,	13,	14,	16,	18,	18,	20,	21,	22,	23,	24,	25,	26]+[26]*11
		else:#if((self.systemParams.fbNco[self.topno]>3000) & (self.systemParams.fbNco[self.topno]<4000)):
			#PG1P1 3.5G
			log("FB DSA 3.5G Band")
			Rcode=[0,1,2, 5, 8,  12,17, 22,30,  43,65, 100, 100, 100,100,100,100,100,100,100,100 ]+[100]*11                    
			CserCode=[0,94,94,103 ,127 ,166 ,223 ,249 ,312, 323, 663, 521, 575, 641, 679, 721, 757, 789, 814, 835, 853] + [853]*11  
			CshuntCode=[0,1,4,6 ,8  ,9,10 ,12,12,13,14 ,16,18,18, 20,21, 22, 23, 24, 25, 26]+[26]*11  
			
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_df0h_22_0 	= CserCode[0 ]+(CshuntCode[0 ]<<10)+(Rcode[0 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_df4h_22_0 	= CserCode[1 ]+(CshuntCode[1 ]<<10)+(Rcode[1 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_df8h_22_0 	= CserCode[2 ]+(CshuntCode[2 ]<<10)+(Rcode[2 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_dfch_22_0 	= CserCode[3 ]+(CshuntCode[3 ]<<10)+(Rcode[3 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e00h_22_0 	= CserCode[4 ]+(CshuntCode[4 ]<<10)+(Rcode[4 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e04h_22_0 	= CserCode[5 ]+(CshuntCode[5 ]<<10)+(Rcode[5 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e08h_22_0 	= CserCode[6 ]+(CshuntCode[6 ]<<10)+(Rcode[6 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e0ch_22_0 	= CserCode[7 ]+(CshuntCode[7 ]<<10)+(Rcode[7 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e10h_22_0 	= CserCode[8 ]+(CshuntCode[8 ]<<10)+(Rcode[8 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e14h_22_0 	= CserCode[9 ]+(CshuntCode[9 ]<<10)+(Rcode[9 ]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e18h_22_0	= CserCode[10]+(CshuntCode[10]<<10)+(Rcode[10]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e1ch_22_0	= CserCode[11]+(CshuntCode[11]<<10)+(Rcode[11]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e20h_22_0	= CserCode[12]+(CshuntCode[12]<<10)+(Rcode[12]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e24h_22_0	= CserCode[13]+(CshuntCode[13]<<10)+(Rcode[13]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e28h_22_0	= CserCode[14]+(CshuntCode[14]<<10)+(Rcode[14]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e2ch_22_0	= CserCode[15]+(CshuntCode[15]<<10)+(Rcode[15]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e30h_22_0	= CserCode[16]+(CshuntCode[16]<<10)+(Rcode[16]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e34h_22_0	= CserCode[17]+(CshuntCode[17]<<10)+(Rcode[17]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e38h_22_0	= CserCode[18]+(CshuntCode[18]<<10)+(Rcode[18]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e3ch_22_0	= CserCode[19]+(CshuntCode[19]<<10)+(Rcode[19]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e40h_22_0	= CserCode[20]+(CshuntCode[20]<<10)+(Rcode[20]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e44h_22_0	= CserCode[21]+(CshuntCode[21]<<10)+(Rcode[21]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e48h_22_0	= CserCode[22]+(CshuntCode[22]<<10)+(Rcode[22]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e4ch_22_0	= CserCode[23]+(CshuntCode[23]<<10)+(Rcode[23]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e50h_22_0	= CserCode[24]+(CshuntCode[24]<<10)+(Rcode[24]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e54h_22_0	= CserCode[25]+(CshuntCode[25]<<10)+(Rcode[25]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e58h_22_0	= CserCode[26]+(CshuntCode[26]<<10)+(Rcode[26]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e5ch_22_0	= CserCode[27]+(CshuntCode[27]<<10)+(Rcode[27]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e60h_22_0	= CserCode[28]+(CshuntCode[28]<<10)+(Rcode[28]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e64h_22_0	= CserCode[29]+(CshuntCode[29]<<10)+(Rcode[29]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e68h_22_0	= CserCode[30]+(CshuntCode[30]<<10)+(Rcode[30]<<15)
		self.regs.FB_DSA_LUT.Register7030_DF0h.Property_e6ch_22_0	= CserCode[31]+(CshuntCode[31]<<10)+(Rcode[31]<<15)
		
		
		self.regs.FB_DSA_CTRL.Register7013_150h.gate_tdd_on_off = 1
		#fbDsaCodesPopulate
		
	@funcDecorator
	def txDsaCodesPopulate(self):
		
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9a8h_7_0  = (((1<<40)-(1<<0 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9b0h_7_0  = (((1<<40)-(1<<1 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9b8h_7_0  = (((1<<40)-(1<<2 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9c0h_7_0  = (((1<<40)-(1<<3 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9c8h_7_0  = (((1<<40)-(1<<4 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9d0h_7_0  = (((1<<40)-(1<<5 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9d8h_7_0  = (((1<<40)-(1<<6 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9e0h_7_0  = (((1<<40)-(1<<7 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9e8h_7_0  = (((1<<40)-(1<<8 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9f0h_7_0  = (((1<<40)-(1<<9 ))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9f8h_7_0 = (((1<<40)-(1<<10))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a00h_7_0 = (((1<<40)-(1<<11))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a08h_7_0 = (((1<<40)-(1<<12))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a10h_7_0 = (((1<<40)-(1<<13))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a18h_7_0 = (((1<<40)-(1<<14))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a20h_7_0 = (((1<<40)-(1<<15))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a28h_7_0 = (((1<<40)-(1<<16))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a30h_7_0 = (((1<<40)-(1<<17))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a38h_7_0 = (((1<<40)-(1<<18))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a40h_7_0 = (((1<<40)-(1<<19))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a48h_7_0 = (((1<<40)-(1<<20))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a50h_7_0 = (((1<<40)-(1<<21))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a58h_7_0 = (((1<<40)-(1<<22))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a60h_7_0 = (((1<<40)-(1<<23))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a68h_7_0 = (((1<<40)-(1<<24))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a70h_7_0 = (((1<<40)-(1<<25))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a78h_7_0 = (((1<<40)-(1<<26))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a80h_7_0 = (((1<<40)-(1<<27))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a88h_7_0 = (((1<<40)-(1<<28))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a90h_7_0 = (((1<<40)-(1<<29))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a98h_7_0 = (((1<<40)-(1<<30))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_aa0h_7_0 = (((1<<40)-(1<<31))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_aa8h_7_0 = (((1<<40)-(1<<32))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ab0h_7_0 = (((1<<40)-(1<<33))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ab8h_7_0 = (((1<<40)-(1<<34))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ac0h_7_0 = (((1<<40)-(1<<35))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ac8h_7_0 = (((1<<40)-(1<<36))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ad0h_7_0 = (((1<<40)-(1<<37))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ad8h_7_0 = (((1<<40)-(1<<38))>>32)
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ae0h_7_0 = (((1<<40)-(1<<39))>>32)
		
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9ach_31_0  = (((1<<40)-(1<<0 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9b4h_31_0  = (((1<<40)-(1<<1 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9bch_31_0  = (((1<<40)-(1<<2 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9c4h_31_0  = (((1<<40)-(1<<3 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9cch_31_0  = (((1<<40)-(1<<4 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9d4h_31_0  = (((1<<40)-(1<<5 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9dch_31_0  = (((1<<40)-(1<<6 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9e4h_31_0  = (((1<<40)-(1<<7 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9ech_31_0  = (((1<<40)-(1<<8 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9f4h_31_0  = (((1<<40)-(1<<9 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_9fch_31_0 = (((1<<40)-(1<<10))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a04h_31_0 = (((1<<40)-(1<<11))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a0ch_31_0 = (((1<<40)-(1<<12))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.tdsa_code_lb_13 = (((1<<40)-(1<<13))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a1ch_31_0 = (((1<<40)-(1<<14))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a24h_31_0 = (((1<<40)-(1<<15))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a2ch_31_0 = (((1<<40)-(1<<16))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a34h_31_0 = (((1<<40)-(1<<17))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a3ch_31_0 = (((1<<40)-(1<<18))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a44h_31_0 = (((1<<40)-(1<<19))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a4ch_31_0 = (((1<<40)-(1<<20))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a54h_31_0 = (((1<<40)-(1<<21))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a5ch_31_0 = (((1<<40)-(1<<22))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a64h_31_0 = (((1<<40)-(1<<23))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a6ch_31_0 = (((1<<40)-(1<<24))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a74h_31_0 = (((1<<40)-(1<<25))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a7ch_31_0 = (((1<<40)-(1<<26))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a84h_31_0 = (((1<<40)-(1<<27))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a8ch_31_0 = (((1<<40)-(1<<28))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a94h_31_0 = (((1<<40)-(1<<29))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_a9ch_31_0 = (((1<<40)-(1<<30))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_aa4h_31_0 = (((1<<40)-(1<<31))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_aach_31_0 = (((1<<40)-(1<<32))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ab4h_31_0 = (((1<<40)-(1<<33))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_abch_31_0 = (((1<<40)-(1<<34))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ac4h_31_0 = (((1<<40)-(1<<35))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_acch_31_0 = (((1<<40)-(1<<36))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ad4h_31_0 = (((1<<40)-(1<<37))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_adch_31_0 = (((1<<40)-(1<<38))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6769_9A8h.Property_ae4h_31_0 = (((1<<40)-(1<<39))&((1<<32)-1))
		
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bc8h_7_0  = (((1<<40)-(1<<0 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bd0h_7_0  = (((1<<40)-(1<<1 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bd8h_7_0  = (((1<<40)-(1<<2 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_be0h_7_0  = (((1<<40)-(1<<3 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_be8h_7_0  = (((1<<40)-(1<<4 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bf0h_7_0  = (((1<<40)-(1<<5 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bf8h_7_0  = (((1<<40)-(1<<6 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c00h_7_0  = (((1<<40)-(1<<7 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c08h_7_0  = (((1<<40)-(1<<8 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c10h_7_0  = (((1<<40)-(1<<9 ))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c18h_7_0 = (((1<<40)-(1<<10))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c20h_7_0 = (((1<<40)-(1<<11))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c28h_7_0 = (((1<<40)-(1<<12))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c30h_7_0 = (((1<<40)-(1<<13))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c38h_7_0 = (((1<<40)-(1<<14))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c40h_7_0 = (((1<<40)-(1<<15))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c48h_7_0 = (((1<<40)-(1<<16))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c50h_7_0 = (((1<<40)-(1<<17))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c58h_7_0 = (((1<<40)-(1<<18))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c60h_7_0 = (((1<<40)-(1<<19))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c68h_7_0 = (((1<<40)-(1<<20))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c70h_7_0 = (((1<<40)-(1<<21))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c78h_7_0 = (((1<<40)-(1<<22))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c80h_7_0 = (((1<<40)-(1<<23))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c88h_7_0 = (((1<<40)-(1<<24))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c90h_7_0 = (((1<<40)-(1<<25))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c98h_7_0 = (((1<<40)-(1<<26))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ca0h_7_0 = (((1<<40)-(1<<27))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ca8h_7_0 = (((1<<40)-(1<<28))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cb0h_7_0 = (((1<<40)-(1<<29))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cb8h_7_0 = (((1<<40)-(1<<30))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cc0h_7_0 = (((1<<40)-(1<<31))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cc8h_7_0 = (((1<<40)-(1<<32))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cd0h_7_0 = (((1<<40)-(1<<33))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cd8h_7_0 = (((1<<40)-(1<<34))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ce0h_7_0 = (((1<<40)-(1<<35))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ce8h_7_0 = (((1<<40)-(1<<36))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cf0h_7_0 = (((1<<40)-(1<<37))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cf8h_7_0 = (((1<<40)-(1<<38))>>32)
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_d00h_7_0 = (((1<<40)-(1<<39))>>32)
		
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bcch_31_0  = (((1<<40)-(1<<0 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bd4h_31_0  = (((1<<40)-(1<<1 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bdch_31_0  = (((1<<40)-(1<<2 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_be4h_31_0  = (((1<<40)-(1<<3 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bech_31_0  = (((1<<40)-(1<<4 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bf4h_31_0  = (((1<<40)-(1<<5 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_bfch_31_0  = (((1<<40)-(1<<6 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c04h_31_0  = (((1<<40)-(1<<7 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c0ch_31_0  = (((1<<40)-(1<<8 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c14h_31_0  = (((1<<40)-(1<<9 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c1ch_31_0 = (((1<<40)-(1<<10))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c24h_31_0 = (((1<<40)-(1<<11))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c2ch_31_0 = (((1<<40)-(1<<12))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c34h_31_0 = (((1<<40)-(1<<13))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c3ch_31_0 = (((1<<40)-(1<<14))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c44h_31_0 = (((1<<40)-(1<<15))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c4ch_31_0 = (((1<<40)-(1<<16))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c54h_31_0 = (((1<<40)-(1<<17))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c5ch_31_0 = (((1<<40)-(1<<18))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c64h_31_0 = (((1<<40)-(1<<19))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c6ch_31_0 = (((1<<40)-(1<<20))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c74h_31_0 = (((1<<40)-(1<<21))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c7ch_31_0 = (((1<<40)-(1<<22))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c84h_31_0 = (((1<<40)-(1<<23))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c8ch_31_0 = (((1<<40)-(1<<24))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c94h_31_0 = (((1<<40)-(1<<25))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_c9ch_31_0 = (((1<<40)-(1<<26))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ca4h_31_0 = (((1<<40)-(1<<27))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cach_31_0 = (((1<<40)-(1<<28))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cb4h_31_0 = (((1<<40)-(1<<29))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cbch_31_0 = (((1<<40)-(1<<30))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cc4h_31_0 = (((1<<40)-(1<<31))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ccch_31_0 = (((1<<40)-(1<<32))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cd4h_31_0 = (((1<<40)-(1<<33))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cdch_31_0 = (((1<<40)-(1<<34))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_ce4h_31_0 = (((1<<40)-(1<<35))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cech_31_0 = (((1<<40)-(1<<36))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cf4h_31_0 = (((1<<40)-(1<<37))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_cfch_31_0 = (((1<<40)-(1<<38))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register6850_BC8h.Property_d04h_31_0 = (((1<<40)-(1<<39))&((1<<32)-1))
		
		self.regs.TX_DSA_CTRL.Register6749_9A3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register6749_9A3h.fw_update_gpec_lut=1
		self.regs.TX_DSA_CTRL.Register6749_9A3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register6759_BC3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register6759_BC3h.fw_update_gpec_lut=1
		self.regs.TX_DSA_CTRL.Register6759_BC3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register6707_100h.dig_gain=24
		self.regs.TX_DSA_CTRL.Register6728_120h.dig_gain=24
		self.regs.TX_DSA_CTRL.Register6707_100h.en_idx_update=1
		self.regs.TX_DSA_CTRL.Register6728_120h.en_idx_update=1
		self.regs.TX_DSA_CTRL.Register6707_100h.spi_dsa=1
		self.regs.TX_DSA_CTRL.Register6707_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register6707_100h.index_update=1
		self.regs.TX_DSA_CTRL.Register6707_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register6707_100h.spi_dsa=0
		self.regs.TX_DSA_CTRL.Register6707_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register6707_100h.index_update=1
		self.regs.TX_DSA_CTRL.Register6707_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register6728_120h.spi_dsa=1
		self.regs.TX_DSA_CTRL.Register6728_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register6728_120h.index_update=1
		self.regs.TX_DSA_CTRL.Register6728_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register6728_120h.spi_dsa=0
		self.regs.TX_DSA_CTRL.Register6728_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register6728_120h.index_update=1
		self.regs.TX_DSA_CTRL.Register6728_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register6707_100h.en_idx_update=0
		self.regs.TX_DSA_CTRL.Register6728_120h.en_idx_update=0
		self.regs.TOP_CFG.Register7063_DE0h.map_to_txgswap=15
		
		# Writes for Tx DSA
		self.regs.TX_DSA_CTRL.Register6707_100h.Property_994h_0_0 = 1
		self.regs.TX_DSA_CTRL.Register6728_120h.Property_bb4h_0_0 = 1
		#txDsaCodesPopulate
		
		
		
