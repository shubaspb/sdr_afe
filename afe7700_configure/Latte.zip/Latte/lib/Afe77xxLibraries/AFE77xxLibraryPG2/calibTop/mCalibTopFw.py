from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *

import random
import math

import mCalibTopConst
reload(mCalibTopConst)
from mCalibTopConst import *
class CalibTopFw(projectBaseClass):
	"""Contains Calib top FW specific functions self.regs=device.TOP"""
	@initDecorator
	def __init__(self,regs):
		self.regs=regs
		self.errorList=['','']
		#__init__
		
		
	@funcDecorator
	def function_name(self,parameters):
		"""Description"""
		"""Definition"""
		#function_name
		
		#CalibTopFw
