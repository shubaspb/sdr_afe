from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class rxAnaCDLib(projectBaseClass):
	"""Contains RX ANA CD specific functions. self.regs=device.RX.ANA_CD.ANA_CD """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs.ANA_CD
		self.topno=topno
		
		#__init__
		
		#rxAnaCDLib
