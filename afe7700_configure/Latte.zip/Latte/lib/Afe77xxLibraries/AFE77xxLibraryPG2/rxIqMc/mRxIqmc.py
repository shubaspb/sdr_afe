from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *
from mRxIqmcEstim import *
from mRxIqmcFw import *
from mRxTopConst import *
from common.mDeviceConstants import *
import random

class RxIqmc(projectBaseClass):
	"""Contains Rx Iqmc Corrector specific functions. self.regs=device.RX.RXIQMC.rx_iqmc """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.errorList=['','']
		#self.RXIQMC_ESTIM = RxIqmcEstim(regs.RX_IQMC_ESTIM)
		#self.RXIQMC_FW = RxIqmcFw(regs.RX_IQMC_ESTIM)
		#self.RXDISPLAY_FUNC = RxDisplayFunc(regs.RX_IQMC_ESTIM)
		#__init__
		
	@funcDecorator
	def disable_wfi_for_rx_MCU(self):
		self.regs.Register30953_300h.Property_304h_8_8 			= 1
		self.regs.Register30953_300h.Property_304h_9_9 	= 1
		# disable_wfi_for_rx_MCU()
		
		#RxIqmc
		
