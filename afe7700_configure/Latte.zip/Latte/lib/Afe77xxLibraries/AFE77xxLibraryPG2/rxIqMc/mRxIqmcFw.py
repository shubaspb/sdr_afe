import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *
from mRxTopConst import *
from common.mDeviceConstants import *
import random
from globalDefs import *
import math
class RxIqmcFw(projectBaseClass):
	"""Contains FW specific functions. self.regs=device.
	   Functions used only in steady state calib are prefixed with STEADY_STATE
	   Functions used only in power up calib are prefixed with PWR_UP
	   In steady state calib, params are divided into base setting and derived setting
	   The base setting is used to derive many hardware params 
	   derived setting is used to override some of these hardware settings based on base setting.
	   base settings are indicated by _bs_
	   derived settings are indicated by _ds_
	"""
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.errorList=['','']
		#__init__
		
	@funcDecorator
	def function_name(self,parameters):
		"""Description"""
		"""Definition"""
		#function_name
		
	@funcDecorator
	def CLEAR_ALL_FW_REGS(self):
		"""Description"""
		"""Definition"""
		#Incomplete
		#May be its better to write this one through addresses ??
		#CLEAR_ALL_FW_REGS
		
	@funcDecorator
	def DBG_FW_FREEZE(self):
		self.regs.FW_FREEZE = 1
		self.regs.VALIDITY_FW_FREEZE = 1
		# DBG_FW_FREEZE
		
	@funcDecorator
	def DBG_FW_CHECK_FW_FREEZE(self):
		return self.regs.FW_FREEZE_STATUS 
		#This bit, if 1, indicates that FW is frozen either for single step or general breakpoint
		#DBG_FW_CHECK_FW_FREEZE
		
		
		
	@funcDecorator
	def DBG_FW_UNFREEZE(self):
		self.regs.FW_FREEZE = 0
		self.regs.VALIDITY_FW_FREEZE = 1
		# DBG_FW_UNFREEZE
		
	@funcDecorator
	def DBG_FW_ENABLE_ONE_SHOT_BREAKPOINT_MODE(self):
		self.regs.FW_ONE_SHOT_BLKPT_MODE = 1
		#FW will enter into and stay in single step mode if this bit is set
		# DBG_FW_ENABLE_ONE_SHOT_BREAKPOINT_MODE
		
	@funcDecorator
	def DBG_FW_RELEASE_ONE_SHOT_BREAKPOINT(self):
		self.regs.RELEASE_ONE_SHOT_BKPT = 1		
		#If this bit is set, then FW will run for one interrupt, make this bit 0 and stop if  FW_ONE_SHOT_BLKPT_MODE=1
		#To again move to the next interrupt, first check if this bit is made 0(ie 1 intrpt is processed)
		#This can be checked by either reading this bit or reading a status reg below.
		#If this bit is made 0, then make RELEASE_ONE_SHOT_BKPT=1 again to move again by 1 interrupt
		# DBG_FW_RELEASE_ONE_SHOT_BREAKPOINT
		
	@funcDecorator
	def DBG_FW_DISABLE_ONE_SHOT_BREAKPOINT_MODE(self):
		self.regs.FW_ONE_SHOT_BLKPT_MODE = 0
		self.regs.RELEASE_ONE_SHOT_BKPT = 1		
		#FW will enter into and stay in single step mode if this bit is set
		# DBG_FW_DISABLE_ONE_SHOT_BREAKPOINT_MODE
		
		
	@funcDecorator
	def DBG_FW_CHECK_ONE_INTRPT_DONE_ONE_SHOT_BREAKPOINT(self):
		return self.regs.FW_FREEZE_STATUS 
		#This bit, if 1, indicates that FW is frozen either for single step or general breakpoint
		#DBG_FW_CHECK_ONE_INTRPT_DONE_ONE_SHOT_BREAKPOINT
		
	@funcDecorator
	def DBG_WFI_DISABLE(self):
		self.regs.WFI_DIS = 1
		self.regs.VALIDITY_WFI_DIS = 1
		#DBG_WFI_DISABLE
		
	@funcDecorator
	def DBG_PATCH_AVAILABLE(self):
		self.regs.PATCH_AV = 1
		#DBG_PATCH_AVAILABLE
		
	@funcDecorator
	def DBG_PATCH_VALIDITY_STATUS(self):
		return self.regs.PATCH_VALIDITY_STATUS 
		#DBG_PATCH_VALIDITY_STATUS
		
		
	@funcDecorator
	def SET_FREQ_DEP_IQMC_FILT_I_LEN(self,filt_len_i):
		self.regs.FILT_LEN_I = filt_len_i
		self.regs.VALIDITY_FILT_LEN_I = 1
		# SET_FREQ_DEP_IQMC_FILT_I_LEN
		
	@funcDecorator
	def SET_FREQ_DEP_IQMC_FILT_Q_LEN(self,filt_len_q):
		self.regs.FILT_LEN_Q = filt_len_q
		self.regs.VALIDITY_FILT_LEN_Q = 1
		# SET_FREQ_DEP_IQMC_FILT_I_LEN
		
	@funcDecorator
	def STEADY_STATE_BS_SET_INTERP_BIN_EDGE(self,edgeBin):
		self.regs.INTERP_BIN_EDGE = edgeBin
		self.regs.VALIDITY_INTERP_BIN_EDGE = 1
		#STEADY_STATE_BS_SET_INTERP_BIN_EDGE
		
	@funcDecorator
	def STEADY_STATE_BS_SET_INTERP_HOLD_BIN_EDGE(self,interpHoldBin):
		self.regs.INTERP_HOLD_BIN_EDGE = interpHoldBin
		self.regs.VALIDITY_INTERP_HOLD_BIN_EDGE = 1
		#Estimates are held between INTERP_BIN_EDGE and HOLD_BIN_EDGE
		#By default there is no hold and this may not be needed.
		#STEADY_STATE_BS_SET_INTERP_BIN_EDGE
		
		
	@funcDecorator
	def PWR_UP_CALIB_SET_DESIRED_SNRdB_DSA_DEP(self, desired_snr_dsa_dep):
		self.regs.DESIRED_SNR_DSA_DEP = min(max(floor(desired_snr_dsa_dep)-50,0),31)#5 bit field
		self.regs.VALIDITY_DESIRED_SNR_DSA_DEP = 1
		print("Actual DESIRED_SNR_DSA_DEP set is %d" % (self.regs.DESIRED_SNR_DSA_DEP+50))
		# PWR_UP_CALIB_SET_DESIRED_SNRdB_DSA_DEP
		
	@funcDecorator
	def PWR_UP_CALIB_SET_DESIRED_SNRdB_FREQ_DEP(self, desired_snr_freq_dep):
		self.regs.DESIRED_SNR_FREQ_DEP = min(max(floor(desired_snr_freq_dep)-50,0),31)#5 bit field
		self.regs.VALIDITY_DESIRED_SNR_FREQ_DEP = 1
		print("Actual DESIRED_SNR_FREQ_DEP set is %d" % (self.regs.DESIRED_SNR_FREQ_DEP+50))
		# PWR_UP_CALIB_SET_DESIRED_SNRdB_FREQ_DEP
		
	@funcDecorator
	def PWR_UP_SET_INP_PWR_DESIRED_SETPOINT_DBFS(self,desired_max_inp_power_level_dBFs):
		self.regs.MAX_INP_LEVL_PWR_UP = min(-desired_max_inp_power_level_dBFs,15)
		self.regs.VALIDITY_MAX_INP_LEVL_PWR_UP =1
		#PWR_UP_SET_INP_PWR_DESIRED_SETPOINT_DBFS
		
	@funcDecorator
	def PWR_UP_SET_MAX_LOOPBACK_PWR_DBFS(self,max_loopback_pwr_dBFs):
		self.regs.PSIG_PWR_UP = min(-max_loopback_pwr_dBFs,63)
		self.regs.VALIDITY_PSIG_PWR_UP = 1
		#PWR_UP_SET_MAX_LOOPBACK_PWR_DBFS - Max power fed into Rx when DSA=0, in dBFs of Rx
		
	@funcDecorator
	def STEADY_STATE_DS_SET_BLK_LEN_AGGR_4CH(self,blk_len_aggr_4ch):
		self.regs.BLK_LEN_AGGR = min(blk_len_aggr_4ch,2**15-1)
		self.regs.VALIDITY_BLK_LEN_AGGR = 1
		#STEADY_STATE_SET_DS_SET_BLK_LEN_AGGR_4CH
		
		
		
	@funcDecorator
	def ENABLE_CLSIN_ESTIMATION(self):
		self.regs.DIS_CLSIN_EST=0
		self.regs.VALIDITY_DIS_CLSIN_EST = 1
		#ENABLE_CLSIN_ESTIMATION
		
	@funcDecorator
	def DISABLE_CLSIN_ESTIMATION(self):
		self.regs.DIS_CLSIN_EST=1
		self.regs.VALIDITY_DIS_CLSIN_EST = 1
		#DISABLE_CLSIN_ESTIMATION
		
	@funcDecorator
	def STEADY_STATE_DS_SET_MIN_VALID_BLKS_chAB(self,min_valid_blks_chAB):
		self.regs.MIN_VALID_BLKS_2R0 = min(min_valid_blks_chAB,2**13-1)
		self.regs.VALIDITY_MIN_VALID_BLKS_2R0=1
		#STEADY_STATE_SET_MIN_VALID_BLKS_chAB - This is used to set the min number of valid blocks to be aggregated before TDD causes aggregation to stop
		
	@funcDecorator
	def STEADY_STATE_DS_SET_MIN_VALID_BLKS_chCD(self,min_valid_blks_chCD):
		self.regs.MIN_VALID_BLKS_2R1 = min(min_valid_blks_chCD,2**13-1)
		self.regs.VALIDITY_MIN_VALID_BLKS_2R1=1
		#STEADY_STATE_SET_MIN_VALID_BLKS_chCD - This is used to set the min number of valid blocks to be aggregated before TDD causes aggregation to stop
		
	@funcDecorator
	def STEADY_STATE_DS_SET_MIN_VALID_BLKS(self,min_valid_blks,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:
			STEADY_STATE_DS_SET_MIN_VALID_BLKS_chAB(min_valid_blks)
		else :
			STEADY_STATE_DS_SET_MIN_VALID_BLKS_chCD(min_valid_blks)
			#STEADY_STATE_SET_MIN_VALID_BLKS_chCD - This is used to set the min number of valid blocks to be aggregated before TDD causes aggregation to stop
			
			
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_PWR_THRESH(self,closein_min_pwr_thresh_dBFs):
		self.regs.CLSIN_PWR_THRESH = pow(10,(closein_min_pwr_thresh_dBFs+72)/20)
		self.regs.VALIDITY_CLSIN_PWR_THRESH = 1
		#STEADY_STATE_CLSIN_BS_PWR_THRESH
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_PWR_RATIO_THRESH(self,closein_pwr_ratio_thresh_dB):
		self.regs.CLSIN_PWR_RATIO_THRESH = floor(closein_pwr_ratio_thresh_dB)
		self.regs.VALIDITY_CLSIN_PWR_RATIO_THRESH = 1
		#STEADY_STATE_CLSIN_BS_PWR_RATIO_THRESH
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_PWR_ALIAS_THRESH(self,closein_pwr_alias_ratio_thresh_dB):
		self.regs.CLSIN_PWR_ALIAS_THRESH = pow(10,((closein_pwr_alias_ratio_thresh_dB+60)/20))
		self.regs.VALIDITY_CLSIN_PWR_ALIAS_THRESH = 1
		#STEADY_STATE_CLSIN_BS_PWR_ALIAS_THRESH
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_UNC_THRESH(self,closein_unc_thresh_dBFs):
		self.regs.CLSIN_UNC_THRESH = pow(10,((closein_unc_thresh_dBFs+84)/20))
		self.regs.VALIDITY_CLSIN_UNC_THRESH = 1
		#STEADY_STATE_CLSIN_BS_UNC_THRESH
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_MAX_BIN_NUM_GOODESTIM_TO_DISABLE(self,max_bin_num_goodestim_to_disable_clsin):
		self.regs.CLSIN_NBINS_MAX = floor(max_bin_num_goodestim_to_disable_clsin)
		self.regs.VALIDITY_CLSIN_NBINS_MAX = 1
		#def STEADY_STATE_CLSIN_BS_MAX_BIN_NUM_GOODESTIM_TO_DISABLE
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_MIN_BIN_WITH_HIGH_PWR_TO_DISABLE(self,min_bin_with_high_pwr_to_disable_clsin):
		self.regs.CLSIN_N1 = min(min_bin_with_high_pwr_to_disable_clsin,63)
		self.regs.VALIDITY_CLSIN_N1 = 1	
		#def STEADY_STATE_CLSIN_BS_MIN_BIN_WITH_HIGH_PWR_TO_DISABLE
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_MAX_BIN_WITH_HIGH_PWR_TO_DISABLE(self,max_bin_with_high_pwr_to_disable_clsin):
		self.regs.CLSIN_N2 = min(max_bin_with_high_pwr_to_disable_clsin,63)
		self.regs.VALIDITY_CLSIN_N2 = 1	
		#def STEADY_STATE_CLSIN_BS_MAX_BIN_WITH_HIGH_PWR_TO_DISABLE
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_MIN_FREQ_CHAB(self,min_freq_clsin_kHz_chAB):
		self.regs.CLSIN_FMIN_2R0 = min(min_freq_clsin_kHz_chAB,127)
		self.regs.VALIDITY_CLSIN_FMIN_2R0 = 1	
		#def STEADY_STATE_CLSIN_BS_MIN_FREQ_CHAB
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_MIN_FREQ_CHCD(self,min_freq_clsin_kHz_chCD):
		self.regs.CLSIN_FMIN_2R1 = min(min_freq_clsin_kHz_chCD,127)
		self.regs.VALIDITY_CLSIN_FMIN_2R1 = 1	
		#def STEADY_STATE_CLSIN_BS_MIN_FREQ_CHCD
		
	@funcDecorator
	def STEADY_STATE_CLSIN_BS_MIN_FREQ(self,min_freq_clsin_kHz,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:#channel AB
			STEADY_STATE_CLSIN_BS_MIN_FREQ_CHAB(min_freq_clsin_kHz)
		else :#channel CD
			STEADY_STATE_CLSIN_BS_MIN_FREQ_CHCD(min_freq_clsin_kHz)
			#STEADY_STATE_CLSIN_BS_MIN_FREQ - This is used to set the min number of valid blocks to be aggregated before TDD causes aggregation to stop
			
			
	def STEADY_STATE_CLSIN_DS_NUM_SETS_OF_ESTIMATES(self,numSetsOfCloseinEstimates,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:#channel AB
			self.regs.CLSIN_NSETS_2R0 = min(7,numSetsOfCloseinEstimates)
			self.regs.VALIDITY_CLSIN_NSETS_2R0 = 1
		else :
			self.regs.CLSIN_NSETS_2R1 = min(7,numSetsOfCloseinEstimates)
			self.regs.VALIDITY_CLSIN_NSETS_2R1 = 1	
			#STEADY_STATE_CLSIN_DS_NUM_SETS_OF_ESTIMATES
			
	def STEADY_STATE_CLSIN_DC_NOTCH_ALPHA_REG_VALUE(self,dcNotchAlphaReg,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:#channel AB
			self.regs.CLSIN_DCALPHA_2R0 = min(dcNotchAlphaReg,8)
			self.regs.VALIDITY_CLSIN_DCALPHA_2R0 = 1
		else :
			self.regs.CLSIN_DCALPHA_2R1 = min(dcNotchAlphaReg,8)
			self.regs.VALIDITY_CLSIN_DCALPHA_2R1 = 1
			#STEADY_STATE_CLSIN_DC_NOTCH_ALPHA_REG_VALUE
			
	def STEADY_STATE_CLSIN_CLSIN_DCSETL_SAMPLES(self,dcSetlSamples,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:#channel AB
			self.regs.CLSIN_DCSETL_SAMPLES_2R0 = np.floor(dcSetlSamples/32)
			self.regs.VALIDITY_CLSIN_DCSETL_SAMPLES_2R0 = 1
		else :
			self.regs.CLSIN_DCSETL_SAMPLES_2R1 = np.floor(dcSetlSamples/32)
			self.regs.VALIDITY_CLSIN_DCSETL_SAMPLES_2R1 = 1
			#STEADY_STATE_CLSIN_DC_NOTCH_ALPHA_REG_VALUE
			
			
	def STEADY_STATE_CLSIN_DS_NUM_BLOCKS(self,numBlocksClosein,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:#channel AB
			self.regs.CLSIN_NBLOCK_2R0 = min(pow(2,15)-1,numBlocksClosein)
			self.regs.VALIDITY_CLSIN_NBLOCK_2R0 = 1
		else :
			self.regs.CLSIN_NBLOCK_2R1 = min(pow(2,15)-1,numBlocksClosein)
			self.regs.VALIDITY_CLSIN_NBLOCK_2R1 = 1						
			#STEADY_STATE_CLSIN_DS_NUM_BLOCKS
			
	def STEADY_STATE_CLSIN_BS_SET_ESTIM_UNC(self,clsinUncdBc,chID):
		if chID == DeviceConstants.RXTOP_DIG_0:
			self.regs.CLSIN_ESTUNC_PERSET_2R0 = round(-clsinUncdBc/3)
			self.regs.VALIDITY_CLSIN_ESTUNC_PERSET_2R0 = 1
		else :
			self.regs.CLSIN_ESTUNC_PERSET_2R1 = round(-clsinUncdBc/3)
			self.regs.VALIDITY_CLSIN_ESTUNC_PERSET_2R1 = 1
			#STEADY_STATE_CLSIN_BS_SET_ESTIM_UNC
			
	def STEADY_STATE_BS_SET_KF_PROCESS_NOISE(self,processNoisedBc):
		self.regs.KF_PROCESS_NOISE = max(round(pow(10,(processNoisedBc+114)/20)),127)
		self.regs.VALIDITY_KF_PROCESS_NOISE = 1
		#STEADY_STATE_BS_SET_KF_PROCESS_NOISE
		
	def STEADY_STATE_BS_SET_KF_UNC_THRESH(self,kfUncThreshdBc):
		self.regs.KF_UNC_THRESH = round(pow(10,(kfUncThreshdBc+72)/20))
		self.regs.VALIDITY_KF_UNC_THRESH = 1
		#STEADY_STATE_BS_SET_KF_PROCESS_NOISE
		
	@funcDecorator
	def PWR_UP_PNOISE_PWR_UP_PERBIN_1x(self,pNoisePerBinPowerUp):
		self.regs.PNOISE_PWR_UP_PERBIN_1x =  min(-(77+pNoisePerBinPowerUp),31)
		self.regs.VALIDITY_PNOISE_PWR_UP_PERBIN_1x=1
		#PWR_UP_PNOISE_PWR_UP_PERBIN_1x
		
	@funcDecorator
	def STEADY_STATE_GINST_SIG_PWR_CHK_ENABLE(self):
		self.regs.GINST_SIG_PWR_CHK_EN = 1
		self.regs.VALIDITY_GINST_SIG_PWR_CHK_EN=1
		#STEADY_STATE_GINST_SIG_PWR_CHK_ENABLE
		
	@funcDecorator
	def STEADY_STATE_GINST_SIG_PWR_CHK_DISABLE(self):
		self.regs.GINST_SIG_PWR_CHK_EN = 0
		self.regs.VALIDITY_GINST_SIG_PWR_CHK_EN=1
		#STEADY_STATE_GINST_SIG_PWR_CHK_DISABLE
		
	@funcDecorator
	def STEADY_STATE_GINST_SIG_RATIO_CHK_ENABLE(self):
		self.regs.GINST_SIG_RATIO_CHK_EN = 1
		self.regs.VALIDITY_GINST_SIG_RATIO_CHK_EN=1
		#STEADY_STATE_GINST_SIG_RATIO_CHK_ENABLE
		
	@funcDecorator
	def STEADY_STATE_GINST_SIG_RATIO_CHK_DISABLE(self):
		self.regs.GINST_SIG_RATIO_CHK_EN = 0
		self.regs.VALIDITY_GINST_SIG_RATIO_CHK_EN=1
		#STEADY_STATE_GINST_SIG_RATIO_CHK_DISABLE
		
	@funcDecorator
	def STEADY_STATE_GINST_CORR_TONE_CHK_ENABLE(self):
		self.regs.GINST_CORR_TONE_CHK_EN = 1
		self.regs.VALIDITY_GINST_CORR_TONE_CHK_EN=1
		#STEADY_STATE_GINST_CORR_TONE_CHK_ENABLE
		
	@funcDecorator
	def STEADY_STATE_GINST_CORR_TONE_CHK_DISABLE(self):
		self.regs.GINST_CORR_TONE_CHK_EN = 0
		self.regs.VALIDITY_GINST_CORR_TONE_CHK_EN=1
		#STEADY_STATE_GINST_CORR_TONE_CHK_DISABLE
		
	@funcDecorator
	def STEADY_STATE_SET_GINST_RATIO_CHECK_PARAMS(self,sigImgRatioHwThreshdB,sigImgRatioHwToFwLowThreshdB,sigImgRatioFWLowToHighThreshdB):
		hwRegVal = min(round(10**(sigImgRatioHwThreshdB/20)*4),pow(2,12)-1)
		self.regs.EST_RATIO_CHK = hwRegVal
		self.regs.VALIDITY_EST_RATIO_CHK = 1
		fwLowThreshRegVal = min(round((10**(sigImgRatioHwToFwLowThreshdB/20)-1)*16),pow(2,7)-1)
		fwHiThreshRegVal = min(round((10**(sigImgRatioFWLowToHighThreshdB/20)-1)*16),pow(2,7)-1)
		self.regs.GINST_RATIOCHK_LOW_THRESH = fwLowThreshRegVal
		self.regs.GINST_RATIOCHK_HIGH_THRESH = fwHiThreshRegVal
		self.regs.VALIDITY_GINST_RATIOCHK_LOW_THRESH =1
		self.regs.VALIDITY_GINST_RATIOCHK_HIGH_THRESH =1
		#STEADY_STATE_SET_GINST_RATIO_CHECK_PARAMS
		
	@funcDecorator
	def STEADY_STATE_SET_GINST_SIGPWR_CHECK_PARAMS(self,sigPwrHwThreshdB,sigPwrHwToFwLowThreshdB,sigPwrFWLowToHighThreshdB):
		hwRegVal = min(round((10**(sigPwrHwThreshdB/20))*(2**12)),pow(2,12)-1)
		info(['Setting HW sig thresh to', str(hwRegVal)])
		self.regs.EST_SIG_LVL_CHK = hwRegVal
		self.regs.VALIDITY_EST_SIG_LVL_CHK = 1
		fwLowThreshRegVal = min(round((10**(sigPwrHwToFwLowThreshdB/20)-1)*16),pow(2,7)-1)
		fwHiThreshRegVal = min(round((10**(sigPwrFWLowToHighThreshdB/20)-1)*16),pow(2,7)-1)
		self.regs.GINST_SIGPWRCHK_LOW_THRESH = fwLowThreshRegVal
		self.regs.GINST_SIGPWRCHK_HIGH_THRESH = fwHiThreshRegVal
		self.regs.VALIDITY_GINST_SIGPWRCHK_LOW_THRESH =1
		self.regs.VALIDITY_GINST_SIGPWRCHK_HIGH_THRESH =1
		#STEADY_STATE_SET_GINST_SIGPWR_CHECK_PARAMS
		
	@funcDecorator
	def STEADY_STATE_GKF_ENABLE_CHECK_SS_VS_PWRUP(self):
		self.regs.KF_ESTVALCHK_EN = 1
		self.regs.VALIDITY_KF_ESTVALCHK_EN=1
		#STEADY_STATE_GKF_ENABLE_CHECK_SS_VS_PWRUP
		
	@funcDecorator
	def STEADY_STATE_GKF_DISABLE_CHECK_SS_VS_PWRUP(self):
		self.regs.KF_ESTVALCHK_EN = 0
		self.regs.VALIDITY_KF_ESTVALCHK_EN=1
		#STEADY_STATE_GKF_DISABLE_CHECK_SS_VS_PWRUP
		
	@funcDecorator
	def STEADY_STATE_KF_MERGE_EST_ENABLE(self):
		self.regs.KF_MERGE_EST_EN = 1
		self.regs.VALIDITY_KF_MERGE_EST_EN=1
		#STEADY_STATE_KF_MERGE_EST_ENABLE
		
	@funcDecorator
	def STEADY_STATE_KF_MERGE_EST_DISABLE(self):
		self.regs.KF_MERGE_EST_EN = 0
		self.regs.VALIDITY_KF_MERGE_EST_EN=1
		#STEADY_STATE_KF_MERGE_EST_DISABLE
		
	@funcDecorator
	def STEADY_STATE_KF_MERGEEST_MAX_DIST(self,mergeEstMaxBinSeparation):
		self.regs.KF_MERGEEST_MAX_DIST = min(mergeEstMaxBinSeparation,31)
		self.regs.VALIDITY_KF_MERGEEST_MAX_DIST = 1
		#STEADY_STATE_KF_MERGEEST_MAX_DIST
		
		
	def STEADY_STATE_KF_MERGEEST_NEARUNCTHRESH(self,mergeEstNextBinUncDiffdB):
		self.regs.KF_MERGEEST_NEARUNCTHRESH = min(round(10**(mergeEstNextBinUncDiffdB*1.0/10)/4),pow(2,7)-1)
		self.regs.VALIDITY_KF_MERGEEST_NEARUNCTHRESH = 1
		#STEADY_STATE_KF_MERGEEST_NEARUNCTHRESH
		
	def STEADY_STATE_KF_MERGEEST_FARUNCTHRESH(self,mergeEstFartherBinUncDiffdB):
		self.regs.KF_MERGEEST_FARUNCTH = min(round(10**(mergeEstFartherBinUncDiffdB*1.0/10)/4),pow(2,7)-1)
		self.regs.VALIDITY_KF_MERGEEST_FARUNCTH = 1
		#STEADY_STATE_KF_MERGEEST_FARUNCTHRESH
		
		
		
		#RxIqmcFw
