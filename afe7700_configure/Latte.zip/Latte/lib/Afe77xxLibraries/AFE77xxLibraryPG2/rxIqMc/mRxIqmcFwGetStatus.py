import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *
from mRxTopConst import *
from common.mDeviceConstants import *
from common.mMemConst import *
from mRxIQMCConstants import *
from array import *
#import random
from globalDefs import *
import numpy as np
#import matplotlib.pyplot as plt
import math
#import cmath

class RxIqmcFwGetStatus(projectBaseClass):
	"""Contains FW specific functions. self.regs=device.RX.RXIQMC.rx_iqmc.Register30953_300h.Property_300h_31_0

	   Functions used only in steady state calib are prefixed with STEADY_STATE
	   Functions used only in power up calib are prefixed with PWR_UP
	   In steady state calib, params are divided into base setting and derived setting
	   The base setting is used to derive many hardware params 
	   derived setting is used to override some of these hardware settings based on base setting.
	   base settings are indicated by _bs_
	   derived settings are indicated by _ds_
	"""
	
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.errorList=['','']
		#__init__
		
	@funcDecorator
	def function_name(self,parameters):
		"""Description"""
		"""Definition"""
		#function_name
		
	@funcDecorator
	def getGInstData(self,chID,adcregProg):
		structSize = 2+2+4+1+3
		N = RxIQMCConstants.NUM_FFT_POINTS         
		gInstReal = np.zeros(N)
		gInstImag = np.zeros(N)
		gUnc = np.zeros(N)
		gValidFlag = np.zeros(N)
		
		gInstStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_GINST_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		gInstStartAddress = gInstStartAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		gInstAllData = np.zeros(N*structSize)
		dummyRead = self.memRead16('rxiqmcDram',gInstStartAddress)
		gInstAllData = adcregProg.burstRead(gInstStartAddress+0x8000+0x20,N*structSize)
		#for i in range(N):
		#	gInstReal[i] = self.memRead16('rxiqmcDram',gInstStartAddress+i*structSize)
		#	gInstImag[i] = self.memRead16('rxiqmcDram',gInstStartAddress+i*structSize+2)
		#	gUnc[i] = self.memRead32('rxiqmcDram',gInstStartAddress+i*structSize+4)
		#	gValidFlag[i] = self.memRead8('rxiqmcDram',gInstStartAddress+i*structSize+8)
		for i in range(N):
			if i== 0:
				binIdx = 0
			else:
				binIdx = N-i				
			gInstReal[binIdx] = gInstAllData[i*structSize] + 256*gInstAllData[i*structSize+1]#self.memRead16('rxiqmcDram',gInstStartAddress+i*structSize)
			gInstImag[binIdx] = gInstAllData[i*structSize+2] + 256*gInstAllData[i*structSize+3]#self.memRead16('rxiqmcDram',gInstStartAddress+i*structSize+2)
			if gInstReal[binIdx] >=2**15:
				gInstReal[binIdx] = gInstReal[binIdx]-2**16
			if gInstImag[binIdx] >=2**15:
				gInstImag[binIdx] = gInstImag[binIdx]-2**16
			gUnc[binIdx] = gInstAllData[i*structSize+4] + 256*gInstAllData[i*structSize+5]+ 256*8*gInstAllData[i*structSize+6]+ 256*256*gInstAllData[i*structSize+7]#self.memRead32('rxiqmcDram',gInstStartAddress+i*structSize+4)
			gValidFlag[binIdx] = gInstAllData[i*structSize+8]#self.memRead8('rxiqmcDram',gInstStartAddress+i*structSize+8)
		return(gInstReal,gInstImag,gUnc,gValidFlag)
		#getGInstData
		
	@funcDecorator
	def getGInstDataSpecificBin(self,chID,binId):
		structSize = 2+2+4+1+3
		N = RxIQMCConstants.NUM_FFT_POINTS         
		if binId==0:
			binIdGInst = 0
		else:
			binIdGInst = N - binId
			#gInstReal = np.zeros(N)
			#gInstImag = np.zeros(N)
			#gUnc = np.zeros(N)
			#gValidFlag = np.zeros(N)
			
		gInstStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_GINST_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		gInstStartAddress = gInstStartAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		i = binIdGInst
		#for i in range(N):
		gInstReal = self.memRead16('rxiqmcDram',gInstStartAddress+i*structSize)
		gInstImag = self.memRead16('rxiqmcDram',gInstStartAddress+i*structSize+2)
		gUnc = self.memRead32('rxiqmcDram',gInstStartAddress+i*structSize+4)
		gValidFlag = self.memRead8('rxiqmcDram',gInstStartAddress+i*structSize+8)
		if gInstReal >=2**15:
			gInstReal = gInstReal-2**16
		if gInstImag >=2**15:
			gInstImag = gInstImag-2**16
		return(gInstReal,gInstImag,gUnc,gValidFlag)
		#getGInstDataSpecificBin
		
		
	@funcDecorator
	def getPwrupGKFData(self,chID, adcregProg):
		structSize = 2+2+4+1+3
		N = RxIQMCConstants.NUM_FFT_POINTS
		gKFReal = np.zeros(N)
		gKFImag = np.zeros(N)
		gUnc = np.zeros(N)
		gValidFlag = np.zeros(N)
		
		gKFStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_PWRUP_IQGKFOUT_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		gKFStartAddress = gKFStartAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		gKFAllData = np.zeros(N*structSize)
		dummyRead = self.memRead16('rxiqmcDram',gKFStartAddress)
		gKFAllData = adcregProg.burstRead(gKFStartAddress+0x8000+0x20,N*structSize)
		#for i in range(N):
		#	gKFReal[i] = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize)
		#	gKFImag[i] = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize+2)
		#	gUnc[i] = self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4)
		#	gValidFlag[i] = self.memRead8('rxiqmcDram',gKFStartAddress+i*structSize+8)
		for i in range(N):
			if i== 0:
				binIdx = 0
			else:
				binIdx = N-i		
			gKFReal[binIdx] = gKFAllData[i*structSize] + 256*gKFAllData[i*structSize+1]#self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize]
			gKFImag[binIdx] = gKFAllData[i*structSize+2] + 256*gKFAllData[i*structSize+3]#self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize+2]
			if gKFReal[binIdx] >=2**15:
				gKFReal[binIdx] = gKFReal[binIdx]-2**16
			if gKFImag[binIdx] >=2**15:
				gKFImag[binIdx] = gKFImag[binIdx]-2**16			
			gUnc[binIdx] = gKFAllData[i*structSize+4] + 256*gKFAllData[i*structSize+5]+ 256*256*gKFAllData[i*structSize+6]+ 256*256*256*gKFAllData[i*structSize+7]#self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4]
			gValidFlag[binIdx] = gKFAllData[i*structSize+8]#self.memRead8('rxiqmcDram',gKFStartAddress+i*structSize+8]
			
		return(gKFReal,gKFImag,gUnc,gValidFlag)
		#getPwrupGKFData
		
	@funcDecorator
	def getSSGKFData(self,chID,adcregProg):
		structSize = 2+2+4+1+3
		N = RxIQMCConstants.NUM_FFT_POINTS
		gKFReal = np.zeros(N)
		gKFImag = np.zeros(N)
		gUnc = np.zeros(N)
		gValidFlag = np.zeros(N)
		
		gKFStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_SS_GKFVAR_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		gKFStartAddress = gKFStartAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		gKFAllData = np.zeros(N*structSize)
		dummyRead = self.memRead16('rxiqmcDram',gKFStartAddress)
		gKFAllData = adcregProg.burstRead(gKFStartAddress+0x8000+0x20,N*structSize)
		#for i in range(N):
		#	info(i)
		#	gKFReal[i] = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize)
		#	gKFImag[i] = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize+2)
		#	gUnc[i] = self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4)
		#	gValidFlag[i] = self.memRead8('rxiqmcDram',gKFStartAddress+i*structSize+8)
		for i in range(N):
			if i== 0:
				binIdx = 0
			else:
				binIdx = N-i
			gKFReal[binIdx] = gKFAllData[i*structSize] + 256*gKFAllData[i*structSize+1]#self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize]
			gKFImag[binIdx] = gKFAllData[i*structSize+2] + 256*gKFAllData[i*structSize+3]#self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize+2]
			if gKFReal[binIdx] >=2**15:
				gKFReal[binIdx] = gKFReal[binIdx]-2**16
			if gKFImag[binIdx] >=2**15:
				gKFImag[binIdx] = gKFImag[binIdx]-2**16			
			gUnc[binIdx] = gKFAllData[i*structSize+4] + 256*gKFAllData[i*structSize+5]+ 256*256*gKFAllData[i*structSize+6]+ 256*256*256*gKFAllData[i*structSize+7]#self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4]
			gValidFlag[binIdx] = gKFAllData[i*structSize+8]#self.memRead8('rxiqmcDram',gKFStartAddress+i*structSize+8)
			
		return(gKFReal,gKFImag,gUnc,gValidFlag)
		#getSSGKFData
		
	@funcDecorator
	def getInternalGKFData(self,chID,adcregProg):
		structSize = 4+4+4
		N = RxIQMCConstants.NUM_FFT_POINTS
		gKFReal = np.zeros(N)
		gKFImag = np.zeros(N)
		gUnc = np.zeros(N)
		gValidFlag = np.zeros(N)
		
		gKFStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_SS_INTERNALKFVAR_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		gKFStartAddress = gKFStartAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		gKFAllData = np.zeros(N*structSize)
		dummyRead = self.memRead16('rxiqmcDram',gKFStartAddress)
		gKFAllData = adcregProg.burstRead(gKFStartAddress+0x8000+0x20,N*structSize)
		#for i in range(N):
		#	info(i)
		#	gKFReal[i] = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize)
		#	gKFImag[i] = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize+2)
		#	gUnc[i] = self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4)
		#	gValidFlag[i] = self.memRead8('rxiqmcDram',gKFStartAddress+i*structSize+8)
		for i in range(N):
			if i== 0:
				binIdx = 0
			else:
				binIdx = N-i
			gKFReal[binIdx] = gKFAllData[i*structSize] + 256*gKFAllData[i*structSize+1]+ 256*256*gKFAllData[i*structSize+2]+ 256*256*256*gKFAllData[i*structSize+3]
			gKFImag[binIdx] = gKFAllData[i*structSize+4] + 256*gKFAllData[i*structSize+5]+ 256*256*gKFAllData[i*structSize+6]+ 256*256*256*gKFAllData[i*structSize+7]
			if gKFReal[binIdx] >=2**31:
				gKFReal[binIdx] = gKFReal[binIdx]-2**32
			if gKFImag[binIdx] >=2**31:
				gKFImag[binIdx] = gKFImag[binIdx]-2**32			
			gUnc[binIdx] = gKFAllData[i*structSize+8] + 256*gKFAllData[i*structSize+9]+ 256*256*gKFAllData[i*structSize+10]+ 256*256*256*gKFAllData[i*structSize+11]#self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4]
		return(gKFReal,gKFImag,gUnc)
		#getInternalGKFData
		
		
	@funcDecorator
	def getSSGKFDataSpecificBin(self,chID,binIdInp):
		structSize = 2+2+4+1+3
		N = RxIQMCConstants.NUM_FFT_POINTS         
		binIdGInst = 0
		if binIdInp==0:
			binIdGInst = 0
		else:
			binIdGInst = N - binIdInp
			#gInstReal = np.zeros(N)
			#gInstImag = np.zeros(N)
			#gUnc = np.zeros(N)
			#gValidFlag = np.zeros(N)
			
		gKFStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_SS_GKFVAR_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		gKFStartAddress = gKFStartAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		i = binIdGInst
		#for i in range(N):
		gKFReal = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize)
		gKFImag = self.memRead16('rxiqmcDram',gKFStartAddress+i*structSize+2)
		gUnc = self.memRead32('rxiqmcDram',gKFStartAddress+i*structSize+4)
		gValidFlag = self.memRead8('rxiqmcDram',gKFStartAddress+i*structSize+8)
		if gKFReal >=2**15:
			gKFReal = gKFReal-2**16
		if gKFImag >=2**15:			
			gKFImag = gKFImag-2**16
			
		return(gKFReal,gKFImag,gUnc,gValidFlag)
		#getSSGKFDataSpecificBin
		
	@funcDecorator
	def getFreqIQMismatchCorrCoeffs(self):
		structSize = 2*17+2*17+4*17+4*17+4+4+4
		N = RxIQMCConstants.NUM_FFT_POINTS
		hR = np.zeros(17)
		hI = np.zeros(17)
		
		coeffStartAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_SS_INTERNALKFVAR_ADDRESS_POINTER_OFFSET) + chID*RxIQMCConstants.NUM_BINS*structSize
		
		
		
	@funcDecorator
	def getValidInstEstimatesAndValidityFlags(self,chID,expectedValidBins,adcregProg):
		[gInstReal,gInstImag,gUnc,gValid] = self.getGInstData(chID,adcregProg)
		#Compare if validity is high only for expectedValidBins and not for others. In this case pass output as 1 and pass out the gKF for the valid bins and then
		# in the calling fn, check if gKF is within expected value
		condition = gValid == 1
		N = RxIQMCConstants.NUM_FFT_POINTS
		binIndex = np.array(range(N))
		binValid = np.extract(condition,binIndex)
		allValidBinsMatch = (set(binValid)==set(expectedValidBins))
		gInstRealValid = np.extract(condition,gInstReal)
		gInstImagValid = np.extract(condition,gInstImag)
		gUncValid = np.extract(condition,gUnc)
		return(allValidBinsMatch,gInstRealValid,gInstImagValid,gUncValid)
		#getValidInstEstimatesAndValidityFlags
		
		
	@funcDecorator
	def getSSValidKFEstimatesAndValidityFlags(self,chID,expectedValidBins,adcregProg):
		[gKFReal,gKFImag,gUnc,gValid] = self.getSSGKFData(chID,adcregProg)
		#Compare if validity is high only for expectedValidBins and not for others. In this case pass output as 1 and pass out the gKF for the valid bins and then
		# in the calling fn, check if gKF is within expected value
		condition = gValid == 1
		N = RxIQMCConstants.NUM_FFT_POINTS
		binIndex = np.array(range(N))
		binValid = np.extract(condition,binIndex)
		allValidBinsMatch = (set(binValid)==set(expectedValidBins))
		gKFRealValid = np.extract(condition,gKFReal)
		gKFImagValid = np.extract(condition,gKFImag)
		gUncValid = np.extract(condition,gUnc)
		return(allValidBinsMatch,gKFRealValid,gKFImagValid,gUncValid)
		#getSSValidKFEstimatesAndValidityFlags
		
	@funcDecorator
	def getPwrupValidKFEstimatesAndValidityFlags(self,chID,expectedValidBins):
		[gKFReal,gKFImag,gUnc,gValid] = self.getPwrupGKFData(chID)
		#Compare if validity is high only for expectedValidBins and not for others. In this case pass output as 1 and pass out the gKF for the valid bins and then
		# in the calling fn, check if gKF is within expected value
		condition = gValid == 1
		N = RxIQMCConstants.NUM_FFT_POINTS
		binIndex = np.array(range(N))
		binValid = np.extract(condition,binIndex)
		allValidBinsMatch = (set(binValid)==set(expectedValidBins))
		gKFRealValid = np.extract(condition,gKFReal)
		gKFImagValid = np.extract(condition,gKFImag)
		gUncValid = np.extract(condition,gUnc)
		return(allValidBinsMatch,gKFRealValid,gKFImagValid,gUncValid)
		#getSSValidKFEstimatesAndValidityFlags
		
	@funcDecorator
	def getCurrInterruptCount(self):
		currInterruptCountAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_AGGR_INTERRUPTS_RECEIVED_POINTER_OFFSET)
		currInterruptCountAddress = currInterruptCountAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		currInterruptCount = self.memRead32('rxiqmcDram',currInterruptCountAddress)
		return(currInterruptCount)
		
	@funcDecorator
	def readMessageArray(self, Nvalues=10):
		messageArrayAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_FIFO_ARRAY_POINTER_OFFSET)
		messageArrayAddress = messageArrayAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		currMessAddress = messageArrayAddress
		info(currMessAddress)
		message = []
		for i in range(Nvalues):			
			tmp = self.memRead32('rxiqmcDram',currMessAddress)
			message.append(tmp)
			info([currMessAddress,tmp])
			currMessAddress = currMessAddress + 4 
		return(message)
		#readMessageArray
		
	@funcDecorator
	def getFwVersion(self):
		version = ''
		PGIndicator = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET)
		version = version + 'PG ' + str(PGIndicator)
		fwVersion = self.memRead16('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+2)
		dateVersion = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+4)
		monthVersion = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+5)
		yearVersion = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+6)
		version = version + 'FW version: ' + str(fwVersion) + 'date: ' + str(dateVersion) + 'month: ' + str(monthVersion) + 'year: ' + str(yearVersion)
		return(version)
		
		
	@funcDecorator
	def getFwVersionAllData(self):
		version = ''
		PGIndicator = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET)
		version = version + 'PG ' + str(PGIndicator)
		fwVersion = self.memRead16('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+2)
		dateVersion = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+4)
		monthVersion = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+5)
		yearVersion = self.memRead8('rxiqmcDram',MemConst.RX_IQMC_FW_VERSION_OFFSET+6)
		version = version + 'FW version: ' + str(fwVersion) + 'date: ' + str(dateVersion) + 'month: ' + str(monthVersion) + 'year: ' + str(yearVersion)
		return(version,fwVersion,dateVersion,monthVersion,yearVersion)
		
	@funcDecorator
	def read_iqTapPwrUpVars(self,adcregProg,chID):
		"""    // The below coeffs are in <-5.16s> by default.
		S16    x_hi[MAX_TAP_LENGTH];
		S16    x_hq[MAX_TAP_LENGTH];
		
		// This is the error in the loop that we track
		CS32   cl_hLoopVar[MAX_TAP_LENGTH];
		CS16   cx_GfLoopVar[NUM_FFT_BINS];
		
		S32    l_hiBias;
		S32    l_hqBias;
		
		U8     u_hiScale;
		U8     u_hqScale;
		U8     RESERVED
		U8     RESERVED"""
		
		structSize=RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR*(4+8)+RxIQMCConstants.NUM_BINS*4+12
		iqTapPwrUpVarsAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_PWRUP_IQTAPS_ADDRESS_POINTER_OFFSET) + chID*structSize
		info("iqTapPwrUpVarsAddress="+str(iqTapPwrUpVarsAddress))
		iqTapPwrUpVarsAddress = iqTapPwrUpVarsAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		iqTapPwrUpVars = np.zeros(structSize)
		dummyRead = self.memRead16('rxiqmcDram',iqTapPwrUpVarsAddress)
		iqTapPwrUpVars = adcregProg.burstRead(iqTapPwrUpVarsAddress+0x8000+0x20,structSize)
		
		x_hi = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		x_hq = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		x_hi_db = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		x_hq_db = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		cl_hLoopVar_I = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		cl_hLoopVar_Q = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		cx_GfLoopVar_I = np.zeros(RxIQMCConstants.NUM_BINS)
		cx_GfLoopVar_Q = np.zeros(RxIQMCConstants.NUM_BINS)
		relative_address=0
		for i in range (RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR):
			x_hi[i] = self.twos_comp(iqTapPwrUpVars[relative_address]+(iqTapPwrUpVars[relative_address+1]<<8),16)
			x_hi_db[i] = 20.0*np.log10(np.abs(x_hi[i])/2**16)
			relative_address=relative_address+2		
		for i in range (RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR):
			x_hq[i] = self.twos_comp(iqTapPwrUpVars[relative_address]+(iqTapPwrUpVars[relative_address+1]<<8),16)
			x_hq_db[i] = 20.0*np.log10(np.abs(x_hq[i])/2**16)
			relative_address=relative_address+2
		for i in range (RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR):
			cl_hLoopVar_I[i] = self.twos_comp(iqTapPwrUpVars[relative_address]+(iqTapPwrUpVars[relative_address+1]<<8)+\
			(iqTapPwrUpVars[relative_address+2]<<16)+(iqTapPwrUpVars[relative_address+3]<<24),32)
			cl_hLoopVar_Q[i] = self.twos_comp(iqTapPwrUpVars[relative_address+4]+(iqTapPwrUpVars[relative_address+1+4]<<8)+\
			(iqTapPwrUpVars[relative_address+2+4]<<16)+(iqTapPwrUpVars[relative_address+3+4]<<24),32)			
			relative_address=relative_address+8
		for i in range (RxIQMCConstants.NUM_BINS):
			cx_GfLoopVar_I[i] = self.twos_comp(iqTapPwrUpVars[relative_address]+(iqTapPwrUpVars[relative_address+1]<<8),16)
			cx_GfLoopVar_Q[i] = self.twos_comp(iqTapPwrUpVars[relative_address+2]+(iqTapPwrUpVars[relative_address+3]<<8),16)
			relative_address=relative_address+4
		l_hiBias=iqTapPwrUpVars[relative_address]
		relative_address=relative_address+4
		l_hqBias=iqTapPwrUpVars[relative_address]
		relative_address=relative_address+4
		u_hiScale=iqTapPwrUpVars[relative_address]
		relative_address=relative_address+1
		u_hqScale=iqTapPwrUpVars[relative_address]
		relative_address=relative_address+1
		info("Total bytes="+str(relative_address))
		info("x_hi="+str(x_hi))
		info("x_hq="+str(x_hq))
		info("x_hi_db="+str(x_hi_db))
		info("x_hq_db="+str(x_hq_db))
		info("cl_hLoopVar="+str(cl_hLoopVar_I))
		info("cl_hLoopVar="+str(cl_hLoopVar_Q))
		info("cx_GfLoopVar="+str(cx_GfLoopVar_I))
		info("cx_GfLoopVar="+str(cx_GfLoopVar_Q))
		info("l_hiBias="+str(l_hiBias))
		info("l_hqBias="+str(l_hqBias))
		info("u_hiScale="+str(u_hiScale))
		info("u_hqScale="+str(u_hqScale))
		return(x_hi,x_hq,x_hi_db,x_hq_db,cl_hLoopVar_I,cl_hLoopVar_Q,cx_GfLoopVar_I,cx_GfLoopVar_Q,l_hiBias,l_hqBias,u_hiScale,u_hqScale)
		
	@funcDecorator
	def read_iqTapSSVars(self,adcregProg,chID):
		"""    // The below coeffs are in <-5.16s> by default.
		S16    x_hi[MAX_TAP_LENGTH];
		S16    x_hq[MAX_TAP_LENGTH];
		
		// This is the error in the loop that we track
		CS32   cl_hLoopVar[MAX_TAP_LENGTH];
		CS16   cx_GfLoopVar[NUM_FFT_BINS];
		
		S32    l_hiBias;
		S32    l_hqBias;
		
		U8     u_hiScale;
		U8     u_hqScale;
		U8     RESERVED
		U8     RESERVED"""
		
		structSize=RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR*(4+8)+RxIQMCConstants.NUM_BINS*4+12
		iqTapSSVarsAddress = self.memRead32('rxiqmcDram',MemConst.RX_IQMC_SS_IQTAPS_ADDRESS_POINTER_OFFSET) + chID*structSize
		info("iqTapSSVarsAddress="+str(iqTapSSVarsAddress))
		iqTapSSVarsAddress = iqTapSSVarsAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
		iqTapSSVars = np.zeros(structSize)
		dummyRead = self.memRead16('rxiqmcDram',iqTapSSVarsAddress)
		iqTapSSVars = adcregProg.burstRead(iqTapSSVarsAddress+0x8000+0x20,structSize)
		
		x_hi = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		x_hq = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		x_hi_db = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		x_hq_db = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		cl_hLoopVar_I = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		cl_hLoopVar_Q = np.zeros(RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR)
		cx_GfLoopVar_I = np.zeros(RxIQMCConstants.NUM_BINS)
		cx_GfLoopVar_Q = np.zeros(RxIQMCConstants.NUM_BINS)
		relative_address=0
		for i in range (RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR):
			x_hi[i] = self.twos_comp(iqTapSSVars[relative_address]+(iqTapSSVars[relative_address+1]<<8),16)
			x_hi_db[i] = 20.0*np.log10(np.abs(x_hi[i])/2**16)
			relative_address=relative_address+2		
		for i in range (RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR):
			x_hq[i] = self.twos_comp(iqTapSSVars[relative_address]+(iqTapSSVars[relative_address+1]<<8),16)
			x_hq_db[i] = 20.0*np.log10(np.abs(x_hq[i])/2**16)
			relative_address=relative_address+2
		for i in range (RxIQMCConstants.NUM_TAPS_FREQ_DEP_CORRECTOR):
			cl_hLoopVar_I[i] = self.twos_comp(iqTapSSVars[relative_address]+(iqTapSSVars[relative_address+1]<<8)+\
			(iqTapSSVars[relative_address+2]<<16)+(iqTapSSVars[relative_address+3]<<24),32)
			cl_hLoopVar_Q[i] = self.twos_comp(iqTapSSVars[relative_address+4]+(iqTapSSVars[relative_address+1+4]<<8)+\
			(iqTapSSVars[relative_address+2+4]<<16)+(iqTapSSVars[relative_address+3+4]<<24),32)			
			relative_address=relative_address+8
		for i in range (RxIQMCConstants.NUM_BINS):
			cx_GfLoopVar_I[i] = self.twos_comp(iqTapSSVars[relative_address]+(iqTapSSVars[relative_address+1]<<8),16)
			cx_GfLoopVar_Q[i] = self.twos_comp(iqTapSSVars[relative_address+2]+(iqTapSSVars[relative_address+3]<<8),16)
			relative_address=relative_address+4
		l_hiBias=iqTapSSVars[relative_address]
		relative_address=relative_address+4
		l_hqBias=iqTapSSVars[relative_address]
		relative_address=relative_address+4
		u_hiScale=iqTapSSVars[relative_address]
		relative_address=relative_address+1
		u_hqScale=iqTapSSVars[relative_address]
		relative_address=relative_address+1
		info("Total bytes="+str(relative_address))
		info("x_hi="+str(x_hi))
		info("x_hq="+str(x_hq))
		info("x_hi_db="+str(x_hi_db))
		info("x_hq_db="+str(x_hq_db))
		info("cl_hLoopVar="+str(cl_hLoopVar_I))
		info("cl_hLoopVar="+str(cl_hLoopVar_Q))
		info("cx_GfLoopVar="+str(cx_GfLoopVar_I))
		info("cx_GfLoopVar="+str(cx_GfLoopVar_Q))
		info("l_hiBias="+str(l_hiBias))
		info("l_hqBias="+str(l_hqBias))
		info("u_hiScale="+str(u_hiScale))
		info("u_hqScale="+str(u_hqScale))
		return(x_hi,x_hq,x_hi_db,x_hq_db,cl_hLoopVar_I,cl_hLoopVar_Q,cx_GfLoopVar_I,cx_GfLoopVar_Q,l_hiBias,l_hqBias,u_hiScale,u_hqScale)
		
		
	@funcDecorator
	def read_iqDSADepGainCoeff(self,adcregProg,chID):
		""" PG1p1   // 
		U8     u_gainCoefsAv;
		U8     u_gainScaleI;
		U8     u_gainScaleQ;
		U8     u_maxAbsEstDsaId;
		// The below coeffs are in <-4.15s> by default (scale = 0),
		// but if scale it is <-4+scale.15-scale,s>
		S16    x_gainCoeffI[NUM_DSA_ATTN];
		S16    x_gainCoeffQ[NUM_DSA_ATTN];
		
		// The below will bein <.16u> format
		U16    w_maxAbsGainCoeff;
		U16    RESERVED
		// <-6.38u> format
		U32    q_estUnc[NUM_DSA_ATTN];
		// This contains 1 for RC indices for which we have valid estimates
		U8     u_rcEstAv[MAX_NUM_RC_IDX];
		
		// This contains 1 for Dsa indices for which we have valid estimates
		U8     u_estAv[NUM_DSA_ATTN];
		
		U8 RESERVED
		U8 RESERVED
		
		
		
		"""
		RX_IQMC_SS_DSADEPGAINCOEFF_ADDRESS_POINTER_OFFSET=0x17C08
		NUM_DSA_ATTN=37
		MAX_NUM_RC_IDX=128
		[version,fwVersion,dateVersion,monthVersion,yearVersion] = self.getFwVersionAllData()
		if fwVersion > 100:#PG1p1
			
			structSize=4+NUM_DSA_ATTN*(2*2)+4+NUM_DSA_ATTN*(4)+MAX_NUM_RC_IDX*(1)+NUM_DSA_ATTN*1+2
			#structSize=304
			iqDSADepGainCoeffAddress = self.memRead32('rxiqmcDram',RX_IQMC_SS_DSADEPGAINCOEFF_ADDRESS_POINTER_OFFSET) + chID*structSize
			info("iqDSADepGainCoeffAddress="+str(iqDSADepGainCoeffAddress))
			iqDSADepGainCoeffAddress = iqDSADepGainCoeffAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
			iqDSADepGainCoeff = np.zeros(structSize)
			dummyRead = self.memRead16('rxiqmcDram',iqDSADepGainCoeffAddress)
			iqDSADepGainCoeff = adcregProg.burstRead(iqDSADepGainCoeffAddress+0x8000+0x20,structSize)
			
			x_gainCoeffi = np.zeros(NUM_DSA_ATTN)
			x_gainCoeffq = np.zeros(NUM_DSA_ATTN)
			gainCoeffEstimUnc = np.zeros(NUM_DSA_ATTN)
			gainCoeffEstimAvailable = np.zeros(NUM_DSA_ATTN)
			relative_address=0
			gainScaleI = iqDSADepGainCoeff[relative_address+1];
			gainScaleQ = iqDSADepGainCoeff[relative_address+2];
			relative_address  =  relative_address + 4
			for i in range (NUM_DSA_ATTN):
				x_gainCoeffi[i] = self.twos_comp(iqDSADepGainCoeff[relative_address]+(iqDSADepGainCoeff[relative_address+1]<<8),16)			
				relative_address=relative_address+2		
			for i in range (NUM_DSA_ATTN):
				x_gainCoeffq[i] = self.twos_comp(iqDSADepGainCoeff[relative_address]+(iqDSADepGainCoeff[relative_address+1]<<8),16)			
				relative_address=relative_address+2		
			relative_address  =  relative_address + 4-2	
			for i in range (NUM_DSA_ATTN):
				gainCoeffEstimUnc[i] = iqDSADepGainCoeff[relative_address]+(iqDSADepGainCoeff[relative_address+1]<<8)+\
				(iqDSADepGainCoeff[relative_address+2]<<16)+(iqDSADepGainCoeff[relative_address+3]<<24)
				relative_address=relative_address+4
			relative_address = relative_address + MAX_NUM_RC_IDX*(1)-4
			for i in range (NUM_DSA_ATTN):
				gainCoeffEstimAvailable[i] = iqDSADepGainCoeff[relative_address]
				relative_address = relative_address + 1
		else:#PG1p0
			"""
			//PG1p0
			U8     u_gainCoefsAv;
			U8     u_gainScaleI;
			U8     u_gainScaleQ;
			U8     u_maxAbsEstDsaId;
			// The below coeffs are in <-4.15s> by default (scale = 0),
			// but if scale it is <-4+scale.15-scale,s>
			S16    x_gainCoeffI[NUM_DSA_ATTN];
			S16    x_gainCoeffQ[NUM_DSA_ATTN];
			
			// The below will bein <.16u> format
			U16    w_maxAbsGainCoeff;
			U16    RESERVED
			// <-6.38u> format
			U32    q_estUnc[NUM_DSA_ATTN];
			"""
			
			
			structSize=4+NUM_DSA_ATTN*(2*2)+4+NUM_DSA_ATTN*(4)			
			iqDSADepGainCoeffAddress = self.memRead32('rxiqmcDram',RX_IQMC_SS_DSADEPGAINCOEFF_ADDRESS_POINTER_OFFSET) + chID*structSize
			info("iqDSADepGainCoeffAddress="+str(iqDSADepGainCoeffAddress))
			iqDSADepGainCoeffAddress = iqDSADepGainCoeffAddress - MemConst.RX_IQMC_DRAM_START_ADDRESS
			iqDSADepGainCoeff = np.zeros(structSize)
			dummyRead = self.memRead16('rxiqmcDram',iqDSADepGainCoeffAddress)
			iqDSADepGainCoeff = adcregProg.burstRead(iqDSADepGainCoeffAddress+0x8000+0x20,structSize)
			
			x_gainCoeffi = np.zeros(NUM_DSA_ATTN)
			x_gainCoeffq = np.zeros(NUM_DSA_ATTN)
			gainCoeffEstimUnc = np.zeros(NUM_DSA_ATTN)
			gainCoeffEstimAvailable = np.zeros(NUM_DSA_ATTN)
			relative_address=0
			gainScaleI = iqDSADepGainCoeff[relative_address+1];
			gainScaleQ = iqDSADepGainCoeff[relative_address+2];
			relative_address  =  relative_address + 4
			for i in range (NUM_DSA_ATTN):
				x_gainCoeffi[i] = self.twos_comp(iqDSADepGainCoeff[relative_address]+(iqDSADepGainCoeff[relative_address+1]<<8),16)			
				relative_address=relative_address+2		
			for i in range (NUM_DSA_ATTN):
				x_gainCoeffq[i] = self.twos_comp(iqDSADepGainCoeff[relative_address]+(iqDSADepGainCoeff[relative_address+1]<<8),16)			
				relative_address=relative_address+2		
			relative_address  =  relative_address + 4-2	
			for i in range (NUM_DSA_ATTN):
				gainCoeffEstimUnc[i] = iqDSADepGainCoeff[relative_address]+(iqDSADepGainCoeff[relative_address+1]<<8)+\
				(iqDSADepGainCoeff[relative_address+2]<<16)+(iqDSADepGainCoeff[relative_address+3]<<24)
				relative_address=relative_address+4
				
		info("WARNING: IN PG1p0, estimate availability is not populated. So variable will have 0s")
		info("Total bytes="+str(relative_address))
		info("gainScaleI="+str(gainScaleI))
		info("gainScaleQ="+str(gainScaleQ))
		info("x_gainCoeffi="+str(x_gainCoeffi))
		info("x_gainCoeffq="+str(x_gainCoeffq))
		info("gainCoeffEstimUnc="+str(gainCoeffEstimUnc))
		info("gainCoeffEstimAvailable="+str(gainCoeffEstimAvailable))
		return(x_gainCoeffi,x_gainCoeffq,gainScaleI,gainScaleQ,gainCoeffEstimUnc,gainCoeffEstimAvailable)
		
		
	@funcDecorator
	def twos_comp(self,val, bits):
		"""compute the 2's complement of int value val"""
		if (val & (1 << (bits - 1))) != 0:# if sign bit is set e.g., 8bit: 128-255
			val = val - (1 << bits)# compute negative value
		return (val)
		
		#RxIqmcFwGetStatus
