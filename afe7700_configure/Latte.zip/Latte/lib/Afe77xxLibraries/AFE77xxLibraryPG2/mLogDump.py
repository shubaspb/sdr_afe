import globalDefs as Globals
import os
import math

class logDump():
	
	def __init__(self,fileName):
		self.commentForWrite=""
		self.rewriteFileFormat4=0
		self.rewriteFile=0
		self.logFileName=""
		self.setFileName(fileName)
		self.ignoreLogComments=0
		self.logFormat=0x24# Bit 0:				Address    Data
		# Bit 1:	Custom		AFE77xx_RegWrite(0x0014,0x00);	AFE77xx_RegRead(0x0049)
		# Bit 2:	Custom2		SPIWrite 0014,00,lsb,msb;	SPIRead 0049,lsb,msb
		# Bit 3:	Tester		Tester Format: WriteSPI(0x0000,0x30);
		# Bit 4:	Property	Direct Property Writes
		# Bit 5:	Custom3		Eformat
		self.previousBlock=""
		self.previousStepName=""
		self.stepCommandPrefix=""
		self.stepCommandSuffix=""
		self.previousStepNo=-1
		self.overrideMask=0
		self.logCombinedBurstWrites=False
		self.enableReadCheck=False
		self.enableReads=True
		#__init__
		
	def setFileName(self,fileName):
		if not os.path.exists(fileName[:fileName.rfind(r'/')]) and not os.path.exists(fileName[:fileName.rfind('\\')]):
			Globals.error(r"Path "+str(fileName[:fileName.rfind(r'/')])+" doesn't exist. Writing into file: "+str(Globals.ASTERIX_DIR+Globals.DEVICES_DIR+"test.txt"))
			fileName=Globals.ASTERIX_DIR+"test.txt"
		self.fileFormat0=fileName
		self.fileFormat1=fileName[:fileName.rfind(r'.')]+"Custom"+fileName[fileName.rfind(r'.'):]
		self.fileFormat2=fileName[:fileName.rfind(r'.')]+"Custom2"+fileName[fileName.rfind(r'.'):]
		self.fileFormat3=fileName[:fileName.rfind(r'.')]+"Tester"+fileName[fileName.rfind(r'.'):]
		self.fileFormat4=fileName[:fileName.rfind(r'.')]+"Property"+fileName[fileName.rfind(r'.'):]
		self.fileFormat5=fileName[:fileName.rfind(r'.')]+"Custom3"+fileName[fileName.rfind(r'.'):]
		#setFileName
		
		
	def logNewStep(self,stepName):
		if stepName==self.previousStepName:
			self.previousStepNo+=1
		else:
			self.previousStepNo=0
			self.previousStepName=stepName
		if self.logFormat&0b00100!=0:
			if not os.path.exists(self.fileFormat2) or self.rewriteFile==True:
				logFileFormat2=open(self.fileFormat2, "w")
			else:
				logFileFormat2=open(self.fileFormat2, "a")
				
				
			logFileFormat2.write(r"\\ STEP: "+self.stepCommandPrefix+stepName+r"/step"+str(self.previousStepNo)+" "+self.stepCommandSuffix+"\n")
			logFileFormat2.close()
			
		if self.logFormat&0b00010!=0:
			if not os.path.exists(self.fileFormat1) or self.rewriteFile==True:
				logFileFormat1=open(self.fileFormat1, "w")
			else:
				logFileFormat1=open(self.fileFormat1, "a")
				
				
			logFileFormat1.write("/*"+self.stepCommandPrefix+stepName+r"/step"+str(self.previousStepNo)+" "+self.stepCommandSuffix+"*/\n")
			logFileFormat1.close()
			
			############# Format 5 and Format 2
		if self.logFormat&0b100000!=0:
			newFile=True
			if not os.path.exists(self.fileFormat5) or self.rewriteFile==True:
				newFile=True
				logFileFormat5=open(self.fileFormat5, "w")
			else:
				newFile=False
				#logFileFormat5=open(self.fileFormat5, "a")
				
			if newFile==False:
				lineToWrite=self.stepCommandPrefix+stepName+r"/step"+str(self.previousStepNo)+" "+self.stepCommandSuffix+"\n"
				logFileFormat5=open(self.fileFormat5, "r")
				fileData=logFileFormat5.read()
				if "0x" in fileData:
					if fileData[fileData.rfind(", 0x")+12]==",":
						fileData=fileData[:fileData.rfind(", 0x")+12]+fileData[fileData.rfind(", 0x")+13:]+"\n"+lineToWrite+"\n"
				else:
					fileData=lineToWrite+"\n"
				logFileFormat5.close()
				logFileFormat5=open(self.fileFormat5, "w")
				logFileFormat5.write(fileData)
			else:
				logFileFormat5.write(self.stepCommandPrefix+stepName+r"/step"+str(self.previousStepNo)+" "+self.stepCommandSuffix+"\n")
			logFileFormat5.close()
		self.rewriteFile=0
		#logNewStep
		
	def logComment(self,block,msg):
		msg=str(msg)
		msg=msg.replace("CREDO","SERDES")
		msg=msg.replace("api","macro")
		msg=msg.replace("API","MACRO")
		
		if self.logFormat&0b0001!=0:
			if msg=="":
				lineEnd="\n"
			else:
				lineEnd="// "+msg+"\n"
			if not os.path.exists(self.fileFormat0) or self.rewriteFile==True:
				logFileFormat0=open(self.fileFormat0, "w")
			else:
				logFileFormat0=open(self.fileFormat0, "a")
			logFileFormat0.write("\n")
			if self.previousBlock!=block:
				logFileFormat0.write("// "+str(block)+"\n")
			logFileFormat0.write(lineEnd)
			logFileFormat0.write("\n")
			logFileFormat0.close()
			
			############# Format 1
		if self.logFormat&0b0010!=0:
			if msg=="":
				lineEnd="\n"
			else:
				if "SPIPoll " in msg or "WAIT " in msg:
					lineEnd=msg+"\n"
				else:
					lineEnd="/*"+msg+"*/\n"
			if not os.path.exists(self.fileFormat1) or self.rewriteFile==True:
				logFileFormat1=open(self.fileFormat1, "w")
			else:
				logFileFormat1=open(self.fileFormat1, "a")
			logFileFormat1.write("\n")
			logFileFormat1.write(lineEnd)
			logFileFormat1.write("\n")
			logFileFormat1.close()
			
			############# Format 2
		if self.logFormat&0b0100!=0:
			if msg=="":
				lineEnd="\n"
			else:
				if "SPIPoll " in msg or "WAIT " in msg:
					lineEnd=msg+"\n"
				else:
					lineEnd=r"\\"+msg+"\n"
			if not os.path.exists(self.fileFormat2) or self.rewriteFile==True:
				logFileFormat2=open(self.fileFormat2, "w")
			else:
				logFileFormat2=open(self.fileFormat2, "a")
			logFileFormat2.write("\n")
			if self.previousBlock!=block:
				logFileFormat2.write(r"\\"+str(block)+"\n")
			logFileFormat2.write(lineEnd)
			logFileFormat2.write("\n")
			logFileFormat2.close()
			
			############# Format 3
		if self.logFormat&0b1000!=0:
			if msg=="":
				lineEnd="\n"
			else:
				lineEnd="{"+msg+"}\n"
			if not os.path.exists(self.fileFormat3) or self.rewriteFile==True:
				logFileFormat3=open(self.fileFormat3, "w")
			else:
				logFileFormat3=open(self.fileFormat3, "a")
			logFileFormat3.write("\n")
			logFileFormat3.write(lineEnd)
			logFileFormat3.write("\n")
			logFileFormat3.close()
			
			
			
			############# Format 5
		if self.logFormat&0b100000!=0:
			if msg=="":
				lineEnd="\n"
			else:
				
				if "SPIPoll " in msg:
					address=int(msg[8:].split(',')[0],16)
					lsb=int(msg[8:].split(',')[1],16)
					msb=int(msg[8:].split(',')[2],16)
					expectedValue=int(msg[8:].split(',')[3],16)<<lsb
					mask=(2**(msb+1-lsb)-1)<<lsb
					lineEnd="0xD000"+"{:04x}".format(address).upper()+", 0x0000"+"{:02x}".format(mask).upper()+"{:02x}".format(expectedValue).upper()+",\n"
				elif "WAIT " in msg:
					delayTime=int(math.ceil(float(msg.strip()[5:])*1000))
					if delayTime<0x100:
						lineEnd="0xDE000000, 0x0000"+"{:04x}".format(delayTime).upper()+",\n"
					else:
						lineEnd=""
						for i in range(delayTime>>8):
							lineEnd+="0xDE000000, 0x0000"+"{:04x}".format(0xff).upper()+",\n"
						lineEnd+="0xDE000000, 0x0000"+"{:04x}".format(delayTime-(0xff*(i+1))).upper()+",\n"
						#lineEnd=msg+"\n"
				else:
					lineEnd=r"/*"+msg.replace('\\','')+"*/\n"
			if (not os.path.exists(self.fileFormat5)) or self.rewriteFile==True:
				logFileFormat5=open(self.fileFormat5, "w")
				logFileFormat5.write("\n")
				logFileFormat5.write(lineEnd)
				logFileFormat5.write("\n")
			elif False:#"/*END: " in lineEnd:
				logFileFormat5=open(self.fileFormat5, "r")
				fileData=logFileFormat5.read()
				if fileData[fileData.rfind(", 0x")+12]==",":
					fileData=fileData[:fileData.rfind(", 0x")+12]+fileData[fileData.rfind(", 0x")+13:]+"\n"+lineEnd+"\n"
				logFileFormat5.close()
				logFileFormat5=open(self.fileFormat5, "w")
				logFileFormat5.write(fileData)
				logFileFormat5.close()
			else:
				logFileFormat5=open(self.fileFormat5, "a")
				logFileFormat5.write("\n")
				#if self.previousBlock!=block:
				#	logFileFormat5.write(r"\\"+str(block)+"\n")
				logFileFormat5.write(lineEnd)
				logFileFormat5.write("\n")
				logFileFormat5.close()
		self.rewriteFile=0
		#printCommentToLog
		
	def logPolling(self,address,lsb,msb,expectedReadValue):
		pass
		
	def logBurstWrite(self,block,address,writeValues):
		if self.logCombinedBurstWrites==False:
			for i in range(len(writeValues)): 
				self.logRawWriteRead(block,address+i,writeValues[i],0,lsb=0,msb=7) 
		else:
			if self.ignoreLogComments==False: 
				commentForWrite=self.commentForWrite.strip() 
				commentForWrite=commentForWrite.replace("SERDES","SERDES") 
				commentForWrite=commentForWrite.replace("macro","macro") 
				commentForWrite=commentForWrite.replace("MACRO","MACRO") 
			else: 
				commentForWrite="" 
				
			if self.logFormat&0b00100!=0: 
				if commentForWrite=="": 
					lineEnd="\n" 
				else: 
					lineEnd="\t//"+commentForWrite+"\n" 
				if not os.path.exists(self.fileFormat2) or self.rewriteFile==True: 
					logFileFormat2=open(self.fileFormat2, "w") 
				else: 
					logFileFormat2=open(self.fileFormat2, "a") 
				if self.previousBlock!=block: 
					logFileFormat2.write("\n//"+str(block)+"\n") 
				writeValuesStr=["0x{:02x}".format(i).replace("0x","") for i in writeValues]
				logFileFormat2.write("SPIBurstWrite "+"0x{:04x}".format(address).replace("0x","")+","+str(writeValuesStr).replace("'","")+lineEnd) 
				logFileFormat2.close() 			
				
			x=self.logFormat
			self.logFormat=self.logFormat&0xfb
			for i in range(len(writeValues)): 
				self.logRawWriteRead(block,address+i,writeValues[i],0,lsb=0,msb=7) 
			self.logFormat=x
			
			
	def logPropertyWriteRead(self,block,prop,value,writeRead):
		""" Call this function before raw writes or after the raw reads 
			writeRead=0 for write and writeRead=1 for read"""
		if writeRead==0:
			msg=""
		else:
			msg="Read\t"
			
		if str(prop.name)+"="+str(hex(value).lower().replace('l','')) not in self.commentForWrite:
			if prop.parent.parent.name == "PAGE_SEL":
				msg+="PAGE: " +str(prop.name)+"="+str(hex(value).lower().replace('l',''))
			else:
				msg+=str(prop.name)+"="+str(hex(value).lower().replace('l',''))
			msg+=";"
			if len(prop.valueList)>value and prop.valueList[value].desc.strip()=="":
				msg+="(Meaning: "+str(prop.valueList[value].desc)+");"
			msg+=" \tAddress("
			for r in reversed(prop.rangeList):
				msg+=str(hex(r.address))+"["+str(r.msb)+":"+str(r.lsb)+"],"
			msg+=")"
		if writeRead==0:
			self.commentForWrite+=msg
		else:
			self.logComment(block,msg)
			
		if self.logFormat&0b10000!=0:
			if not os.path.exists(self.fileFormat4) or self.rewriteFileFormat4==True:
				logFileFormat4=open(self.fileFormat4, "w")
			else:
				logFileFormat4=open(self.fileFormat4, "a")
			if writeRead==0:
				logFileFormat4.write(str(prop.fqn[:prop.fqn.rfind('._')]+"."+prop.fqn[prop.fqn.rfind('._')+2:])+" = "+str(value)+"\n")
			else:
				logFileFormat4.write(str(prop.fqn[:prop.fqn.rfind('._')]+"."+prop.fqn[prop.fqn.rfind('._')+2:])+"\n")
			logFileFormat4.close()
			self.rewriteFileFormat4=False
			#logPropertyWriteRead
			
			
	def logRawWriteRead(self,block,address,value,writeRead,lsb=0,msb=7,expectedReadValue=-1):
		""" writeRead=0 for write and =1 for read """
		if self.ignoreLogComments==False:
			commentForWrite=self.commentForWrite.strip()
			commentForWrite=commentForWrite.replace("CREDO","SERDES")
			commentForWrite=commentForWrite.replace("api","macro")
			commentForWrite=commentForWrite.replace("API","MACRO")
		else:
			commentForWrite=""
			############# Format 0
		if self.logFormat&0b00001!=0:
			if commentForWrite=="":
				lineEnd="\n"
			else:
				lineEnd="\t// "+commentForWrite+"\n"
			if not os.path.exists(self.fileFormat0) or self.rewriteFile==True:
				logFileFormat0=open(self.fileFormat0, "w")
			else:
				logFileFormat0=open(self.fileFormat0, "a")
			if self.previousBlock!=block:
				logFileFormat0.write("\n// "+str(block)+"\n")
			if writeRead==0:
				logFileFormat0.write("0x{:04x}".format(address)+"\t"+"0x{:02x}".format(value)+lineEnd)
			else:
				logFileFormat0.write("0x{:04x}".format(address)+"\t\t// Read: "+"0x{:02x}".format(value)+lineEnd)
			logFileFormat0.close()
			
			############# Format 1
		if self.logFormat&0b00010!=0:
			if commentForWrite=="":
				lineEnd="\n"
			else:
				lineEnd="\t/*"+commentForWrite+"*/\n"
			if not os.path.exists(self.fileFormat1) or self.rewriteFile==True:
				logFileFormat1=open(self.fileFormat1, "w")
			else:
				logFileFormat1=open(self.fileFormat1, "a")
			if writeRead==0:
				logFileFormat1.write(block+"_RegWrite("+"0x{:04x}".format(address)+","+"0x{:02x}".format(value)+","+str(lsb)+","+str(msb)+")"+lineEnd)
			else:
				logFileFormat1.write(block+"_RegRead("+"0x{:04x}".format(address)+","+str(lsb)+","+str(msb)+");"+"\t\*Read"+"0x{:02x}".format(value)+"*/"+lineEnd)
			logFileFormat1.close()
			
			############# Format 2
		if self.logFormat&0b00100!=0:
			if commentForWrite=="":
				lineEnd="\n"
			else:
				lineEnd="\t//"+commentForWrite+"\n"
			if not os.path.exists(self.fileFormat2) or self.rewriteFile==True:
				logFileFormat2=open(self.fileFormat2, "w")
			else:
				logFileFormat2=open(self.fileFormat2, "a")
			if self.previousBlock!=block:
				logFileFormat2.write("\n//"+str(block)+"\n")
			if writeRead==0:
				logFileFormat2.write("SPIWrite "+"0x{:04x}".format(address).replace("0x","")+","+"0x{:02x}".format(value).replace("0x","")+","+str(lsb)+","+str(msb)+lineEnd)
			elif expectedReadValue!=-1 and self.enableReadCheck==True:
				if self.overrideMask==0:
					logFileFormat2.write("SPIReadCheck "+"0x{:04x}".format(address).replace("0x","")+","+str(lsb)+","+str(msb)+","+"{:02x}".format(expectedReadValue)+lineEnd)#",// Read"+"0x{:02x}".format(value).replace("0x","")+lineEnd)
				else:
					lsbPostMask=lsb+(len("{:0b}".format(self.overrideMask))-"{:0b}".format(self.overrideMask).rfind('1'))-1
					msbPostMask=lsb+(len("{:0b}".format(self.overrideMask))-"{:0b}".format(self.overrideMask).find('1'))-1				
					logFileFormat2.write("SPIReadCheck "+"0x{:04x}".format(address).replace("0x","")+","+str(lsbPostMask)+","+str(msbPostMask)+","+"{:02x}".format(expectedReadValue)+lineEnd)#",// Read"+"0x{:02x}".format(value).replace("0x","")+lineEnd)
					self.overrideMask=self.overrideMask>>(msb+1-lsb)
			elif self.enableReads==True:
				logFileFormat2.write("SPIRead "+"0x{:04x}".format(address).replace("0x","")+","+str(lsb)+","+str(msb)+lineEnd)#",// Read"+"0x{:02x}".format(value).replace("0x","")+lineEnd)
			logFileFormat2.close()
			
			############# Format 3
		if self.logFormat&0b01000!=0:
			if commentForWrite=="":
				lineEnd="\n"
			else:
				lineEnd="\t{"+commentForWrite+"}\n"
			if not os.path.exists(self.fileFormat3) or self.rewriteFile==True:
				logFileFormat3=open(self.fileFormat3, "w")
			else:
				logFileFormat3=open(self.fileFormat3, "a")
			if writeRead==0:
				if "afe" in block.lower():
					logFileFormat3.write("WriteSPI"+"("+"0x{:04x}".format(address)+","+"0x{:02x}".format(value)+")"+lineEnd)
				else:
					logFileFormat3.write("WriteSPI_"+block+"("+"0x{:04x}".format(address)+","+"0x{:02x}".format(value)+")"+lineEnd)
			else:
				if "afe" in block.lower():
					logFileFormat3.write("ReadSPI"+"("+"0x{:04x}".format(address)+",SPI_READBACK);\t{Read Value: "+"0x{:02x}".format(value)+"}"+lineEnd)
				else:
					logFileFormat3.write("ReadSPI_"+block+"("+"0x{:04x}".format(address)+",SPI_READBACK);\t{Read Value: "+"0x{:02x}".format(value)+"}"+lineEnd)
			logFileFormat3.close()
			
			
			############# Format 5
		if self.logFormat&0b100000!=0:
			if commentForWrite=="":
				lineEnd="\n"
			else:
				lineEnd="\t/*"+commentForWrite+"*/\n"
			if not os.path.exists(self.fileFormat5) or self.rewriteFile==True:
				logFileFormat5=open(self.fileFormat5, "w")
			else:
				logFileFormat5=open(self.fileFormat5, "a")
			if self.previousBlock!=block:
				logFileFormat5.write("\n//"+str(block)+"\n")
			if writeRead==0:
				if (lsb==0 and msb==7) or address in range(0x10,0x20):
					logFileFormat5.write("0x0000"+"{:04x}".format(address).upper()+", 0x000000"+"{:02x}".format(value).upper()+","+lineEnd)
					#logFileFormat5.write("SPIWrite "+"0x{:04x}".format(address).replace("0x","")+","+"0x{:02x}".format(value).replace("0x","")+lineEnd)
				else:
					logFileFormat5.write("0xDF00"+"{:04x}".format(address).upper()+", 0x0000"+"{:02x}".format((2**(msb+1-lsb)-1)<<lsb).upper()+"{:02x}".format(value).upper()+","+lineEnd)
					#logFileFormat5.write("SPIRMW "+"0x{:04x}".format(address).replace("0x","")+","+"0x{:02x}".format(value).replace("0x","")+","+str(lsb)+","+str(msb)+lineEnd)
			else:
				
				if self.overrideMask==0:
					mask=(2**(msb+1-lsb)-1)<<lsb
				else:
					mask=(self.overrideMask<<lsb)&0xff
				if expectedReadValue==-1:
					logFileFormat5.write("0xAD00"+"{:04x}".format(address).upper()+", 0x0010"+"{:02x}".format(mask).upper()+"00"+","+lineEnd)
				else:
					logFileFormat5.write("0xAD00"+"{:04x}".format(address).upper()+", 0x0000"+"{:02x}".format(mask).upper()+"{:02x}".format(expectedReadValue).upper()+","+lineEnd)
				if self.overrideMask!=0:
					self.overrideMask=self.overrideMask>>(msb+1-lsb)
					#logFileFormat5.write("SPIRead "+"0x{:04x}".format(address).replace("0x","")+","+str(lsb)+","+str(msb)+lineEnd)#",// Read"+"0x{:02x}".format(value).replace("0x","")+lineEnd)
			logFileFormat5.close()
		self.rewriteFile=0
		self.commentForWrite=""
		self.previousBlock=block
		#logRawWriteRead
