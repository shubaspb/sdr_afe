from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

import mRxAgc
reload(mRxAgc)
from mRxAgc import rxAgcDgcLib

class rxDigLib(projectBaseClass):
	"""Contains RX DIG AB/CD specific functions. self.regs=device.RX.DIG_AB.RxDecSet """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
		self.AGCDGC=[rxAgcDgcLib(topno,0,regs,deviceRefs),rxAgcDgcLib(topno,1,regs,deviceRefs)]
		#__init__
		
	@funcDecorator
	def configRxDig(self):
		""" 'Configuring the RX Digital' 'Done configuring the RX Digital' """  
		self.defaultRxtop()
		decimMode      =self.systemParams.ddcFactorRx[self.topno]
		halfRateMode   =self.systemParams.halfRateModeRx
		if self.systemParams.ddcFactorRx[self.topno]!=1:
			self.regs.Register36133_100h.Property_a00h_1_1 = 0
		else:
			self.regs.Register36133_100h.Property_a00h_1_1 = 1
			
		self.regs.Register37538_545h.pdn_in = 1
		self.regs.Register37565_945h.pdn_in = 1
		(found,(stage1Setting,stage2Setting,stage3Setting,stage4Setting,stage4p5Setting))=self.checkValidityOfDigChain(0,decimMode,halfRateMode)
		if found==False and self.systemParams.ddcFactorRx[self.topno]!=1:
			error(r"Didnt find the Correct Setting for Rx Decim chain: "+str(decimMode))
			
		self.regs.Register36133_100h.RxADCRate 		= (2,1).index(stage1Setting)
		self.regs.Register36133_100h.RxDecStg2Mode 	= (2,3).index(stage2Setting)
		self.regs.Register36133_100h.RxDecStg3Mode 	= (1,2).index(stage3Setting)
		self.regs.Register36133_100h.RxDecStg4Mode   = (1.0,1.0,round(7.0/6,4),round(9.0/8,4)).index(round(stage4Setting,4))
		self.regs.Register36247_A04h.RxDecStg4p5mode = (1,2).index(stage4p5Setting)
		
		self.regs.low_if_decim_common.bypass_low_if_decimator = 1
		self.regs.Register36133_100h.Property_124h_0_0 = not (2,3).index(stage2Setting)
		
		#configRxDig
		
	@funcDecorator
	def defaultRxtop(self):
		lane = ["i","q"]
		chno = [0,1]
		if self.systemStatus.chipVersion>0x10:
			self.regs.Register36133_100h.Property_120h_2_0 = 3
		else:
			self.regs.Register36133_100h.Property_120h_2_0 = 4;# intially it was 3 changing to 4 based on simulations
		self.regs.RxDecCfg3.RxDecClkDiv2PhaseDis = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv4PhaseDis = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv2p0gate = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv2p1gate = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv4p0gate = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv4p1gate = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv4p2gate = 0	;
		self.regs.RxDecCfg3.RxDecClkDiv4p3gate = 0	;
		self.regs.Register36156_A1Eh.RxClkGenLFSRLoad = 0	;
		self.regs.Register36156_A1Eh.RxClkGenLFSRSeed = 527284091;
		self.regs.Register36133_100h.ReservedDecCfg1 = 0	;
		self.regs.RxDecCfg3.ReservedDecCfg3 = 0	;
		self.regs.RxDecCfg3.SpareDecCfg3 = 0	;
		#info("fifo pointer load")
		#info("fifo pointer load end")
		self.regs.Register36133_100h.Property_120h_26_24 = 2#4;
		
		self.regs.Register36133_100h.RxDecJESDDataSel2 = 0	;
		self.regs.Register36133_100h.Property_120h_13_8 = 38;
		self.regs.Register36133_100h.Property_120h_21_16 = 38;
		self.regs.RxDSAGainPhaseCorr0.dsa_gain_phase_bypass = 1
		self.regs.RxDSAGainPhaseCorr1.dsa_gain_phase_bypass = 1
		self.regs.Register36358_A50h.droop_filter_bypass = 1
		self.regs.Register36370_A51h.droop_filter_bypass = 1
		self.regs.Register36382_A52h.droop_filter_bypass = 1
		self.regs.Register36394_A53h.droop_filter_bypass = 1
		
		self.regs.Register37266_C94h.bypass=1
		self.regs.Register37332_CC0h.bypass=1
		self.regs.Register37398_E94h.bypass=1
		self.regs.Register37464_EC0h.bypass=1	
		
		self.regs.Register36872_A70h.dsa_freq_bypass = 1
		self.regs.Register36879_A74h.dsa_freq_bypass = 1
		
		self.regs.Register36975_C10h.Property_c10h_0_0 = 1
		
		self.regs.Register37180_510h.bypass_mode = 1
		self.regs.Register37209_910h.bypass_mode = 1
		
		self.regs.RxDGC0.DgcEnRxMode = 0
		self.regs.RxDGC1.DgcEnRxMode = 0
		
		self.regs.RxDigitalGainControl0ich.digital_gain_ctrl_bypass = 1
		self.regs.RxDigitalGainControl0qch.digital_gain_ctrl_bypass = 1
		self.regs.RxDigitalGainControl1ich.digital_gain_ctrl_bypass = 1
		self.regs.RxDigitalGainControl1qch.digital_gain_ctrl_bypass = 1
		
		self.regs.Register36358_A50h.Property_a50h_7_0 = 51#3
		self.regs.Register36370_A51h.gain_component_n = 51#3
		self.regs.Register36382_A52h.gain_component_n = 51#3
		self.regs.Register36394_A53h.gain_component_n = 51#3
		
		self.regs.Register36358_A50h.gain_corrector_bypass = 0
		self.regs.Register36370_A51h.gain_corrector_bypass = 0
		self.regs.Register36382_A52h.gain_corrector_bypass = 0
		self.regs.Register36394_A53h.gain_corrector_bypass = 0
		
		self.regs.Register36406_A54h.Property_a54h_0_0 = 1
		self.regs.Register36406_A54h.rx2_unit_gain_mode = 1
		
		self.regs.Register36358_A50h.coef_update_signal = 0
		self.regs.Register36370_A51h.coef_update_signal = 0
		self.regs.Register36382_A52h.coef_update_signal = 0
		self.regs.Register36394_A53h.coef_update_signal = 0
		
		self.regs.Register36358_A50h.coef_update_signal = 1
		self.regs.Register36370_A51h.coef_update_signal = 1
		self.regs.Register36382_A52h.coef_update_signal = 1
		self.regs.Register36394_A53h.coef_update_signal = 1
		
		self.regs.Register36358_A50h.coef_update_signal = 0
		self.regs.Register36370_A51h.coef_update_signal = 0
		self.regs.Register36382_A52h.coef_update_signal = 0
		self.regs.Register36394_A53h.coef_update_signal = 0
		#defaultRxtopForJesd
		
	@funcDecorator
	def freqIQMCcorrBypass(self,en=1):
		"""Bypass the frequency dependent IQMC corrector"""
		self.regs.Register36199_B0Ch.Property_500h_0_0 = en
		self.regs.Register36085_D04h.Property_900h_0_0 = en
		#freqIQMCcorrBypass_en
		
	@funcDecorator
	def gainIQMCcorrBypass(self,en=1):
		"""Bypasses the gain dependent corrector"""
		self.regs.RxIQMCgainCorr0.bypass_mode = en
		self.regs.RxIQMCgainCorr1.bypass_mode = en
		#gainIQMCcorrBypass_en
		
		
	@funcDecorator
	def bypassRxIqmcCorrector(self,chNo,bypass):
		""" bypass will turn bypass the IQMC corrector of chNo 0 or 1 """
		if chNo==0:
			self.regs.Register36199_B0Ch.Property_500h_0_0=bypass
		else:
			self.regs.Register36085_D04h.Property_900h_0_0=bypass
			#bypassRxIqmcCorrector
			
	@funcDecorator
	def dcOffsetCorrection(self,en):
		""" "Enabling RX DC correction" "Done enabling RX DC correction" Bypasses DC offset filter"""
		self.regs.Register37266_C94h.dc_freeze_reg=1
		self.regs.Register37266_C94h.alpha_update_signal=0
		self.regs.Register37266_C94h.alpha_update_signal=1
		self.regs.Register37266_C94h.alpha_update_signal=0
		self.regs.Register37266_C94h.dc_freeze_reg=0
		self.regs.Register37266_C94h.bypass=not en
		self.regs.Register37332_CC0h.dc_freeze_reg=1
		self.regs.Register37332_CC0h.alpha_update_signal=0
		self.regs.Register37332_CC0h.alpha_update_signal=1
		self.regs.Register37332_CC0h.alpha_update_signal=0
		self.regs.Register37332_CC0h.dc_freeze_reg=0
		self.regs.Register37332_CC0h.bypass=not en
		
		self.regs.Register37398_E94h.dc_freeze_reg=1
		self.regs.Register37398_E94h.alpha_update_signal=0
		self.regs.Register37398_E94h.alpha_update_signal=1
		self.regs.Register37398_E94h.alpha_update_signal=0
		self.regs.Register37398_E94h.dc_freeze_reg=0
		self.regs.Register37398_E94h.bypass=not en
		self.regs.Register37464_EC0h.dc_freeze_reg=1
		self.regs.Register37464_EC0h.alpha_update_signal=0
		self.regs.Register37464_EC0h.alpha_update_signal=1
		self.regs.Register37464_EC0h.alpha_update_signal=0
		self.regs.Register37464_EC0h.dc_freeze_reg=0
		self.regs.Register37464_EC0h.bypass=not en
		#dcOffsetCorrection
		
	@funcDecorator
	def updateRxDcFilterBw(self,chNo,alpha):
		if chNo==0:
			self.regs.Register37266_C94h.alpha1=alpha
			self.regs.Register37266_C94h.alpha2=alpha
			self.regs.Register37266_C94h.alpha3=alpha
			self.regs.Register37332_CC0h.alpha1=alpha
			self.regs.Register37332_CC0h.alpha2=alpha
			self.regs.Register37332_CC0h.alpha3=alpha
			self.regs.Register37266_C94h.alpha_update_signal=0
			self.regs.Register37266_C94h.alpha_update_signal=1
			self.regs.Register37266_C94h.alpha_update_signal=0
			self.regs.Register37332_CC0h.alpha_update_signal=0
			self.regs.Register37332_CC0h.alpha_update_signal=1
			self.regs.Register37332_CC0h.alpha_update_signal=0
		else:
			self.regs.Register37398_E94h.alpha1=alpha
			self.regs.Register37398_E94h.alpha2=alpha
			self.regs.Register37398_E94h.alpha3=alpha
			self.regs.Register37464_EC0h.alpha1=alpha
			self.regs.Register37464_EC0h.alpha2=alpha
			self.regs.Register37464_EC0h.alpha3=alpha
			self.regs.Register37398_E94h.alpha_update_signal=0
			self.regs.Register37398_E94h.alpha_update_signal=1
			self.regs.Register37398_E94h.alpha_update_signal=0
			self.regs.Register37464_EC0h.alpha_update_signal=0
			self.regs.Register37464_EC0h.alpha_update_signal=1
			self.regs.Register37464_EC0h.alpha_update_signal=0
			
			#rxDigLib
