
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

class fpgaLib_J58(projectBaseClass):
	"""Contains FPGA specific functions. self.regs=myfpga """
	@initDecorator
	def __init__(self,regs,fpgaParams):
		self.fpgaParams=fpgaParams
		self.regs=regs
		
		self.LMFSHdTx=""
		self.LMFSHdRx=""		
		
		self.firmwareName="TSW14J57RevE_16L_XCVR_ADCBRAMDACDDR"
		self.iniPath=r"C:\Program Files (x86)\Texas Instruments\High Speed Data Converter Pro\14J57revD Details"
		self.converterOrder=(0,1)
		
		self.lanesTx=(0,1)
		self.laneRateTx=9830.4
		
		self.lanesRx=(0,1)
		self.laneRateRx=9830.4
		#__init__
		
		
	def fpgaRxConfig(self):
		LMFSHdRx=self.LMFSHdRx
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHdRx)
		iniPath=self.iniPath+r"\ADC files\Afe77xxAuto.ini"
		iniFile=open(iniPath,"w")
		
		iniFile.write("[ADC]\n")
		
		iniFile.write('Interface name="'+self.firmwareName+'"\n')
		iniFile.write('Number of channels='+str(len(self.lanesRx))+"\n")
		iniFile.write('Channel Pattern='+str(range(1,len(self.lanesRx)+1))[1,-1]+"\n")
		
		iniFile.write('Data Postprocessing=1:32768'+"\n")
		iniFile.write('Number of Bits='+str(resolution)+"\n")
		iniFile.write('Max sample Rate=750000000'+"\n")
		iniFile.write('Register_Config="-"'+"\n")
		iniFile.write('DLL Version=1.0'+"\n")
		iniFile.write('Read EVM Setup Procedure="EVM Setup Procedure not available"'+"\n")
		iniFile.write('[Version 1.0]'+"\n")
		
		iniFile.write('JESD IP Core_CS=0      '+"\n")
		iniFile.write('JESD IP Core_F='+str(F)+'       '+"\n")
		iniFile.write('JESD IP Core_HD='+str(Hd)+'      '+"\n")
		iniFile.write('JESD IP Core_K=16      '+"\n")
		iniFile.write('JESD IP Core_L='+str(L)+'       '+"\n")
		iniFile.write('JESD IP Core_M='+str(M)+'       '+"\n")
		iniFile.write('JESD IP Core_N=16      '+"\n")
		iniFile.write('JESD IP Core_NTotal=16 '+"\n")
		iniFile.write('JESD IP Core_S='+str(S)+'       '+"\n")
		iniFile.write('JESD IP Core_SCR=1     '+"\n")
		iniFile.write('JESD IP Core_Tailbits=0'+"\n")
		iniFile.write('JESD IP Core_LaneSync=1'+"\n")
		iniFile.write('JESD IP Core_Subclass=1'+"\n")
		iniFile.write('JESD IP Core_JESDV=1	  '+"\n")
		iniFile.write('MIF Config= 0.611G to 12.5G:RX:RX_PMA_x40'+"\n")
		iniFile.write('Fabric PLL Counter = 0.611G to 12.5G:0x080202'+"\n")
		
		iniFile.write('Invert Sync Polarity = 0 '+"\n")
		iniFile.write('Enable Individual Lane Inversion = 1'+"\n")
		iniFile.write('Invert Serdes Data = 240'+"\n")
		iniFile.write('Transceiver Mode = 0'+"\n")
		iniFile.write('Lane Mapping=lane0:6,lane1:5'+"\n")
		
