from globalDefs import * 
from mFuncDecorator import * 
#from mAfeParameters import systemParams 
#from mAfeParameters import systemStatus 
#from mAfeParameters import lmkParams 

class lmkLib(object): 
	""" self.regs=lmk """ 
	@initDecorator 
	def __init__(self,regs,lmkParams): 
		#self.deviceRefs=deviceRefs 
		#self.systemParams=deviceRefs.systemParams 
		#self.systemStatus=deviceRefs.systemStatus 
		self.lmkParams=lmkParams 
		self.regs=regs 
		self.laneRate=0 
	#__init__ 
	 
	@funcDecorator 
	def lmkSysrefEn(self,En=False): 
		if setupParams.boardType in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"): 
			if self.lmkParams.pllEn==True: 
				if En==True: 
					self.regs.writeReg(0x106,0xF0) 
				else: 
					self.regs.writeReg(0x106,0xF1) 
			else: 
				self.regs.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=not En 
				if En==True: 
					self.regs.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1 
				else: 
					self.regs.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0 
		else: 
			if self.lmkParams.pllEn==True: 
				if En==True: 
					self.regs.writeReg(0x10e,0xF0) 
					self.regs.writeReg(0x116,0xF0) 
				else: 
					self.regs.writeReg(0x10e,0xF1) 
					self.regs.writeReg(0x116,0xF1) 
			else: 
				self.regs.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=not En 
				self.regs.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=not En 
				if En==True: 
					self.regs.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1 
					self.regs.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1 
				else: 
					self.regs.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0 
					self.regs.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0 
			 
	#lmkSysrefEn 
	 
	@funcDecorator 
	def lmkConfig(self,rxFbTx=0,instanceNo=0): 
		""""Doing LMK config" "Done with LMK Config" 
			rxFbTx, instanceNo are needed when the lane rates are different for any case.""" 
		 
		lmk=self.regs 
		lmk.reset() 
		lmk.gui.reset() 
		lmk.head.page.System.Top_Modes.SW_RESET=1 
		lmk.head.page.System.Top_Modes.SW_RESET=0 

		if setupParams.boardType not in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"): 
			deviceRefClk=[setupParams.dutInstances[0].systemParams.FRef,setupParams.dutInstances[1].systemParams.FRef] 
		else: 
			deviceRefClk=self.systemParams.FRef 
		sysrefFreq=self.lmkParams.sysrefFreq 
		instanceNo=instanceNo&1 
		if setupParams.boardType not in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"): 
			if rxFbTx==0: 
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateRx[instanceNo] 
			elif rxFbTx==1:                                                               
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateFb[instanceNo] 
			else:                                                                         
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateTx[instanceNo] 
			 
		else: 
			if rxFbTx==0: 
				laneRate=self.systemStatus.laneRateRx[instanceNo] 
			elif rxFbTx==1: 
				laneRate=self.systemStatus.laneRateFb[instanceNo] 
			else: 
				laneRate=self.systemStatus.laneRateTx[instanceNo] 
		if self.lmkParams.pllEn: 
			self.lmkPllConfig(deviceRefClk,sysrefFreq,laneRate,False) 
		else: 
			if setupParams.boardType not in ("BENCH",): 
				self.lmkEvmDivConfig(deviceRefClk,sysrefFreq,laneRate,False) 
			else: 
				self.lmkDivConfig(deviceRefClk,sysrefFreq,laneRate,False) 
		self.laneRate=laneRate 
	#lmkConfig 
	 
	 
	@funcDecorator 
	def lmkSelectCh(self,rxFbTx=0,instanceNo=0): 
		if setupParams.boardType not in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"): 
			deviceRefClk=[setupParams.dutInstances[0].systemParams.FRef,setupParams.dutInstances[1].systemParams.FRef] 
		else: 
			deviceRefClk=self.systemParams.FRef 
		 
		sysrefFreq=self.lmkParams.sysrefFreq 
		instanceNo=instanceNo&1 
		if setupParams.boardType in ("BENCH",): 
			if rxFbTx==0: 
				laneRate=self.systemStatus.laneRateRx[instanceNo] 
			elif rxFbTx==1: 
				laneRate=self.systemStatus.laneRateFb[instanceNo] 
			else: 
				laneRate=self.systemStatus.laneRateTx[instanceNo] 
			if self.lmkParams.pllEn: 
				self.lmkPllConfig(deviceRefClk,sysrefFreq,laneRate,True) 
			else: 
				self.lmkDivConfig(deviceRefClk,sysrefFreq,laneRate,True) 
		else: 
			if rxFbTx==0: 
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateRx[instanceNo] 
			elif rxFbTx==1:                                                               
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateFb[instanceNo] 
			else:                                                                         
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateTx[instanceNo] 
			self.lmkEvmDivConfig(deviceRefClk,sysrefFreq,laneRate,True) 
		self.laneRate=laneRate 
	#lmkSelectCh 
	 
	@funcDecorator 
	def lmkDivConfig(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig): 
		lmk=self.regs 
		divInputClk=self.lmkParams.inputClk 
		if not onlyDivConfig: 
			deviceRefClkDiv=divInputClk/deviceRefClk 
			if deviceRefClkDiv not in range(1,33): 
				error("LMK Div factor from Input Frequency to device Ref "+str(deviceRefClkDiv)+" is not supported. Choose a different FRef to the Device or LMK input clock.")	 
			sysrefDiv=int(round(divInputClk/sysrefFreq)) 
			if sysrefDiv>8191: 
				error("Minimum sysref frequency = :" + str(sysrefDiv)) 
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=sysrefDiv 
			 
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_=int(round(deviceRefClkDiv)) 
			# 500 -- i/p to lmk 
			lmk.writeReg(0x145,127) 
			  
			#lmk_gui.System.Top_Modes.Power_Down=0 
			#Reset 

			#Clk0_1 (0=JESD Clk= 125MHz, 1= DUT_SYSREF= 31.25M) 
			lmk.writeReg(256,0x0C) #Set dclk0 divider as Ext/4; 
			delay(0.1) 
			lmk.writeReg(260,0x20) #Enable Sysref out on clk1 
			lmk.writeReg(262,0x10) #Disable output pdn(default set) 
			lmk.writeReg(263,0x11) #Set outputs as LVDS 
			lmk.writeReg(267,0x02) #Bypass divider 
			lmk.writeReg(270,0x11) #Disable output pdn for clk2 (default set to 1) 
			lmk.writeReg(271,0x01) #Set output as LVDS 

			#qport_lmk.writeReg(256,0x02) #Set dclk0 divider as Ext/2; 

			#qport_lmk.writeReg(259,0x00000002) 
			#Clk2 (2= DUT_CLK= 500MHz) 
			lmk.writeReg(278,0x19) #Disable output pdn for clk4 (default set to 1) 
			lmk.writeReg(278,0x11) #Disable output pdn for clk4 (default set to 1) 
			lmk.writeReg(279,0x01) #Set output as LVDS 
			lmk.writeReg(286,0x00000019) 
			lmk.writeReg(294,0x00000019) 
			lmk.writeReg(302,0x00000019) 

			#qport_lmk.writeReg(304,0x02) #Set dclk0 divider as Ext/2; 
			lmk.writeReg(304,0x0C) #Set dclk0 divider as Ext/4; 
			delay(0.1) 
			lmk.writeReg(308,0x20) #Enable Sysref out on clk1 
			#Clk12_13 (12=CLK_kintex_capture= 125MHz, 13= FPGA_SYSREF= 31.25M) 
			lmk.writeReg(310,0x10) #Disable output pdn(default set) 
			lmk.writeReg(311,0x11) #Set outputs as LVDS 
			#Choose Ext clock(No PLL) 
			lmk.writeReg(312,0x44) 
			lmk.writeReg(313,0x03) #Enable continuous sysref 
			lmk.writeReg(314,0x10) #Setting the Sysref divide to Ext/16= MSB 5bits 
			lmk.writeReg(315,0x00) #Setting the Sysref divide to Ext/16= LSB 8bits 
			#Select CLK input to MOS(Changes input Common mode) 
			lmk.writeReg(320,0x03) #Disable sysref pdn 
			lmk.writeReg(323,0x11) #clear Syref clear to enable sysref output 
			lmk.writeReg(324,0xFF) #Disable sync event from diturbing sysref and clock outputs 
			lmk.writeReg(326,0x10) 
			 #Common setting for Sysref outputs 

			#qport_lmk.writeReg(307,0x02) #Bypass Divider 
			#PDN all other outputs 

			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_mux_lt_2_0_gt_ = 6 
			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_type_lt_2_0_gt_ = 5 



			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 


			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4 
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 

			lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux = 1 

			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1 
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0 

			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 7 
			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 8 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1  
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1 
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0 

			lmk.head.page.Clkin_Control.Enable_Type.clkin1_type=1 
		if self.systemParams.jesdProtocol ==0: 
			if(laneRate<=7500): 
				divFactor=round(2.0*20*divInputClk/laneRate,4) 
				if divFactor not in range(1,33): 
					error("LMK Div factor from Input Frequency to FPGA require clock "+str(divFactor)+" is not supported. Link will not be established.") 
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor) 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor-1)		# This write is just to make sure the next write goes through 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor) 
				#reProgramFPGA(0) 
			else: 
				divFactor1=round(2.0*20*divInputClk/laneRate,4) 
				divFactor2=round(5.0*20*divInputClk/laneRate,4) 
				if divFactor1 not in range(1,33): 
					error("LMK Div factor1 from Input Frequency to FPGA required clock "+str(divFactor1)+" is not supported. Link will not be established.") 
				if divFactor2 not in range(1,33): 
					error("LMK Div factor2 from Input Frequency to FPGA required clock "+str(divFactor2)+" is not supported. Link will not be established.") 
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor1) 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2-1)		# This write is just to make sure the next write goes through 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2) 
		else: 
			divFactor=0x1F&int(round(divInputClk/122.88,4)) 
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor 
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor-1		# This write is just to make sure the next write goes through 
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor 
				 
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1 
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0 
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1 
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0 
	 
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=False 
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=False 
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=False 
		lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
		lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=768#3072 
		 
		if self.lmkParams.lmkFrefClk==False: 
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0 
		else: 
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=4 
				 
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=True 
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=True 
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=True 
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=True 
	#lmkDivConfig 

	 
	@funcDecorator 
	def lmkDivConfigOld(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig): 
		lmk=self.regs 
		divInputClk=self.lmkParams.inputClk 
		if not onlyDivConfig: 
			deviceRefClkDiv=divInputClk/deviceRefClk 
			if deviceRefClkDiv not in range(1,33): 
				error("LMK Div factor from Input Frequency to device Ref "+str(deviceRefClkDiv)+" is not supported. Choose a different FRef to the Device or LMK input clock.")	 
			sysrefDiv=int(round(divInputClk/sysrefFreq)) 
			if sysrefDiv>8191: 
				error("Minimum sysref frequency = :" + str(sysrefDiv)) 
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=sysrefDiv 
			 
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_=int(round(deviceRefClkDiv)) 
			# 500 -- i/p to lmk 
			lmk.writeReg(0x145,127) 
			  
			#lmk_gui.System.Top_Modes.Power_Down=0 
			#Reset 

			#Clk0_1 (0=JESD Clk= 125MHz, 1= DUT_SYSREF= 31.25M) 
			lmk.writeReg(256,0x04) #Set dclk0 divider as Ext/4; 
			lmk.writeReg(260,0x20) #Enable Sysref out on clk1 
			lmk.writeReg(262,0x10) #Disable output pdn(default set) 
			lmk.writeReg(263,0x11) #Set outputs as LVDS 
			lmk.writeReg(267,0x02) #Bypass divider 
			lmk.writeReg(270,0x11) #Disable output pdn for clk2 (default set to 1) 
			lmk.writeReg(271,0x01) #Set output as LVDS 

			#qport_lmk.writeReg(256,0x02) #Set dclk0 divider as Ext/2; 

			#qport_lmk.writeReg(259,0x00000002) 
			#Clk2 (2= DUT_CLK= 500MHz) 
			lmk.writeReg(278,0x19) #Disable output pdn for clk4 (default set to 1) 
			lmk.writeReg(278,0x11) #Disable output pdn for clk4 (default set to 1) 
			lmk.writeReg(279,0x01) #Set output as LVDS 
			lmk.writeReg(286,0x00000019) 
			lmk.writeReg(294,0x00000019) 
			lmk.writeReg(302,0x00000019) 

			#qport_lmk.writeReg(304,0x02) #Set dclk0 divider as Ext/2; 
			lmk.writeReg(304,0x04) #Set dclk0 divider as Ext/4; 
			lmk.writeReg(308,0x20) #Enable Sysref out on clk1 
			#Clk12_13 (12=CLK_kintex_capture= 125MHz, 13= FPGA_SYSREF= 31.25M) 
			lmk.writeReg(310,0x10) #Disable output pdn(default set) 
			lmk.writeReg(311,0x11) #Set outputs as LVDS 
			#Choose Ext clock(No PLL) 
			lmk.writeReg(312,0x44) 
			lmk.writeReg(313,0x03) #Enable continuous sysref 
			lmk.writeReg(314,0x10) #Setting the Sysref divide to Ext/16= MSB 5bits 
			lmk.writeReg(315,0x00) #Setting the Sysref divide to Ext/16= LSB 8bits 
			#Select CLK input to MOS(Changes input Common mode) 
			lmk.writeReg(320,0x03) #Disable sysref pdn 
			lmk.writeReg(323,0x11) #clear Syref clear to enable sysref output 
			lmk.writeReg(324,0xFF) #Disable sync event from diturbing sysref and clock outputs 
			lmk.writeReg(326,0x10) 
			 #Common setting for Sysref outputs 

			#qport_lmk.writeReg(307,0x02) #Bypass Divider 
			#PDN all other outputs 

			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_mux_lt_2_0_gt_ = 6 
			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_type_lt_2_0_gt_ = 5 

			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=768#3072 
			 
						# Clkout_pdn_dis 
			if self.lmkParams.lmkFrefClk==False: 
				lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0 
			else: 
				lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=4 
				 

			lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
			lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=True 
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=True 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=True 
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=True 

			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 


			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 

			lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux = 1 

			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1 
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0 

			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 7 
			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 8 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1  
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1 
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0 

			lmk.head.page.Clkin_Control.Enable_Type.clkin1_type=1 
		if self.systemParams.jesdProtocol ==0: 
			if(laneRate<=7500): 
				divFactor=round(2.0*20*divInputClk/laneRate,4) 
				if divFactor not in range(1,33): 
					error("LMK Div factor from Input Frequency to FPGA require clock "+str(divFactor)+" is not supported. Link will not be established.") 
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor) 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor-1)		# This write is just to make sure the next write goes through 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor) 
				#reProgramFPGA(0) 
			else: 
				divFactor1=round(2.0*20*divInputClk/laneRate,4) 
				divFactor2=round(5.0*20*divInputClk/laneRate,4) 
				if divFactor1 not in range(1,33): 
					error("LMK Div factor1 from Input Frequency to FPGA required clock "+str(divFactor1)+" is not supported. Link will not be established.") 
				if divFactor2 not in range(1,33): 
					error("LMK Div factor2 from Input Frequency to FPGA required clock "+str(divFactor2)+" is not supported. Link will not be established.") 
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor1) 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2-1)		# This write is just to make sure the next write goes through 
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2) 
		else: 
			divFactor=0x1F&int(round(divInputClk/122.88,4)) 
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor 
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor-1		# This write is just to make sure the next write goes through 
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor 
				 
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1 
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0 
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1 
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0 
	#lmkDivConfig 
	 
	 
	 
	@funcDecorator
	def lmkPllConfig(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig):
		lmk=self.regs
		divInputClk=2949.12
		
		deviceRefClkDiv=divInputClk/deviceRefClk
		if deviceRefClkDiv not in range(1,33):
			error("LMK Div factor from Input Frequency to device Ref "+str(deviceRefClkDiv)+" is not supported. Choose a different FRef to the Device or LMK input clock.")	

		sysrefDiv=int(round(divInputClk/sysrefFreq))
		if sysrefDiv>8191:
			error("Minimum sysref frequency = :" + str(sysrefDiv))
		
		lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_type_lt_2_0_gt_=3
		lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_mux_lt_2_0_gt_=6
		lmk.head.page.System.Top_Modes.SPI_3Wire_Disable=0
		lmk.head.page.System.Top_Modes.Power_Down=0

		lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(divInputClk/setupParams.fpgaRefClk)) #LMK04828 VCO = 2949.12MHz. FPGACLK = LMK04828VCO/12 = 245.76MHz.
		lmk.head.page.DCLK0_SDCLK1_controls.Out_control.Input_Drive=0
		lmk.head.page.DCLK0_SDCLK1_controls.Out_control.Output_Drive=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux=1
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=0
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=0
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=1
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.property1=3
		lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_=1
		lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1
		lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_pol=0

		lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(deviceRefClkDiv))
		#Fref = LMK04828 VCO/6 = 491.52MHz. This is Fref to the AFE with LVPECL level.
		lmk.head.page.DCLK2_SDCLK3_controls.Out_control.Input_Drive=1
		lmk.head.page.DCLK2_SDCLK3_controls.Out_control.Output_Drive=1
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_aldly_lt_4_0_gt_=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux=1
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=0
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.pdn_dclk_sdclk=0
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=1
		lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.property1=3
		if self.lmkParams.lmkFrefClk==False:
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0
			warning("Please ensure REFCLOCK is connected from external source")
		else:
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=4
			warning("REFCLOCK is used from LMK source, ensure board connections are ok to do the same")
		lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1
		lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_pol=0

		lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_=8
		lmk.head.page.DCLK4_SDCLK5_controls.Out_control.Input_Drive=0
		lmk.head.page.DCLK4_SDCLK5_controls.Out_control.Output_Drive=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.dclk_aldly_lt_4_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_mux=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=1
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=1
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=2
		lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.property1=3
		lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_pol=0

		lmk.head.page.DCLK6_SDCLK7_controls.Out_control.dclkout_DIV_lt_4_0_gt_=24
		lmk.head.page.DCLK6_SDCLK7_controls.Out_control.Input_Drive=0
		lmk.head.page.DCLK6_SDCLK7_controls.Out_control.Output_Drive=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.dclk_aldly_lt_4_0_gt_=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.sdclk_mux=1
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=1
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=1
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=1
		lmk.head.page.DCLK6_SDCLK7_controls.Analog_Dig_Delay.property1=3
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_pol=0

		lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_=12#16
		lmk.head.page.DCLK8_SDCLK9_controls.Out_control.Input_Drive=0
		lmk.head.page.DCLK8_SDCLK9_controls.Out_control.Output_Drive=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_aldly_lt_4_0_gt_=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.sdclk_mux=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=1
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=1
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=1
		lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.property1=3
		lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_=1
		lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1
		lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_pol=0

		lmk.head.page.DCLK10_SDCLK11_controls.Out_control.dclkout_DIV_lt_4_0_gt_=8
		lmk.head.page.DCLK10_SDCLK11_controls.Out_control.Input_Drive=0
		lmk.head.page.DCLK10_SDCLK11_controls.Out_control.Output_Drive=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.dclk_aldly_lt_4_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_mux=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=1
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=1
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=1
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.property1=3
		lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_pol=0

		#lmk.writeReg(0x130,0x14) # divide30

		lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=12
		lmk.head.page.DCLK12_SDCLK13_controls.Out_control.Input_Drive=0
		lmk.head.page.DCLK12_SDCLK13_controls.Out_control.Output_Drive=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_cntl_lt_3_0_gt_=5
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_cnth_lt_3_0_gt_=5
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_adly_mux=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_aldly_lt_4_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_hs=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_ddly_lt_3_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux=1
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_hs=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_adly_lt_3_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_adly_en=0
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=1
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_dis_mode_lt_1_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.pdn_Adelay_dclk=1
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.pdn_Ddelay_dclk=1
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.property1=3
		lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_=1
		lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_pol=0
		lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_pol=0

		# if(setupParams.bitFile==1):
			# lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_SRC.Sysref_Mux_lt_1_0_gt_=3
			# lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux=1
			# lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=0
			# lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=int(divInputClk/(setupParams.dutInstances[0].systemStatus.laneRateFb[0]*1./80))

		lmk.head.page.Config_Sysref_Sync_Device_.ClockDist_OSC.OSCout_FMT_lt_3_0_gt_=0
		lmk.head.page.Config_Sysref_Sync_Device_.ClockDist_OSC.OSCout_MUX=0
		lmk.head.page.Config_Sysref_Sync_Device_.ClockDist_OSC.VCO_MUX_lt_1_0_gt_=1
		lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_SRC.Sysref_Mux_lt_1_0_gt_=3
		lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_SRC.Sysref_Mux_clkin0=0
		lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_ = sysrefDiv
		lmk.head.page.Config_Sysref_Sync_Device_.Sysref_ddly.Ddly_lt_12_0_gt_=8
		lmk.writeReg(0x13E,0x03)
		# lmk.head.page.Misc.Property4.Reg318=3# lmk.writeReg(0x13E,0x03)
		lmk.head.page.Config_Sysref_Sync_Device_.PLL_FB.Fb_mux_en=0
		lmk.head.page.Config_Sysref_Sync_Device_.PLL_FB.Fb_mux_lt_1_0_gt_=0
		lmk.head.page.Config_Sysref_Sync_Device_.PLL_FB.Pll1_Nclk_mux=0
		lmk.head.page.Config_Sysref_Sync_Device_.PLL_FB.Pll2_Nclk_mux=0

		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.sysref_plsr_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.sysref_ddly_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.sysref_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.sysref_gbl_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.oscin_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.vco_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.vco_ldo_pd=0
		lmk.head.page.Config_Sysref_Sync_Device_.pdn_ctrls.Pll1_pd=0

		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk0=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk2=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk4=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk6=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk8=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk10=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_dclk12=0
		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.En_sysref=0

		lmk.head.page.Config_Sysref_Sync_Device_.DynamicDigDelay.Step_cnt_lt_3_0_gt_=0
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sync_mode_lt_1_0_gt_=2
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sync_pll1_dld=0
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sync_pll2_dld=0
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sync_en=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sync_pol=0
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sync_1shot_en=0
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.sysref_clr=0

		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk0=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk2=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk4=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk6=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk8=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk10=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_clk12=1
		lmk.head.page.Config_Sysref_Sync_Device_.prog_Sync.dis_sync_sysref=1

		# lmk.writeReg(0x145,0x00)
		lmk.head.page.Clkin_Control.Enable_Type.clkin0_type=0
		lmk.head.page.Clkin_Control.Enable_Type.clkin1_type=0
		lmk.head.page.Clkin_Control.Enable_Type.clkin2_type=0
		lmk.head.page.Clkin_Control.Enable_Type.Clkin0_en=0
		lmk.head.page.Clkin_Control.Enable_Type.Clkin1_en=1
		lmk.head.page.Clkin_Control.Enable_Type.Clkin2_en=0

		lmk.head.page.Clkin_Control.Polarity_Mux_select.Clkin0_out_mux_lt_1_0_gt_=2
		lmk.head.page.Clkin_Control.Polarity_Mux_select.Clkin1_out_mux_lt_1_0_gt_=2
		lmk.head.page.Clkin_Control.Polarity_Mux_select.Clkin_sel_mode_lt_2_0_gt_=1
		lmk.head.page.Clkin_Control.Polarity_Mux_select.Clkin_pol=0

		lmk.head.page.Clkin_Control.Clkin_sel0.sel0_type_lt_2_0_gt_=2
		lmk.head.page.Clkin_Control.Clkin_sel0.sel0_mux_lt_2_0_gt_=0
		lmk.head.page.Clkin_Control.Clkin_sel1_sdio.clkin_sel1_type_lt_2_0_gt_=2
		lmk.head.page.Clkin_Control.Clkin_sel1_sdio.clkin_sel1_mux_lt_2_0_gt_=0
		lmk.head.page.Clkin_Control.Clkin_sel1_sdio.sdio_rd_type=1

		lmk.head.page.HoldOver_Prog.Holdover_functions.man_dac_lt_9_0_gt_=512
		lmk.head.page.HoldOver_Prog.Holdover_functions.man_dac_en=1
		lmk.head.page.HoldOver_Prog.Holdover_functions.holdover_force=0
		lmk.head.page.HoldOver_Prog.Holdover_functions.Track_en=1
		lmk.head.page.HoldOver_Prog.Holdover_functions.Los_en=0
		lmk.head.page.HoldOver_Prog.Holdover_functions.LOS_TIMEOUT_lt_1_0_gt_=0

		lmk.head.page.HoldOver_Prog.Holdover_Threshold.Trip_low_lt_5_0_gt_=0
		lmk.head.page.HoldOver_Prog.Holdover_Threshold.Trip_high_lt_5_0_gt_=0
		lmk.head.page.HoldOver_Prog.DAC_Clk_counter.DAC_clk_mult_lt_1_0_gt_=3
		lmk.head.page.HoldOver_Prog.DAC_Clk_counter.DAC_counter_val_lt_7_0_gt_=127

		lmk.head.page.HoldOver_Prog.Holdover_misc.holdover_en=1
		lmk.head.page.HoldOver_Prog.Holdover_misc.holdover_hitless_sw=1
		lmk.head.page.HoldOver_Prog.Holdover_misc.holdover_vtune_det=0
		lmk.head.page.HoldOver_Prog.Holdover_misc.holdover_los_det=0
		lmk.head.page.HoldOver_Prog.Holdover_misc.holdover_pll1_det=0
		lmk.head.page.HoldOver_Prog.Holdover_misc.clkin_override=1
		lmk.head.page.HoldOver_Prog.Holdover_misc.holdver_dld_cnt_lt_13_0_gt_=512

		lmk.head.page.PLL1_Config.Clkin0_1_2_Divider.div_clkin0_lt_13_0_gt_=120
		lmk.head.page.PLL1_Config.Clkin0_1_2_Divider.div_clkin1_lt_13_0_gt_=125
		lmk.head.page.PLL1_Config.Clkin0_1_2_Divider.div_clkin2_lt_13_0_gt_=150
		lmk.head.page.PLL1_Config.N_Divider_PLL1.N_DIV_PLL1_lt_13_0_gt_=1536 #0x600
		lmk.head.page.PLL1_Config.PD_settings.CP_gain_lt_3_0_gt_=4
		lmk.head.page.PLL1_Config.PD_settings.CP_pol=1
		lmk.head.page.PLL1_Config.PD_settings.CP_TRI=0
		lmk.head.page.PLL1_Config.PD_settings.Wind_size_lt_1_0_gt_=3
		lmk.head.page.PLL1_Config.DLD_counter.DLD_CNT_lt_13_0_gt_=8192
		lmk.head.page.PLL1_Config.Delay_prog.N_Dly_lt_2_0_gt_=0
		lmk.head.page.PLL1_Config.Delay_prog.R_Dly_lt_2_0_gt_=0
		lmk.head.page.PLL1_Config.LD_pin_options.PLL_LD_Type_lt_2_0_gt_=3
		lmk.head.page.PLL1_Config.LD_pin_options.PLL_LD_MUX_lt_4_0_gt_=1

		lmk.head.page.PLL2_Config.R_Divider.Div_Value_lt_11_0_gt_=1
		lmk.head.page.PLL2_Config.PLL2_options.ref_2X_en=0
		lmk.head.page.PLL2_Config.PLL2_options.xtal_en=0
		lmk.head.page.PLL2_Config.PLL2_options.OSCin_freq_lt_2_0_gt_=1
		lmk.head.page.PLL2_Config.PLL2_options.PLL2_Prescale_lt_2_0_gt_=2
		lmk.head.page.PLL2_Config.PLL2_options.pll2_Ncal_lt_17_0_gt_=12
		lmk.head.page.PLL2_Config.PLL2_options.pll2_Fcal_dis=0
		lmk.head.page.PLL2_Config.PLL2_options.Pll2_N_divider_lt_17_0_gt_=12
		lmk.head.page.PLL2_Config.PD_settings.property2=1
		lmk.head.page.PLL2_Config.PD_settings.CP_tri=0
		lmk.head.page.PLL2_Config.PD_settings.CP_pol=0
		lmk.head.page.PLL2_Config.PD_settings.CP_gain_lt_1_0_gt_=3
		lmk.head.page.PLL2_Config.PD_settings.Wind_size_lt_1_0_gt_=2
		lmk.head.page.PLL2_Config.DLD_counter.DLD_CNT_lt_15_0_gt_=8192

		lmk.head.page.PLL2_Config.Filter_RC_prog.LF_R3_lt_2_0_gt_=0
		lmk.head.page.PLL2_Config.Filter_RC_prog.LF_R4_lt_2_0_gt_=0
		lmk.head.page.PLL2_Config.Filter_RC_prog.LF_C3_lt_3_0_gt_=0
		lmk.head.page.PLL2_Config.Filter_RC_prog.LF_C4_lt_3_0_gt_=0
		lmk.head.page.PLL2_Config.LD_pin_options.PLL_LD_Type_lt_2_0_gt_=3
		lmk.head.page.PLL2_Config.LD_pin_options.PLL_LD_MUX_lt_4_0_gt_=2

		lmk.writeReg(0x17C,0x15) 
		lmk.writeReg(0x17D,0x0F) 
		# lmk.head.page.Misc.Property3.Reg380=21
		# lmk.head.page.Misc.Property3.Reg381=15
		
	#lmkPllConfig
	 
	 

	#lmkPllConfig 

	@funcDecorator 
	def lmkEvmDivConfig(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig): 
		lmk = self.regs 
		divInputClk=self.lmkParams.inputClk 
		if onlyDivConfig==False: 
			lmk.gui.reset() 
			#lmk.reset() 
			# 500 -- i/p to lmk 
			  
			lmk.head.page.System.Top_Modes.SW_RESET=1 
			lmk.head.page.System.Top_Modes.SW_RESET=0 
			  
			  
			#lmk_gui.System.Top_Modes.Power_Down=0 
			#Reset 
			  
			#Choose Ext clock(No PLL) 
			lmk.writeReg(312,0x44) 
			 #Select CLK input to MOS(Changes input Common mode) 
			lmk.writeReg(326,0x10) 
			 #Common setting for Sysref outputs 
			lmk.writeReg(313,0x03) #Enable continuous sysref 
			lmk.writeReg(320,0x03) #Disable sysref pdn 
			lmk.writeReg(323,0x11) #clear Syref clear to enable sysref output 
			lmk.writeReg(324,0xFF) #Disable sync event from diturbing sysref and clock outputs 
			lmk.writeReg(315,0x00) #Setting the Sysref divide to Ext/16= LSB 8bits 
			lmk.writeReg(314,0x10) #Setting the Sysref divide to Ext/16= MSB 5bits 

			  
			  
			#Clk0_1 (0=JESD Clk= 125MHz, 1= DUT_SYSREF= 31.25M) 
			lmk.writeReg(262,0x10) #Disable output pdn(default set) 
			lmk.writeReg(263,0x11) #Set outputs as LVDS 

			#qport_lmk.writeReg(256,0x02) #Set dclk0 divider as Ext/2; 
			lmk.writeReg(256,0x04) #Set dclk0 divider as Ext/4; 
			#lmk.writeReg(256,0x06) #Set dclk0 divider as Ext/6 JBG; 
			lmk.writeReg(260,0x20) #Enable Sysref out on clk1 

			#qport_lmk.writeReg(259,0x00000002) 
			  
			#Clk2 (2= DUT_CLK= 500MHz) 
			lmk.writeReg(270,0x11) #Disable output pdn for clk2 (default set to 1) 
			lmk.writeReg(271,0x01) #Set output as LVDS 
			lmk.writeReg(267,0x02) #Bypass divider 

			  
			  
			#Clk12_13 (12=CLK_kintex_capture= 125MHz, 13= FPGA_SYSREF= 31.25M) 
			lmk.writeReg(310,0x10) #Disable output pdn(default set) 
			lmk.writeReg(311,0x11) #Set outputs as LVDS 

			#qport_lmk.writeReg(304,0x02) #Set dclk0 divider as Ext/2; 
			lmk.writeReg(304,0x04) #Set dclk0 divider as Ext/4; 
			lmk.writeReg(308,0x20) #Enable Sysref out on clk1 

			#qport_lmk.writeReg(307,0x02) #Bypass Divider 
			  
			#PDN all other outputs 
			  
			lmk.writeReg(278,0x00000019) 
			lmk.writeReg(286,0x00000019) 
			lmk.writeReg(294,0x00000019) 
			lmk.writeReg(302,0x00000019) 

			  
			lmk.writeReg(278,0x11) #Disable output pdn for clk4 (default set to 1) 
			lmk.writeReg(279,0x01) #Set output as LVDS 
	  

			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0 
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=4 

			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=5 
			lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=3072 

			lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			if setupParams.boardType in ('EVM-1Device',"EVM-1DeviceJ58"): 
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True 
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=True 
			else: 
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=False 
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=False 

			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 


			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4 
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4 
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4 
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4 
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4 


			lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux = 1 



			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_=2 

			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1 
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0 


			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=10 

			lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_=2 
			lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_mux = 1 
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1 
			if setupParams.boardType in ('EVM-1Device',"EVM-1DeviceJ58"): 
				lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk)) 
				lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk)) 
			else: 
				lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[0])) 
				lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[1])) 

		##################################	 
		lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_= int(round(self.lmkParams.inputClk/(245.76)))#round(divInputClk/(laneRate/40))#GTX_Clk #10Gbps = 245.76 #15Gbps = 368.74 
		if setupParams.boardType in ('EVM-1Device',"EVM-1DeviceJ58"): 
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk)) 
			lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk)) 
		else: 
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[0])) 
			lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[1])) 

		lmk.head.page.DCLK6_SDCLK7_controls.Out_control.dclkout_DIV_lt_4_0_gt_= int(round((self.lmkParams.inputClk/245.76)))#round(divInputClk/245.76)#FPGA_RefClk1 
		lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_= int(round((self.lmkParams.inputClk/245.76)))#round(divInputClk/245.76)#FPGA_RefClk2 
				 
		# lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn 
		 
		# lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0 
		# lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0 
		 

		# lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0 
		# lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn = 0 
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4 
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4 
		'''CPLD Clock''' 
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False 
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=False 
		lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=4 
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_mux=1 
	#lmkEvmDivConfig 
		 
