from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import mAfeConstants
reload(mAfeConstants)
from mAfeConstants import jesdConstants
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import random
import math

class jesdRxLib(projectBaseClass):
	"""Contains DAC JESD RX specific functions. self.regs=device.JESD.DAC_RX.DAC_RX """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.topno=topno
		self.regs=regs.DAC_RX
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
					
					#__init__
					
	@funcDecorator
	def reSync(self):
		self.regs.TXDUC_REG129.jesd_clear_data=0xff
		self.regs.TXDUC_REG32.init_state_tx0=1
		self.regs.TXDUC_REG288.comma_align_reset_tx0=1
		self.regs.TXDUC_REG288.comma_align_reset_tx0=0
		self.regs.TXDUC_REG32.init_state_tx0=0
		self.regs.TXDUC_REG45.serdes_fifo_err_clear=1
		self.regs.TXDUC_REG45.serdes_fifo_err_clear=0
		self.regs.TXDUC_REG400.clear_all_alarms=1
		self.regs.TXDUC_REG400.clear_all_alarms=0
		self.regs.TXDUC_REG129.jesd_clear_data=0
		#reSync
		
	@funcDecorator
	def jesdConfig(self):
		""" "Configuring Device JESD RX" "Done configuring Device JESD RX" """
		
		jesdConfigParams=self.systemStatus.jesdConfigParams[self.topno]
		self.regs.TXDUC_REG127.k_m1=jesdConfigParams['RX_K']
		self.regs.TXDUC_REG126.rbd_m1=jesdConfigParams['RX_RBD']
		self.regs.TXDUC_REG32.init_state_tx0=1
		self.regs.TXDUC_REG129.jesd_clear_data=0xff
		
		self.regs.TXDUC_REG35.lc_gearbox_init_state_ovr=1
		self.regs.TXDUC_REG35.lc_gearbox_init_state=0
		
		rootClockDivFactors=[round(i,4) for i in jesdConstants.rootClockDivFactors]
		if round(jesdConfigParams['rootClkDivTx'],4) in rootClockDivFactors:
			self.regs.TXDUC_REG33.dac_jesd_root_clk_div=rootClockDivFactors.index(round(jesdConfigParams['rootClkDivTx'],4))
		else:
			error("Invalid rootClkDivTx: "+str(jesdConfigParams['rootClkDivTx']))
			
		ducWrClockDivFactors=[round(i,4) for i in jesdConstants.ducWrClockDivFactors]
		if round(jesdConfigParams['ducWrClkDivFactorTx'],4) in ducWrClockDivFactors:
			self.regs.TXDUC_REG317.duc_wr_clk_ratio_tx0=ducWrClockDivFactors.index(round(jesdConfigParams['ducWrClkDivFactorTx'],4))
		else:
			error("Invalid ducWrClkDivFactorTx: "+str(jesdConfigParams['ducWrClkDivFactorTx']))
			
		jesdClockDivFactors=[round(i,4) for i in jesdConstants.jesdClockDivFactors]
		if round(jesdConfigParams['jesdClkDivFactorTx'],4) in jesdClockDivFactors:
			self.regs.TXDUC_REG319.jesd_rx_clk_ratio_tx0=jesdClockDivFactors.index(round(jesdConfigParams['jesdClkDivFactorTx'],4))
		else:
			error("Invalid jesdClkDivFactorTx: "+str(jesdConfigParams['jesdClkDivFactorTx']))
			
		if jesdConfigParams['LMFSHdTx'] in jesdConstants.jesdModesTx:
			self.regs.TXDUC_REG36.jesd_mode_tx0=jesdConstants.jesdModesTx.index(jesdConfigParams['LMFSHdTx'])
		else:
			error("Invalid LMFSHdTx: "+str(jesdConfigParams['LMFSHdTx']))
			
		if 'dedicated_tx_lane_mode' in jesdConfigParams:
			self.regs.TXDUC_REG42.dedicated_lane_mode=jesdConfigParams['dedicated_tx_lane_mode']
			
		self.regs.TXDUC_REG317.duc_wr_clk_ratio_tx0_override=1
		self.regs.TXDUC_REG319.jesd_rx_clk_ratio_tx0_override=1
		
		self.regs.TXDUC_REG45.spi_txenable=1
		self.regs.TXDUC_REG147.spidac=32767
		self.regs.TXDUC_REG147.spidac=32767
		self.regs.TXDUC_REG146.spidac_ena=0
		self.regs.TXDUC_REG146.spidac_ena=0
		self.regs.TXDUC_REG139.sync_request_ena=0xdf
		self.regs.TXDUC_REG140.error_ena=0x0
		self.regs.TXDUC_REG291.comma_align_valid_thresh_tx0=127
		
		if jesdConfigParams['jesdProtocol']==1:
			self.regs.Register40699_148h.jesd_c_ena=0
			self.regs.Register40699_148h.Property_148h_1_1=1
		elif jesdConfigParams['jesdProtocol']==2:
			self.regs.Register40699_148h.Property_148h_1_1=0
			self.regs.Register40699_148h.jesd_c_ena=1
		elif jesdConfigParams['jesdProtocol']==3:
			self.regs.Register40699_148h.Property_148h_1_1=0
			self.regs.Register40699_148h.jesd_c_ena=1
			self.regs.Register40699_148h.jesdc_80b_mode_en=1
		else:
			self.regs.Register40699_148h.Property_148h_1_1=0
			self.regs.Register40699_148h.jesd_c_ena=0
			
		F=self.jesdModeFeatures(jesdConfigParams['LMFSHdTx'])[2]
		#self.regs.TXDUC_REG38.buffer_depth=(F*(jesdConfigParams['RX_K']+1)/8)-1
		if 'scr' in jesdConfigParams:
			self.regs.TXDUC_REG125.scr=jesdConfigParams['scr']
			
		self.regs.TXDUC_REG124.lane_ena=2**(int(jesdConfigParams['LMFSHdTx'][0]))-1
		if self.systemStatus.chipVersion>0x10:
			self.regs.TXDUC_REG308.sysref_to_dac_jesd_clk_div_override=1
		self.regs.TXDUC_REG32.init_state_tx0=1
		#jesdConfig
		
	@funcDecorator
	def clearInitStates(self):
		""" "Clearing JESD RX Init States" "Done clearing JESD RX Init States" """
		self.regs.TXDUC_REG32.init_state_tx0=0
		if self.systemStatus.chipVersion>0x10:
			self.regs.TXDUC_REG308.sysref_to_dac_jesd_clk_div_override=0
			#clearInitStates
			
	@funcDecorator
	def clearDataAlarms(self):
		""" "Clearing JESD RX Data and alarms" "Done clearing JESD RX Data and alarms" """
		self.regs.TXDUC_REG129.jesd_clear_data=0xff
		self.regs.TXDUC_REG129.jesd_clear_data=0
		self.regs.TXDUC_REG45.serdes_fifo_err_clear=1
		self.regs.TXDUC_REG45.serdes_fifo_err_clear=0
		self.regs.TXDUC_REG400.clear_all_alarms=1
		self.regs.TXDUC_REG400.clear_all_alarms=0
		self.regs.TXDUC_REG400.clear_all_alarms_to_pap=1
		self.regs.TXDUC_REG400.clear_all_alarms_to_pap=0
		#clearDataAlarms
		
	@funcDecorator
	def clearData(self):
		self.regs.TXDUC_REG129.jesd_clear_data=0xff
		#clearData
		
	def laneErrorMeaning(self,error):
		bit={}
		bit[7] = "multiframe alignment error"
		bit[6] = "frame alignment error"
		bit[5] = "link configuration error"
		bit[4] = "elastic buffer overflow (bad RBD value)"
		bit[3] = "elastic buffer match error. The first no-/K/ does not match 'match_ctrl' and 'match_data' programmed values"
		bit[2] = "code synchronization error"
		bit[1] = "8b/10b not-in-table code error"
		bit[0] = "8b/10b disparty error"
		errorMeaning=""
		for i in range(8):
			if (error>>i)&1==1:
				errorMeaning+=bit[i]+"; "
		return errorMeaning
		
	def fifoErrorMeaning(self,error):
		bit={}
		bit[3] = "write_error : High if write request and FIFO is full (NOTE: only released when JESD block is initialized with init_state)"
		bit[2] = "write_full : FIFO is FULL"
		bit[1] = "read_error : High if read request with empty FIFO (NOTE: only released when JESD block is initialized with init_state)"
		bit[0] = "read_empty : FIFO is empty"
		errorMeaning=""
		for i in range(8):
			if (error>>i)&1==1:
				errorMeaning+=bit[i]+"; "
		return errorMeaning
		
	@funcDecorator
	def getJesdAlarms(self,clearAlarms=1):
		""" "Reading the JESD RX states to check if link is established" "Done reading the JESD RX states to check if link is established" """
		
		instanceNo=self.topno
		if clearAlarms:
			self.clearDataAlarms()
		self.systemStatus.jesdRxAlarms=self.systemStatus.jesdRxAlarms.replace("Got JESD Alarms for CH "+("AB","CD")[self.topno]+". Check log window.","")
		
		self.delay(0.001)
		self.deviceRefs.device.expectedReadValue=0
		deviceRxAlarms=self.regs.TXDUC_REG352._alarms.getValue()
		if (deviceRxAlarms>>3)&1!=0:
			deviceRxAlarms=deviceRxAlarms^0x8
			
		info("###########Device DAC JESD-RX "+str(self.topno)+" Link Status###########")
		if (deviceRxAlarms>>8)&0xff!=0:
			for i in range(4):
				error("LOS Indicator for (Serdes Loss of signal) lane "+str(i)+": " +str((deviceRxAlarms>>(8+i))&0x1))
				error("Frame Sync error (unexpected k28.5) for lane "+str(i)+": " +str((deviceRxAlarms>>(12+i))&0x1))
		laneErrors=[] 
		commaAlignLock=[]
		for i in range(int(self.systemParams.LMFSHdTx[self.topno][0])):
			laneErrors.append((deviceRxAlarms>>(32+(i*8)))&0xff)
			self.deviceRefs.device.expectedReadValue=1
			exec("commaAlignLockVal=self.regs.TXDUC_REG309._comma_align_lock_lane"+str(i)+"_monitor_flag.getValue()")
			commaAlignLock.append(commaAlignLockVal)
			if commaAlignLockVal == False:
				error("Comma Align Lock Lane"+str(i)+": "+str(commaAlignLockVal)+"; Please check if the transmitter is sending data and eye is good.")
				
		fifoErrors=(deviceRxAlarms>>16)&(2**16-1)
		if fifoErrors!=0:
			lane0FifoErrors=(fifoErrors>>0)&0xf
			lane1FifoErrors=(fifoErrors>>4)&0xf
			lane2FifoErrors=(fifoErrors>>8)&0xf
			lane3FifoErrors=(fifoErrors>>12)&0xf
			error("lane0 FIFO Errors=" +str('0b{:04b}'.format(lane0FifoErrors))+"; Got errors: "+self.fifoErrorMeaning(lane0FifoErrors))
			error("lane1 FIFO Errors=" +str('0b{:04b}'.format(lane1FifoErrors))+"; Got errors: "+self.fifoErrorMeaning(lane1FifoErrors))
			error("lane2 FIFO Errors=" +str('0b{:04b}'.format(lane2FifoErrors))+"; Got errors: "+self.fifoErrorMeaning(lane2FifoErrors))
			error("lane3 FIFO Errors=" +str('0b{:04b}'.format(lane3FifoErrors))+"; Got errors: "+self.fifoErrorMeaning(lane3FifoErrors))
			
		if deviceRxAlarms>>32!=0:
			lane0Errors=(deviceRxAlarms>>(32+(0*8)))&0xff
			lane1Errors=(deviceRxAlarms>>(32+(1*8)))&0xff
			lane2Errors=(deviceRxAlarms>>(32+(2*8)))&0xff
			lane3Errors=(deviceRxAlarms>>(32+(3*8)))&0xff
			error("lane0 Errors=" +str('0b{:04b}'.format(lane0Errors))+"; Got errors: "+self.laneErrorMeaning(lane0Errors))
			error("lane1 Errors=" +str('0b{:04b}'.format(lane1Errors))+"; Got errors: "+self.laneErrorMeaning(lane1Errors))
			error("lane2 Errors=" +str('0b{:04b}'.format(lane2Errors))+"; Got errors: "+self.laneErrorMeaning(lane2Errors))
			error("lane3 Errors=" +str('0b{:04b}'.format(lane3Errors))+"; Got errors: "+self.laneErrorMeaning(lane3Errors))
			
			
		expectedCsState=0
		expectedFsState=0
		for l in range(int(self.systemParams.LMFSHdTx[self.topno][0])):
			expectedCsState=expectedCsState+(2<<(2*l))
			if self.systemParams.jesdProtocol not in (2,3):
				expectedFsState=expectedFsState+(1<<(2*l))
				
		self.deviceRefs.device.expectedReadValue=expectedCsState
		deviceCsState=self.regs.TXDUC_REG298._jesd_cs_state_tx0.getValue()
		if self.systemParams.jesdProtocol not in (2,3):
			self.deviceRefs.device.expectedReadValue=expectedFsState
			deviceFsState=self.regs.TXDUC_REG300._jesd_fs_state_tx0.getValue()
		else:
			self.deviceRefs.device.expectedReadValue=deviceCsState
			deviceShState=self.regs.TXDUC_REG304._jesd_sh_state_tx0.getValue()
			expectedFsState=deviceCsState
			deviceFsState=deviceShState
			
			#self.deviceRefs.device.expectedReadValue=expectedFsState
			#deviceFsState=self.regs.TXDUC_REG300._jesd_fs_state_tx0.getValue()
			
		info("CS State TX0: "+'0b{:08b}'.format(deviceCsState)+" . It is expected to be "+'0b{:08b}'.format(expectedCsState&0xf))
		#info("FS State TX0: "+'0b{:08b}'.format(deviceFsState)+" . It is expected to be "+'0b{:08b}'.format(expectedFsState&0xf))
		if self.systemParams.jesdProtocol not in (2,3):
			info("FS State TX0: "+'0b{:08b}'.format(deviceFsState)+" . It is expected to be "+'0b{:08b}'.format(expectedFsState&0xf))
		else:
			info("SH State TX0: "+'0b{:08b}'.format(deviceShState)+" . It is expected to be "+'0b{:08b}'.format(expectedCsState&0xf))
			
		if expectedCsState==deviceCsState and expectedFsState==deviceFsState and deviceRxAlarms==0:
			info("Could get the link up for device RX: "+str(instanceNo))
			self.systemStatus.jesdRxLink[self.topno]=True
		else:
			error("Couldn't get the link up for device RX: "+str(instanceNo)+ "; Alarms: "+str(hex(deviceRxAlarms)))
			#error(self.systemParams.LMFSHdTx[self.topno])
			#error(self.systemParams.ducFactorTx[self.topno])
			self.systemStatus.jesdRxLink[self.topno]=False
			self.systemStatus.jesdRxAlarms="Got JESD Alarms for CH "+("AB","CD")[self.topno]+". Check log window."
		info("###################################")
		#getJesdAlarms
		
	@funcDecorator
	def configLaneMux(self,laneMuxOrder):
		offset=self.topno*4
		self.regs.TXDUC_REG116.octetpath0_sel_tx0=laneMuxOrder[0]-offset
		self.regs.TXDUC_REG116.octetpath1_sel_tx0=laneMuxOrder[1]-offset
		self.regs.TXDUC_REG117.octetpath2_sel_tx0=laneMuxOrder[2]-offset
		self.regs.TXDUC_REG117.octetpath3_sel_tx0=laneMuxOrder[3]-offset
		#configLaneMux
		
	@funcDecorator
	def enableTestPattern(self,en=1,power=32767):
		self.regs.TXDUC_REG147.spidac=power&0x7fff
		self.regs.TXDUC_REG146.spidac_ena=en
		#enableTestPattern
		
		
	@funcDecorator
	def setDucWrClk(self,ducWrClk):
		""" ducWrClk is in MHz """
		ducWrClkRateDivTx=self.systemParams.Fs/ducWrClk
		for rootClkDiv in jesdConstants.rootClockDivFactors:
			if round(ducWrClkRateDivTx/(8.0*rootClkDiv),4) in jesdConstants.ducWrClockDivFactors:
				rootClkDivTx=rootClkDiv
				ducWrClkDivFactorTx=round(ducWrClkRateDivTx/(8.0*rootClkDiv),4)
				break
		self.regs.TXDUC_REG33.dac_jesd_root_clk_div=jesdConstants.rootClockDivFactors.index(round(rootClkDivTx,4))
		self.regs.TXDUC_REG317.duc_wr_clk_ratio_tx0=jesdConstants.ducWrClockDivFactors.index(round(ducWrClkDivFactorTx,4))
		#setDucWrClk
		
		
	@funcDecorator
	def enableSquareWave(self,enable):
		self.regs.TXDUC_REG179.testpattern_ai_ena=1#testpatt0
		self.regs.TXDUC_REG179.testpattern_aq_ena=1#testpatt0
		self.regs.TXDUC_REG180.testpattgen0_patternsel=2#Pulse
		self.regs.TXDUC_REG206.testpattgena_pulse_ampl_high=16384#High level
		self.regs.TXDUC_REG214.testpattgena_pulse_ampl_low=0#Low level
		self.regs.TXDUC_REG222.testpattgena_pulse_high_cnt=10#High count
		self.regs.TXDUC_REG226.testpattgena_pulse_period_cnt=20#Period count
		self.regs.TXDUC_REG80.syncsel_testpattgen=8#choose SPI based sync of test patterns
		#Sync for test patterns
		self.regs.TXDUC_REG85.spi_sync=0
		self.regs.TXDUC_REG85.spi_sync=1
		self.regs.TXDUC_REG85.spi_sync=0
		
		#jesdRxLib
