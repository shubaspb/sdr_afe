from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mAfeConstants
reload(mAfeConstants)
from mAfeConstants import pllConstants
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import random
import math,inspect
from fractions import Fraction

class pllLib(projectBaseClass):
	"""Contains PLL specific functions. self.regs=device.TOP.PLL.pll1 """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.topno=topno
		self.regs=regs
		self.chooseHigherVco=0
		self.programmedFOut=[0,0]
		self.pll6G=False
		#__init__
		
	@funcDecorator
	def powerUpPll(self,pu=1):
		""" "Powers up/down the PLL" """
		self.regs.pll1.EN_VCO=pu
		#powerUpPll
		
	@funcDecorator
	def resetLockLost(self):
		self.regs.pll1.lock_lost_rst=1
		self.regs.pll1.lock_lost_rst=0
		#resetLockLost
		
	@funcDecorator
	def freeRunningVco(self,en):
		self.regs.pll1.CTL_CP_TRS=en
		#freeRunningVco
		
	@funcDecorator
	def pllOpOntoPin(self,en,refClk=False):
		self.regs.pll1.EN_VCO_LOOP_TEST = en&0x1###to enable VCO/Digitest points to output
		self.regs.pll1.CTL_VCO_LOOP_TEST = refClk##### 0 - VCO to out, 1 - Digitest to out
		self.regs.pll1.CTL_TEST_MUX=3
		#pllOntoPin
		
	@funcDecorator
	def vcoTune(self,VCO_SEL_IN,CTL_CP_IREF,CTL_CP_IOUT,VCO_TRIM_IN):
		""" "Tuning VCO" """
		self.regs.pll1.VCO_SEL_IN=VCO_SEL_IN
		self.regs.pll1.CTL_CP_IREF=CTL_CP_IREF
		self.regs.pll1.CTL_CP_IOUT=CTL_CP_IOUT
		self.regs.pll1.VCO_TRIM_IN=VCO_TRIM_IN
		self.regs.pll1.CAL_BYPASS=1
		#vcoTune
		
	@funcDecorator
	def configurePll(self,enFracMode=True):
		""" "Configure PLL" "Done configuring PLL" """
		if (self.topno==0 and self.systemParams.usePllExternalLoClock[1]==True) or (self.topno==2 and self.systemParams.usePllExternalLoClock[0]==True):
			self.regs.pll1.EN_EXT_LO=True
			self.regs.pll1.CTL_OUT_DIV=1
			self.regs.pll1.EN_VCO=0
			self.systemStatus.pllLockStatus[self.topno]=True
			self.systemParams.pllLo[self.topno]
			return
		FRef=self.systemParams.FRef
		Fout=self.systemParams.pllLo[self.topno]
		self.programmedFOut[0]=Fout
		if self.systemParams.setLoForCoherence==True and self.systemStatus.chipVersion<=0x10:
			Fout=self.findLoNcoPossibleFrequency(Fout)
		if self.topno!=1:
			Fout=Fout*2
		if self.topno==1:
			pllOpDivFactors=pllConstants.pllDcPllOpDivFactors
		else:
			pllOpDivFactors=pllConstants.pllOpDivFactors
		if self.chooseHigherVco==1:
			pllOpDivFactors1=list(reversed(pllOpDivFactors))
		else:
			pllOpDivFactors1=pllOpDivFactors
		found=False	
		#if self.pll6G==False:
		#	vcoMin=6000.0#pllConstants.pllVcoRange[0]
		#else:
		
		if self.topno==1:
			vcoMin=6000.0
			pllIpDivFactors=[1,2,4]
		else:
			vcoMin=5700.0
			pllIpDivFactors=[1,]
		for ipDiv in pllIpDivFactors:
			for opDiv in pllOpDivFactors1:
				if opDiv not in pllOpDivFactors1:
					continue
				Fvco=Fout*opDiv
				divFactor=Fvco*ipDiv/FRef
				if self.topno==1:
					F=0
					D=2**17
					N=round(divFactor,6)
				else:
					N=int(divFactor)
					if self.systemStatus.chipVersion>0x10:
						if (FRef*1000.0>2**18):
							numMulFact=math.ceil(FRef*1000.0/2.**18)
							D=int(round(FRef*1000.0/numMulFact))
						else:
							D=int(round(FRef*1000.0))
							numMulFact=1
						F=int(round((divFactor-N)*D,4))
						if F!=0:
							numMulFact=numMulFact*opDiv
							
							# if (((N*D)+F)%numMulFact)!=0:
							# if F>=(((N*D)+F)%numMulFact):
							# F=F-(((N*D)+F)%numMulFact)
							# else:
							# N=N-1
							# F=D+F-(((N*D)+F)%numMulFact)
					else:
						
						F=int(round((divFactor-N)*2**15,4))*(2**3)#Fraction(divFactor-N).limit_denominator(2**19).numerator
						D=2**18#2**18#Fraction(divFactor-N).limit_denominator(2**19).denominator
						#mulfact=int(2.0**19/D)
						#D=D*mulfact
						#F=F*mulfact
						#if N in pllConstants.pllNfactors and Fvco>pllConstants.pllVcoRange[0] and Fvco<pllConstants.pllVcoRange[1] and (F==0 or F in pllConstants.pllFfactors) and D in pllConstants.pllDfactors and F<D:
				if N in pllConstants.pllNfactors and Fvco>vcoMin and Fvco<pllConstants.pllVcoRange[1] and (F==0 or F in pllConstants.pllFfactors) and D in pllConstants.pllDfactors and F<D: 
					found=True
					break
			if found==True:
				break
		if found==False:
			F = 0#pllConstants.pllFfactors[0]
			D = pllConstants.pllDfactors[0]
			N = pllConstants.pllNfactors[0]
			ipDiv = pllConstants.pllIpDivFactors[0]
			opDiv = pllConstants.pllOpDivFactors[0]
			error("Could not find suitable factors for PLL"+str(self.topno)+": refClk="+str(FRef)+"\t Fout="+str(Fout))
		if enFracMode==False:
			if (F*1.0/D)>0.5:
				N=N+1
			F=0
		if F==0:
			enFrac=False
		else:
			enFrac=True
			
		if ipDiv!=1 and self.topno==1:
			self.regs.pll1.EN_SYNC_REF_DIV=1
			self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Give Sysref Here.")
			self.delay(0.001)
			self.regs.pll1.EN_SYNC_REF_DIV=0
			self.regs.pll1.FORCE_REFIN_CLOCK_TO_DIGZ=1
			
		if self.topno!=1:
			self.regs.pll1.PLL_SPARE0=0xcc000
			
		self.regs.pll1.EN_VCO=1
		self.regs.pll1.N=N
		self.regs.pll1.N_to_CAL=N
		for i in pllConstants.pllCalControlFRefRanges:
			if (FRef/(ipDiv*61.44))>=i[0] and (FRef/(ipDiv*61.44))<=i[1]:
				self.regs.pll1.CAL_CONTROL=pllConstants.pllCalControlFRefRanges.index(i)
				break
				
		self.regs.pll1.CTL_REF_DIV=ipDiv
		self.regs.pll1.EN_DIV8_CLK_TO_PLLDIG=1
		self.regs.pll1.EN_CLK_TO_PLLDIG=1
		self.regs.pll1.EN_SYNC_TO_PLLDIG_DIV=1
		if N<15:
			self.regs.pll1.CTL_DIV_23_45=1
		else:
			self.regs.pll1.CTL_DIV_23_45=0
		self.regs.pll1.EN_FRAC_N_MODE=enFrac
		self.regs.pll1.EN_FRAC_MODE=enFrac
		#Make the CTL_TEST_MUX = 3 to bring out LO
		self.regs.pll1.CTL_TEST_MUX=0
		
		self.regs.pll1.EN_VCO_PKDET = 1
		self.regs.pll1.VCO_PKDT_BIAS = 7
		
		self.regs.pll1.CTL_VCO_IB_GM = 7
		self.regs.pll1.CTL_VCO_IB_TAIL = 12
		
		self.regs.pll1.CTL_VCO_IB_GM_SLOPE = 0
		self.regs.pll1.CTL_VCO_IB_TAIL_SLOPE = 0
		self.regs.pll1.CTL_VCO_IB_GM1 = 0
		self.regs.pll1.CTL_VB_VAR_SLOPE = 0
		
		self.regs.pll1.F=F
		self.regs.pll1.D=D
		#Sigma delta order
		self.regs.pll1.F_order=1
		##if EnableDither:
		#######self.regs.pll1.EN_SDM_DITHER=0	#Enable for PRBS
		#######self.regs.pll1.SDM_DITH_MODE=4	#Enable for PRBS
		#######self.regs.pll1.SDM_DITH_SCALE=7	#Enable for PRBS
		self.regs.pll1.EN_LOCK_DETECT=1
		self.regs.pll1.CTL_PFD_DEL=2
		if opDiv==8:
			self.regs.pll1.CTL_OUT_DIV=4
		else:
			self.regs.pll1.CTL_OUT_DIV=(range(7)+[8,]).index(opDiv)
			
		self.regs.pll1.CTL_LDO_ANA=4
		self.regs.pll1.CTL_LDO_RF=4
		self.regs.pll1.CTL_FBDIV_LDO_PROG=8
		if Fout>=4000 and self.topno!=1:
			#In case the integrated phase noise is high, try IREF=2, IOUT = 2
			self.regs.pll1.CTL_CP_IREF=2
			self.regs.pll1.CTL_CP_IOUT=3
		else:
			self.regs.pll1.CTL_CP_IREF=1 
			self.regs.pll1.CTL_CP_IOUT=1
			
		self.regs.pll1.lock_acc=3
		self.regs.pll1.lock_cnt=3
		self.regs.pll1.lock_err=1
		self.regs.pll1.lock_rst=1
		self.regs.pll1.lock_rst=0
		self.regs.pll1.lock_lost_rst=1
		self.regs.pll1.lock_lost_rst=0
		self.regs.pll1.EN_CAL=0
		self.regs.pll1.EN_CAL=1
		if Fout<4000 and self.topno!=1:
			self.regs.pll1.CTL_I_OFFSET=1 
		self.delay(0.01)
		if enFrac==True:
			self.regs.pll1.EN_I_OFFSET=1
			self.regs.pll1.CTL_I_OFST_UP_DN=0###0--Up>DN
			self.regs.pll1.CTL_I_OFST_REF=1
			if Fout>=4000 and self.topno!=1:
				self.regs.pll1.CTL_I_OFFSET=2
		else:
			self.regs.pll1.EN_I_OFFSET=0
			
			#self.regs.pll1.sysref_width = 7
			
			
		self.deviceRefs.device.printCommentToLog("SPIPoll 0062,7,7,1")
		if self.systemParams.simulationMode==False:
			pll_lock=False
			lockCount=0
			for i in range(7):
				if lockCount==1:
					pll_lock=True
					break
				self.deviceRefs.device.expectedReadValue=True
				if self.regs.pll1._lock.getValue()==True:
					lockCount+=1
		else:
			self.regs.pll1._lock.getValue()
			pll_lock=True
			
		if opDiv==8:
			self.regs.pll1.CTL_OUT_DIV=(range(7)+[8,]).index(opDiv)
			
		if self.topno==1:
			self.regs.pll1.EN_DIV8_CLK_TO_PLLDIG=0
			
			
		if self.topno==1:
			self.systemStatus.pllLo[self.topno]=FRef*(N+(F*1.0/D))/(ipDiv*opDiv)
			self.systemParams.pllLo[self.topno]=FRef*(N+(F*1.0/D))/(ipDiv*opDiv)
		else:
			self.systemStatus.pllLo[self.topno]=FRef*(N+(F*1.0/D))/(2*ipDiv*opDiv)
			self.systemParams.pllLo[self.topno]=FRef*(N+(F*1.0/D))/(2*ipDiv*opDiv)
		self.systemStatus.pllLockStatus[self.topno]=pll_lock
		self.programmedFOut[1]=self.systemParams.pllLo[self.topno]
		#info("VCO_CAP_SEL_RO: "+str(self.regs.pll1._VCO_CAP_SEL_RO.getValue()))
		#info("VCO_SEL_RO: "+str(self.regs.pll1._VCO_SEL_RO.getValue()))
		if pll_lock==False:
			error("pll"+str(self.topno)+":  "+str(pll_lock)+"; \t LO Frequency: "+str(self.systemStatus.pllLo[self.topno]))
		else:
			info("pll"+str(self.topno)+":  "+str(pll_lock)+"; \t LO Frequency: "+str(self.systemStatus.pllLo[self.topno]))
			#configurePll
			
	@funcDecorator
	def sendSysref(self,spiSysref=0,n=1):
		""" "Send Sysref" """
		self.regs.pll1.SYS_REF_FROM_PIN_BYPAS=1
		if spiSysref==0:
			self.regs.pll1.EN_SYNC_DIV=1
			self.regs.pll1.EN_SYNC_TO_PLLDIG_DIV=1
		self.regs.pll1.lcmgen_div=self.systemParams.sysrefFreqDiv-1
		self.regs.pll1.lcmgen_sync_ena=0
		self.regs.pll1.lcmgen_sync_ena=1
		if spiSysref==0:
			self.regs.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			#self.regs.pll1.EN_SYNC_DIV=0
		if spiSysref==1:
			self.regs.pll1.lcmgen_usespisysref=1
			for i in range(n):
				self.regs.pll1.lcmgen_spisysref=0
				self.regs.pll1.lcmgen_spisysref=1
			self.regs.pll1.lcmgen_spisysref=0
		else:
			self.regs.pll1.lcmgen_usespisysref=0
			self.delay(0.1)
		self.regs.pll1.SYS_REF_FROM_PIN_BYPAS=0
		#sendSysref
		
		#pllLib
