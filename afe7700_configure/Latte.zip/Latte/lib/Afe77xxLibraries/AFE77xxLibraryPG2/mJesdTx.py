from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import mAfeConstants
reload(mAfeConstants)
from mAfeConstants import jesdConstants
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import random
import math

class jesdTxLib(projectBaseClass):
	"""Contains ADC JESD TX specific functions. self.regs=device.JESD.ADC_TX.JESD """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.topno=topno
		self.regs=regs.ADC_TX
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
					
					#__init__
					
	@funcDecorator
	def jesdConfig(self):
		""" "Configuring Device JESD TX" "Done configuring Device JESD TX" """
		jesdConfigParams=self.systemStatus.jesdConfigParams[self.topno]
		self.regs.ALARM_CONFIG1.hd_sts_pll_lock_override=1
		self.regs.ALARM_CONFIG1.hd_sts_pll_lock_reg=1
		self.regs.LC_INIT_STATE_OVR.lc_gearbox_init_state=0
		if self.systemParams.ddcFactorRx[self.topno]==1:
			self.regs.JESD_TX_CONFIG51.ddc_bypass_8lanemode_en=1
		else:
			self.regs.JESD_TX_CONFIG51.ddc_bypass_8lanemode_en=0
		self.regs.JESD_TX_CONFIG38.init_state=1
		self.regs.JESD_TX_CONFIG38.fifo_init_state=1
		self.regs.JESD_TX_CONFIG38.fb_init_state=1
		self.regs.JESD_TX_CONFIG7.jesd_clear_data=15
		if "sysref_jesd_mode" in jesdConfigParams:
			self.regs.JESD_TX_CONFIG1.sysref_jesd_mode=jesdConfigParams['sysref_jesd_mode']
		else:
			self.regs.JESD_TX_CONFIG1.sysref_jesd_mode=1
		self.regs.JESD_TX_CONFIG1.k_m1=jesdConfigParams['TX_K']
		self.regs.JESD_TX_CONFIG2.fb_k_m1=jesdConfigParams['TX_K']
		
		if jesdConfigParams['LMFSHdRx'] in jesdConstants.jesdModesRx:
			self.regs.JESD_TX_CONFIG36.jesd_mode=jesdConstants.jesdModesRx.index(jesdConfigParams['LMFSHdRx'])
		else:
			error("Invalid LMFSHdRx Mode: "+str(jesdConfigParams['LMFSHdRx']))
			
		if (jesdConfigParams['LMFSHdFb'] in jesdConstants.jesdModesFb) and (jesdConfigParams['sampDropByFb'] in (1,3)):
			self.regs.JESD_TX_CONFIG37.fb_jesd_mode=jesdConstants.jesdModesFb.index(jesdConfigParams['LMFSHdFb'])
		elif (jesdConfigParams['LMFSHdFb'] in jesdConstants.jesdModesRx) and (jesdConfigParams['sampDropByFb'] not in (1,3)):
			self.regs.JESD_TX_CONFIG37.fb_jesd_mode=jesdConstants.jesdModesRx.index(jesdConfigParams['LMFSHdFb'])
		else:
			error("Invalid LMFSHdFb Mode: "+str(jesdConfigParams['LMFSHdFb']) +" and Sample Drop factor is "+str(jesdConfigParams['sampDropByFb']))
			
		rootClockDivFactors=[round(i,4) for i in jesdConstants.rootClockDivFactors]
		if round(jesdConfigParams['rootClkDivRxFb'],4) in rootClockDivFactors:
			if 'CLK_DIV_CONFIG32' in self.regs.entities.keys():
				self.regs.CLK_DIV_CONFIG32.adc_jesd_root_clk_div= rootClockDivFactors.index(round(jesdConfigParams['rootClkDivRxFb'],4))
			else:
				self.regs.RX_ROOT_CLK_DIV_CONFIG.adc_jesd_root_clk_div= rootClockDivFactors.index(round(jesdConfigParams['rootClkDivRxFb'],4))
		else:
			error("Invalid rootClkDivRxFb: "+str(jesdConfigParams['rootClkDivRxFb']))
			
		ddcRdClockDivFactors=[round(i,4) for i in jesdConstants.ddcRdClockDivFactors]
		if round(jesdConfigParams['ddcRdClkDivFactorRx'],4) in ddcRdClockDivFactors:
			self.regs.CLK_DIV_CONFIG42.ddc_rd_clk_ratio_rx1=ddcRdClockDivFactors.index(round(jesdConfigParams['ddcRdClkDivFactorRx'],4))
		else:
			error("Invalid ddcRdClkDivFactorRx: "+str(jesdConfigParams['ddcRdClkDivFactorRx']))
		self.regs.CLK_DIV_CONFIG42.ddc_rd_clk_ratio_rx1_override=1
		
		if round(jesdConfigParams['ddcRdClkDivFactorFb'],4) in ddcRdClockDivFactors:
			self.regs.CLK_DIV_CONFIG43.ddc_rd_clk_ratio_rx2=ddcRdClockDivFactors.index(round(jesdConfigParams['ddcRdClkDivFactorFb'],4))
		else:
			error("Invalid ddcRdClkDivFactorFb: "+str(jesdConfigParams['ddcRdClkDivFactorFb']))
		self.regs.CLK_DIV_CONFIG43.ddc_rd_clk_ratio_rx2_override=1
		
		jesdClockDivFactors=[round(i,4) for i in jesdConstants.jesdClockDivFactors]
		if round(jesdConfigParams['jesdClkDivFactorRx'],4) in jesdClockDivFactors:
			self.regs.CLK_DIV_CONFIG46.jesd_tx_clk_ratio_rx1=jesdClockDivFactors.index(round(jesdConfigParams['jesdClkDivFactorRx'],4))
		else:
			error("Invalid jesdClkDivFactorRx: "+str(jesdConfigParams['jesdClkDivFactorRx']))
		self.regs.CLK_DIV_CONFIG46.jesd_tx_clk_ratio_rx1_override=1
		
		if round(jesdConfigParams['jesdClkDivFactorFb'],4) in jesdClockDivFactors:
			self.regs.CLK_DIV_CONFIG47.jesd_tx_clk_ratio_rx2=jesdClockDivFactors.index(jesdConfigParams['jesdClkDivFactorFb'])
		self.regs.CLK_DIV_CONFIG47.jesd_tx_clk_ratio_rx2_override=1
		
		self.regs.JESD_TX_CONFIG65.jesd_system_mode=jesdConfigParams['systemMode']
		self.regs.SCRAMBLER_64B_CONFIG1.scr_64b_initval=1
		
		if jesdConfigParams['jesdProtocol']==3:
			self.regs.JESD_TX_CONFIG55.jesd_std_sel=2
			self.regs.JESDC_TX_CONFIG0.jesdc_encoding_80b_66bz=1
			self.regs.SCRAMBLER_64B_CONFIG9.scr_64b_en=1
		elif jesdConfigParams['jesdProtocol'] not in (0,1,2):
			jesdConfigParams['jesdProtocol']=0
		else:
			if jesdConfigParams['jesdProtocol'] == 0:
				self.regs.SCRAMBLER_64B_CONFIG9.scr_64b_en=0
			else:
				self.regs.SCRAMBLER_64B_CONFIG9.scr_64b_en=1
			self.regs.JESD_TX_CONFIG55.jesd_std_sel=jesdConfigParams['jesdProtocol']
			
		self.regs.JESD_TX_CONFIG64.dedicated_rx_fb_lane_mode=jesdConfigParams['dedicated_rx_fb_lane_mode']
		
		(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(jesdConfigParams['LMFSHdFb'])
		#if S==1:
		#	self.regs.JESD_TX_CONFIG88.swap_samples_pre_sample_drop_rx2_override=1
		#	self.regs.JESD_TX_CONFIG88.swap_samples_pre_sample_drop_rx2=0
		
		self.regs.JESD_TX_CONFIG89.sample_drop_mode_rx1=jesdConfigParams['sampDropByRx']
		self.regs.JESD_TX_CONFIG89.sample_drop_mode_rx2=jesdConfigParams['sampDropByFb']
		if jesdConfigParams['sampDropByFb']==3 and S==1 and M==2:
			self.regs.JESD_TX_CONFIG93.swap_samples_post_sample_drop_rx2=2
			self.regs.JESD_TX_CONFIG93.swap_samples_post_sample_drop_rx2_override=1
		elif jesdConfigParams['sampDropByFb']==3 and S==1 and M==4:
			self.regs.JESD_TX_CONFIG93.swap_samples_post_sample_drop_rx2=2
			self.regs.JESD_TX_CONFIG93.swap_samples_post_sample_drop_rx2_override=1
			
		if 'scr' in jesdConfigParams:
			self.regs.JESD_TX_CONFIG3.scr=jesdConfigParams['scr']
			self.regs.JESD_TX_CONFIG4.fb_scr=jesdConfigParams['scr']
		else:
			self.regs.JESD_TX_CONFIG3.scr=1
			
			#if jesdConfigParams['jesdProtocol']==0:
			#	if jesdConfigParams['systemMode']==1:
			#		self.regs.JESD_TX_CONFIG6.lane_ena=(2**(int(jesdConfigParams['LMFSHdRx'][0]))-1)+((2**(int(jesdConfigParams['LMFSHdFb'][0]))-1)<<2)
			#	else:
			#		self.regs.JESD_TX_CONFIG6.lane_ena=2**(int(jesdConfigParams['LMFSHdRx'][0]))-1
			#else:
			#self.regs.JESD_TX_CONFIG6.lane_ena=15
			
		if jesdConfigParams['systemMode']==1 or (jesdConfigParams['dedicated_rx_fb_lane_mode']==True and jesdConfigParams['systemMode']==2):
			self.regs.JESD_TX_CONFIG6.lane_ena=(2**(int(jesdConfigParams['LMFSHdRx'][0]))-1)+((2**(int(jesdConfigParams['LMFSHdFb'][0]))-1)<<2)
		else:
			self.regs.JESD_TX_CONFIG6.lane_ena=2**(int(jesdConfigParams['LMFSHdRx'][0]))-1
			
		if False:#self.systemParams.jesdProtocol!=0:
			self.regs.SERDES_LANE_MUX_SEL.serdes_lane0_mux_sel=0
			self.regs.SERDES_LANE_MUX_SEL.serdes_lane1_mux_sel=0
			self.regs.SERDES_LANE_MUX_SEL.serdes_lane2_mux_sel=0
			self.regs.SERDES_LANE_MUX_SEL.serdes_lane3_mux_sel=0
			
		if self.systemStatus.chipVersion>0x10:
			self.regs.CLK_DIV_CONFIG33.sysref_to_ddc_jesd_clk_div_override=1
		self.regs.JESD_TX_CONFIG38.init_state=1
		self.regs.JESD_TX_CONFIG38.fifo_init_state=1
		self.regs.JESD_TX_CONFIG38.fb_init_state=1
		#jesdConfig
		
	@funcDecorator
	def clearInitStates(self):
		""" "Clearing JESD TX Init States" "Done clearing JESD TX Init States" """
		self.regs.JESD_TX_CONFIG38.init_state=0
		self.regs.JESD_TX_CONFIG38.fb_init_state=0
		if self.systemStatus.chipVersion>0x10:
			self.regs.CLK_DIV_CONFIG33.sysref_to_ddc_jesd_clk_div_override=0
			#clearInitStates
			
	@funcDecorator
	def clearDataAlarms(self):
		""" "Clearing JESD TX Data and alarms" "Done clearing JESD TX Data and alarms" """
		self.regs.ALARM_CONFIG2.alarms_serdes_fifo_errors_clear=15
		self.regs.ALARM_CONFIG2.alarms_serdes_fifo_errors_clear=0
		self.regs.JESD_TX_CONFIG7.jesd_clear_data=15
		self.regs.JESD_TX_CONFIG7.jesd_clear_data=0
		self.regs.JESD_TX_CONFIG38.fifo_init_state=0
		#clearDataAlarms
		
	@funcDecorator
	def toggleSync(self):
		if self.systemParams.syncLoopBack==False:
			self.regs.JESD_TX_CONFIG83.sync_override=12
			self.regs.JESD_TX_CONFIG83.sync=12
			self.delay(0.2)
			self.regs.JESD_TX_CONFIG83.sync=0
			#toggleSync
			
	@funcDecorator
	def reSync(self):
		""" Restarts the State Machine. """
		self.regs.JESD_TX_CONFIG38.init_state=1
		self.regs.JESD_TX_CONFIG38.fifo_init_state=1
		self.regs.JESD_TX_CONFIG38.fb_init_state=1
		self.regs.JESD_TX_CONFIG7.jesd_clear_data=15
		self.clearInitStates()
		self.clearDataAlarms()
		#reSync
		
	@funcDecorator
	def enableTestPattern(self,en=1):
		#self.regs.JESD_TX_CONFIG38.jesd_shorttest_ena
		self.regs.JESD_TX_CONFIG38.jesd_ramptest_ena=en
		#enableTestPattern
		#jesdTxLib
