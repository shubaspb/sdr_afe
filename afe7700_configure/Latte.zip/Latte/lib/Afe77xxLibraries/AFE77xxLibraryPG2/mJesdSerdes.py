from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math
import numpy
import sys
import matplotlib.pyplot

import mSetupParams
from mSetupParams import setupJesdParams
from mAfeConstants import jesdConstants

class serdesLib(projectBaseClass):
	"""Contains Serdes specific functions. self.regs=device.JESD.SERDES """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.topno=topno
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
	
	#__init__

	@funcDecorator
	def serdesReset(self):
		""" "Resetting Serdes" "Done resetting Serdes" This function resets the SERDES Phy Layer"""
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x888
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x000
		self.delay(0.1)
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x777
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x000
		self.delay(0.1)
	#serdesReset
	
	@funcDecorator
	def enableRxToTxLoopback(self,en):
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE3.getValue()
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE2.getValue()
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE1.getValue()
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE0.getValue()
		self.regs.Common.IO_MODE_CONTROL.LOOPBACK_EN=en
	#enableRxToTxLoopback
	
	@funcDecorator
	def setLanePolarity(self):
		temp=self.deviceRefs.device.hardReadAlways
		self.deviceRefs.device.hardReadAlways=True
		tx_polarity = setupJesdParams.boardLaneSettings[setupParams.boardType][self.systemStatus.dutNo]['tx_polarity']
		rx_polarity = setupJesdParams.boardLaneSettings[setupParams.boardType][self.systemStatus.dutNo]['rx_polarity']
		for i in range(4):
			self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_POLARITY_FLIP = tx_polarity[(self.topno*4)+i]
			self.regs.laneRegisters[i].RX_PRBS_CONFIGURATION.RX_POLARITY_FLIP = rx_polarity[(self.topno*4)+i]
		self.deviceRefs.device.hardReadAlways=temp
	
	@funcDecorator
	def serdes1010Pattern(self,laneEna=0xf):
		""" "Sending 1010 pattern on SERDES Lanes" Makes the output of serdes as 1010 for the selected lanes. Each bit of the parameter laneEna is for one lane."""
		laneEna=laneEna&0xf
		for i in range(4):
			if (laneEna>>i)&1==1:
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_DATA_SOURCE=0
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_CLOCK_EN=0
				self.regs.laneRegisters[i].TX_TEST_PATTERN_HIGH.TX_TEST_PATTERN_HIGH=0xaaaa
				self.regs.laneRegisters[i].TX_TEST_PATTERN_LOW.TX_TEST_PATTERN_LOW=0xaaaa
	#serdes1010Pattern
	
	@funcDecorator
	def serdesPrbsPattern(self,laneEna=0xf,PRBSPattern=0):
		""" "Sending PRBS pattern on SERDES Lanes" Makes the output of serdes as PRBS for the selected lanes. Each bit of the parameter laneEna is for one lane."""
		laneEna=laneEna&0xf
		for i in range(4):
			if (laneEna>>i)&1==1:
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_DATA_SOURCE=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_GEN_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_CLOCK_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_MODE=PRBSPattern
	#serdesPrbsPattern
	
	@funcDecorator
	def serdesSendData(self,laneEna=0xf):
		""" "Sending Data on SERDES Lanes" Sends Data on the selected lanes. Each bit of the parameter laneEna is for one lane."""
		for i in range(4):
			if (laneEna>>i)&1==1:
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_EN=0
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_DATA_SOURCE=0
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_CLOCK_EN=0
	#serdesSendData
	
	@funcDecorator
	def serdesPdn(self,pdn=0):
		""" "Powering down SERDES Lanes" """
		self.regs.Common.PLL_REFCLK_DIVIDER.PU_RX_AGC_MASTER=pdn
		self.regs.Common.PLL_REFCLK_DIVIDER.PU_RX_BANDGAP=pdn
		self.regs.Common.PLL_REFCLK_DIVIDER.RX_PLL_BIAS1=pdn
		self.regs.Common.RX_PLL_MULTIPLIER.PU_RX_PLL=pdn
		self.regs.Common.TX_REFCLK_SELECT.TX_PLL_BIAS4=pdn
		self.regs.Common.TX_REFCLK_SELECT.PU_RVDD_TX=pdn
		self.regs.Common.TX_REFCLK_SELECT.PU_TX_BANDGAP=pdn
		self.regs.Common.TX_PLL_MULTIPLIER.PU_TX_PLL=pdn
	#serdesPdn
	
	@funcDecorator
	def enableTxPllTp(self,en=1):
		self.regs.Common.TEST_MUX_B_CONTROL.TEST_MUX_SEL_B=0
		self.regs.Common.TX_POWER_UP_MASTER.ENTTSTPGROUP_TX=en
		self.regs.Common.TX_POWER_UP_MASTER.TEST_MODE_TX=2
		self.regs.Common.TX_POWER_UP_MASTER.VTSTPGROUP_TX=13
	#enableTxPllTp
	
	@funcDecorator
	def enableRxPllTp(self,en=1):
		self.regs.Common.TX_POWER_UP_MASTER.ENTTSTPGROUP_TX=0
		self.regs.Common.TEST_MUX_B_CONTROL.TEST_MUX_SEL_B=0b010011011
		#val=self.serdesRead(0x84f7)
		#val=(val&0x7f)+(0b010011011)<<7
		#self.serdesWrite(0x84f7,)
	#enableRxPllTp
	
	@funcDecorator
	def getSerdesEye(self,fileName=ASTERIX_DIR+DEVICES_DIR+r"\eyeDiagram.txt"):
		self.regs.Common.FIRMWARE_WATCHDOG_TIMER._FIRMWARE_WATCHDOG.getValue()
		REG_CMD = 0x9815
		REG_CMD_DETAIL = 0x9816
		
		#chip = Chip()
		
		def parse_response():
			while True:
				response = self.serdesRead(REG_CMD)
				if response>>12 == 0:
					break;
			status = (response>>8) & 0xf
			data = response & 0xff
			if status == 0x3:
				if data == 0x02:
					print 'Invalid input'
				elif data == 0x03:
					print 'Phy not ready'
				elif data == 0x05:
					print 'Eye monitor going on'
				elif data == 0x06:
					print 'Eye monitor cancelled'
				elif data == 0x07:
					print 'Eye monitor not started'
				else:
					print hex(data)
			return status, data
		
		def em_start(lane_num, ber_exp, mode):
			command = 0x1000 | (lane_num&0xF) | ((ber_exp&0xF)<<4)
			detail = mode
			self.serdesWrite(REG_CMD_DETAIL, detail)
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x0:
				print 'Eye monitor starts...'
		
		def em_report_progress():
			command = 0x2000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x1:
				return data
			return None
		
		def em_read():
			ber=numpy.zeros((95, 33))
			for phase in range(-16,17):
				pindex = phase+16
				for margin in range(-47, 48, 16):
					self.serdesWrite(REG_CMD_DETAIL, margin&0xffff)
					self.serdesWrite(REG_CMD, (phase&0xFF) | 0x3000)
					status, data = parse_response()
					if status == 0x2:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = self.serdesRead(0x9f00+i)
					else:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = 0
			
			#log_file = open("em_data.txt", "w")
			#for margin in range(95):
			#	for phase in range(33):
			#		value = ber[margin, phase]
			#		log_file.write('%.0f ' % value)
			#	log_file.write('\n')
			#log_file.close()
			return ber
		
		def em_draw(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			f=matplotlib.pyplot.figure()
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			c=matplotlib.pyplot.pcolor(x, y, ber/-16, cmap='jet', vmin=-8, vmax=0, figure=f)
			cax=f.add_axes([0.9, 0.1, 0.02, 0.8])
			f.colorbar(mappable=c, cax=cax)
			matplotlib.pyplot.show()
		
		def em_print(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			for margin in range(95):
				if margin%10 == 0:
					print '%4d | ' % y[margin],
				else:
					print '	 | ',
				for phase in range(33):
					value = ber[margin, phase]
					magnitude = int(value/16)
					if magnitude == 15:
						sys.stdout.write(' '*2)
					else:
						sys.stdout.write(str(magnitude)+' '*1)
				print ''
			print '%4d | ' % y[-1]
			sys.stdout.write(' '*5 + '----'*len(x)+'\n')
			sys.stdout.write(' '*5)
			for idx, x_point in enumerate(x):
				if idx%5 == 0:
					if x_point >= 0:
						if idx == 30:
							sys.stdout.write(' '*4)
						else:
							sys.stdout.write(('%.2f' % x_point) + ' '*6)
					else:
						sys.stdout.write(('%.2f' % x_point) + ' '*5)
			print '%.2f' % x[-1]
			
		def em_cancel():
			command = 0x4000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
		
		#em_cancel()
		
		em_start(0, 7, 1) #lane0, ber_exp 10^7, mode 1
		old_progress = 0
		while True:
			progress = em_report_progress()
			if progress == None: break
			if old_progress != progress:
				print '%d%%' % progress
			if progress == 100: break
			old_progress = progress
		ber = em_read()
		em_print(ber)
		em_draw(ber)
	#getSerdesEye

	@funcDecorator
	def getSerdesEye25Gbps(self,instance):
		self.regs.Common.FIRMWARE_WATCHDOG_TIMER._FIRMWARE_WATCHDOG.getValue()
		REG_CMD = 0x9815
		REG_CMD_DETAIL = 0x9816
		
		#chip = Chip()
		
		def parse_response():
			count=0
			while True:
				response = self.serdesRead(REG_CMD)
				if response>>12 == 0:
					break;
				if count>500:
					error("Error in parse_response. Invalid read. Check if firmware loaded.")
			status = (response>>8) & 0xf
			data = response & 0xff
			if status == 0x3:
				if data == 0x02:
					info('Invalid input')
				elif data == 0x03:
					info('Phy not ready')
				elif data == 0x05:
					info('Eye monitor going on')
				elif data == 0x06:
					info('Eye monitor cancelled')
				elif data == 0x07:
					info('Eye monitor not started')
				else:
					info(hex(data))
			return status, data
		
		def em_start(lane_num, ber_exp, mode):
			command = 0x1000 | (lane_num&0xF) | ((ber_exp&0xF)<<4)
			detail = mode
			self.serdesWrite(REG_CMD_DETAIL, detail)
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x0:
				info('Eye monitor starts...')
		
		def em_report_progress():
			command = 0x2000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x1:
				return data
			return None
		
		def em_read():
			ber=numpy.zeros((95, 33))
			for phase in range(-16,17):
				pindex = phase+16
				for margin in range(-47, 48, 16):
					self.serdesWrite(REG_CMD_DETAIL, margin&0xffff)
					self.serdesWrite(REG_CMD, (phase&0xFF) | 0x3000)
					status, data = parse_response()
					if status == 0x2:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = self.serdesRead(0x9f00+i)
					else:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = 0
			
			#log_file = open("em_data.txt", "w")
			#for margin in range(95):
			#	for phase in range(33):
			#		value = ber[margin, phase]
			#		log_file.write('%.0f ' % value)
			#	log_file.write('\n')
			#log_file.close()
			return ber
		
		def em_draw(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			f=matplotlib.pyplot.figure()
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			c=matplotlib.pyplot.pcolor(x, y, ber/-16, cmap='jet', vmin=-8, vmax=0, figure=f)
			cax=f.add_axes([0.9, 0.1, 0.02, 0.8])
			f.colorbar(mappable=c, cax=cax)
			matplotlib.pyplot.show()
		
		def em_print(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			for margin in range(95):
				if margin%10 == 0:
					print '%4d | ' % y[margin],
				else:
					print '	 | ',
				for phase in range(33):
					value = ber[margin, phase]
					magnitude = int(value/16)
					if magnitude == 15:
						sys.stdout.write(' '*2)
					else:
						sys.stdout.write(str(magnitude)+' '*1)
				print ''
			print '%4d | ' % y[-1]
			sys.stdout.write(' '*5 + '----'*len(x)+'\n')
			sys.stdout.write(' '*5)
			for idx, x_point in enumerate(x):
				if idx%5 == 0:
					if x_point >= 0:
						if idx == 30:
							sys.stdout.write(' '*4)
						else:
							sys.stdout.write(('%.2f' % x_point) + ' '*6)
					else:
						sys.stdout.write(('%.2f' % x_point) + ' '*5)
			print '%.2f' % x[-1]
			
		def em_cancel():
			command = 0x4000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
		
		#em_cancel()

		em_start(1, 7, 1) #lane0, ber_exp 10^7, mode 1
		old_progress = 0
		while True:
			progress = em_report_progress()
			if progress == None: break
			if old_progress != progress:
				info('%d%%' % progress)
			if progress == 100: break
			old_progress = progress
		ber = em_read()
		em_print(ber)
		em_draw(ber)	
	#getSerdesEye25Gbps
	
	
	@funcDecorator
	def postLinkupSerdesWrites(self):
		""" "Writing Post Link up SERDES writes" "Done writing Post Link up SERDES writes" """
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=self.topno+1
		#temp=self.deviceRefs.device.rawWriteLogEn
		#self.deviceRefs.device.rawWriteLogEn=0
		for i in range(4):
			if(self.systemStatus.serdesConfig[self.topno]['serdesRxVco']>24000):	
				self.serdesWrite(0x80fd+(0x100*i),0x026E)
			else:
				self.serdesWrite(0x80fd+(0x100*i),0x0246)		
			#	self.regs.laneRegisters[i].RX_INTPOLATOR_CONTROL._VREF_DELAY_DAC_BOT.getValue()
		#self.deviceRefs.device.rawWriteLogEn=temp
		#for i in range(4):
		#	val=self.serdesRead(0x80fd+(0x100*i))
		#	val=val&0xbfff
		#	self.serdesWrite(0x80fd+(0x100*i),val)#0x0246)
	#postLinkupSerdesWrites

	
	@funcDecorator
	def postFwDownloadSerdesWrites(self):
		self.serdesWrite(0x9816,5)
		self.serdesWrite(0x9812,8)
		self.serdesWrite(0x9815,0xe020)
		self.delay(0.01)
		
		self.serdesWrite(0x9816,2)
		self.serdesWrite(0x9812,80)
		self.serdesWrite(0x9815,0xe020)
		self.delay(0.01)
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x777
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x000
		self.delay(5)
	#postFwDownloadSerdesWrites

	@funcDecorator
	def reloadFirmware(self):
		topno=self.topno
		self.serdesWrite(0x9814,0xFFF0)
		self.serdesWrite(0x980D,0x0AAA)
		self.serdesWrite(0x980D,0x0000)
		self.serdesWrite(0x9803,0x0000)
	#reloadFirmware
	
	
	@funcDecorator
	def configSerdesCommon(self):
		topno=self.topno
		if(self.systemParams.serdesManualCTLEEn==True):
			self.serdesWrite(0x9811,0x000F)
		else:
			pass
		for laneNo in range(4):
			data_84f8=0x9240
			data_84f9=0xea80
			data_84f1=0xf000
			
			jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
			serlane=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]
			if(self.systemStatus.serdesConfig[self.topno]['serdesRxLaneEna'][laneNo]==False):
				data_84f8&=(~(0x8000>>(serlane*3)))
				data_84f9&=(~(0x2000>>(serlane*2)))
			if(self.systemStatus.serdesConfig[self.topno]['serdesTxLaneEna'][laneNo]==False):
				data_84f1&=(~(0x8000>>(serlane)))

		#if self.systemStatus.serdesConfig[self.topno]['serdesRxLaneEna'][laneNo]==False:
			#swithcing of Rx lane interpolator
		#	data=0
		self.serdesWrite(0x84F8,data_84f8)
			#switching of Rx lane ADC
		self.serdesWrite(0x84F9,data_84f9)
			#switching of Rx ADC by lane 
		#if self.systemStatus.serdesConfig[self.topno]['serdesTxLaneEna'][laneNo]==False:
			#switching of Tx lane Master 
		self.serdesWrite(0x84F1,data_84f1)
		self.serdesWrite(0x84da,0x4747)
		if self.systemStatus.serdesConfig[self.topno]['serdesTxPllOn']==True or self.systemStatus.serdesConfig[self.topno]['serdesRxPllOn']==True:
			self.serdesWrite(0x84ff,0xFDB0)
			self.serdesWrite(0x84f6,0x1DC0)
		else:
			self.serdesWrite(0x84ff,0xEDB0)
			self.serdesWrite(0x84f6,0x0DC0)
		self.serdesWrite(0x84F3,0x5226+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[self.topno]['serdesTxVcoRange'])>>3)<<4))
		self.serdesWrite(0x84F2,0x6EB6)
		self.serdesWrite(0x84EF,0xA828)
		if(self.systemStatus.serdesConfig[self.topno]['serdesTxVco']>32000):	
			value=0x0
		elif(self.systemStatus.serdesConfig[self.topno]['serdesTxVco']<20000):	
			value=0xE
		else:
			value=0x8
		if self.systemStatus.serdesConfig[self.topno]['serdesTxPllOn']==True:
			self.serdesWrite(0x84F5,((self.systemStatus.serdesConfig[self.topno]['serdesTxPllN'])<<8)+0x90+value)
		else:
			self.serdesWrite(0x84F5,((self.systemStatus.serdesConfig[self.topno]['serdesTxPllN'])<<8)+0x10+value)
			
		self.serdesWrite(0x84F4,0x1244+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[self.topno]['serdesTxVcoRange'])&0x7)<<13))

		if(self.systemStatus.serdesConfig[self.topno]['serdesRxVco']>32000):	
			value=0x0
		elif(self.systemStatus.serdesConfig[self.topno]['serdesRxVco']<20000):	
			value=0xE
		else:
			value=0x8
		if self.systemStatus.serdesConfig[self.topno]['serdesRxPllOn']==True:
			self.serdesWrite(0x84FE,((self.systemStatus.serdesConfig[self.topno]['serdesRxPllN'])<<8)+0x90+value)
		else:
			self.serdesWrite(0x84FE,((self.systemStatus.serdesConfig[self.topno]['serdesRxPllN'])<<8)+0x10+value)

		self.serdesWrite(0x84FD,0x1248+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[self.topno]['serdesRxVcoRange'])&0x7)<<13))
		data=0x4A44+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[self.topno]['serdesRxVcoRange'])>>3)<<1)
		if self.systemStatus.serdesConfig[self.topno]['serdesRxVcoRange'][0]<20:
			data=data|0x20
		self.serdesWrite(0x84FC,data)
		self.serdesWrite(0x84FB,0x79B6)#<INTERNAL>6db6 low temp
		self.serdesWrite(0x84EC,0x6C06)
	#configSerdesCommon
	
	@funcDecorator
	def configSerdesLane(self,laneNo):
		jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
		offset=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]*0x100
		serlane=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]
		
		self.serdesWrite(0x8000+offset, 0x106b)
		self.serdesWrite(0x8001+offset, 0x6480)
		self.serdesWrite(0x8002+offset, 0x6200)
		self.serdesWrite(0x8003+offset, 0x7b33)
		self.serdesWrite(0x8004+offset, 0x700a)
		self.serdesWrite(0x8005+offset, 0xbd68)
		self.serdesWrite(0x8006+offset, 0x762d)
		self.serdesWrite(0x8007+offset, 0x66ab)
		self.serdesWrite(0x8008+offset, 0xd008)
		self.serdesWrite(0x8009+offset, 0x0018)
		self.serdesWrite(0x800a+offset, 0x662c)
		self.serdesWrite(0x800b+offset, 0x3d15)
		self.serdesWrite(0x800c+offset, 0x0080)
		self.serdesWrite(0x800d+offset, 0x0002)
		self.serdesWrite(0x800e+offset, 0x3400)
		self.serdesWrite(0x800f+offset, 0x0000)
		self.serdesWrite(0x8010+offset, 0x101a)
		self.serdesWrite(0x801C+offset, 0x0340)
		self.serdesWrite(0x801D+offset,(self.systemParams.serdesManualCTLE[laneNo+(self.topno*4)]<<4)|self.systemParams.serdesManualCTLEEn<<7)
		self.serdesWrite(0x801e+offset, 0x0000)
		if(self.systemStatus.serdesConfig[self.topno]['subRateDivSerdesRx'][laneNo]<2):
			self.serdesWrite(0x801F+offset, 0x0080)
		else:
			self.serdesWrite(0x801F+offset, 0x0000)
	
		self.serdesWrite(0x803b+offset, 0x0000)
		self.serdesWrite(0x803c+offset, 0x0000)
		self.serdesWrite(0x803d+offset, 0x0000)
		self.serdesWrite(0x803e+offset, 0x0000)
		self.serdesWrite(0x8041+offset, 0x9fdf)
		self.serdesWrite(0x8042+offset, 0xb3c0+(self.systemParams.serdesRxLanePolarity[(self.topno*4)+laneNo]))
		self.serdesWrite(0x8047+offset, 0x24A2)
		self.serdesWrite(0x8048+offset, 0xCC34)
		self.serdesWrite(0x8049+offset, 0xe3d7)
		self.serdesWrite(0x804A+offset, 0x7460+(jesdConstants.serdesSupportedSubRateDivs.index(self.systemStatus.serdesConfig[self.topno]['subRateDivSerdesRx'][laneNo])<<7))
		self.serdesWrite(0x804B+offset, 0x06db)
		self.serdesWrite(0x80A0+offset, 0x0300+(jesdConstants.serdesSupportedSubRateDivs.index(self.systemStatus.serdesConfig[self.topno]['subRateDivSerdesTx'][laneNo])<<4)+(not self.systemParams.serdesTxLanePolarity[(self.topno*4)+laneNo]))
		self.serdesWrite(0x80f3+offset, 0x0080)
		self.serdesWrite(0x80F4+offset, 0xfc00)
		if(self.systemStatus.serdesConfig[self.topno]['serdesTxLaneEna'][laneNo]==False):
			self.serdesWrite(0x80F5+offset, 0x1ffe)
		else:
			self.serdesWrite(0x80F5+offset, 0x9ffe)
		pre=self.systemParams.serdesTxPreCursor[(self.topno*4)+laneNo]
		post=self.systemParams.serdesTxPostCursor[(self.topno*4)+laneNo]
		main=self.systemParams.serdesTxMainCursor[(self.topno*4)+laneNo]
		self.serdesWrite(0x80F6+offset, 0x00+(post<<11)+(pre<<8)+(main<<5))

		self.serdesWrite(0x80f7+offset, 0x1000)
		self.serdesWrite(0x80F8+offset, 0x6864)
		self.serdesWrite(0x80f9+offset, 0x9230)
		self.serdesWrite(0x80fa+offset, 0x0000)
		if(self.systemStatus.serdesConfig[self.topno]['serdesRxLaneEna'][laneNo]==True):
			self.serdesWrite(0x80fb+offset, 0x6d87)
		else:		
			self.serdesWrite(0x80fb+offset, 0x6d87)

		self.serdesWrite(0x80fc+offset, 0x6db6)
		if(self.systemStatus.serdesConfig[self.topno]['serdesRxVco']>26000):	
			self.serdesWrite(0x80fd+offset, 0x426E)
		else:
			self.serdesWrite(0x80fd+offset, 0x4246)
			
		if(self.systemStatus.serdesConfig[self.topno]['serdesRxLaneEna'][laneNo]==True):
			self.serdesWrite(0x80FE+offset, 0x627c)
			self.serdesWrite(0x80FF+offset, 0x88c8)
		else:		
			self.serdesWrite(0x80FE+offset, 0x627c)
			self.serdesWrite(0x80FF+offset, 0x88c8)
	#configSerdeslanes

	@funcDecorator
	def serdesSetCursor(self,laneNo,pre,post,main):
		jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
		offset=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]*0x100
		value=0XC000+(post<<11)+(pre<<8)+(main<<5)
		self.serdesWrite(0x80F6+offset,value)


	@funcDecorator
	def serdesGetWatchdogTimer(self):
		log("The value of the watch dog timer is : "+str(self.serdesRead(0x9810)))


	@funcDecorator
	def serdesLogicReset(self):
		self.serdesWrite(0x980D,0x0777)
		self.serdesWrite(0x980D,0x0000)
		self.dealy(0.1)


	@funcDecorator
	def serdesAllReset(self):

		self.serdesWrite(0x980D,0x888)
		self.serdesWrite(0x980D,0x000)
		self.delay(0.01)


	@funcDecorator
	def serdesDomainReset(self,mode):
		"""Does DOMAIN_RESET for the follwoing modes 
		   Mode 0: LOGIC_RESET 
		   Mode 1: ALL_RESET 
		   Mode 2: REGISTER_RESET 
		   Mode 3: CPU_RESET 
		   """
		values=[0x777,0x888,0x999,0xAAA]
		self.serdesWrite(0x980D,values[mode])
		self.serdesWrite(0x980D,0x000)
		self.delay(0.01)

	@funcDecorator
	def serdeslaneReset(self,laneNo):
		jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
		offset=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]*0x100 
		self.serdesWrite(0x8000+offset,0x906b)
		self.serdesWrite(0x8000+offset,0x106b)
		self.delay(0.01)

	@funcDecorator
	def serdesPollAdaptation(self):
		value=self.serdesRead(0x980f)
		result=(value&0x000F)
		log(bin(result))
		lane=0
		jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
		for offset in jesdToSerdesLaneMapping[self.topno*4:(self.topno+1)*4]:
			if self.systemStatus.serdesConfig[self.topno]['serdesRxLaneEna'][lane]==True:
				if((result>>offset)&0x1==1):
					log("SRX"+str(lane+1)+"Adaptation Complete")
				else:
					log("SRX"+str(lane+1)+"Adaptation Not Complete")
				lane+=1

	@funcDecorator
	def serdesPllCalibDone(self):
		
		if (self.systemStatus.serdesConfig[self.topno]['serdesTxPllOn']==True or self.systemStatus.serdesConfig[self.topno]['serdesTxPllOn']==True):
			if((self.serdesRead(0x84DA)&0x8000)>>15)==1:
				log("Serdes Pll Caliberation is Done ")
			else:
				log("Serdes Pll Caliberation is NOT Done ")
		else:
			log("Serdes Tx Pll are turned on :  " +str(self.systemStatus.serdesConfig[self.topno]['serdesTxPllOn']))
			log("Serdes Rx Pll are turned on :  " +str(self.systemStatus.serdesConfig[self.topno]['serdesRxPllOn']))

	@funcDecorator
	def serdesPdnTxLanes(self,laneNo):
		"""Powers down Tx Lanes <INTERNAL> """
		jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
		offset=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]*0x100
		serlane=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]
		#switching of Tx lane Master 
		self.serdesWrite(0x84F1,self.serdesRead(0x84F1)|(~(0x8000>>(serlane))))
		#switching Tx enable by lane 
		self.serdesWrite(0x80F5+offset,self.serdesRead(0x80F5+(serlane<<8))|(0x7fff))


	@funcDecorator
	def serdesPdnRxLanes(self,laneNo):
		"""Powers Down Rx lanes <INTERNAL> """
		jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
		offset=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]*0x100
		serlane=jesdToSerdesLaneMapping[(self.topno*4)+laneNo]
		#swithcing of Rx lane interpolator
		self.serdesWrite(0x84F8,self.serdesRead(0x84F8)&(~(0x8000>>(serlane*3))))
		#switching of Rx lane ADC
		self.serdesWrite(0x84F9,self.serdesRead(0x84F9)&(~(0x2000>>(serlane*2))))
		#switching of Rx ADC by lane 
		self.serdesWrite(0x80FB+offset,self.serdesRead(0x80FB+(serlane<<8))&((0xfffc)))
		#switching of Rx Interpolator by lane 
		self.serdesWrite(0x80FE+offset,self.serdesRead(0x80FE+(serlane<<8))&(0xfffc))
		#switching of Rx AGC by lane 
		self.serdesWrite(0x80FF+offset,self.serdesRead(0x80FF+(serlane<<8))&(0x7fff))
		
################################################# please verify the above. 

	
#serdesLib
