from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class rxAnaABLib(projectBaseClass):
	"""Contains RX ANA AB specific functions. self.regs=device.RX.ANA_AB.ANA_AB """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs.ANA_AB
		self.topno=topno
		#__init__
		
		
		
		#rxAnaABLib
