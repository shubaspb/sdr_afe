from HSCDevices import *
from mConnect import *
import globalDefs as Globals
import os
class LMK(Device):
	#ADCRes = Object(typ=Integer,label="ADC Resolution",default=13)
	rawWriteLogEn=0
	rawWriteLogsFile=r"D:/backup/rawWriteLogs1.txt"
	commentForWrite=""
	rewriteFile=False

	def rawWriteLog(self,msg=''):
		rawWriteLogsFile=self.rawWriteLogsFile
		msg=msg.replace("CREDO","SERDES")
		testerLogsFile=self.rawWriteLogsFile.replace(".txt","Tester.txt")
		if (not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')])) and (not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind('\\')])):
			self.rawWriteLogsFile=Globals.ASTERIX_DIR+"test.txt"
			error(r"Path "+str(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')])+" doesn't exist. Writing into file: "+str(self.rawWriteLogsFile))
			rawWriteLogsFile=self.rawWriteLogsFile
		if self.rawWriteLogEn:
			printNewSection=False
			if not os.path.exists(rawWriteLogsFile) or self.rewriteFile==True:
				text_file = open(rawWriteLogsFile, "w")
				testerLog = open(testerLogsFile, "w")
				self.rewriteFile=False
				printNewSection=True
			else:
				text_file = open(rawWriteLogsFile, "r")
				for line in reversed(text_file.readlines()):
					if not ((line.strip()[0:2].lower() == "0x") or (line.strip() == "LMK04828")):
						printNewSection=True
					elif line.strip() == "LMK04828":
						break
				text_file.close()
				text_file = open(rawWriteLogsFile, "a")
				testerLog = open(testerLogsFile, "a")
			if printNewSection:		
				text_file.write('LMK04828\n')
			msg=msg+self.commentForWrite
			reMatch=re.match("(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)(.*)",msg.replace('//',''))
			if reMatch:
				if reMatch.group(3).strip()=='':
					testerLog.write("WriteSPI_LMK("+reMatch.group(1)+", "+reMatch.group(2)+");\n")
				else:
					testerLog.write("WriteSPI_LMK("+reMatch.group(1)+", "+reMatch.group(2)+");\t{"+reMatch.group(3).strip()+"}\n")
			else:
				testerLog.write("{"+msg+"}"+'\n')
			testerLog.close()
			text_file.write(msg+"\n")
			self.commentForWrite=""
			text_file.close()
	#rawWriteLog
	
	def writeReg(self,addr,writeval):
		super(LMK,self).writeReg(addr,writeval)	
		if self.rawWriteLogEn:
			self.rawWriteLog(str("0x{:04x}".format(addr).lower().replace('l',''))+"    "+str("0x{:02x}".format(writeval).lower().replace('l','')))
	#writeReg

	def writeProperty(self,prop,value,soft=False):
		if prop.rawRegIndex is None: return
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal = (regVal & r.zeros()) | (r.shift(value) & r.ones())
			if True:#regVal != self._rawRegisters[(prop.rawRegIndex,r.address)]:
				self._rawRegisters[(prop.rawRegIndex,r.address)]=regVal
				if not soft:
					if str(prop.name)+"."+str(prop.parent.parent.name)+"="+str(hex(value).lower().replace('l','')) not in self.commentForWrite:
						self.commentForWrite+="\t// " +str(prop.name)+"."+str(prop.parent.parent.name)+"="+str(hex(value).lower().replace('l',''))
						if len(prop.valueList)>value:
							self.commentForWrite=self.commentForWrite+"(Meaning: "+str(prop.valueList[value].desc)+");"
					self.writeReg(r.address,regVal)
			value = value >> r.size()
			
