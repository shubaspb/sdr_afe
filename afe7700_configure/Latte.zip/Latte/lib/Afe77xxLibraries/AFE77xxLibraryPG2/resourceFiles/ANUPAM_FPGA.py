from mDevice import *
import time
import globalDefs as Globals
import numpy as np
import math
import copy,os,re#,xlwt

class ANUPAM_FPGA(Device):
	refreshAlarms = Object(typ = Trigger, label = "Refresh alarms",function='updateAlarms')
	delay_time=0.5
	myRX_L = 4	
	myRX_M = 4	
	myRX_F = 3		
	logEn=False
	myconv_per_Lane = 1	
	
	byte_swap = 0
	mult_fact = 1
	frame_phase	= 0
	
	lane0_shift = 0
	lane1_shift = 0
	lane2_shift = 0
	lane3_shift = 0

	dropAlternateFrames=0
	sampleConverterOrderReverse=0
	dropAlternateSamplesPerConverter=0
	LMFSHd="44210"
	converterOrder=(0,1)
	reverseFourSamplesInLane=0
	read16bit=1
	#captureTx=0
	printCommentsForDebug=0
	oldCaptureFunc=True
	
	rawWriteLogEn=0
	rawWriteLogsFile=r"C:/rawWriteLogs1.txt"
	commentForWrite=""
	rewriteFile=False
	
	previousDataInput=[]
	softCapture=False
	converterWiseData=[]
	def rawWriteLog(self,msg=''):
		rawWriteLogsFile=self.rawWriteLogsFile
		testerLogsFile=self.rawWriteLogsFile.replace(".txt","Tester.txt")
		msg=msg.replace("CREDO","SERDES")
		if not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')]) and not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind('\\')]):
			self.rawWriteLogsFile=Globals.ASTERIX_DIR+"test.txt"
			error(r"Path "+str(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')])+" doesn't exist. Writing into file: "+str(self.rawWriteLogsFile))
			rawWriteLogsFile=self.rawWriteLogsFile
		if self.rawWriteLogEn:
			printNewSection=False
			if not os.path.exists(rawWriteLogsFile) or self.rewriteFile==True:
				text_file = open(rawWriteLogsFile, "w")
				testerLog = open(testerLogsFile, "w")
				self.rewriteFile=False
				printNewSection=True
			else:
				text_file = open(rawWriteLogsFile, "r")
				for line in reversed(text_file.readlines()):
					if not ((line.strip()[0:2].lower() == "0x") or (line.strip() == "FPGA_WRITE")):
						printNewSection=True
					elif line.strip() == "FPGA_WRITE":
						break
				text_file.close()
				text_file = open(rawWriteLogsFile, "a")
				testerLog = open(testerLogsFile, "a")
			if printNewSection:		
				text_file.write('FPGA_WRITE\n')
			
			msg=msg+self.commentForWrite
			reMatch=re.match("(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)(.*)",msg.replace('//',''))
			if reMatch:
				if reMatch.group(3).strip()=='':
					testerLog.write("WriteSPI_FPGA("+reMatch.group(1)+", "+reMatch.group(2)+");\n")
				else:
					testerLog.write("WriteSPI_FPGA("+reMatch.group(1)+", "+reMatch.group(2)+");\t{"+reMatch.group(3).strip()+"}\n")
			else:
				testerLog.write("{"+msg+"}"+'\n')
			testerLog.close()
			text_file.write(msg+"\n")
			self.commentForWrite=""
			text_file.close()
	#rawWriteLog
	
	def superWriteReg(self,addr,writeval):
		if self.regProgDevice:
			super(ANUPAM_FPGA,self).writeReg(addr,writeval)	
		if self.rawWriteLogEn:
			self.rawWriteLog(str("0x{:04x}".format(addr).lower().replace('l',''))+"    "+str("0x{:02x}".format(writeval).lower().replace('l','')))
	#superWriteReg
	
	def writeReg(self,addr,val):
		#log(addr)		
		
		masterBase = 0
		masterReg = 73
		
		TXA_Base = 500
		TXB_Base = 525
		TXReg = 15
		
		TXA_ILA_Base = 516				
		TXB_ILA_Base = 541				
		TX_ILA_Reg = 5
		
		RXA_Base = 600
		RXB_Base = 614
		RXReg = 14		
		
		TXA_LMFS_Reg = 700
		RXA_LMFS_Reg = 701
		TXB_LMFS_Reg = 702
		RXB_LMFS_Reg = 703
		Capture_Reg = 704		
		pack_Reg = 705		
		samp_drop_Reg = 706
		mode24_Reg = 707
		
		if addr >= masterBase and  addr< masterBase+masterReg:
			if addr >=37 and addr <=40:
				gain1 = val&0x3f
				gain2 = (val>>6)&0x3f
				gain1 = int('{:06b}'.format(gain1)[::-1], 2)
				gain2=int('{:06b}'.format(gain2)[::-1], 2)
				mode = (val>>16)%2
				p1 = self.parityOf(gain1)
				p2 = self.parityOf(gain2)

				d1 = (1<<7)|(gain1<<1)|p1
				d2 = (gain2<<2)|(p2<<1)

				if (mode):
					writeval = ((val>>16)<<16)+(d1<<8) +0x80				
					#log(writeval)
					self.superWriteReg(addr,writeval)	
				else :
					writeval = ((val>>16)<<16)+(d1<<8) +d2+1
					#log(writeval)
					self.superWriteReg(addr,writeval)	
			else :
				self.superWriteReg(addr,val)		
			
		elif addr >= TXA_Base and  addr< TXA_Base+TXReg:
		
			#log('TX_2T2RA')			
			addr1 = (addr - TXA_Base)*4;			
			self.superWriteReg(13,val)
			time.sleep(self.delay_time)
			addr2 = addr1 + 0x80000000;		
			self.superWriteReg(14,addr1)	
			time.sleep(self.delay_time)
			self.superWriteReg(14,addr2)	
			time.sleep(self.delay_time)
			self.AXI_done_chk(0)
			
		elif addr >= TXA_ILA_Base and  addr< TXA_ILA_Base+TX_ILA_Reg:
		
			#log('TX_2T2RA_ILA')			
			addr1 = (addr - TXA_ILA_Base)*4 + 0x80C;	
			self.superWriteReg(13,val)
			time.sleep(self.delay_time)
			addr2 = addr1 + 0x80000000		
			self.superWriteReg(14,addr1)
			time.sleep(self.delay_time)
			self.superWriteReg(14,addr2)
			time.sleep(self.delay_time)
			self.AXI_done_chk(0)
			
		elif addr >= RXA_Base and  addr< RXA_Base+RXReg:
		
			#log('RX_2T2RA')			
			addr1 = (addr - RXA_Base)*4;	
			self.superWriteReg(13,val)
			time.sleep(self.delay_time)
			addr2 = addr1 + 0x10000000;		
			addr3 = addr2 + 0x80000000;		
			self.superWriteReg(14,addr2)
			time.sleep(self.delay_time)
			self.superWriteReg(14,addr3)
			time.sleep(self.delay_time)
			self.AXI_done_chk(0)
			
		elif addr >= TXB_Base and  addr< TXB_Base+TXReg:
		
			#log('TX_2T2RB')			
			addr1 = (addr - TXB_Base)*4;			
			self.superWriteReg(29,val)
			time.sleep(self.delay_time)
			addr2 = addr1 + 0x80000000;		
			self.superWriteReg(30,addr1)
			time.sleep(self.delay_time)
			self.superWriteReg(30,addr2)
			time.sleep(self.delay_time)
			self.AXI_done_chk(1)
			
		elif addr >= TXB_ILA_Base and  addr< TXB_ILA_Base+TX_ILA_Reg:
		
			#log('TX_2T2RB_ILA')			
			addr1 = (addr - TXB_ILA_Base)*4 + 0x80C;	
			self.superWriteReg(29,val)
			time.sleep(self.delay_time)
			addr2 = addr1 + 0x80000000;		
			self.superWriteReg(30,addr1)
			time.sleep(self.delay_time)
			self.superWriteReg(30,addr2)
			time.sleep(self.delay_time)
			self.AXI_done_chk(1)
			
		elif addr >= RXB_Base and  addr< RXB_Base+RXReg:
		
			#log('RX_2T2RB')			
			addr1 = (addr - RXB_Base)*4;	
			self.superWriteReg(29,val)
			time.sleep(self.delay_time)
			addr2 = addr1 + 0x10000000;		
			addr3 = addr2 + 0x80000000;		
			self.superWriteReg(30,addr2)
			time.sleep(self.delay_time)
			self.superWriteReg(30,addr3)
			time.sleep(self.delay_time)
			self.AXI_done_chk(1)
		
		elif addr == TXA_LMFS_Reg :
			#log('TX_2T2RA_LMFS')
			if val == 0x0: #4-4-2-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3 
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0001 #F=2-1=1
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x1: #2-4-4-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b0011 #L=2 First Two Lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3 
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0003 #F=4-1=3
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0	
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x2: #2-4-3-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b0011 #L=2 First Two Lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0	
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x3: #1-4-6-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b0001 #L=2 First Two Lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0005 #F=6-1=5
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0	
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x4: #8-4-1-1-1
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=8 All lanes of 2 2T2Rs [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0000 #F=1-1=0
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RA.ILA.HD						= 0x0001 #HD = 1				
				
			elif val == 0x5: #4-4-3-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x6: #4-4-3-2-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RA.ILA.S						= 0x0001 #S=2-1=1
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x7: #4-8-4-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0007 #M=8-1=7  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0003 #F=4-1=3
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x8: #4-8-3-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0007 #M=8-1=7  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x9: #8-8-2-1-0
			
				self.head.page.TX_2T2RA.Link.Lanes_in_use		  = 0b1111 #L=8 All lanes of 2 2T2Rs [Thermometric]
				self.head.page.TX_2T2RA.ILA.M						= 0x0007 #M=8-1=7  
				self.head.page.TX_2T2RA.Link.F_Octets_per_Frame = 0x0001 #F=2-1=1
				self.head.page.TX_2T2RA.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RA.ILA.HD						= 0x0000 #HD = 0
				
			self.head.page.TX_2T2RA.Reset.Reset = 1
			self.head.page.TX_2T2RA.Reset.Reset = 0
			
		elif addr == TXB_LMFS_Reg :
			#log('TX_2T2RB_LMFS')
			if val == 0x0: #4-4-2-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3 
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0001 #F=2-1=1
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x1: #2-4-4-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b0011 #L=2 First Two Lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3 
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0003 #F=4-1=3
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0	
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x2: #2-4-3-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b0011 #L=2 First Two Lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0	
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x3: #1-4-6-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b0001 #L=2 First Two Lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0005 #F=6-1=5
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0	
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0				
				
			elif val == 0x4: #8-4-1-1-1
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=8 All lanes of 2 2T2Rs [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0000 #F=1-1=0
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RB.ILA.HD						= 0x0001 #HD = 1				
				
			elif val == 0x5: #4-4-3-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x6: #4-4-3-2-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0003 #M=4-1=3  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RB.ILA.S						= 0x0001 #S=2-1=1
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x7: #4-8-4-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0007 #M=8-1=7  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0003 #F=4-1=3
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x8: #4-8-3-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=4 All lanes [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0007 #M=8-1=7  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0002 #F=3-1=2
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0
				
			elif val == 0x9: #8-8-2-1-0
			
				self.head.page.TX_2T2RB.Link.Lanes_in_use		  = 0b1111 #L=8 All lanes of 2 2T2Rs [Thermometric]
				self.head.page.TX_2T2RB.ILA.M						= 0x0007 #M=8-1=7  
				self.head.page.TX_2T2RB.Link.F_Octets_per_Frame = 0x0001 #F=2-1=1
				self.head.page.TX_2T2RB.ILA.S						= 0x0000 #S=1-1=0
				self.head.page.TX_2T2RB.ILA.HD						= 0x0000 #HD = 0
				
			self.head.page.TX_2T2RB.Reset.Reset = 1
			self.head.page.TX_2T2RB.Reset.Reset = 0	
		
		elif addr == RXA_LMFS_Reg :
		
			#RX MODES			
			#log('RX_2T2RA_LMFS')
			if val == 0: #4-4-2-1-0
			
				self.myRX_L			= 4 #L=4 All lanes					
				self.myRX_M = 4
				self.myRX_F = 0x0001 #F=2-1=1
				self.head.page.Common.Final_Options.mode_24bit = 0				
				
			elif val == 1: #2-4-4-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 4
				self.myRX_F = 0x0003 #F=4-1=3
				self.head.page.Common.Final_Options.mode_24bit = 0				
				
			elif val == 2: #1-4-8-1-0
			
				self.myRX_L			= 1 #L=1 First Lane	 
				self.myRX_M = 4
				self.myRX_F = 0x0007 #F=8-1=7								
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 3: #1-4-6-1-0
			
				self.myRX_L			= 1 #L=1 First Lane	 
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5				
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 4: #2-4-6-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5					
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 5: #1-4-12-1-0
			
				self.myRX_L			= 1 #L=1 First Lane	 
				self.myRX_M = 4
				self.myRX_F = 0x000B #F=12-1=11				
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 6: #2-4-3-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 4
				self.myRX_F = 0x0002 #F=3-1=2
				self.head.page.Common.Final_Options.mode_24bit = 0				
				
			elif val == 7: #4-4-3-1-0
			
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 4
				self.myRX_F = 0x0002 #F=3-1=2
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 8: #2-8-8-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 8
				self.myRX_F = 0x0007 #F=8-1=7
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 9: #2-8-6-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 8
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 10: #4-8-6-1-0
			
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 8
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 1
			
			elif val == 11: #4-8-4-1-0
						
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 8
				self.myRX_F = 0x0003 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			#FEEDBACK self.head.page.moDES	
			
			elif val == 12: #2-2-4-2-0
						
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 2
				self.myRX_F = 0x0003 #F=4-1=3
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 13: #1-2-8-2-0
						
				self.myRX_L			= 1 #L=1 First lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0007 #F=8-1=7
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 14: #1-2-6-2-0
						
				self.myRX_L			= 1 #L=1 First lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 15: #2-2-6-2-0
						
				self.myRX_L			= 2 #L=2 First Two Lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 16: #1-2-12-2-0
									
				self.myRX_L			= 1 #L=1 First lane		
				self.myRX_M = 2
				self.myRX_F = 0x000b #F=12-1=11
				self.head.page.Common.Final_Options.mode_24bit = 1				
				
			elif val == 17: #4-2-2-2-0
									
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 2
				self.myRX_F = 0x0001 #F=2-1=1	
				self.head.page.Common.Final_Options.mode_24bit = 0
			
			elif val == 18: #2-2-3-2-0
												
				self.myRX_L			= 2 #L=2 First Two Lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0002 #F=3-1=2				
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 19: #4-2-3-2-0
												
				self.myRX_L			= 4 #L=4 All lanes			
				self.myRX_M = 2
				self.myRX_F = 0x0002 #F=3-1=2					
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 20: #2-4-8-2-0
												
				self.myRX_L			= 2 #L=2 First Two Lanes		
				self.myRX_M = 4
				self.myRX_F = 0x0007 #F=8-1=7		
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 21: #2-4-6-2-0
												
				self.myRX_L			= 2 #L=2 First Two Lanes		
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 22: #4-4-6-2-0
												
				self.myRX_L			= 4 #L=4 All lanes			
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 1
			
			elif val == 23: #4-4-4-2-0
												
				self.myRX_L			= 4 #L=4 All lanes			
				self.myRX_M = 4
				self.myRX_F = 0x0003 #F=4-1=3
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			# elif val == 24: #1-2-8-2-0
												
				# self.myRX_L		  = 1 #L=1 First lane		
				# self.myRX_M = 2
				# self.myRX_F = 0x0007 #F=8-1=1	
				# self.head.page.Common.Final_Options.mode_24bit = 0
			
			# elif val == 25: #1-2-6-2-0
												
				# self.myRX_L		  = 1 #L=1 First lane		
				# self.myRX_M = 2
				# self.myRX_F = 0x0005 #F=6-1=5
				# self.head.page.Common.Final_Options.mode_24bit = 0
				
			# elif val == 26: #2-2-4-2-0
												
				# self.myRX_L		  = 2 #L=2 First Two Lanes		
				# self.myRX_M = 2
				# self.myRX_F = 0x0003 #F=4-1=3	
				# self.head.page.Common.Final_Options.mode_24bit = 0
			#else:
				#log("None")
			
			#log('RX_2T2RA_LMFS')			
			self.head.page.RX_2T2RA.Link.Lanes_in_use		  = (2**(self.myRX_L)-1) #Thermometric			
			self.head.page.RX_2T2RA.Link.F_Octets_per_Frame = self.myRX_F 
			self.myconv_per_Lane = self.myRX_M*1.0/self.myRX_L			
			self.head.page.RX_2T2RA.Reset.Reset = 1
			self.head.page.RX_2T2RA.Reset.Reset = 0
			if self.logEn==True:
				info("LM %d %d"%(self.myRX_F,self.myRX_L))
			if self.myRX_F == 2	or self.myRX_F == 5 or self.myRX_F == 11: #3/6/12-Sample Mode
				self.head.page.Common.Final_Options.pack_mode = 1
			else:
				self.head.page.Common.Final_Options.pack_mode = 0
			
		elif addr == RXB_LMFS_Reg :
		
			#RX MODES			
			#log('RX_2T2RB_LMFS')
			if val == 0: #4-4-2-1-0
			
				self.myRX_L			= 4 #L=4 All lanes					
				self.myRX_M = 4
				self.myRX_F = 0x0001 #F=2-1=1
				self.head.page.Common.Final_Options.mode_24bit = 0				
				
			elif val == 1: #2-4-4-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 4
				self.myRX_F = 0x0003 #F=4-1=3
				self.head.page.Common.Final_Options.mode_24bit = 0				
				
			elif val == 2: #1-4-8-1-0
			
				self.myRX_L			= 1 #L=1 First Lane	 
				self.myRX_M = 4
				self.myRX_F = 0x0007 #F=8-1=7								
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 3: #1-4-6-1-0
			
				self.myRX_L			= 1 #L=1 First Lane	 
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5				
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 4: #2-4-6-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5					
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 5: #1-4-12-1-0
			
				self.myRX_L			= 1 #L=1 First Lane	 
				self.myRX_M = 4
				self.myRX_F = 0x000B #F=12-1=11				
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 6: #2-4-3-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 4
				self.myRX_F = 0x0002 #F=3-1=2
				self.head.page.Common.Final_Options.mode_24bit = 0				
				
			elif val == 7: #4-4-3-1-0
			
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 4
				self.myRX_F = 0x0002 #F=3-1=2
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 8: #2-8-8-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 8
				self.myRX_F = 0x0007 #F=8-1=7
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 9: #2-8-6-1-0
			
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 8
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 10: #4-8-6-1-0
			
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 8
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 1
			
			elif val == 11: #4-8-4-1-0
						
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 8
				self.myRX_F = 0x0003 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			#FEEDBACK self.head.page.moDES	
			
			elif val == 12: #2-2-4-2-0
						
				self.myRX_L			= 2 #L=2 First Two Lanes  
				self.myRX_M = 2
				self.myRX_F = 0x0003 #F=4-1=3
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 13: #1-2-8-2-0
						
				self.myRX_L			= 1 #L=1 First lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0007 #F=8-1=7
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 14: #1-2-6-2-0
						
				self.myRX_L			= 1 #L=1 First lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 15: #2-2-6-2-0
						
				self.myRX_L			= 2 #L=2 First Two Lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 16: #1-2-12-2-0
									
				self.myRX_L			= 1 #L=1 First lane		
				self.myRX_M = 2
				self.myRX_F = 0x000b #F=12-1=11
				self.head.page.Common.Final_Options.mode_24bit = 1				
				
			elif val == 17: #4-2-2-2-0
									
				self.myRX_L			= 4 #L=4 All lanes		
				self.myRX_M = 2
				self.myRX_F = 0x0001 #F=2-1=1	
				self.head.page.Common.Final_Options.mode_24bit = 0
			
			elif val == 18: #2-2-3-2-0
												
				self.myRX_L			= 2 #L=2 First Two Lanes	
				self.myRX_M = 2
				self.myRX_F = 0x0002 #F=3-1=2				
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 19: #4-2-3-2-0
												
				self.myRX_L			= 4 #L=4 All lanes			
				self.myRX_M = 2
				self.myRX_F = 0x0002 #F=3-1=2					
				self.head.page.Common.Final_Options.mode_24bit = 1
				
			elif val == 20: #2-4-8-2-0
												
				self.myRX_L			= 2 #L=2 First Two Lanes		
				self.myRX_M = 4
				self.myRX_F = 0x0007 #F=8-1=7		
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 21: #2-4-6-2-0
												
				self.myRX_L			= 2 #L=2 First Two Lanes		
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			elif val == 22: #4-4-6-2-0
												
				self.myRX_L			= 4 #L=4 All lanes			
				self.myRX_M = 4
				self.myRX_F = 0x0005 #F=6-1=5
				self.head.page.Common.Final_Options.mode_24bit = 1
			
			elif val == 23: #4-4-4-2-0
												
				self.myRX_L			= 4 #L=4 All lanes			
				self.myRX_M = 4
				self.myRX_F = 0x0003 #F=4-1=3
				self.head.page.Common.Final_Options.mode_24bit = 0
				
			# elif val == 24: #1-2-8-2-0
												
				# self.myRX_L		  = 1 #L=1 First lane		
				# self.myRX_M = 2
				# self.myRX_F = 0x0007 #F=8-1=1	
				# self.head.page.Common.Final_Options.mode_24bit = 0
			
			# elif val == 25: #1-2-6-2-0
												
				# self.myRX_L		  = 1 #L=1 First lane		
				# self.myRX_M = 2
				# self.myRX_F = 0x0005 #F=6-1=5
				# self.head.page.Common.Final_Options.mode_24bit = 0
				
			# elif val == 26: #2-2-4-2-0
												
				# self.myRX_L		  = 2 #L=2 First Two Lanes		
				# self.myRX_M = 2
				# self.myRX_F = 0x0003 #F=4-1=3	
				# self.head.page.Common.Final_Options.mode_24bit = 0
			#else:
				#log("None")
				
			#log('RX_2T2RB_LMFS')	
			self.head.page.RX_2T2RB.Link.Lanes_in_use		  = (2**(self.myRX_L)-1) #Thermometric			
			self.head.page.RX_2T2RB.Link.F_Octets_per_Frame = self.myRX_F 
			self.myconv_per_Lane = self.myRX_M*1.0/self.myRX_L			
			self.head.page.RX_2T2RB.Reset.Reset = 1
			self.head.page.RX_2T2RB.Reset.Reset = 0
			if self.logEn==True:
				info("LM %d %d"%(self.myRX_F,self.myRX_L))
			if self.myRX_F == 2	or self.myRX_F == 5 or self.myRX_F == 11: #3/6/12-Sample Mode
				self.head.page.Common.Final_Options.pack_mode = 1
			else:
				self.head.page.Common.Final_Options.pack_mode = 0
			
			
		elif addr == Capture_Reg:

			if val == 0: #DEF
			
				self.head.page.Common.Lanes.Lanes_in_use = 2 
				self.head.page.Common.Lanes.Lane_sel = 0				
				self.head.page.Common.Final_Options.samp_drop = 0
		
			elif val == 1: #A-I1
			
				self.head.page.Common.Lanes.Lanes_in_use = 0 
				self.head.page.Common.Lanes.Lane_sel = 0				
				self.head.page.Common.Final_Options.samp_drop = int(self.myconv_per_Lane-1)
				
			elif val == 2: #A-Q1
			
				self.head.page.Common.Lanes.Lanes_in_use = 0 
				
				if self.myconv_per_Lane == 1:
					self.head.page.Common.Lanes.Lane_sel = 1 
					self.head.page.Common.Final_Options.samp_drop = 0					
				else:
					self.head.page.Common.Lanes.Lane_sel = 0				
					self.head.page.Common.Final_Options.samp_drop = int(self.myconv_per_Lane)
					
			elif val == 3: #B-I1
			
				self.head.page.Common.Lanes.Lanes_in_use = 0 
				
				if self.myconv_per_Lane == 2:
					self.head.page.Common.Lanes.Lane_sel = int(self.myRX_M*1.0/4)				
					self.head.page.Common.Final_Options.samp_drop = 1
				elif self.myconv_per_Lane == 4:
					self.head.page.Common.Lanes.Lane_sel = int((self.myRX_M*1.0/4)-1)					
					self.head.page.Common.Final_Options.samp_drop = int(4 + ((-1)**(self.head.page.Common.Lanes.Lane_sel)))
				else:
					self.head.page.Common.Lanes.Lane_sel = 2 
					self.head.page.Common.Final_Options.samp_drop = 0
				
			elif val == 4: #B-Q1
			
				self.head.page.Common.Lanes.Lanes_in_use = 0 
				
				if self.myconv_per_Lane == 2:
					self.head.page.Common.Lanes.Lane_sel = int(self.myRX_M*1.0/4)				
					self.head.page.Common.Final_Options.samp_drop = 2
				elif self.myconv_per_Lane == 4:
					self.head.page.Common.Lanes.Lane_sel = int((self.myRX_M*1.0/4)-1)					
					self.head.page.Common.Final_Options.samp_drop = int(5 + ((-1)**(self.head.page.Common.Lanes.Lane_sel)))		
				else:
					self.head.page.Common.Lanes.Lane_sel = 3 
					self.head.page.Common.Final_Options.samp_drop = 0			
		
			elif val == 5: #A-I1,A-Q1
			
				self.head.page.Common.Lanes.Lane_sel = 0
			
				if self.myconv_per_Lane == 1:
					self.head.page.Common.Lanes.Lanes_in_use = 1					
					self.head.page.Common.Final_Options.samp_drop = 0
				elif self.myconv_per_Lane == 2:
					self.head.page.Common.Lanes.Lanes_in_use = 0										
					self.head.page.Common.Final_Options.samp_drop = 0
				elif self.myconv_per_Lane == 4:
					self.head.page.Common.Lanes.Lanes_in_use = 0
					self.head.page.Common.Final_Options.samp_drop = 7
			
			elif val == 6: #B-I1,B-Q1
							
				if self.myconv_per_Lane == 1:
					self.head.page.Common.Lanes.Lanes_in_use = 1					
					self.head.page.Common.Lanes.Lane_sel = 1
					self.head.page.Common.Final_Options.samp_drop = 0
				elif self.myconv_per_Lane == 2:
					self.head.page.Common.Lanes.Lanes_in_use = 0
					self.head.page.Common.Lanes.Lane_sel = int(self.myRX_M*1.0/4)					
					self.head.page.Common.Final_Options.samp_drop = 0
				elif self.myconv_per_Lane == 4:
					self.head.page.Common.Lanes.Lanes_in_use = 0 
					self.head.page.Common.Lanes.Lane_sel = int(self.myRX_M*1.0/4)-1						
					self.head.page.Common.Final_Options.samp_drop = 9 - int(self.myRX_M*1.0/4)

			elif val == 7: #A-I2
				if self.myRX_M == 8:
					self.head.page.Common.Lanes.Lanes_in_use = 0					
					if self.myconv_per_Lane == 2:						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 1				
					elif self.myconv_per_Lane == 4:						
						self.head.page.Common.Lanes.Lane_sel = 0
						self.head.page.Common.Final_Options.samp_drop = 5						
				else:
					warning("2nd DDC not available in this mode.")

			elif val == 8: #A-Q2
				if self.myRX_M == 8:
					self.head.page.Common.Lanes.Lanes_in_use = 0					
					if self.myconv_per_Lane == 2:						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 2				
					elif self.myconv_per_Lane == 4:						
						self.head.page.Common.Lanes.Lane_sel = 0
						self.head.page.Common.Final_Options.samp_drop = 6						
				else:
					warning("2nd DDC not available in this mode.")
					
			elif val == 9: #B-I2
				if self.myRX_M == 8:
					self.head.page.Common.Lanes.Lanes_in_use = 0					
					if self.myconv_per_Lane == 2:						
						self.head.page.Common.Lanes.Lane_sel = 3
						self.head.page.Common.Final_Options.samp_drop = 1				
					elif self.myconv_per_Lane == 4:						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 5						
				else:
					warning("2nd DDC not available in this mode.")

			elif val == 10: #B-Q2
				if self.myRX_M == 8:
					self.head.page.Common.Lanes.Lanes_in_use = 0					
					if self.myconv_per_Lane == 2:						
						self.head.page.Common.Lanes.Lane_sel = 3
						self.head.page.Common.Final_Options.samp_drop = 2				
					elif self.myconv_per_Lane == 4:						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 6						
				else:
					warning("2nd DDC not available in this mode.")		
						
			elif val == 11: #A-I2,A-Q2
				if self.myRX_M == 8:
					self.head.page.Common.Lanes.Lanes_in_use = 0					
					if self.myconv_per_Lane == 2:						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 0				
					elif self.myconv_per_Lane == 4:						
						self.head.page.Common.Lanes.Lane_sel = 0
						self.head.page.Common.Final_Options.samp_drop = 8
				else:
					warning("2nd DDC not available in this mode.")	
					
			elif val == 12: #B-I2,B-Q2		
				if self.myRX_M == 8:
					self.head.page.Common.Lanes.Lanes_in_use = 0	
					if self.myconv_per_Lane == 2:						
						self.head.page.Common.Lanes.Lane_sel = 3
						self.head.page.Common.Final_Options.samp_drop = 0				
					elif self.myconv_per_Lane == 4:									
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 8
				else:
					warning("2nd DDC not available in this mode.")				
					
			elif val == 13: #FB-I1
				
				if self.myconv_per_Lane == 1:											
					self.head.page.Common.Lanes.Lanes_in_use = 0	
					self.head.page.Common.Lanes.Lane_sel = 0
					self.head.page.Common.Final_Options.samp_drop = 0				
				elif self.myconv_per_Lane == 2:														
					self.head.page.Common.Lanes.Lanes_in_use = 0	
					self.head.page.Common.Lanes.Lane_sel = 0
					self.head.page.Common.Final_Options.samp_drop = 7
				elif self.myconv_per_Lane == 0.5:										
					self.head.page.Common.Lanes.Lanes_in_use = 1	
					self.head.page.Common.Lanes.Lane_sel = 0
					self.head.page.Common.Final_Options.samp_drop = 0				
					
			elif val == 14: #FB-Q1
						
				if self.myconv_per_Lane == 1:											
					self.head.page.Common.Lanes.Lanes_in_use = 0	
					self.head.page.Common.Lanes.Lane_sel = 1
					self.head.page.Common.Final_Options.samp_drop = 0				
				elif self.myconv_per_Lane == 2:									
					self.head.page.Common.Lanes.Lanes_in_use = 0						
					self.head.page.Common.Lanes.Lane_sel = 0
					self.head.page.Common.Final_Options.samp_drop = 8
				elif self.myconv_per_Lane == 0.5:										
					self.head.page.Common.Lanes.Lanes_in_use = 1	
					self.head.page.Common.Lanes.Lane_sel = 1		
					self.head.page.Common.Final_Options.samp_drop = 0			

			elif val == 15: #FB-I1,FB-Q1
						
				if self.myconv_per_Lane == 1:											
					self.head.page.Common.Lanes.Lanes_in_use = 1	
					self.head.page.Common.Lanes.Lane_sel = 0
					self.head.page.Common.Final_Options.samp_drop = 0				
				elif self.myconv_per_Lane == 2:									
					self.head.page.Common.Lanes.Lanes_in_use = 0						
					self.head.page.Common.Lanes.Lane_sel = 0
					self.head.page.Common.Final_Options.samp_drop = 0
				elif self.myconv_per_Lane == 0.5:										
					self.head.page.Common.Lanes.Lanes_in_use = 2	
					self.head.page.Common.Lanes.Lane_sel = 0		
					self.head.page.Common.Final_Options.samp_drop = 0

			elif val == 16: #FB-I2
				
				if self.myRX_M == 4:
					if self.myconv_per_Lane == 1:											
						self.head.page.Common.Lanes.Lanes_in_use = 0	
						self.head.page.Common.Lanes.Lane_sel = 2
						self.head.page.Common.Final_Options.samp_drop = 0				
					elif self.myconv_per_Lane == 2:									
						self.head.page.Common.Lanes.Lanes_in_use = 0						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 7					
				else:
					warning("2nd DDC not available in this mode.")			
					
			elif val == 17: #FB-Q2
						
				if self.myRX_M == 4:
					if self.myconv_per_Lane == 1:											
						self.head.page.Common.Lanes.Lanes_in_use = 0	
						self.head.page.Common.Lanes.Lane_sel = 3
						self.head.page.Common.Final_Options.samp_drop = 0				
					elif self.myconv_per_Lane == 2:									
						self.head.page.Common.Lanes.Lanes_in_use = 0						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 8					
				else:
					warning("2nd DDC not available in this mode.")				

			elif val == 18: #FB-I2,FB-Q2
						
				if self.myRX_M == 4:
					if self.myconv_per_Lane == 1:											
						self.head.page.Common.Lanes.Lanes_in_use = 1	
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 0				
					elif self.myconv_per_Lane == 2:									
						self.head.page.Common.Lanes.Lanes_in_use = 0						
						self.head.page.Common.Lanes.Lane_sel = 1
						self.head.page.Common.Final_Options.samp_drop = 0					
				else:
					warning("2nd DDC not available in this mode.")									
						
			
		elif addr == samp_drop_Reg and self.logEn==True:
			info("samp_drop = %d"%(val))
		elif addr == pack_Reg and self.logEn==True:
			info("pack_mode = %d"%(val))
		elif addr == mode24_Reg and self.logEn==True:
			info("mode_24bit = %d"%(val))
		else:
		
			warning("Register address %s out of range."%str(addr))
			
			
	def readReg(self,addr):
	
		addr_shift = (addr<<32) + 0x4000000000
		if self.regProgDevice:
			a=super(ANUPAM_FPGA,self).readReg(addr_shift)
		else:
			a=0
		time.sleep(self.delay_time)
		# a = a/2;
		# sum = 0
		# for x in range(32):
				
			# b = a - 2*(a/2);
			# sum = sum + b*(2**(x))		
			# a = a/4		
		
		return a
		
		
	def capture(self,captureSampleNo):
		if self.oldCaptureFunc==True:
			return self.captureOld(captureSampleNo)
		errorCode=0x00
		try:		
			printCommentsForDebug=self.printCommentsForDebug
			jesdModeIn=self.LMFSHd.lower()
			if "_real" in jesdModeIn:
				realMode=1
				jesdMode=jesdModeIn.replace("_real","")
			elif "_" in jesdModeIn:
				jesdMode=jesdModeIn[:jesdModeIn.find("_")]
				realMode=0
			else:
				jesdMode=jesdModeIn
				realMode=0
			L=int(jesdMode[0])
			M=int(jesdMode[1])
			if len(jesdMode)==5:
				F=int(jesdMode[2])
				S=int(jesdMode[3])
				Hd=int(jesdMode[4])
			elif len(jesdMode)==6:
				F=int(jesdMode[2:4])
				S=int(jesdMode[4])
				Hd=int(jesdMode[5])
			
			resolution=16*(F*L)/(M*S*2.0)
			self.converterOrder=list(self.converterOrder)
			for i in range(len(self.converterOrder)):
				if self.converterOrder[i] >=M:
					del self.converterOrder[i]
			converterOrderOutofRange=False
			if len(self.converterOrder)==0:
				converterOrderOutofRange=True
				self.converterOrder=range(M)
			captureSampleNo = self.mult_fact*captureSampleNo
			captureSamples = captureSampleNo
			captureSampleNo=int(captureSampleNo*resolution/(16.0))	# To get required number of samples even if it is 12/24-bit
			captureSampleNoNeeded=int(math.ceil(captureSampleNo*M/len(self.converterOrder)))		#To account for the number of converters needed out of total ones.
			if captureSampleNoNeeded<=(32768*L):
				captureSampleNo=captureSampleNoNeeded
			else:
				captureSampleNo=int(captureSampleNoNeeded/math.ceil((65536.0*L)/captureSampleNoNeeded))
			
			if len(self.previousDataInput)==0 or self.softCapture==False:
				values_a0=super(ANUPAM_FPGA,self).capture(captureSampleNo+self.frame_phase)[0]		
				dataInput=values_a0[self.frame_phase:(captureSampleNo+self.frame_phase)]
				
				if len(values_a0)!=(captureSampleNo+self.frame_phase):
					values_a0=super(ANUPAM_FPGA,self).capture(captureSampleNo+self.frame_phase)[0]					
					dataInput=values_a0[self.frame_phase:(captureSampleNo+self.frame_phase)]

				
				if self.byte_swap:
					dataInput=((dataInput&0xff00)>>8)+((dataInput&0x00ff)<<8)
				self.previousDataInput=dataInput[:]
			else:
				dataInput=self.previousDataInput[:]
			
			laneWiseData=[]
			if (self.read16bit==1):
				if L == 1:
					laneWiseData.append(dataInput)
				elif L == 2:
					if len(dataInput)%2!=0:
						dataInput=dataInput[:-1]
					laneWiseData.append(dataInput[0::2])
					laneWiseData.append(dataInput[1::2])
				else:
					if len(dataInput)%4!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%4]
					laneWiseData.append(dataInput[0::4])
					laneWiseData.append(dataInput[1::4])
					laneWiseData.append(dataInput[2::4])
					laneWiseData.append(dataInput[3::4])
			else:
				if L == 1:
					laneWiseData.append(dataInput)
				elif L == 2:
					if len(dataInput)%4!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%4]
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[::2].reshape(len(dataInput)/2))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[1::2].reshape(len(dataInput)/2))
				elif L==3:
					del laneWiseData[3]
				elif L == 4:
					if len(dataInput)%16!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%16]
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[::4].reshape(len(dataInput)/4))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[1::4].reshape(len(dataInput)/4))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[2::4].reshape(len(dataInput)/4))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[3::4].reshape(len(dataInput)/4))
				else:
					if len(dataInput)%64!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%64]

					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[1::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[2::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[3::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[4::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[5::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[6::8].reshape(len(dataInput)/8))
					laneWiseData.append(dataInput.reshape(len(dataInput)/8.0,8)[7::8].reshape(len(dataInput)/8))
					
			if (self.reverseFourSamplesInLane==1): # Due to Bug in FPGA
				for laneData in laneWiseData:
					laneData1=laneData[0::4].tolist()
					laneData2=laneData[1::4].tolist()
					laneData3=laneData[2::4].tolist()
					laneData4=laneData[3::4].tolist()
					laneData[0::4]=np.asarray(laneData4)
					laneData[1::4]=np.asarray(laneData3)
					laneData[2::4]=np.asarray(laneData2)
					laneData[3::4]=np.asarray(laneData1)
			elif (self.reverseFourSamplesInLane==2): # Due to Bug in FPGA
				for laneData in laneWiseData:
					laneData1=laneData[0::4].tolist()
					laneData2=laneData[1::4].tolist()
					laneData3=laneData[2::4].tolist()
					laneData4=laneData[3::4].tolist()
					laneData[0::4]=np.asarray(laneData3)
					laneData[1::4]=np.asarray(laneData4)
					laneData[2::4]=np.asarray(laneData1)
					laneData[3::4]=np.asarray(laneData2)
			
				
			if Hd==1 and F==1:
				if printCommentsForDebug:
					info("if Hd==1 and F==1:")
				if L==4:
					lane0=[(((laneWiseData[0].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					lane1=[(((laneWiseData[2].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[3].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))
					laneWiseData.append(np.asarray(lane1))
				elif L==2:
					lane0=[(((laneWiseData[0].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))	
				elif L == 8:
					lane0=[(((laneWiseData[0].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					lane1=[(((laneWiseData[2].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[3].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					lane2=[(((laneWiseData[4].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[5].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					lane3=[(((laneWiseData[6].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[7].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))
					laneWiseData.append(np.asarray(lane1))
					laneWiseData.append(np.asarray(lane2))
					laneWiseData.append(np.asarray(lane3))
				L=L/2
				F=F*2
					
			if resolution!=16 and not (L==3 and Hd==1 and F!=1):
				if printCommentsForDebug:
					info("Unwrapping: if resolution!=16 and not (L==3 and Hd==1 and F!=1):")
				unwrappedLaneWiseData=[]
				totalSampleNumber=0
				if F==3:
					noSamplesMultipleOfFactor=3
				else:
					noSamplesMultipleOfFactor=(F/2)
				for laneData in laneWiseData:
					unwrappedLaneData=[]
					if resolution == 24:
						for laneSampleNo in range(0,len(laneData)-(len(laneData)%noSamplesMultipleOfFactor),3):
							a=laneData[laneSampleNo]
							b=laneData[laneSampleNo+1]
							c=laneData[laneSampleNo+2]
							unwrappedLaneData.append(a)
							unwrappedLaneData.append(((b&0xFF)<<8)+((c&0xFF00)>>8))
							totalSampleNumber+=2
					elif resolution == 12:
						for laneSampleNo in range(0,len(laneData)-(len(laneData)%noSamplesMultipleOfFactor),3):
							a=laneData[laneSampleNo]
							b=laneData[laneSampleNo+1]
							c=laneData[laneSampleNo+2]
							unwrappedLaneData.append(a&0xFFF0)
							unwrappedLaneData.append(((a&0xF)<<12)+((b&0xFF00)>>4))
							unwrappedLaneData.append(((b&0x00FF)<<8)+((c&0xF000)>>8))
							unwrappedLaneData.append((c&0x0FFF)<<4)
							totalSampleNumber+=4
					elif resolution == 32:
						unwrappedLaneData=laneData[::2]
						totalSampleNumber+=len(laneData.tolist())/2
					unwrappedLaneWiseData.append(unwrappedLaneData)
				laneWiseData=unwrappedLaneWiseData
			else:
				totalSampleNumber=len(laneWiseData[0])*len(laneWiseData)
			
			if Hd==1 and F!=1 and resolution==24:
				noSamplesPerLanePerFrame=int(round(F/2.0))
			else:
				noSamplesPerLanePerFrame=int(round(F/(resolution/8.0)))
			if printCommentsForDebug:
				info("First noSamplesPerLanePerFrame: "+str(noSamplesPerLanePerFrame))
			#info("L: "+str(L))
			#info("M: "+str(M))
			#info("F: "+str(F))
			#info("S: "+str(S))
			#info("Hd: "+str(Hd))
			#info("noSamplesPerLanePerFrame: "+str(noSamplesPerLanePerFrame))
			#info("totalSampleNumber: "+str(totalSampleNumber))
			
				
				
			frameInterleavedData=np.zeros(totalSampleNumber,dtype=int)
			for laneNo in range(L):
				for sampleNo in range(noSamplesPerLanePerFrame):
					frameInterleavedData[(laneNo*noSamplesPerLanePerFrame)+sampleNo::(L*noSamplesPerLanePerFrame)]=laneWiseData[laneNo][sampleNo::noSamplesPerLanePerFrame]
			if printCommentsForDebug:
				info("Calculated frameInterleavedData")
			if self.dropAlternateFrames==True:
				if printCommentsForDebug:
					info("if self.dropAlternateFrames==True:")
				lenOfFrameInterleavedData=len(frameInterleavedData)
				frameInterleavedData=frameInterleavedData.reshape(lenOfFrameInterleavedData/(L*noSamplesPerLanePerFrame),L*noSamplesPerLanePerFrame)[::2]
				frameInterleavedData=frameInterleavedData.reshape(len(frameInterleavedData)*L*noSamplesPerLanePerFrame)
				totalSampleNumber=len(frameInterleavedData)
			#self.frameInterleavedData=frameInterleavedData
			#self.laneWiseData=laneWiseData
			
			if Hd==1 and F!=1 and F%2==0 and resolution==24:
				if printCommentsForDebug:
					info("special case unwrapping: if Hd==1 and F!=1 and resolution==24:")
				if F==3:
					noSamplesMultipleOfFactor=3*L
				else:
					noSamplesMultipleOfFactor=(F*L/2)
				unwrappedFrameData=[]
				totalSampleNumber=0
				for laneSampleNo in range(0,len(frameInterleavedData)-(len(frameInterleavedData)%noSamplesMultipleOfFactor),3):
					a=frameInterleavedData[laneSampleNo]
					b=frameInterleavedData[laneSampleNo+1]
					c=frameInterleavedData[laneSampleNo+2]
					unwrappedFrameData.append(a)
					unwrappedFrameData.append(((b&0xFF)<<8)+((c&0xFF00)>>8))
					totalSampleNumber+=2
				frameInterleavedData=unwrappedFrameData
				noSamplesPerLanePerFrame=int(round(F/(2.0)))
				L=2
			
			converterWiseData=[]
			if printCommentsForDebug:
				info("going in for converterNo in range(M):")
			for converterNo in range(M):
				converterData=np.zeros(totalSampleNumber/M,dtype=int)
				for sampleNo in range(S):
					if self.sampleConverterOrderReverse:
						converterData[sampleNo::S]=frameInterleavedData[sampleNo+(converterNo*(L*noSamplesPerLanePerFrame)/M)::(L*noSamplesPerLanePerFrame)]
					else:
						converterData[sampleNo::S]=frameInterleavedData[converterNo+(sampleNo*(L*noSamplesPerLanePerFrame)/S)::(L*noSamplesPerLanePerFrame)]
				converterWiseData.append(converterData)
			self.converterWiseData=converterWiseData
			if printCommentsForDebug:
				info("converterInterleavedData=np.zeros")
			if self.dropAlternateSamplesPerConverter:
				converterInterleavedData=np.zeros(len(converterWiseData[0])*len(self.converterOrder)/2,dtype=int)
			else:
				converterInterleavedData=np.zeros(len(converterWiseData[0])*len(self.converterOrder),dtype=int)
			index=0
			if len(self.converterOrder)>1:
				for converterIndex in self.converterOrder:
					#if converterIndex>=M:
					#	continue
					if self.dropAlternateSamplesPerConverter:
						converterInterleavedData[index::len(self.converterOrder)]=converterWiseData[converterIndex][::2]
					else:
						converterInterleavedData[index::len(self.converterOrder)]=converterWiseData[converterIndex]
					index+=1
			else:
				converterInterleavedData=converterWiseData[self.converterOrder[0]]
			if converterOrderOutofRange==False:
				values=converterInterleavedData[:2**int(math.log(len(converterInterleavedData),2))]
			else:
				values=np.zeros(65536,dtype=int)
			
			
			#if self.dropAlternateSamplesPerConverter==True:
			#	if printCommentsForDebug:
			#		info("if self.dropAlternateSamplesPerLane==True:")
			#	laneWiseDataAfterDropping=[]
			#	for laneData in laneWiseData:
			#		laneWiseDataAfterDropping.append(laneData[::2])
			#	laneWiseData=laneWiseDataAfterDropping
			#	totalSampleNumber=totalSampleNumber/2
			#self.converterInterleavedData=converterInterleavedData
			#if captureSamples!=totalSampleNumber:
			#	raise ValueError("Enough samples not received. Got: "+str(totalSampleNumber)+"; Expected: "+str(captureSamples))	


			#if self.head.page.Common.Final_Options.samp_drop == 1 or self.head.page.Common.Final_Options.samp_drop == 2:
			##keeps 1, drops 1 sample
			#	values = values[(self.head.page.Common.Final_Options.samp_drop-1)::2]			
			#elif self.head.page.Common.Final_Options.samp_drop == 3 or self.head.page.Common.Final_Options.samp_drop == 4 or self.head.page.Common.Final_Options.samp_drop == 5 or self.head.page.Common.Final_Options.samp_drop == 6:				
			##keeps 1, drops 3 samples
			#	values = values[(self.head.page.Common.Final_Options.samp_drop-3)::4]								
			#elif self.head.page.Common.Final_Options.samp_drop == 7 or self.head.page.Common.Final_Options.samp_drop == 8:
			##keeps 2, drops 2 samples
			#	values1 = values[(2*(self.head.page.Common.Final_Options.samp_drop-7))::4]					
			#	values2 = values[((2*(self.head.page.Common.Final_Options.samp_drop-7))+1)::4]									
			#	values = np.insert(values2,np.arange(len(values1)),values1)		
				
		except Exception,E:
			info(str(E))
			error(str(E))
			errorCode=-1
			values=[]
		return values, errorCode
		
	def captureOld(self,sampleNo):
		errorCode=0x00
		try:		
			sampleNo = self.mult_fact*sampleNo
			values_a0=super(ANUPAM_FPGA,self).capture(sampleNo+self.frame_phase+32)					
			values_a=values_a0[0][self.frame_phase:(sampleNo+self.frame_phase+32)]
			#### changed by kawaljeet
			data0 = values_a[(4*(self.lane0_shift)+0)::4]
			data1 = values_a[(4*(self.lane1_shift)+1)::4]
			data2 = values_a[(4*(self.lane2_shift)+2)::4]
			data3 = values_a[(4*(self.lane3_shift)+3)::4]
	
			data0 = data0[0:sampleNo/4.0]
			data1 = data1[0:sampleNo/4.0]
			data2 = data2[0:sampleNo/4.0]
			data3 = data3[0:sampleNo/4.0]

			values1 = np.insert(data2,np.arange(len(data0)),data0)	
			values2 = np.insert(data3,np.arange(len(data1)),data1)	
			valuesA  = np.insert(values2,np.arange(len(values1)),values1)							
			values_a = valuesA[0:sampleNo]
			#### end change
			values_b = np.zeros(sampleNo*4.0/3,dtype=int)
			values_temp = values_a.copy()
			if self.byte_swap == 1:
				values_temp = np.array(values_temp)				  
				values_a = np.array(values_a)				  
				values_a = (((values_temp&0xFF)<<8) + ((values_temp&0xFF00)>>8))
				values_temp = values_a.copy()
			
						
			if self.head.page.Common.Final_Options.pack_mode == 1: #3/6/12-Sample Mode
				if self.head.page.Common.Lanes.Lanes_in_use == 1:
					for me_i in range(int(sampleNo*1.0/6)):
						values_a[6*me_i]   = values_temp[6*me_i]  
						values_a[6*me_i+1] = values_temp[6*me_i+2]
						values_a[6*me_i+2] = values_temp[6*me_i+4]
						values_a[6*me_i+3] = values_temp[6*me_i+1]
						values_a[6*me_i+4] = values_temp[6*me_i+3]
						values_a[6*me_i+5] = values_temp[6*me_i+5]
				
					values_a = values_a[0:6*(me_i+1)]
					
				elif self.head.page.Common.Lanes.Lanes_in_use == 2:
					for me_i in range(int(sampleNo*1.0/12)):
						values_a[12*me_i]	 = values_temp[12*me_i]	 
						values_a[12*me_i+1]	 = values_temp[12*me_i+4]
						values_a[12*me_i+2]	 = values_temp[12*me_i+8]
						values_a[12*me_i+3]	 = values_temp[12*me_i+1]
						values_a[12*me_i+4]	 = values_temp[12*me_i+5]
						values_a[12*me_i+5]	 = values_temp[12*me_i+9]
						values_a[12*me_i+6]	 = values_temp[12*me_i+2]  
						values_a[12*me_i+7]	 = values_temp[12*me_i+6]
						values_a[12*me_i+8]	 = values_temp[12*me_i+10]
						values_a[12*me_i+9]	 = values_temp[12*me_i+3]
						values_a[12*me_i+10] = values_temp[12*me_i+7]
						values_a[12*me_i+11] = values_temp[12*me_i+11]
				
					values_a = values_a[0:12*(me_i+1)]			
			
				for me_i in range(int(len(values_a)*1.0/3)):
				
					me_a = values_a[3*me_i]
					me_b = values_a[3*me_i+1]
					me_c = values_a[3*me_i+2]
					
					values_b[4*me_i]   = ((me_a&0xFFF0)>>4)
					values_b[4*me_i+1] = ((me_a&0xF)<<8) + ((me_b&0xFF00)>>8) 
					values_b[4*me_i+2] = ((me_b&0xFF)<<4) + ((me_c&0xF000)>>12) 
					values_b[4*me_i+3] = (me_c&0xFFF)
					
			else:
				values_b = values_a			
			
			values_b = values_b[0:sampleNo]
					
			if self.head.page.Common.Final_Options.mode_24bit == 1:
				mode_24bit_msb = [x<<12 for x in values_b[0::2]]				
				mode_24bit_lsb = values_b[1::2]
				values_c = np.add(mode_24bit_msb,mode_24bit_lsb)
			else:
				values_c = values_b
				
							
			if self.head.page.Common.Final_Options.pack_mode == 1:
				values_temp = values_c.copy()
				if self.head.page.Common.Lanes.Lanes_in_use == 1:
					if self.head.page.Common.Final_Options.mode_24bit == 0:
						for me_i in range(int(len(values_c)*1.0/8)):
							values_c[8*me_i]   = values_temp[8*me_i]  
							values_c[8*me_i+1] = values_temp[8*me_i+4]
							values_c[8*me_i+2] = values_temp[8*me_i+1]
							values_c[8*me_i+3] = values_temp[8*me_i+5]
							values_c[8*me_i+4] = values_temp[8*me_i+2]	
							values_c[8*me_i+5] = values_temp[8*me_i+6]
							values_c[8*me_i+6] = values_temp[8*me_i+3]
							values_c[8*me_i+7] = values_temp[8*me_i+7]
					else:
						for me_i in range(int(len(values_c)*1.0/4)):
							values_c[4*me_i]   = values_temp[4*me_i]  
							values_c[4*me_i+1] = values_temp[4*me_i+2]
							values_c[4*me_i+2] = values_temp[4*me_i+1]
							values_c[4*me_i+3] = values_temp[4*me_i+3]
				elif self.head.page.Common.Lanes.Lanes_in_use == 2:
					for me_i in range(int(len(values_c)*1.0/8)):
						values_c[8*me_i]   = values_temp[8*me_i]  
						values_c[8*me_i+1] = values_temp[8*me_i+4]
						values_c[8*me_i+2] = values_temp[8*me_i+2]
						values_c[8*me_i+3] = values_temp[8*me_i+6]
						values_c[8*me_i+4] = values_temp[8*me_i+1]	
						values_c[8*me_i+5] = values_temp[8*me_i+5]
						values_c[8*me_i+6] = values_temp[8*me_i+3]
						values_c[8*me_i+7] = values_temp[8*me_i+7]
				
						
			if self.head.page.Common.Final_Options.samp_drop == 0:				
				values = values_c
			elif self.head.page.Common.Final_Options.samp_drop == 1 or self.head.page.Common.Final_Options.samp_drop == 2:
			#keeps 1, drops 1 sample
				values = values_c[(self.head.page.Common.Final_Options.samp_drop-1)::2]			
			elif self.head.page.Common.Final_Options.samp_drop == 3 or self.head.page.Common.Final_Options.samp_drop == 4 or self.head.page.Common.Final_Options.samp_drop == 5 or self.head.page.Common.Final_Options.samp_drop == 6:				
			#keeps 1, drops 3 samples
				values = values_c[(self.head.page.Common.Final_Options.samp_drop-3)::4]								
			elif self.head.page.Common.Final_Options.samp_drop == 7 or self.head.page.Common.Final_Options.samp_drop == 8:
			#keeps 2, drops 2 samples
				values1 = values_c[(2*(self.head.page.Common.Final_Options.samp_drop-7))::4]					
				values2 = values_c[((2*(self.head.page.Common.Final_Options.samp_drop-7))+1)::4]									
				values = np.insert(values2,np.arange(len(values1)),values1)							
			
					
			if len(values_b)!=sampleNo:
				raise ValueError("Enough samples not received.")			
		except Exception:
			errorCode=-1
			values=[]
		return values, errorCode

	def saveDataToFile(self,fileName):
		file=open(fileName, "w")
		title=""
		for col in range(len(self.converterWiseData)):
			title+="Converter"+str(col)+"\t"
		file.write(title+"\n")
		for col in range(len(self.converterWiseData)):
			for row in range(len(self.converterWiseData[col])):
				file.write(str(self.converterWiseData[col][row])+"\t")
			file.write("\n")
		file.close()
		
		
	def JESDIP_RX_rdbk(self,addr,ch):	

		addr1 = addr +	 0x10000000
		addr2 = addr1 + 0x40000000	
		
		self.superWriteReg(14 + (16*ch),addr1)
		time.sleep(self.delay_time)
		self.superWriteReg(14 + (16*ch),addr2)		
		time.sleep(self.delay_time)		
		if self.regProgDevice:
			a = super(ANUPAM_FPGA,self).readReg(((13 + (16*ch))<<32) + 0x4000000000)
		else:
			a=0
		# a = a/2;
		# sum = 0
		# for x in range(32):
				
			# b = a - 2*(a/2)
			# sum = sum + b*(2**(x))		
			# a = a/4
			# sum = int(sum)
		
		self.AXI_done_chk(ch)		
		
		return a
	
	def JESDIP_TX_rdbk(self,addr,ch):
			
		
		addr1 = addr + 0x40000000
		self.superWriteReg(14 + (16*ch),addr)
		time.sleep(self.delay_time)			
		self.superWriteReg(14 + (16*ch),addr1)	
		time.sleep(self.delay_time)			
		if self.regProgDevice:
			a = super(ANUPAM_FPGA,self).readReg(((13 + (16*ch))<<32) + 0x4000000000)	
		else:
			a=0
		# a = a/2;
		# sum = 0
		# for x in range(32):
				
			# b = a - 2*(a/2);
			# sum = sum + b*(2**(x))		
			# a = a/4
			# sum = int(sum)
			
		self.AXI_done_chk(ch)
		
		return a	
		
	def JESDIP_TX_wr(self,addr,data,ch):	

		
		addr1 = addr + 0x80000000;		
		self.superWriteReg(13 + (16*ch),data)
		time.sleep(self.delay_time)		
		self.superWriteReg(14 + (16*ch),addr)
		time.sleep(self.delay_time)
		self.superWriteReg(14 + (16*ch),addr1)
		time.sleep(self.delay_time)
		
		self.AXI_done_chk(ch)
		
		return None
		
	def JESDIP_RX_wr(self,addr,data,ch):	
		
		addr1  = addr  + 0x10000000;	
		addr2 = addr1 + 0x80000000;
		
		self.superWriteReg(13 + (16*ch),data)
		time.sleep(self.delay_time)
		self.superWriteReg(14 + (16*ch),addr1)
		time.sleep(self.delay_time)
		self.superWriteReg(14 + (16*ch),addr2)
		time.sleep(self.delay_time)

		self.AXI_done_chk(ch)

		return None
		
	def AXI_done_chk(self,ch):
	
		reg14 = (self.readReg(14 + (16*ch))&0xC0000000)>>30
		trial = 0
		
		while(reg14 > 0):
			info("AXI Not Yet Done!")
			reg14 = (self.readReg(14 + (16*ch))&0xC0000000)>>30
			time.sleep(self.delay_time)
			trial=trial+1
			if (trial>1):
				reg14 = -1
		
		if self.logEn==True:
			if (reg14 == 0):	
				info("AXI Done!")
			else:
				info("AXI NOT Done!")
			
		return None
		
	def writeProperty(self,prop,value,soft=False):
		if prop.rawRegIndex is None: return
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal = (regVal & r.zeros()) | (r.shift(value) & r.ones())
			if regVal != self._rawRegisters[(prop.rawRegIndex,r.address)]:
				self._rawRegisters[(prop.rawRegIndex,r.address)]=regVal
				if not soft:
					if self.commentForWrite not in self.commentForWrite:
						self.commentForWrite+="\t// "+self.commentForWrite
					self.writeReg(r.address,regVal)
			value = value >> r.size()
			
	def readProperty(self,prop,soft=False):
		val = 0
		lsb = 0
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			if not soft:
				regVal = self.readReg(r.address)
				if regVal is None:
					regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
					warning("%s, Dummy read \t: %d = %d"%(self.fqn,r.address,regVal))
				else:
					self._rawRegisters[(prop.rawRegIndex,r.address)] = regVal
			else:
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal &= r.ones()
			val |= r.unshift(regVal)<<lsb
			lsb += r.size()
		if prop.signed:
			val=prop.get2sComplement(val)		
		return val
		
	def updateAlarms(self):
		entity = self.Header.Page.alarms
		for group in entity.entityList:
			for prop in group.stateVariableList:
				prop.getValue()
	def parityOf(self,a):
		parity = 0
		while (a):
			parity = parity+1
			a = a & (a - 1)
		parity = parity%2
		return parity