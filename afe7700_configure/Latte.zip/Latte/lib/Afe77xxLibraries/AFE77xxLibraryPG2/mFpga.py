from globalDefs import *
from tswDecode import lteDecode
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
from mSetupParams import setupParams
import numpy as np
import random,math
import os

class fpgaLib(projectBaseClass):
	"""Contains FPGA specific functions. self.regs=myfpga """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		#self.deviceRefs=deviceRefs
		#self.systemParams=deviceRefs.systemParams
		#self.systemStatus=deviceRefs.systemStatus
		#self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.oldFpgaFunc=False
		
		self.setJesdTxF=[0,0]
		self.setJesdRxF=[0,0]
		#__init__
		
		
	@funcDecorator
	def selectCapture(self,LMFSHd,lanes,converterOrder,dutNo=0,byte_swap=0):
		""" Assumes that lanes are consecutive. Looks at the first element of the list and number of lanes only. """
		myfpga=self.regs
		myfpga.oldCaptureFunc=False
		myfpga.sampleConverterOrderReverse=1
		myfpga.read16bit=1
		myfpga.byte_swap=byte_swap
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if resolution==48 or "_DUP" in LMFSHd:
			myfpga.LMFSHd=str(L)+str(M)+str(F)+str(S*2)+str(Hd)
			myfpga.dropAlternateSamplesPerConverter=1
		else:
			myfpga.LMFSHd=LMFSHd
			myfpga.dropAlternateSamplesPerConverter=0
			
		myfpga.converterOrder=converterOrder
		
		myfpga.head.page.Common.USB_READ.Channel_Select=not int(round(lanes[0]/4))# 1 for 0-3 lanes and 0 for 4-7 lanes
		if len(lanes)==1:
			myfpga.head.page.Common.Lanes.Lane_sel=lanes[0]%4
		elif len(lanes)==2:
			myfpga.head.page.Common.Lanes.Lane_sel=(lanes[0]%4)/2
		else:
			myfpga.head.page.Common.Lanes.Lane_sel=0
			
		myfpga.head.page.Common.Lanes.Lanes_in_use=int(math.log(len(lanes),2))
		#selectLanesToCapture
		
	@funcDecorator
	def reset(self):
		info("Resetting FPGA.")
		if self.systemParams.jesdProtocol!=0:
			myfpga=self.regs
			myfpga.gui.reset()
			myfpga.reset()
			self.resetFpgaH()
			return
		myfpga=self.regs
		myfpga.gui.reset()
		myfpga.reset()
		myfpga.head.page.Common.Reset.Reset_all=1
		delay(0.5)
		myfpga.head.page.Common.Reset.Reset_all=0
		
		myfpga.head.page.Common.Reset.QPLL_Reset=1
		delay(0.5)
		myfpga.head.page.Common.Reset.QPLL_Reset=0
		#reset
		
		
	@funcDecorator
	def resetQpllIpReset(self):
		self.regs.head.page.Common.Reset.QPLL_Reset=1
		self.regs.head.page.Common.Reset.QPLL_Reset=0
		delay(0.5)
		self.regs.head.page.TX_2T2RA.Reset.Reset=1
		self.regs.head.page.TX_2T2RA.Reset.Reset=0
		self.regs.head.page.TX_2T2RB.Reset.Reset=1
		self.regs.head.page.TX_2T2RB.Reset.Reset=0
		self.regs.head.page.RX_2T2RA.Reset.Reset=1
		self.regs.head.page.RX_2T2RA.Reset.Reset=0
		self.regs.head.page.RX_2T2RB.Reset.Reset=1
		self.regs.head.page.RX_2T2RB.Reset.Reset=0
		#resetQpll
		
	@funcDecorator
	def fpgaTxSendK(self,en=[True]*2):
		if self.systemParams.jesdProtocol!=0:
			if True in en:
				self.fpgaHSync(1)
			else:
				self.fpgaHSync(0)
			return
		if en[0]==True and en[1]==True:
			self.deviceRefs.device.printCommentToLog("FPGA Sending K characters to all the 8 lanes")
		elif en[0]==False and en[1]==False:
			self.deviceRefs.device.printCommentToLog("FPGA Sending Data to all the 8 lanes")
		elif en[0]==True and en[1]==False:
			self.deviceRefs.device.printCommentToLog("FPGA Sending K characters to top 4 and Data to bottom 4 lanes")
		elif en[0]==False and en[1]==True:
			self.deviceRefs.device.printCommentToLog("FPGA Sending Data to top 4 and K characters to bottom 4 lanes")
			
		self.regs.head.page.Basic_U2T2RA.Interface.Syncz=not en[1]
		self.regs.head.page.Basic_U2T2RB.Interface.Syncz=not en[0]
		#fpgaTxSendK
		
	@funcDecorator
	def fpgaRxConfig(self,rxOrFb0=0,rxOrFb1=0,reverse01Mapping=0,dutNo=0):
		""" "Configuring FPGA JESD RX" "Done configuring FPGA JESD RX"
		rxOrFb0 or rxOrFb1 arguments will be taken only when the F in JESD mode of RX and FB are not same, since in those cases link has to be established separately.
		reverse01Mapping will configure instance 0 to 1 and instance 1 to 0."""
		if self.systemParams.jesdProtocol!=0:
			pass#self.fpgaHRxConfig()
		myfpga=self.regs
		
		if myfpga.head.page.alarms.channelA._PLL_Lock.getValue()==False:
			if myfpga.head.page.alarms.channelA._PLL_Lock.getValue()==False:
				warning("In fpgaRxConfig, PLL didn't lock. Resetting QPLL")
				myfpga.head.page.Common.Reset.QPLL_Reset=1
				delay(0.5)
				myfpga.head.page.Common.Reset.QPLL_Reset=0
				delay(0.5)
				info("After Reset PLL_lock: "+str(myfpga.head.page.alarms.channelA._PLL_Lock.getValue()))
		rxOrFb=[rxOrFb0,rxOrFb1]
		RX_K=self.systemStatus.jesdConfigParams[0]['TX_K']
		
		lanes=[0]*2
		f=[0]*2
		for i in range(2):
			dedicatedLaneModes=self.systemParams.dedicatedLaneMode[i]|(self.systemParams.systemMode[i]==1)
			rxParams=self.jesdModeFeatures(self.systemParams.LMFSHdRx[i])
			fbParams=self.jesdModeFeatures(self.systemParams.LMFSHdFb[i])
			if rxParams[2]==fbParams[2] and self.systemStatus.laneRateRx[i]==self.systemStatus.laneRateFb[i] and dedicatedLaneModes==1:# If F is same and lane rates for RX and FB are same. In this case single link is sufficient to be established.
				lanes[i]=(2**rxParams[0]-1)+((2**fbParams[0]-1)<<2)
				f[i]=rxParams[2]
			elif rxOrFb[i]==0:
				lanes[i]=(2**rxParams[0]-1)
				f[i]=rxParams[2]
			elif rxOrFb[i]==1:
				lanes[i]=(2**fbParams[0]-1)<<2
				f[i]=fbParams[2]
			lanes[i]=int(format(lanes[i], '04b')[::-1],2)
			
		if reverse01Mapping==1:
			lanes=list(reversed(lanes))
			f=list(reversed(f))
			
			
		for i in (1,0):# This loop is just to take care of the scenario where FPGA Writes are not going through properly
			myfpga.head.page.Common.What2Cap.What2Cap_on_ALane0=(3+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_ALane1=(2+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_ALane2=(1+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_ALane3=(0+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_BLane0=(7+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_BLane1=(6+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_BLane2=(5+i)&0x7
			myfpga.head.page.Common.What2Cap.What2Cap_on_BLane3=(4+i)&0x7
			myfpga.head.page.Common.Lanes.Lane_sel = i
			
			#myfpga.head.page.GPIO.group1_iosel.RXTDD1_out_ena=1
			#myfpga.head.page.GPIO.group1_iosel.RXTDD2_out_ena=1
			#myfpga.head.page.GPIO.group1_iosel.RXFBSW1_out_ena=1
			#myfpga.head.page.GPIO.group1_iosel.RXFBSW2_out_ena=1
			#myfpga.head.page.GPIO.group1.RXTDD1=1
			#myfpga.head.page.GPIO.group1.RXTDD2=1
			
			
		myfpga.head.page.RX_2T2RA.JESD.En_Scrambler=self.systemStatus.jesdConfigParams[1]['scr']
		myfpga.head.page.RX_2T2RB.JESD.En_Scrambler=self.systemStatus.jesdConfigParams[0]['scr']
		
		myfpga.head.page.RX_2T2RA.Link.F_Octets_per_Frame = f[1]-1
		self.setJesdRxF[1]=f[1]
		myfpga.head.page.RX_2T2RA.Link.K_Frames_per_Multiframe = RX_K
		if self.systemParams.bitFileType!=2:
			myfpga.head.page.RX_2T2RA.Link.Lanes_in_use = lanes[1]#15#
		else:
			myfpga.head.page.RX_2T2RA.Link.Lanes_in_use = 255#lanes[0]
			myfpga.JESDIP_RX_wr(0x28,255,0)
			
		myfpga.head.page.RX_2T2RA.Reset.Reset =1
		delay(0.5)
		myfpga.head.page.RX_2T2RA.Reset.Reset =0
		
		myfpga.head.page.RX_2T2RB.Link.F_Octets_per_Frame = f[0]-1
		self.setJesdRxF[0]=f[0]
		myfpga.head.page.RX_2T2RB.Link.K_Frames_per_Multiframe = RX_K
		myfpga.head.page.RX_2T2RB.Link.Lanes_in_use = lanes[0]#15#
		
		myfpga.head.page.RX_2T2RB.Reset.Reset =1
		delay(0.5)
		myfpga.head.page.RX_2T2RB.Reset.Reset =0
		return
		#fpgaRxConfig
		
	@funcDecorator
	def checkRxSync(self):
		info("###########Device ADC JESD-TX Link Status###########")
		
		myfpga=self.regs
		if self.systemParams.jesdProtocol==0:
			info("########### FPGA RX Link Status ###########")
			info("PLL_lock="+str(myfpga.head.page.alarms.channelA._PLL_Lock.getValue()))
			if myfpga.head.page.alarms.channelB._PLL_Lock.getValue()==False:
				syncValid=False
			else:
				syncValid=True
				
			syncZ = myfpga.head.page.alarms.channelB._SyncZ.getValue()
			if(syncZ == 0):
				info("syncZ="+str(syncZ))
				syncValid1=True
			else :
				error("syncZ="+str(syncZ))
				syncValid1=False
				
				
			syncZ = myfpga.head.page.alarms.channelA._SyncZ.getValue()
			if(syncZ == 0):
				info("syncZ="+str(syncZ))
				syncValid2=True
			else :
				error("syncZ="+str(syncZ))
				syncValid2=False
			if False not in (syncValid1,syncValid2,syncValid):
				info("RX/FB JESD-TX link is up.")
			else:
				error("RX/FB JESD-TX link is not up.")
			info("################################")
			self.systemStatus.jesdTxLink[0]=syncValid1
			self.systemStatus.jesdTxLink[1]=syncValid2
			return (syncValid1,syncValid2)
		else:
			info("CS State 0: "+ str(myfpga.JESD.DAC_RX[0].DAC_RX.TXDUC_REG298._jesd_cs_state_tx0.getValue()))
			info("FS State 0: "+ str(myfpga.JESD.DAC_RX[0].DAC_RX.TXDUC_REG300._jesd_fs_state_tx0.getValue()))
			info("CS State 1: "+ str(myfpga.JESD.DAC_RX[1].DAC_RX.TXDUC_REG298._jesd_cs_state_tx0.getValue()))
			info("FS State 1: "+ str(myfpga.JESD.DAC_RX[1].DAC_RX.TXDUC_REG300._jesd_fs_state_tx0.getValue()))
			#checkRxSync
			
	@funcDecorator
	def fpgaTxConfig(self,instanceNo=0,dutNo=0):
		""" "Configuring FPGA JESD TX" "Done configuring FPGA JESD TX" """
		if self.systemParams.jesdProtocol!=0:
			self.fpgaHTxConfig()
		myfpga=self.regs
		if myfpga.head.page.alarms.channelA._PLL_Lock.getValue()==False:
			if myfpga.head.page.alarms.channelA._PLL_Lock.getValue()==False:
				#warning("In fpgaTxConfig, PLL didn't lock. Resetting QPLL")
				myfpga.head.page.Common.Reset.QPLL_Reset=1
				delay(0.5)
				myfpga.head.page.Common.Reset.QPLL_Reset=0
				delay(0.5)
				#info("After Reset PLL_lock: "+str(myfpga.head.page.alarms.channelA._PLL_Lock.getValue()))
				
		myfpga.head.page.TX_2T2RA.JESD.En_Scrambler=self.systemStatus.jesdConfigParams[1]['scr']
		myfpga.head.page.TX_2T2RB.JESD.En_Scrambler=self.systemStatus.jesdConfigParams[0]['scr']
		
		myfpga.head.page.TX_2T2RA.Link.F_Octets_per_Frame=self.jesdModeFeatures(self.systemParams.LMFSHdTx[1])[2]-1
		self.setJesdTxF[1]=self.jesdModeFeatures(self.systemParams.LMFSHdTx[1])[2]
		myfpga.head.page.TX_2T2RA.Link.K_Frames_per_Multiframe=self.systemStatus.jesdConfigParams[1]['RX_K']#19
		myfpga.head.page.TX_2T2RA.Link.Lanes_in_use=15
		myfpga.head.page.TX_2T2RA.ILA.N=15
		myfpga.head.page.TX_2T2RA.ILA.M=3
		myfpga.head.page.TX_2T2RA.Link.Test__Modes=0
		myfpga.head.page.TX_2T2RA.Reset.Reset=1
		myfpga.head.page.TX_2T2RA.Reset.Reset=0
		
		myfpga.head.page.TX_2T2RB.Link.F_Octets_per_Frame=self.jesdModeFeatures(self.systemParams.LMFSHdTx[0])[2]-1
		self.setJesdTxF[0]=self.jesdModeFeatures(self.systemParams.LMFSHdTx[0])[2]
		myfpga.head.page.TX_2T2RB.Link.K_Frames_per_Multiframe=self.systemStatus.jesdConfigParams[0]['RX_K']#19
		myfpga.head.page.TX_2T2RB.Link.Lanes_in_use=15
		myfpga.head.page.TX_2T2RB.ILA.N=15
		myfpga.head.page.TX_2T2RB.ILA.M=3
		myfpga.head.page.TX_2T2RB.Link.Test__Modes=0
		myfpga.head.page.TX_2T2RB.Reset.Reset=1
		myfpga.head.page.TX_2T2RB.Reset.Reset=0
		
		
		myfpga.head.page.Basic_U2T2RA.Interface.Cust_Pattern_L0=0x3f3f3f3f#0xff3fff3f
		myfpga.head.page.Basic_U2T2RA.Interface.Cust_Pattern_L1=0x3f3f3f3f
		myfpga.head.page.Basic_U2T2RA.Interface.Cust_Pattern_L2=0xff3fff3f
		myfpga.writeReg(9,1061109567)
		myfpga.head.page.Basic_U2T2RA.Interface.En_Test_Pattern=1
		
		myfpga.head.page.Basic_U2T2RB.Interface.Cust_Pattern_L0=0x3f3f3f3f#0xff3fff3f
		myfpga.head.page.Basic_U2T2RB.Interface.Cust_Pattern_L1=0x3f3f3f3f
		myfpga.head.page.Basic_U2T2RB.Interface.Cust_Pattern_L2=0xff3fff3f
		#myfpga.head.page.Basic_U2T2RB.Interface.Cust_Pattern_L3=0x3f3f3f3f ####--------------- Need to check no changes
		myfpga.head.page.Basic_U2T2RB.Interface.En_Test_Pattern=1
		
		myfpga.head.page.Basic_U2T2RA.Interface.Syncz=0
		myfpga.head.page.Basic_U2T2RB.Interface.Syncz=0
		#fpgaTxConfig
		
	@funcDecorator
	def jesdConvertersToLanes(self,LMFSHd,converterWiseData):
		""" This function packs the converterwise data into lanes as per the LMFSHd provided. It returns an array of lane wise data. The lane wise data is an array of 16-bit data. """
		inputDataResolution=16
		jesdModeIn=LMFSHd.lower()
		if "_" in jesdModeIn:
			jesdMode=jesdModeIn[:jesdModeIn.find("_")]
		else:
			jesdMode=jesdModeIn
		L=int(jesdMode[0])
		M=int(jesdMode[1])
		if len(jesdMode)==5:
			F=int(jesdMode[2])
			S=int(jesdMode[3])
			Hd=int(jesdMode[4])
		elif len(jesdMode)==6:
			F=int(jesdMode[2:4])
			S=int(jesdMode[4])
			Hd=int(jesdMode[5])
			
		if M!=len(converterWiseData):
			error("The number of arrays passed and M given doesn't match. Please send an array consisting of converter wise data. No values written to FPGA.")
			#return
		bits=16
		resolution=int(round(16*(F*L)/(M*S*2.0)))
		totalSampleNumber=len(converterWiseData)*len(converterWiseData[0])
		
		converterInterleavedData=np.zeros(totalSampleNumber,dtype=int)
		for i in range(M):
			if (len(converterWiseData[i])*resolution/8.0)%1!=0:
				converterWiseData[i]=converterWiseData[i][:1-(len(converterWiseData[i])*resolution%8)]
			converterInterleavedData[i::M]=converterWiseData[i]
			
		laneInterleavedDataBits=[]
		for sample in converterInterleavedData:
			#exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(sample&(2**inputDataResolution-1))")
			exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(int((sample)+(2**(bits-1)))^(1<<(bits-1))&(2**inputDataResolution-1))")
			if resolution<inputDataResolution:
				resolutionEff=resolution
			else:
				resolutionEff=inputDataResolution
			for i in range(resolutionEff):
				laneInterleavedDataBits.append(sampleBits[i])
			if inputDataResolution<resolution:
				for i in range(resolution-inputDataResolution):
					laneInterleavedDataBits.append('0')
					
		if len(laneInterleavedDataBits)%(8*F*L)!=0:
			for i in range(len(laneInterleavedDataBits)%(8*F*L)):
				laneInterleavedDataBits.append('0')
				
		laneInterleavedDataOctets=[]
		laneInterleavedDataBits=np.array(laneInterleavedDataBits)
		laneInterleavedDataBits=laneInterleavedDataBits.reshape(len(laneInterleavedDataBits)/8,8)
		for octet in laneInterleavedDataBits:
			octetStr=""
			for i in range(8):
				octetStr+=str(octet[i])
			laneInterleavedDataOctets.append(int(octetStr,2))
			
		laneWiseDataOctets=[]
		for lane in range(L):
			laneData=[0]*(len(laneInterleavedDataOctets)/L)
			for octet in range(F):
				laneData[octet::F]=laneInterleavedDataOctets[((lane*F)+octet)::(L*F)]
			laneWiseDataOctets.append(laneData)
			
			
		laneWiseData=[]
		for lane in range(L):
			laneData=[]
			for sample in range(0,len(laneWiseDataOctets[0])/2):
				laneData.append((laneWiseDataOctets[lane][sample*2]<<8)+laneWiseDataOctets[lane][(2*sample)+1])
			laneWiseData.append(laneData)
		return laneWiseData
		
		# laneDataRet=jesdConvertersToLanes(LMFSHd,converterWiseData)
		
	@funcDecorator
	def toneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=4096,fsBaseBand=491.52):
		bits=16
		n = int(NumberOfSamples/2)
		m = int((fInBaseBand/fsBaseBand)*n)	
		if (m%2) == 0 :
			m = m+1
		fInBaseBand=(m/float(n)*fsBaseBand)
		
		ampl=10**(ampl_dBFs/20.0)
		### Max samples 32k for I and 32k for Q for 12410 mode. 64k per lane for 0th and 1st lanes. Same data on 2nd and 3rd lanes as on 0th and 1st lanes respectively
		signal = np.zeros(NumberOfSamples,dtype=complex)
		for x in range(NumberOfSamples):
			signal[x] = np.round((2**(bits-1))*ampl*np.e**(1j*2*np.pi*(fInBaseBand/fsBaseBand)*x))
		realSignal=signal.real
		imagSignal=signal.imag
		return([realSignal,imagSignal])
		
	@funcDecorator
	def multiToneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=4096,fsBaseBand=491.52):
		bits=16
		n = int(NumberOfSamples/2)
		ampl=[]
		for i in range(len(fInBaseBand)):
			m = int((fInBaseBand[i]/fsBaseBand)*n)	
			if (m%2) == 0 :
				m = m+1
			fInBaseBand[i]=(m/float(n)*fsBaseBand)
			if i>=len(ampl_dBFs):
				ampl_dBFs.append(-20.0)
			ampl.append(10**(ampl_dBFs[i]/20.0))
			### Max samples 32k for I and 32k for Q for 12410 mode. 64k per lane for 0th and 1st lanes. Same data on 2nd and 3rd lanes as on 0th and 1st lanes respectively
		signal = np.zeros(NumberOfSamples,dtype=complex)
		for x in range(NumberOfSamples):
			signal[x]=0
			for i in range(len(fInBaseBand)):
				signal[x] += np.round((2**(bits-1))*ampl[i]*np.e**(1j*2*np.pi*(fInBaseBand[i]/fsBaseBand)*x))
		realSignal=signal.real
		imagSignal=signal.imag
		return([realSignal,imagSignal])
		
	@funcDecorator
	def loadSignalToFpga(self,twoT,laneWiseData):
		myfpga=self.regs
		#if len(laneWiseData)>1:		# To compensate for reversal of lanes in FPGA
		#	if len(laneWiseData)==4:
		#		laneWiseData=list(reversed(laneWiseData[:2]))+list(reversed(laneWiseData[2:]))
		#	else:
		#		laneWiseData=list(reversed(laneWiseData))
		noOfSamples=len(laneWiseData[0])*len(laneWiseData)
		inputData=[]#np.zeros(noOfSamples+1,dtype=int)
		if len(laneWiseData)>2:
			noLanes=2
		else:
			noLanes=len(laneWiseData)
		bits=16
		for i in range(len(laneWiseData[0])/2):
			for lane in range(noLanes)[::-1]:# reversing the list to compensate for reversal of lanes in FPGA
				if type(laneWiseData[lane])== r"type 'numpy.ndarray'":
					inputData.append(int((laneWiseData[lane][2*i])+(2**(bits-1)))^(1<<(bits-1)))
					inputData.append(int((laneWiseData[lane][(2*i)+1])+(2**(bits-1)))^(1<<(bits-1)))
				else:
					inputData.append(laneWiseData[lane][2*i])
					inputData.append(laneWiseData[lane][(2*i)+1])
		inputData.append(0)
		inputDataLen=len(inputData)/1.0
		input_data=np.array(inputData)
		# 	info(input_data[:32])
		###Byte swap to compensate for byte swap in the FPGA
		input_data = (((input_data&0x00FF)<<8) + ((input_data&0xFF00)>>8))
		
		dac_length = inputDataLen-2
		
		###Need to capture once to re-wrtie into RAM
		self.deviceRefs.engine.device.captureDevice.capture(2000)
		
		if twoT == 1:
			myfpga.head.page.Basic_U2T2RA.TX_RAM.TX_RAM_datalength = dac_length
			myfpga.head.page.Basic_U2T2RA.TX_RAM.TX_RAM_Mode = 1
			myfpga.head.page.Common.usb_data_to_DAC.sel_AorB = 0
			myfpga.head.page.Basic_U2T2RA.Interface.En_Test_Pattern=0
			myfpga.head.page.Basic_U2T2RA.TX_RAM.TX_RAM_WEN=1
		else:
			myfpga.head.page.Basic_U2T2RB.TX_RAM.TX_RAM_datalength = dac_length
			myfpga.head.page.Basic_U2T2RB.TX_RAM.TX_RAM_Mode = 1
			myfpga.head.page.Common.usb_data_to_DAC.sel_AorB = 1
			myfpga.head.page.Basic_U2T2RB.Interface.En_Test_Pattern=0
			myfpga.head.page.Basic_U2T2RB.TX_RAM.TX_RAM_WEN=1
			
			
		myfpga.head.page.Common.usb_data_to_DAC.Make_USB_Data_in = 1
		delay(.1)
		setupParams.fpgaWriter.write(input_data)
		delay(.1)
		myfpga.head.page.Common.usb_data_to_DAC.Make_USB_Data_in = 0
		
		if myfpga.head.page.Common.usb_data_to_DAC._Make_USB_Data_in.getValue() != 0:
			myfpga.head.page.Common.usb_data_to_DAC.Make_USB_Data_in = 0
		myfpga.regProgDevice._controller.instrument.purge()	
		#loadSignalToFpga
		
	@funcDecorator
	def sendSingleTone(self,twoTNo,fin1,amp1,fin2,amp2):
		LMFSHd=self.systemParams.LMFSHdTx[twoTNo]
		fBand1=self.systemParams.Fs*1.0/self.systemParams.ducFactorTx[0]
		fBand2=self.systemParams.Fs*1.0/self.systemParams.ducFactorTx[1]
		tone1=self.toneGen(fin1,amp1,4096,fBand1)
		tone2=self.toneGen(fin2,amp2,4096,fBand2)
		if LMFSHd[1]=='8':
			converterWiseData=[tone1[0],tone1[1],tone2[0],tone2[1]]+[tone1[0],tone1[1],tone2[0],tone2[1]]
		else:
			converterWiseData=[tone1[0],tone1[1],tone2[0],tone2[1]]
		laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData)
		self.loadSignalToFpga(twoTNo,laneWiseData)
		#sendSingleTone
		
	@funcDecorator
	def sendLteData(self,twoTNo,filePath):
		if filePath.strip()=="":
			return
		elif (not (os.path.exists(filePath) and  os.path.isfile(filePath))) or (filePath[-4:].lower()!=".tsw"):
			error("LTE file Doesn't Exist or invalid. Please give path for a TSW file.")
			return
		LMFSHd=self.systemParams.LMFSHdTx[twoTNo]
		tone1=lteDecode.decodeTswData(filePath)
		converterWiseData=[tone1[0],tone1[1],tone1[0],tone1[1]]
		laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData)
		self.loadSignalToFpga(twoTNo,laneWiseData)
		#sendLteData
		
	@funcDecorator
	def sendCustomData(self,twoTNo,filePath):
		if (not (os.path.exists(filePath) and  os.path.isfile(filePath))): 
			error("File Doesn't Exist. Please give path.") 
			return 
		LMFSHd=self.systemParams.LMFSHdTx[twoTNo] 
		(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(LMFSHd)
		
		LTE_file=open(filePath,'r')
		LTE_data_encoded = LTE_file.read()
		noConvertersInFile=len(LTE_data_encoded[:LTE_data_encoded.find('\n')].strip().split())
		LTE_file.close()
		converterWiseData=[]
		LTE_data_encoded = LTE_data_encoded.split()
		LTE_data_encoded = np.vectorize(int)(LTE_data_encoded)
		
		for c in range(noConvertersInFile):
			converterWiseData.append(LTE_data_encoded[c::noConvertersInFile])
		while len(converterWiseData)<M:
			converterWiseData=converterWiseData+converterWiseData
		converterWiseData=converterWiseData[:M]
		laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData) 
		self.loadSignalToFpga(twoTNo,laneWiseData) 
		#sendCustomData
		
	@funcDecorator
	def sendNTones(self,twoTNo,fin1,amp1,fin2,amp2):
		LMFSHd=self.systemParams.LMFSHdTx[twoTNo]
		fBand1=self.systemParams.Fs*1.0/self.systemParams.ducFactorTx[0]
		fBand2=self.systemParams.Fs*1.0/self.systemParams.ducFactorTx[1]
		tone1=self.multiToneGen(fin1,amp1,4096,fBand1)
		tone2=self.multiToneGen(fin2,amp2,4096,fBand2)
		converterWiseData=[tone1[0],tone1[1],tone2[0],tone2[1]]
		laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData)
		self.loadSignalToFpga(twoTNo,laneWiseData)
		#sendSingleTone
				
	def clearRxInitStates(self):
		pass
		
	@funcDecorator	
	def fbTddEn(self,en1=1,en2=1):
		myfpga=self.regs
		myfpga.head.page.GPIO.group2.FB1EN=en1
		myfpga.head.page.GPIO.group2.FB2EN=en2
		#fbTddEn
		
	@funcDecorator
	def rxTddEn(self,en1=1,en2=1):
		myfpga=self.regs
		myfpga.head.page.GPIO.group1.RXEN1=en1
		myfpga.head.page.GPIO.group1.RXEN2=en2
		#rxTddEn
		
	@funcDecorator
	def txTddEn(self,en1=1,en2=1):
		myfpga=self.regs
		myfpga.head.page.GPIO.group2.TXEN1=en1
		myfpga.head.page.GPIO.group1.TXEN2=en2
		#txTddEn
		
	@funcDecorator
	def defGpioConfig(self):
		#""" "Configuring the FPGA Pins as needed" "Done configuring the FPGA Pins as needed" """
		myfpga=self.regs
		myfpga.head.page.GPIO.group1.SLEEP=0
		myfpga.head.page.GPIO.group1_iosel.SLEEP_out_ena=1
		myfpga.head.page.GPIO.group1_iosel.RXEN1_out_ena=1
		myfpga.head.page.GPIO.group1_iosel.RXEN2_out_ena=1
		myfpga.head.page.GPIO.group2_iosel.FB1EN_out_ena=1
		myfpga.head.page.GPIO.group2_iosel.FB2EN_out_ena=1
		myfpga.head.page.GPIO.group2_iosel.TXEN1_out_ena=1
		myfpga.head.page.GPIO.group1_iosel.TXEN2_out_ena=1
		self.rxTddEn(1,1)
		self.txTddEn(1,1)
		self.fbTddEn(1,1)
		#defGpioConfig
		
		#fpgaLib
