from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class dacAnaLib(projectBaseClass):
	"""Contains DAC Channel specific Analog functions. self.regs=device.TX.DAC_ANA """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
					
					#__init__
					
	@funcDecorator
	def setAttn(self,attn):
		""" "Setting TX DSA Attenuation" Sets the Attenuation. """
		attnWord=(2**40-1)^(2**attn-1)
		self.regs.TX_PAGE.Register41047_9Ch.Property_a4h_31_0=attnWord&(2**32-1)
		self.regs.TX_PAGE.Register41047_9Ch.Property_a8h_7_0=(attnWord>>32)&0xff
		#setAttn
		
		#dacAnaLib
