from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *

import mDacDig
reload(mDacDig)
from mDacDig import dacDigLib

import mDacAna
reload(mDacAna)
from mDacAna import dacAnaLib

import mDacAnaAB
reload(mDacAnaAB)
from mDacAnaAB import dacAnaABLib

import mDacAnaCD
reload(mDacAnaCD)
from mDacAnaCD import dacAnaCDLib

import txIqMc.mTxIqmc
reload(txIqMc.mTxIqmc)
from txIqMc.mTxIqmc import TxIqmc

class txLib(projectBaseClass):
	"""Contains TX specific functions self.regs=device.TX """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.DACANAAB=dacAnaABLib(0,regs.DAC_ANA_AB,deviceRefs)
		self.DACANACD=dacAnaCDLib(1,regs.DAC_ANA_CD,deviceRefs)
		self.DACDIG=[]
		for i in xrange(2):
			self.DACDIG.append(dacDigLib(i,regs.DAC_DIG_AB[i],deviceRefs))
			
		self.TXIQMC=TxIqmc(regs.TXIQMC.tx_iqmc,deviceRefs)
		self.DACANACH=[]
		for i in xrange(4):
			self.DACANACH.append(dacAnaLib(i,regs.DAC_ANA[i],deviceRefs))
			
			
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
					
					#__init__
					
					
					#txLib
