from globalDefs import * 
import mAfeBaseClass 
reload(mAfeBaseClass) 
from mAfeBaseClass import projectBaseClass 
import mFuncDecorator 
#reload(mFuncDecorator) 
from mFuncDecorator import * 
import random 
import math 

class rxAgcDgcLib(projectBaseClass): 
	"""Contains RX AGC AB/CD specific functions. self.regs=device.RX.DIG_AB.RxDecSet """ 
	@initDecorator 
	def __init__(self,topno,chno,regs,deviceRefs): 
		self.deviceRefs=deviceRefs 
		self.systemParams=deviceRefs.systemParams 
		self.systemStatus=deviceRefs.systemStatus 
		self.updateDeviceRefsInBaseClass(deviceRefs) 
		self.regs=regs 
		self.chno=chno 
		self.topno=topno 
		if self.systemStatus.chipVersion==0x10: 
			self.thresholdDetectorMax=2**11 
		else: 
			self.thresholdDetectorMax=2**12 
	#__init__ 
	 
	@funcDecorator 
	def intAgcBasicConfig(self): 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4cch_15_0 = 100")
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8cch_15_0 = 100")
		exec("self.regs.RxAGC"+str(self.chno)+".blank_time = 500") 
		exec("self.regs.RxAGC"+str(self.chno)+".blank_time_for_ext_comp_change = 1000") 
		exec("self.regs.RxAGC"+str(self.chno)+".disable_hysterisis = 1") 
		exec("self.regs.RxAGC"+str(self.chno)+".dig_gain_dis = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".dig_gain_dis = 0") 
		if self.systemStatus.chipVersion==0x10: 
			if self.chno==0:
				exec("self.regs.RxDSAGainPhaseCorr"+str(self.chno)+".Property_a80h_7_0 = 91")
			else:
				exec("self.regs.RxDSAGainPhaseCorr"+str(self.chno)+".gain_comp_stg_2_3_dec_chain = 91")
			self.deviceRefs.device.ignoreLogComments=1 
			step_size=1 
			attack_threshold = -9.0 
			attack_win_len = 6 
			attack_param_6 = [step_size,attack_win_len,attack_threshold] 
			self.pwr_attack_config(1,0,step_size,attack_win_len,attack_threshold) 
			self.deviceRefs.device.ignoreLogComments=0 
		else: 
			if self.chno==0:
				exec("self.regs.RxDSAGainPhaseCorr"+str(self.chno)+".Property_a80h_7_0 = 179")
			else:
				exec("self.regs.RxDSAGainPhaseCorr"+str(self.chno)+".gain_comp_stg_2_3_dec_chain = 179")
			
	#intAgcBasicConfig 
	 
	@funcDecorator 
	def ovrPhmConfig(self): 
		""" "Enabling PHM" "Done Enabling PHM" """ 
		exec("self.regs.RxDGC"+str(self.chno)+".use_lsb_bit_for_control = 1") 
		exec("self.regs.RxDGC"+str(self.chno)+".use_lsb_plus_one_bit_for_control = 1") 
		exec("self.regs.RxDGC"+str(self.chno)+".use_lsb_for_phm_decayn = 1") 
		exec("self.regs.RxAGC"+str(self.chno)+".pin_3_select_bits = 16656") 
		exec("self.regs.RxAGC"+str(self.chno)+".pin_4_select_bits = 16656") 
		exec("self.regs.RxAGC"+str(self.chno)+".enable_fifo_analog_det = 1") 
		if self.chno==0:
			exec("self.regs.Register37538_545h.pdn_in = 0") 
		else:
			exec("self.regs.Register37565_945h.pdn_in = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_det_en = 1") 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_484h_0_0 = 1")
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_884h_0_0 = 1")
	#initPhmConfig 
	 
	@funcDecorator 
	def clearStatusRegs(self): 
		exec("self.regs.RxAGC"+str(self.chno)+".restart_max_min = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".restart_max_min = 1") 
		exec("self.regs.RxAGC"+str(self.chno)+".restart_max_min = 0") 
	#clearStatusRegs 
		 
	@funcDecorator 
	def updateStatus(self): 
		exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['currAttn']=self.regs.RxAGC"+str(self.chno)+"._curr_attn.getValue()")	 
		exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['currExtLnaEn']=self.regs.RxAGC"+str(self.chno)+"._curr_ext_lna_en.getValue()") 
		if self.chno==0:
			exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['currDvgaAttn']=self.regs.RxAGC"+str(self.chno)+"._Property_4d8h_5_0.getValue()") 
		else:
			exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['currDvgaAttn']=self.regs.RxAGC"+str(self.chno)+"._Property_8d8h_5_0.getValue()") 
		exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['maxAttnUsed']=self.regs.RxAGC"+str(self.chno)+"._max_attn.getValue()") 
		exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['minAttnUsed']=self.regs.RxAGC"+str(self.chno)+"._min_attn.getValue()") 
		exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['lnaBypassChanged']=self.regs.RxAGC"+str(self.chno)+"._lna_bypass_changed.getValue()") 
		exec("self.systemStatus.agcStatusConfig[(self.topno*2)+self.chno]['attnChanged']=self.regs.RxAGC"+str(self.chno)+"._attn_changed.getValue()") 
	#updateStatus 
	 
	@funcDecorator 
	def int_agc_en(self,en=1): 
		""" "Enabling or disabling Internal AGC" "DOne enabling or disabling Internal AGC" """ 
		if en==1: 
			exec("self.regs.RxAGC"+str(self.chno)+".ext_agc_mode = 0") 
			exec("self.regs.RxAGC"+str(self.chno)+".internal_agc_en = 0") 
			exec("self.regs.RxAGC"+str(self.chno)+".internal_agc_en = 1") 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+".ext_agc_mode = 1") 
			exec("self.regs.RxAGC"+str(self.chno)+".internal_agc_en =  0") 
	#int_agc_en	 
	 
	@funcDecorator 
	def int_agc_dis(self): 
		exec("self.regs.RxAGC"+str(self.chno)+".internal_agc_en =  0") 
	#int_agc_dis 
	 
	@funcDecorator 
	def default_handler(self): 
		exec("self.regs.RxAGC"+str(self.chno)+".ext_agc_mode = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".def_attn = 22") 
		exec("self.regs.RxAGC"+str(self.chno)+".def_lna_byp_val = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".dont_use_abs_rel_trig = 1") 
		exec("self.regs.RxAGC"+str(self.chno)+".dont_use_rel_rel_trig = 1") 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_cd8h_5_0 = 5") 
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_ed8h_5_0 = 5") 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_decay_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_attack_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_decay_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_attack_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_intm_decay_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_intm_attack_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".ext_lna_cntl_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_det_en = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".min_attn = 2") 
		exec("self.regs.RxAGC"+str(self.chno)+".max_attn = 30") 
		exec("self.regs.RxAGC"+str(self.chno)+".min_dvga_attn = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".max_dvga_attn = 13") 
		exec("self.regs.RxAGCcommon.agc_inp_toff"+str(self.chno)+" = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".dis_sig_invalid = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".dig_gain_dis = 1") 
		exec("self.regs.RxAGC"+str(self.chno)+".attack_dets_reset_at_rx_on = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".decay_dets_reset_at_rx_on = 0") 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4a4h_0_0 = 0") 
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8a4h_0_0 = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".use_running_accum_for_attack = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".decouple_decay_dets = 1") 
		exec("self.regs.RxAGC"+str(self.chno)+".restart_max_min = 0") 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_cd0h_1_0 = 0") 
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_ed0h_1_0 = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".enable_fifo_analog_det = 1") 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4cch_15_0 = 100") 
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8cch_15_0 = 100") 
		exec("self.regs.RxAGC"+str(self.chno)+".blank_time = 500") 
		exec("self.regs.RxAGC"+str(self.chno)+".blank_time_for_ext_comp_change = 1000") 
	#default_handler 
	 
	@funcDecorator 
	def agc_freeze_config(self,freeze,reg_freeze,pin_freeze_en): 
	 
		if(freeze==1): 
			exec("self.regs.RxAGC"+str(self.chno)+".agc_freeze = 1") 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+".agc_freeze = 0") 
		 
		if(reg_freeze == 1): 
			exec("self.regs.RxAGC"+str(self.chno)+"agc_freeze_reg_ctrl = 1") 
			exec("self.regs.RxAGC"+str(self.chno)+"reg_agc_loop_freeze = 1") 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+"agc_freeze_reg_ctrl = 0") 
			exec("self.regs.RxAGC"+str(self.chno)+"reg_agc_loop_freeze = 0") 
		 
		if(pin_freeze_en==1): 
			exec("self.regs.RxAGC"+str(self.chno)+"agc_freeze_pin_en = 1") 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+"agc_freeze_pin_en = 0") 
			 
	#agc_freeze_config 
	 
	@funcDecorator 
	def ext_lna_ctrl(self,enable,lna_bypass_gain,gain_margin): 
		""" "Configuring External LNA Control" "Done configuring External LNA Control" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".ext_lna_cntl_en = "+str(enable)) 
		if enable==True: 
			exec("self.regs.RxAGC"+str(self.chno)+".gain0 = "+str(lna_bypass_gain*32)) 
			exec("self.regs.RxAGC"+str(self.chno)+".ext_lna_gain_margin = "+str(gain_margin)) 
	#ext_lna_ctrl 

	@funcDecorator 
	def big_step_attack_en(self,enable,attack_step_size,attack_th,attack_th_low,attack_win_len,attack_num_hits): 
		""" "Configuring Big Step Attack Detector" "Done configuring Big Step Attack Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_step_size = "+str(attack_step_size)) 
		self.param_1 = self.thresholdDetectorMax*(10**(attack_th/20.0)) 
		self.param_2 = self.thresholdDetectorMax*(10**(attack_th_low/20.0)) 
		info("attack_value: "+str(self.param_1)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_sig_th_high = "+str(self.param_1)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_sig_th_low = "+str(self.param_2)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_win_len = "+str(attack_win_len)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_num_hits = "+str(attack_num_hits)) 
		if self.systemParams.agcRegConfigParams[(2*self.topno)+self.chno]['enableIa']==True: 
			exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_en = "+str(enable)) 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_en = "+str(0)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_attack_det_en = "+str(enable)) 
	#big_step_attack_en 
	 
	@funcDecorator 
	def big_step_decay_en(self,enable,attack_step_size,attack_th,attack_th_low,attack_win_len,attack_num_hits): 
		""" "Configuring Big Step Decay Detector" "Done configuring Big Step Decay Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_syncmode = 0") 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_step_size = "+str(attack_step_size)) 
		self.param_1 = self.thresholdDetectorMax*(10**(attack_th/20.0)) 
		info("decay_value: "+str(self.param_1)) 
		self.param_2 = self.thresholdDetectorMax*(10**(attack_th_low/20.0)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_sig_th_high = "+str(self.param_1)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_sig_th_low = "+str(self.param_2)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_win_len = "+str(attack_win_len)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_num_hits = "+str(attack_num_hits)) 
		if self.systemParams.agcRegConfigParams[(2*self.topno)+self.chno]['enableIa']==True: 
			exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_en = "+str(enable)) 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_en = "+str(0)) 
		exec("self.regs.RxAGC"+str(self.chno)+".big_step_decay_det_en = "+str(enable)) 
		 
	#big_step_decay_config 
	 
	@funcDecorator 
	def small_step_attack_en(self,enable, attack_step_size,attack_th,attack_th_low,attack_win_len,attack_num_hits): 
		""" "Configuring Small Step Attack Detector" "Done configuring Small Step Attack Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_step_size = "+str(attack_step_size)) 
		self.param_1 = self.thresholdDetectorMax*(10**(attack_th/20.0)) 
		info("attack_value: "+str(self.param_1)) 
		self.param_2 = self.thresholdDetectorMax*(10**(attack_th_low/20.0)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_sig_th_high = "+str(self.param_1)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_sig_th_low = "+str(self.param_2)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_win_len = "+str(attack_win_len)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_num_hits = "+str(attack_num_hits)) 
		if self.systemParams.agcRegConfigParams[(2*self.topno)+self.chno]['enableIa']==True: 
			exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_en = "+str(enable)) 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_en = "+str(0)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_attack_det_en = "+str(enable)) 
		 
	#small_step_attack_config 
	 
	@funcDecorator 
	def small_step_decay_en(self,enable,attack_step_size,attack_th,attack_th_low,attack_win_len,attack_num_hits): 
		""" "Configuring Small Step Decay Detector" "Done configuring Small Step Decay Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_step_size = "+str(attack_step_size)) 
		self.param_1 = self.thresholdDetectorMax*(10**(attack_th/20.0)) 
		self.param_2 = self.thresholdDetectorMax*(10**(attack_th_low/20.0)) 
		info("decay_value: "+str(self.param_1)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_sig_th_high = "+str(self.param_1)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_sig_th_low = "+str(self.param_2)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_win_len = "+str(attack_win_len)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_num_hits = "+str(attack_num_hits)) 
		if self.systemParams.agcRegConfigParams[(2*self.topno)+self.chno]['enableIa']==True: 
			exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_en = "+str(enable)) 
		else: 
			exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_en = "+str(0)) 
		exec("self.regs.RxAGC"+str(self.chno)+".small_step_decay_det_en = "+str(enable)) 
		 
	#small_step_decay_config 
	 
	@funcDecorator 
	def rf_attack_config(self,enable,param): 
		""" "Configuring RF Attack Detector" "Done configuring RF Attack Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_attack_step_size = "+str(param[0])) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_det_attack_win_len = "+str(param[1])) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_det_attack_num_hits = "+str(param[2])) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_attack_en = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_attack_det_en = "+str(enable)) 
		 
	#rf_attack_en 
	 
	@funcDecorator 
	def rf_decay_config(self,enable,param): 
		""" "Configuring RF Decay Detector" "Done configuring RF Decay Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_decay_step_size = "+str(param[0])) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_det_decay_win_len = "+str(param[1])) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_det_decay_num_hits = "+str(param[2])) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_decay_en = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".rf_decay_det_en = "+str(enable)) 
	#rf_decay_en 
	 
	@funcDecorator 
	def adc_intm_attack_config(self,enable,param): 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4a8h_5_0 = "+str(param[0])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4ach_23_0 = "+str(param[1])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4b8h_27_0 = "+str(param[2])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4a0h_0_0 = "+str(enable)) 
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8a8h_5_0 = "+str(param[0])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8ach_23_0 = "+str(param[1])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8b8h_27_0 = "+str(param[2])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8a0h_0_0 = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_intm_attack_det_en = "+str(enable)) 
	#adc_intm_decay_en 
	 
	@funcDecorator 
	def adc_intm_decay_config(self,enable,param): 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_intm_decay_step_size = "+str(param[0])) 
		if self.chno==0:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4b0h_23_0 = "+str(param[1])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_4bch_27_0 = "+str(param[2])) 
		else:
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8b0h_23_0 = "+str(param[1])) 
			exec("self.regs.RxAGC"+str(self.chno)+".Property_8bch_27_0 = "+str(param[2])) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_intm_decay_en = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_intm_decay_det_en = "+str(enable)) 
		 
	#adc_intm_attack_en 
	 
	@funcDecorator 
	def adc_ovr_en(self,enable,param): 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_step_size = "+str(param[0])) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_win_len = "+str(param[1])) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_num_hits = "+str(param[2])) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_en = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".adc_ovr_det_en = "+str(enable)) 
		 
	#adc_ovr_en 
	 
	@funcDecorator 
	def pwr_attack_config(self,enable,mode,step_size,attack_win_len,attack_threshold): 
		""" "Configuring Power Attack Detector" "Done configuring Power Attack Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_det_inp_mode = "+str(mode)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_attack_step_size = "+str(step_size)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_det_attack_win_len = "+str(attack_win_len)) 
		self.param_2 = (2**16)*(10**(attack_threshold/10)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_det_attack_th = "+str(self.param_2)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_attack_en = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_attack_det_en = "+str(enable)) 
		 
	#pwr_attack_config 
	 
	@funcDecorator 
	def pwr_decay_config(self,enable,mode,param): 
		""" "Configuring Power Decay Detector" "Done configuring Power Decay Detector" """ 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_det_inp_mode = "+str(mode)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_decay_step_size = "+str(step_size)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwrdet_decay_win_len = "+str(attack_win_len)) 
		self.param_2 = (2**16)*(10**(attack_threshold/10)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_det_decay_th = "+str(self.param_2)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_decay_en = "+str(enable)) 
		exec("self.regs.RxAGC"+str(self.chno)+".pwr_decay_det_en = "+str(enable)) 
	#pwr_decay_en 
	 
	@funcDecorator 
	def configDgcCoarseFine(self,dgc_enable,coarse_index_bits,coarse_step): 
		""" "Configuring DGC" "Done configuring DGC" """ 
		dgc_mode   = self.systemParams.agcRegConfigParams[self.chno]['dgcMode'] 
		coarse_index_invert = 0 
		coarse_index_swap   = 0 
		flt_pt_fmt  = 0 
		flt_pt_mode = 0 
		exec("self.regs.RxDGC"+str(self.chno)+".DgcEnRxMode = dgc_enable") 
		if dgc_enable==True: 
			exec("self.regs.RxDGC"+str(self.chno)+".FltPtMode = flt_pt_mode") 
			exec("self.regs.RxDGC"+str(self.chno)+".FltPtFmt = flt_pt_fmt") 
			exec("self.regs.RxDGC"+str(self.chno)+".DgcMode = dgc_mode") 
			exec("self.regs.RxDGC"+str(self.chno)+".NBitsCoarseIdx = coarse_index_bits") 
			exec("self.regs.RxDGC"+str(self.chno)+".CoarseStep = coarse_step") 
			if self.chno==0:
				exec("self.regs.RxDGC"+str(self.chno)+".Property_4f8h_13_0 = 2") ## some non-zero value 
			else:
				exec("self.regs.RxDGC"+str(self.chno)+".AttnCodeDelay = 2") ## some non-zero value 
			exec("self.regs.RxDGC"+str(self.chno)+".UseMinAttnFromAgc = 1") 
			exec("self.regs.RxDGC"+str(self.chno)+".CoarseIndexSwapIandQ = coarse_index_swap") 
			exec("self.regs.RxDGC"+str(self.chno)+".CoarseIndexInvert = coarse_index_invert") 
	#configDgcCoarseFine 
	
	@funcDecorator 
	def configDgcFloatingPoint(self,dgc_enable,flt_pt_mode,flt_pt_fmt): 
		""" "Configuring DGC" "Done configuring DGC" """ 
		exec("self.regs.RxDGC"+str(self.chno)+".DgcEnRxMode = dgc_enable") 
		if dgc_enable==True: 
			exec("self.regs.RxDGC"+str(self.chno)+".FltPtMode = flt_pt_mode") 
			exec("self.regs.RxDGC"+str(self.chno)+".FltPtFmt = flt_pt_fmt") 
			exec("self.regs.RxDGC"+str(self.chno)+".DgcMode = 0") 
			if self.chno==0:
				exec("self.regs.RxDGC"+str(self.chno)+".Property_4f8h_13_0 = 2") ## some non-zero value 
			else:
				exec("self.regs.RxDGC"+str(self.chno)+".AttnCodeDelay = 2") ## some non-zero value 
				
			exec("self.regs.RxDGC"+str(self.chno)+".UseMinAttnFromAgc = 1") 
	#configDgcCoarseFine 
	 
	@funcDecorator 
	def setupProcess(self): 
		process=self.deviceRefs.process 
		exec("process.floatingPointCoarseGain.dgcEn = "+"self.regs.RxDGC"+str(self.chno)+".DgcEnRxMode") 
		exec("process.floatingPointCoarseGain.DgcEnRxMode = "+"self.regs.RxDGC"+str(self.chno)+".DgcEnRxMode") 
		exec("process.floatingPointCoarseGain.DgcMode = "+"self.regs.RxDGC"+str(self.chno)+".DgcMode") 
		exec("process.floatingPointCoarseGain.FltPtMode = "+"self.regs.RxDGC"+str(self.chno)+".FltPtMode") 
		exec("process.floatingPointCoarseGain.FltPtFmt = "+"self.regs.RxDGC"+str(self.chno)+".FltPtFmt") 
		exec("process.floatingPointCoarseGain.CoarseStep = "+"self.regs.RxDGC"+str(self.chno)+".CoarseStep") 
		exec("process.floatingPointCoarseGain.NBitsCoarseIdx = "+"self.regs.RxDGC"+str(self.chno)+".NBitsCoarseIdx") 
		exec("process.floatingPointCoarseGain.CoarseIndexInvert = "+"self.regs.RxDGC"+str(self.chno)+".CoarseIndexInvert") 
		exec("process.floatingPointCoarseGain.CoarseIndexSwapIandQ = "+"self.regs.RxDGC"+str(self.chno)+".CoarseIndexInvert") 
	#setupProcess 
	 
#rxAgcLib