

Current Libraries Version	: 77xx-2.17

Libraries Version (77xx-2.17)
	77xx-PG1.x:
		Fixed issue with RX interface rate of X/2
		Updated iGui
		Updated half rate mode support for more interface rates
		SYNCIN termination is added
		Fixed bug in TX/RX IQMC enable
		Fixed issue in calling rxAnaWrites
		Updated FIFO pointer values
		Fixed issue in capture for FB LMFSHd "22210"
		Updated rxAdcBw for SNR improvement in RX
		Added FPGA reset and reload functions
		Fixed issue in configuring GPIO crossbar option
		Fixed issue in LMK configure
		Updated Trims loading for more bands
		Added function to update TX-FB loopback for TX IQMC
		Fixed issue with loging delay
		Updated nearest trim frequency for PLL
	77xx-PG2:
		Fixed issue with RX interface rate of X/2
		Updated iGui
		Updated half rate mode support for more interface rates
		SYNCIN termination is added
		Fixed bug in TX/RX IQMC enable
		Fixed issue in calling rxAnaWrites
		Fixed issue in capture for FB LMFSHd "22210"
		Fixed issue with PAP alarm clear
		Updated rxAdcBw for SNR improvement in RX
		Added FPGA reset and reload functions
		Fixed issue in configuring GPIO crossbar option
		Fixed issue in LMK configure
		Updated Trims loading for more bands
		Added function to update TX-FB loopback for TX IQMC
		removed reads in FBCD
		Fixed issue with loging delay
		Updated nearest trim frequency for PLL
		
Libraries Version (77xx-2.14)
	77xx-PG1.x:
		Added Host update mode for TX IQMC
		Fixed issue in GPIO status display of iGui
		Fixed issues in half rate mode support
		Fixed issues in AGC-DGC
		Updated Logging
		Updated Trims loading for more bands
	77xx-PG2:
		Fixed issues in analog performance writes
		Added Host update mode for TX IQMC
		Fixed issue in GPIO status display of iGui
		Fixed issues in half rate mode support
		Fixed issues in AGC-DGC
		Updated Logging
		Updated Trims loading for more bands
				
Libraries Version (77xx-2.13.2)
	Updated Logging
	Added Support for cut-die version (77xx-PG2)
	Fixed issue with GPIO status display in iGui
	Added option to release TX-FB Mux Select control to pins at the end of config. (sysParams.releaseTxMuxControlToPins)
	
Libraries Version (77xx-2.11)
	Fixed issues with analog writes
	Added function to configure low IF
	
Libraries Version (77xx-2.10)
	Updated analog writes to fix RX IQMC and out of band peaking issue. (further updates pending, will be done in next release)
	Added floating point mode of DGC
	Fixed issue of lower LO frequencies not locking
	Optimized some wait times to cut down bringup time
	
Libraries Version (77xx-2.9)
	Fixed TX Loopback char issue
	Support for generic sampling rates other than 2949.12, 3317.76, and 3440.64M is added.
	Added Per TX FB DSA
	Support for lane rate of 16.22Gsps and its factors added

Libraries Version (77xx-2.8)
	Updated iGui
	Fixed Issues with External AGC Mode Config
	Updated Documentation
	Added Serdes Polarity Config
	Updated config to prevent current peaking during bring up
	Fixed issue in RX DSA Calibration
	
Libraries Version (77xx-2.7)
	Added way to load RX and TX DSA calibration packet.
	Fixed bug in the patch which effects setting TX DSA using MACRO

Libraries Version (77xx-2.6)
	Added TX External Delay Char function
	Fixed the selectCh function for DAC side.
	Updated TX IQMC Patch
	Forcing Sync Pins to high during SERDES adaptation for better adaptation.
	Updated FB Ana Writes

Libraries Version (77xx-2.5)
	Test Version
	
Libraries Version (77xx-2.4)
	Updated the Serdes download for reset
	Fixed bugs related to 1x EVM
	Improved log file comments by adding Steps
	Added more functions useful in debug
	Added SERDES firmware reload writes
	Fixed Bugs for Bench EVM
	Updated Fb ANa Writes for Fs=3317.76
	Updated The PLL config for GSM
	Added more AGC, SR, PAP functions
	Fixed the RX Analog writes to handle the efuse.
	Fixed bug in log
	Added TDD option for individual 2T2R1F.
	Loading the TOP Patch.
	
Libraries Version (77xx-2.3)
	Test Version
	
Libraries Version (77xx-2.2) Note: (30-01-2019)
	For all PLL Mux Modes, except 0, the writes to reduce the IBS spur are added.
	Support for low IF NCOs for all the chains along with IQMC.

Libraries Version (77xx-2.1) Note: (28-11-2018)
	Support for PG1.0, sending Custom Data and Reading DSA attenuation added.
	Support for PG1.1 version of the device.
	Updated FB ana writes with latest provided.
	Added Support for Latest EVM(HSC-1373) and also the 1-device EVM (interfaced with J56/57 also with J58).
	Added support for CPLD, current Sense.
	Customer EVM board Support added.
	RX & TX IQMC updated
	RX & TX DSA Calibration updated
	Support for low IF NCOs for all the chains along with IQMC.
	Serdes Firmware download through Macro.
	efuse Loads added
	FB DSA codes gets selected based on NCO
	Added more comments for the Log dump and new formats for log dump added
	Added the fix for the RX DC correction saturation issue
	Added more features for GUI
