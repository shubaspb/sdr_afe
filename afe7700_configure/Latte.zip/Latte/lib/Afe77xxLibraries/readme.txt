Current Libraries Version	: 77xx-2.20
Libraries Version (77xx-2.20)
	77xx-PG1.x:
		Fixed a bug which caused lane polarity not being set
		Fixed RX noise floor issue at DC clock of 54X
		Fixed a bug in TX IQMC delay char
	77xx-PG2:
		Fixed a bug which caused lane polarity not being set
		Fixed RX noise floor issue at DC clock of 54X
		Fixed a bug in TX IQMC delay char

Libraries Version (77xx-2.19)
	77xx-PG1.x:
		Added library version print out on the log file
		Fixed a bug which caused jesdConfig step to run two times
	77xx-PG2:
		Added library version print out on the log file
		Fixed a bug which caused jesdConfig step to run two times

Libraries Version (77xx-2.18)
	77xx-PG1.x:
		RX_ddc/FB_ddc factor need not to be 1,2,3 or 4
		Maximum sysref frequency, which can be supported, is improved for some cases
		Support separate linkup sequence
		Added AFE.relinkJesd function. Can be used to relink when linkup sequence is separate
		Both NCO0&1 of FB can be programmed. NCO1 frequency can be specified using sysParams.fbNcoBand1
        Added a sysParam to configure alarm mask for PAP.(sysParams.srParamsDict[ch]['alarmMask'])
		Reduced number of register writes when single link is used - sysParams.enableRxFbJesd and sysParams.enableTxJesd to indicate whether single link is used
		Supports subclass1 implementation for jesd204B
		Updated supports for JESD204C
		For JESD204C mode RX_F and FB_F can be different for shared lane mode.
		Extented multiblock of more than one is supported
		Added loading FB IMD packets based on band of use
		Fixed issue seen in less than 900M LO
		Fixed issues seen in pllMuxModes of 2,3,4
		Fixed issues seen in host trigger mode
		DC PLL BW is increased for higher phase noise performance
		Updated performance for pllMuxModes of 4
		Updated serdes configuration loading
		Updated AFE.adcDacSync function
		Updated AFE.anaWritesForTddMode2T2R function
		Updated AFE.loadRawConfig function
		Updated TX-FB delay values
		Added sysParams.enableTxIqmcDelayChar for TX-FB delay calculation
		Added freeze and unfreeze functions for TX and RX Qec in mAfeLibrary
		Supports manual CTLE - added sysParams
		Other bug fixes
		
	77xx-PG2:
		RX_ddc/FB_ddc factor need not to be 1,2,3 or 4
		Maximum sysref frequency, which can be supported, is improved for some cases
		Support separate linkup sequence
		Added AFE.relinkJesd function. Can be used to relink when linkup sequence is separate
		Both NCO0&1 of FB can be programmed. NCO1 frequency can be specified using sysParams.fbNcoBand1
        Added a sysParam to configure alarm mask for PAP.(sysParams.srParamsDict[ch]['alarmMask'])
		Reduced number of register writes when single link is used - sysParams.enableRxFbJesd and sysParams.enableTxJesd to indicate whether single link is used
		Supports subclass1 implementation for jesd204B
		Updated supports for JESD204C
		For JESD204C mode RX_F and FB_F can be different for shared lane mode.
		Extented multiblock of more than one is supported
		Added loading FB IMD packets based on band of use
		Fixed issue seen in less than 900M LO
        Fixed issues seen in pllMuxModes of 2
		DC PLL BW is increased for higher phase noise performance
		Updated serdes configuration loading
		Updated AFE.adcDacSync function
		Updated AFE.anaWritesForTddMode2T2R function
		Updated TX-FB delay values
		Added sysParams.enableTxIqmcDelayChar for TX-FB delay calculation
		Added freeze and unfreeze functions for TX and RX Qec in mAfeLibrary
		Supports manual CTLE - added sysParams
        Updated delay values
		Other bug fixes

Libraries Version (77xx-2.17)
	77xx-PG1.x:
		Fixed issue with RX interface rate of X/2
		Updated iGui
		Updated half rate mode support for more interface rates
		SYNCIN termination is added
		Fixed bug in TX/RX IQMC enable
		Fixed issue in calling rxAnaWrites
		Updated FIFO pointer values
		Fixed issue in capture for FB LMFSHd "22210"
		Updated rxAdcBw for SNR improvement in RX
		Added FPGA reset and reload functions
		Fixed issue in configuring GPIO crossbar option
		Fixed issue in LMK configure
		Updated Trims loading for more bands
		Added function to update TX-FB loopback for TX IQMC
		Fixed issue with loging delay
		Updated nearest trim frequency for PLL
	77xx-PG2:
		Fixed issue with RX interface rate of X/2
		Updated iGui
		Updated half rate mode support for more interface rates
		SYNCIN termination is added
		Fixed bug in TX/RX IQMC enable
		Fixed issue in calling rxAnaWrites
		Fixed issue in capture for FB LMFSHd "22210"
		Fixed issue with PAP alarm clear
		Updated rxAdcBw for SNR improvement in RX
		Added FPGA reset and reload functions
		Fixed issue in configuring GPIO crossbar option
		Fixed issue in LMK configure
		Updated Trims loading for more bands
		Added function to update TX-FB loopback for TX IQMC
		removed reads in FBCD
		Fixed issue with loging delay
		Updated nearest trim frequency for PLL
		
Libraries Version (77xx-2.14)
	77xx-PG1.x:
		Added Host update mode for TX IQMC
		Fixed issue in GPIO status display of iGui
		Fixed issues in half rate mode support
		Fixed issues in AGC-DGC
		Updated Logging
		Updated Trims loading for more bands
	77xx-PG2:
		Fixed issues in analog performance writes
		Added Host update mode for TX IQMC
		Fixed issue in GPIO status display of iGui
		Fixed issues in half rate mode support
		Fixed issues in AGC-DGC
		Updated Logging
		Updated Trims loading for more bands
				
Libraries Version (77xx-2.13.2)
	Updated Logging
	Added Support for cut-die version (77xx-PG2)
	Fixed issue with GPIO status display in iGui
	Added option to release TX-FB Mux Select control to pins at the end of config. (sysParams.releaseTxMuxControlToPins)
	
Libraries Version (77xx-2.11)
	Fixed issues with analog writes
	Added function to configure low IF
	
Libraries Version (77xx-2.10)
	Updated analog writes to fix RX IQMC and out of band peaking issue. (further updates pending, will be done in next release)
	Added floating point mode of DGC
	Fixed issue of lower LO frequencies not locking
	Optimized some wait times to cut down bringup time
	
Libraries Version (77xx-2.9)
	Fixed TX Loopback char issue
	Support for generic sampling rates other than 2949.12, 3317.76, and 3440.64M is added.
	Added Per TX FB DSA
	Support for lane rate of 16.22Gsps and its factors added

Libraries Version (77xx-2.8)
	Updated iGui
	Fixed Issues with External AGC Mode Config
	Updated Documentation
	Added Serdes Polarity Config
	Updated config to prevent current peaking during bring up
	Fixed issue in RX DSA Calibration
	
Libraries Version (77xx-2.7)
	Added way to load RX and TX DSA calibration packet.
	Fixed bug in the patch which effects setting TX DSA using MACRO

Libraries Version (77xx-2.6)
	Added TX External Delay Char function
	Fixed the selectCh function for DAC side.
	Updated TX IQMC Patch
	Forcing Sync Pins to high during SERDES adaptation for better adaptation.
	Updated FB Ana Writes

Libraries Version (77xx-2.5)
	Test Version
	
Libraries Version (77xx-2.4)
	Updated the Serdes download for reset
	Fixed bugs related to 1x EVM
	Improved log file comments by adding Steps
	Added more functions useful in debug
	Added SERDES firmware reload writes
	Fixed Bugs for Bench EVM
	Updated Fb ANa Writes for Fs=3317.76
	Updated The PLL config for GSM
	Added more AGC, SR, PAP functions
	Fixed the RX Analog writes to handle the efuse.
	Fixed bug in log
	Added TDD option for individual 2T2R1F.
	Loading the TOP Patch.
	
Libraries Version (77xx-2.3)
	Test Version
	
Libraries Version (77xx-2.2) Note: (30-01-2019)
	For all PLL Mux Modes, except 0, the writes to reduce the IBS spur are added.
	Support for low IF NCOs for all the chains along with IQMC.

Libraries Version (77xx-2.1) Note: (28-11-2018)
	Support for PG1.0, sending Custom Data and Reading DSA attenuation added.
	Support for PG1.1 version of the device.
	Updated FB ana writes with latest provided.
	Added Support for Latest EVM(HSC-1373) and also the 1-device EVM (interfaced with J56/57 also with J58).
	Added support for CPLD, current Sense.
	Customer EVM board Support added.
	RX & TX IQMC updated
	RX & TX DSA Calibration updated
	Support for low IF NCOs for all the chains along with IQMC.
	Serdes Firmware download through Macro.
	efuse Loads added
	FB DSA codes gets selected based on NCO
	Added more comments for the Log dump and new formats for log dump added
	Added the fix for the RX DC correction saturation issue
	Added more features for GUI
