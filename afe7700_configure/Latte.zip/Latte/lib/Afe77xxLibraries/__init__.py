import os,sys
#def symlink(source, link_name):
#	import os
#	os_symlink = getattr(os, "symlink", None)
#	import ctypes
#	csl = ctypes.windll.kernel32.CreateSymbolicLinkW
#	csl.argtypes = (ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32)
#	csl.restype = ctypes.c_ubyte
#	flags = 1 if os.path.isdir(source) else 0
#	if csl(link_name, source, flags) == 0:
#		raise ctypes.WinError()
#os.symlink=symlink
import globalDefs as Globals

folderDirDict={}
folderDirDict['AFE77xxLibraryTC']={}
folderDirDict['AFE77xxLibraryTC']['chipId']=(0x77,0x7777)
folderDirDict['AFE77xxLibraryTC']['chipVersion']=(0x00,0x01)
folderDirDict['AFE77xxLibraryTC']['dmlName']='Afe77xxTC.dml'

folderDirDict['AFE77xxLibraryPG1']={}
folderDirDict['AFE77xxLibraryPG1']['chipId']=(0x77,0x7777)
folderDirDict['AFE77xxLibraryPG1']['chipVersion']=(0x10,)
folderDirDict['AFE77xxLibraryPG1']['dmlName']='Afe77xxPG1.dml'


folderDirDict['AFE77xxLibraryPG1P1']={}
folderDirDict['AFE77xxLibraryPG1P1']['chipId']=(0x77,0x7777)
folderDirDict['AFE77xxLibraryPG1P1']['chipVersion']=(0x11,)
folderDirDict['AFE77xxLibraryPG1P1']['dmlName']='Afe77xxPG1p1.dml'

folderDirDict['AFE77xxLibraryPG2']={}
folderDirDict['AFE77xxLibraryPG2']['chipId']=(0x77,0x7777)
folderDirDict['AFE77xxLibraryPG2']['chipVersion']=(0x20,)
folderDirDict['AFE77xxLibraryPG2']['dmlName']='AFE77xxPG2.dml'

def getFolderName(chipId,chipVersion):
	libFolderName=None
	for folderName in os.listdir(Globals.ASTERIX_DIR+Globals.DEVICES_DIR):
		for path in sys.path:
			if folderName in path:
				sys.path.remove(path)
				
	#print(folderDirDict.keys())			
	for folderName in folderDirDict.keys():
		path1=Globals.ASTERIX_DIR+Globals.DEVICES_DIR+r"\Afe77xxLibraries\\"+folderName
		if chipId in folderDirDict[folderName]['chipId'] and chipVersion in folderDirDict[folderName]['chipVersion'] and folderName in os.listdir(Globals.ASTERIX_DIR+Globals.DEVICES_DIR+r"\Afe77xxLibraries"):
			if 'dmlNameList' in folderDirDict[folderName]:
				folderDirDict[folderName]['dmlName']=folderDirDict['AFE77xxLibraryPG1']['dmlNameList'][chipVersion]
			Globals.libFolderPath=path1
			#Globals.libFolderPath=os.getcwd()+r"\\"+folderName
			if path1 not in sys.path:
				sys.path.append(Globals.libFolderPath)
			if path1+r"\\resourceFiles" not in sys.path:
				sys.path.append(Globals.libFolderPath+r"\\resourceFiles")
			libFolderName=folderName
		else:
			if path1 in sys.path:
				sys.path.remove(path1)
			if path1+r"\\resourceFiles" in sys.path:
				sys.path.remove(path1+r"\\resourceFiles")
			
	return libFolderName