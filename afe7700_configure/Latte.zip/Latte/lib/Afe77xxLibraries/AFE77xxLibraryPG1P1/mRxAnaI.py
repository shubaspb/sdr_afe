from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class rxAnaILib(projectBaseClass):
	"""Contains RX EC DIG I specific functions. self.regs=device.RX_ANA_I """
	@initDecorator
	def __init__(self,topno,chno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
		self.chno=chno
		self.errorList=[topno,chno]
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
	
	#__init__

	@funcDecorator
	def pdnFrontEnd(self,pdn):
		self.regs.PDN_MATRIX.PDN_MATRIX_FE.Register9139_C70h.Property9144_3_3 = pdn
		self.regs.PDN_MATRIX.PDN_MATRIX_FE.Register9139_C70h.Property9145_4_4 = pdn
		self.regs.BB_FILTER_I.BB_FILTER_MODES.Register9112_103h.Property9115_31_31 = pdn
	#pdnFrontEnd

#rxAnaILib