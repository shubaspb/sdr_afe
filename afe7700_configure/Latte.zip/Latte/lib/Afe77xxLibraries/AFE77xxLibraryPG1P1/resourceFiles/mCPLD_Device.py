from HSCDevices import *
from mConnect import *
import globalDefs as Globals
import os

class CPLD(Device):
	delay_time=0.01
	logEn = Object(typ = Boolean, label = "log Enable")
	rawWriteLogEn=0
	rawWriteLogsFile=r"C:/rawWriteLogs1.txt"
	commentForWrite=""
	rewriteFile=0
	prevAddress=0
	extTesterLog=1
	optimizeWrites=0
	ignoreLogComments=0
	hardReadAlways = False
	mappingDict = {'C17': 'GPIOD5', 'T13': 'GPIOC6', 'D15': 'GPIOC5', 'V7': 'GPIOB20', 'T16': 'GPIOD12', 'V11': 'GPIOB26', 'Y18': 'GPIOE6', 'C18': 'GPIOD9', 'D12': 'GPIOB13', 'V14': 'GPIOD10', 'T18': 'GPIOE2', 'U17': 'GPIOE1', 'D7': 'GPIOB5', 'F18': 'GPIOD6', 'V13': 'GPIOC8', 'V18': 'GPIOE4', 'E16': 'GPIOD1', 'E17': 'GPIOD3', 'T5': 'GPIOB16', 'D6': 'GPIOB3', 'W18': 'GPIOE5', 'U14': 'GPIOC9', 'U6': 'GPIOB17', 'V15': 'GPIOD11', 'D13': 'GPIOC2', 'V16': 'GPIOD14', 'C12': 'GPIOB14', 'U15': 'GPIOC10', 'V6': 'GPIOB18', 'V10': 'GPIOB24', 'U18': 'GPIOE3', 'U12': 'GPIOB27', 'E5': 'GPIOB2', 'D18': 'GPIOD8', 'D11': 'GPIOB11', 'C8': 'GPIOB7', 'C11': 'GPIOB12', 'R17': 'GPIOD15', 'V9': 'GPIOB22', 'E13': 'GPIOC1', 'V8': 'GPIOB21', 'D10': 'GPIOB9', 'U16': 'GPIOD13', 'R5': 'GPIOB15', 'C10': 'GPIOB10', 'U13': 'GPIOC7', 'V12': 'GPIOB28', 'D17': 'GPIOD4', 'U10': 'GPIOB23', 'R18': 'GPIOD17', 'U11': 'GPIOB25', 'C9': 'GPIOB8', 'C6': 'GPIOB4', 'E18': 'GPIOD7', 'C13': 'GPIOC3', 'U7': 'GPIOB19', 'F5': 'GPIOB1', 'T17': 'GPIOD16', 'D14': 'GPIOC4', 'C7': 'GPIOB6', 'F17': 'GPIOD2'}

	def __init__(self,*args,**kwargs):
		super(CPLD,self).__init__(*args,**kwargs)
		self.lastSelectGroup = None
		self.currentPageSelected = None
		self.currentPageSelectedValue = None

	def reset(self):
		super(CPLD, self).reset()
		for addr in range(12):
			self.regProgDevice.writeReg(addr, 0x00)
	
			
	def readReg(self,addr):
		addr=addr&0x7fff
		Globals.delay(self.delay_time)
		if self.regProgDevice:
			data = self.regProgDevice.readReg(0x8000 + addr)
			print "Read from ",addr, "value ", str(data)
		else:
			data=0
			debug("No Reg Programmer Connected.")
		return data&0xff 
		print "Read from ",addr, "value ", str(data)
					
	def readReg32(self,addr):
		addr=addr&0x7fff
		Globals.delay(self.delay_time)
		data1 = self.readReg(0x8000 + addr)
		data2 = self.readReg(0x8000 + addr + 1)
		data3 = self.readReg(0x8000 + addr + 2)
		data4 = self.readReg(0x8000 + addr + 3)
		data = (data4 << 24) + (data3 << 16) + (data2 << 8) + data1
		return data 
		