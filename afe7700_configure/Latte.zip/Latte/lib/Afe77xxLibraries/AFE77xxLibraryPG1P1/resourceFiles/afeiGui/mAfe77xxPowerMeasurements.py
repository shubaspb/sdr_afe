import globalDefs as Globals
from mInstrument import *
import iGui

def truncate(f, n=2):
	'''Truncates/pads a float f to n decimal places without rounding'''
	s = '{}'.format(f)
	if 'e' in s or 'E' in s:
		return '{0:.{1}f}'.format(f, n)
	i, p, d = s.partition('.')
	return float('.'.join([i, (d+'0'*n)[:n]]))

class afe77xxCurrentSenseController:
	def __init__(self,parent,*args,**kwargs):
		from workspace import setupParams
		self.libInstance=setupParams.currSensor
		self.guiParams=kwargs['cache']
		self.parent = parent
		self.__currV1p2 = parent.currV1p2
		self.__currV1p8 = parent.currV1p8
		self.__currV0p95 = parent.currV0p95
		self.__currV3p3 = parent.currV3p3
		self.__currV1p2Pll = parent.currV1p2Pll
		self.__currV1p8Pll = parent.currV1p8Pll
		self.__currV2p5 = parent.currV2p5
		self.__voltageV1p2 = parent.voltageV1p2
		self.__voltageV1p8 = parent.voltageV1p8
		self.__voltageV0p95 = parent.voltageV0p95
		self.__voltageV3p3 = parent.voltageV3p3
		self.__voltageV1p2Pll = parent.voltageV1p2Pll
		self.__voltageV1p8Pll = parent.voltageV1p8Pll
		self.__voltageV2p5 = parent.voltageV2p5
		self.__powerV1p2 = parent.powerV1p2
		self.__powerV1p8 = parent.powerV1p8
		self.__powerV0p95 = parent.powerV0p95
		self.__powerV3p3 = parent.powerV3p3
		self.__powerV1p2Pll = parent.powerV1p2Pll
		self.__powerV1p8Pll = parent.powerV1p8Pll
		self.__powerV2p5 = parent.powerV2p5
		self.__totalPower = parent.totalPower
		self.__refresh = parent.refresh

	def setCurrV1p2(self,val):
		self.__currV1p2 = val
		self.libInstance.currV1p2 = val

	def getCurrV1p2(self):
		self.__currV1p2 = self.libInstance.readCurrent('1p2') - self.guiParams.qCurrent['1p2']
		return truncate(self.__currV1p2*10**-3)

	def setCurrV1p8(self,val):
		self.__currV1p8 = val
		self.libInstance.currV1p8 = val

	def getCurrV1p8(self):
		self.__currV1p8 = self.libInstance.readCurrent('1p8') - self.guiParams.qCurrent['1p8']
		return truncate(self.__currV1p8*10**-3)

	def setCurrV0p95(self,val):
		self.__currV0p95 = val
		self.libInstance.currV0p95 = val

	def getCurrV0p95(self):
		self.__currV0p95 = self.libInstance.readCurrent('0p95') - self.guiParams.qCurrent['0p95']
		return truncate(self.__currV0p95*10**-3)

	def setCurrV1p2Pll(self,val):
		self.__currV1p2Pll = val
		self.libInstance.currV1p2Pll = val

	def getCurrV1p2Pll(self):
		self.__currV1p2Pll = self.libInstance.readCurrent('1p2VPLL') - self.guiParams.qCurrent['1p2PLL']
		return truncate(self.__currV1p2Pll*10**-3)

	def setCurrV1p8Pll(self,val):
		self.__currV1p8Pll = val
		self.libInstance.currV1p8Pll = val

	def getCurrV1p8Pll(self):
		self.__currV1p8Pll = self.libInstance.readCurrent('1p8VPLL') - self.guiParams.qCurrent['1p8PLL']
		return truncate(self.__currV1p8Pll*10**-3)

	def setCurrV2p5(self,val):
		self.__currV2p5 = val
		self.libInstance.currV2p5 = val

	def getCurrV2p5(self):
		self.__currV2p5 = self.libInstance.readCurrent('2p5') - self.guiParams.qCurrent['2p5']
		return truncate(self.__currV2p5*10**-3)

	def setVoltageV1p2(self,val):
		self.__voltageV1p2 = val
		self.libInstance.voltageV1p2 = val

	def getVoltageV1p2(self):
		self.__voltageV1p2 = self.libInstance.readVoltage('1p2')
		return truncate(self.__voltageV1p2)

	def setVoltageV1p8(self,val):
		self.__voltageV1p8 = val
		self.libInstance.voltageV1p8 = val

	def getVoltageV1p8(self):
		self.__voltageV1p8 = self.libInstance.readVoltage('1p8')
		return truncate(self.__voltageV1p8)

	def setVoltageV0p95(self,val):
		self.__voltageV0p95 = val
		self.libInstance.voltageV0p95 = val

	def getVoltageV0p95(self):
		self.__voltageV0p95 = self.libInstance.readVoltage('0p95')
		return truncate(self.__voltageV0p95)

	def setVoltageV3p3(self,val):
		self.__voltageV3p3 = val
		self.libInstance.voltageV3p3 = val

	def getVoltageV3p3(self):
		self.__voltageV3p3 = self.libInstance.readVoltage('3p3')
		return truncate(self.__voltageV3p3)

	def setVoltageV1p2Pll(self,val):
		self.__voltageV1p2Pll = val
		self.libInstance.voltageV1p2Pll = val

	def getVoltageV1p2Pll(self):
		self.__voltageV1p2Pll = self.libInstance.readVoltage('1p2VPLL')
		return truncate(self.__voltageV1p2Pll)

	def setVoltageV1p8Pll(self,val):
		self.__voltageV1p8Pll = val
		self.libInstance.voltageV1p8Pll = val

	def getVoltageV1p8Pll(self):
		self.__voltageV1p8Pll = self.libInstance.readVoltage('1p8VPLL')
		return truncate(self.__voltageV1p8Pll)

	def setVoltageV2p5(self,val):
		self.__voltageV2p5 = val
		self.libInstance.voltageV2p5 = val

	def getVoltageV2p5(self):
		self.__voltageV2p5 = self.libInstance.readVoltage('2p5')
		return truncate(self.__voltageV2p5)

	def setPowerV1p2(self,val):
		self.__powerV1p2 = val
		self.libInstance.powerV1p2 = val

	def getPowerV1p2(self):
		self.__powerV1p2 = self.parent.voltageV1p2*self.parent.currV1p2
		return truncate(self.__powerV1p2)

	def setPowerV1p8(self,val):
		self.__powerV1p8 = val
		self.libInstance.powerV1p8 = val

	def getPowerV1p8(self):
		self.__powerV1p8 = self.parent.voltageV1p8*self.parent.currV1p8
		return truncate(self.__powerV1p8)

	def setPowerV0p95(self,val):
		self.__powerV0p95 = val
		self.libInstance.powerV0p95 = val

	def getPowerV0p95(self):
		self.__powerV0p95 = self.parent.voltageV0p95*self.parent.currV0p95
		return truncate(self.__powerV0p95)

	def setPowerV1p2Pll(self,val):
		self.__powerV1p2Pll = val
		self.libInstance.powerV1p2Pll = val

	def getPowerV1p2Pll(self):
		self.__powerV1p2Pll = self.parent.voltageV1p2Pll*self.parent.currV1p2Pll
		return truncate(self.__powerV1p2Pll)

	def setPowerV1p8Pll(self,val):
		self.__powerV1p8Pll = val
		self.libInstance.powerV1p8Pll = val

	def getPowerV1p8Pll(self):
		self.__powerV1p8Pll = self.parent.voltageV1p8Pll*self.parent.currV1p8Pll
		return truncate(self.__powerV1p8Pll)

	def setPowerV2p5(self,val):
		self.__powerV2p5 = val
		self.libInstance.powerV2p5 = val

	def getPowerV2p5(self):
		self.__powerV2p5 = self.parent.voltageV2p5*self.parent.currV2p5
		return truncate(self.__powerV2p5)
		
	def getTotalPower(self):
		self.__totalPower = self.parent.powerV2p5 + self.parent.powerV0p95 + self.parent.powerV1p2 + self.parent.powerV1p2Pll + self.parent.powerV1p8 + self.parent.powerV1p8Pll
		return self.__totalPower




class afe77xxCurrentSense(Interface):
	controller =afe77xxCurrentSenseController
	currV1p2 	= Object(typ=RealNumber,label = 'currV1p2',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	currV1p8 	= Object(typ=RealNumber,label = 'currV1p8',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	currV0p95 	= Object(typ=RealNumber,label = 'currV0p95',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	currV3p3 	= Object(typ=RealNumber,label = 'currV3p3',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	currV1p2Pll 	= Object(typ=RealNumber,label = 'currV1p2Pll',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	currV1p8Pll 	= Object(typ=RealNumber,label = 'currV1p8Pll',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	currV2p5 	= Object(typ=RealNumber,label = 'currV2p5',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV1p2 	= Object(typ=RealNumber,label = 'voltageV1p2',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV1p8 	= Object(typ=RealNumber,label = 'voltageV1p8',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV0p95 	= Object(typ=RealNumber,label = 'voltageV0p95',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV3p3 	= Object(typ=RealNumber,label = 'voltageV3p3',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV1p2Pll 	= Object(typ=RealNumber,label = 'voltageV1p2Pll',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV1p8Pll 	= Object(typ=RealNumber,label = 'voltageV1p8Pll',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	voltageV2p5 	= Object(typ=RealNumber,label = 'voltageV2p5',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV1p2 	= Object(typ=RealNumber,label = 'powerV1p2',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV1p8 	= Object(typ=RealNumber,label = 'powerV1p8',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV0p95 	= Object(typ=RealNumber,label = 'powerV0p95',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV3p3 	= Object(typ=RealNumber,label = 'powerV3p3',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV1p2Pll 	= Object(typ=RealNumber,label = 'powerV1p2Pll',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV1p8Pll 	= Object(typ=RealNumber,label = 'powerV1p8Pll',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	powerV2p5 	= Object(typ=RealNumber,label = 'powerV2p5',default=0.0,widgetParams={"setDisabled":True, "styleSheet": "color: black;"})
	totalPower = Object(typ=String,label='Total Power',default='0.0') 

	refresh 	= Object(typ=Trigger,label='Refresh',function='updateAllObjectsFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})


	############ Below are the choices List.

	def __init__(self,cache):
		super(afe77xxCurrentSense,self).__init__(cache=cache)
		self.gui.show()
		self.gui.hide()


	def updateAllObjectsFunc(self):
		self._currV1p2.getValue()
		self._currV1p8.getValue()
		self._currV0p95.getValue()
		self._currV3p3.getValue()
		self._currV1p2Pll.getValue()
		self._currV1p8Pll.getValue()
		self._currV2p5.getValue()
		self._voltageV1p2.getValue()
		self._voltageV1p8.getValue()
		self._voltageV0p95.getValue()
		self._voltageV3p3.getValue()
		self._voltageV1p2Pll.getValue()
		self._voltageV1p8Pll.getValue()
		self._voltageV2p5.getValue()
		self._powerV1p2.getValue()
		self._powerV1p8.getValue()
		self._powerV0p95.getValue()
		self._powerV3p3.getValue()
		self._powerV1p2Pll.getValue()
		self._powerV1p8Pll.getValue()
		self._powerV2p5.getValue()
		self._totalPower.getValue()