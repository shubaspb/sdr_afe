#gpioGenericSeliGuiClass._c0.gui.widgets[0].combo.addItems(a.values())
import globalDefs as Globals
import math
from PySide import QtGui
class afeGuiControllerClass:
	def __init__(self,AFE,gpioConstants):
		self.AFE=AFE
	
		
		## GPIO Related
		self.gpioConstants=gpioConstants
		self.outputFuncDict=self.gpioConstants.outputFuncDict.copy()
		self.inputFuncDict=self.gpioConstants.inputFuncDict.copy()
		self.gpioList=self.gpioConstants.gpioList.copy()
		self.fixedFuncToBallName=self.gpioConstants.fixedFuncToBallName.copy()
		self.supportedBallNames=self.gpioConstants.supportedBallNames[:]
		self.gpioMapping=AFE.systemParams.gpioMapping
		self.validGpioBallNames=self.gpioConstants.supportedBallNames[:]
		self.validInputFunctions=[]
		self.validOutputFunctions=[]
		self.selectedGpioGroups=['MAIN']
		self.tempGpioMapping={}
		self.currentGpioSelectPage=0
		self.gpioPageSelectListsInputs=[]
		self.gpioPageSelectListsOutputs=[]
		self.genericSelectionInstanceSaving={}
		self.noSelsInGenericGuiInstance=44
	#__init__
		
	def findValidFunctions(self):
		self.tempGpioMapping={}
		self.validGpioBallNames=self.gpioConstants.supportedBallNames[:]
		self.validInputFunctions=[]
		self.validOutputFunctions=[]
		for funcGroup in self.selectedGpioGroups:
			if funcGroup in self.inputFuncDict.keys():
				for func in self.inputFuncDict[funcGroup]:
					if func in self.fixedFuncToBallName.keys():
						self.tempGpioMapping[self.fixedFuncToBallName[func]['ballName']]=func
						if self.fixedFuncToBallName[func]['ballName'] in self.validGpioBallNames:
							self.validGpioBallNames.remove(self.fixedFuncToBallName[func]['ballName'])
						elif self.fixedFuncToBallName[func]['ballName'] in self.tempGpioMapping.keys():
							self.validInputFunctions.append(func)		
						else:
							Globals.error(self.fixedFuncToBallName[func]['ballName']+" is not in "+str(self.validGpioBallNames))
					else:
						self.validInputFunctions.append(func)
			if funcGroup in self.outputFuncDict.keys():
				for func in self.outputFuncDict[funcGroup]:
					if func in self.fixedFuncToBallName.keys():
						self.tempGpioMapping[self.fixedFuncToBallName[func]['ballName']]=func
						if self.fixedFuncToBallName[func]['ballName'] in self.validGpioBallNames:
							self.validGpioBallNames.remove(self.fixedFuncToBallName[func]['ballName'])
						elif self.fixedFuncToBallName[func]['ballName'] in self.tempGpioMapping.keys():
							self.validOutputFunctions.append(func)		
						else:
							print "Error: Didn't find this ball in valid Ball Names: " +str(self.fixedFuncToBallName[func]['ballName'])
					else:
						self.validOutputFunctions.append(func)
	#findValidFunctions
	
	def proceedFuncGenericSelection(self):
		Globals.log(self.currentGpioSelectPage)
		
		if self.currentGpioSelectPage>0:
			self.genericSelectionInstanceSaving[self.currentGpioSelectPage]={}
			self.genericSelectionInstanceSaving[self.currentGpioSelectPage]['validGpioBallNames']=self.validGpioBallNames[:]
			self.genericSelectionInstanceSaving[self.currentGpioSelectPage]['tempGpioMapping']=self.tempGpioMapping.copy()
			
		if self.currentGpioSelectPage==0:
			self.findValidFunctions()
			self.gpioPageSelectListsInputs=[]
			self.gpioPageSelectListsOutputs=[]
			self.genericSelectionInstanceSaving={}
		
			lenOfInputFunctionsGuis=int(math.ceil(len(self.validInputFunctions)*1.0/self.noSelsInGenericGuiInstance))
			for i in range(lenOfInputFunctionsGuis):
				cDict={}
				if i==lenOfInputFunctionsGuis-1:
					noBallNames=len(self.validInputFunctions)-i*self.noSelsInGenericGuiInstance
				else:
					noBallNames=self.noSelsInGenericGuiInstance
				#for funcNo in range(noFunctions):
				#	funcName=self.validInputFunctions[(i*self.noSelsInGenericGuiInstance)+funcNo]
				#	cDict[funcName]=["NC",]+self.validGpioBallNames
				for gpioNo in range(noBallNames):
					ballName=self.validGpioBallNames[(i*self.noSelsInGenericGuiInstance)+gpioNo]
					cDict[ballName]=["NC",]+self.validInputFunctions
				self.gpioPageSelectListsInputs.append(cDict)
		if self.currentGpioSelectPage<=len(self.gpioPageSelectListsInputs) and self.currentGpioSelectPage>=0:
			self.gpioGenericSeliGuiClass.pageName="Select Ball Names for Input Functions."
			self.gpioGenericSeliGuiClass.groupName="Page "+str(self.currentGpioSelectPage+1)+"/"+str(len(self.gpioPageSelectListsInputs))
			ballsSelected=self.gpioGenericSeliGuiClass.getParams()
			for ballName in ballsSelected:
				inputFunction=ballsSelected[ballName]
				if inputFunction!="NC":
					self.tempGpioMapping[ballName]=inputFunction
					if ballName in self.validGpioBallNames:
						self.validGpioBallNames.remove(ballName)
			if self.currentGpioSelectPage<len(self.gpioPageSelectListsInputs):
				self.gpioGenericSeliGuiClass.setParams(self.gpioPageSelectListsInputs[self.currentGpioSelectPage-1])
			else:
				lenOfOutputFunctionsGuis=int(math.ceil(len(self.validGpioBallNames)*1.0/self.noSelsInGenericGuiInstance))
				for i in range(lenOfOutputFunctionsGuis):
					cDict={}
					if i==lenOfOutputFunctionsGuis-1:
						noFunctions=len(self.validGpioBallNames)-i*self.noSelsInGenericGuiInstance
					else:
						noFunctions=self.noSelsInGenericGuiInstance
					for funcNo in range(noFunctions):
						ballName=self.validGpioBallNames[(i*self.noSelsInGenericGuiInstance)+funcNo]
						cDict[ballName]=["NC",]+self.validOutputFunctions
					self.gpioPageSelectListsOutputs.append(cDict)
					
				self.gpioGenericSeliGuiClass.pageName="Select output Functions for Ball Names."
				self.gpioGenericSeliGuiClass.groupName="Page "+str(self.currentGpioSelectPage-len(self.gpioPageSelectListsInputs)+1)+"/"+str(len(self.gpioPageSelectListsOutputs))
			
				self.gpioGenericSeliGuiClass.setParams(self.gpioPageSelectListsOutputs[self.currentGpioSelectPage-len(self.gpioPageSelectListsInputs)-1])
		elif self.currentGpioSelectPage-len(self.gpioPageSelectListsInputs)<len(self.gpioPageSelectListsOutputs):
			self.gpioGenericSeliGuiClass.pageName="Select output Functions for Ball Names."
			self.gpioGenericSeliGuiClass.groupName="Page "+str(self.currentGpioSelectPage-len(self.gpioPageSelectListsInputs)+1)+"/"+str(len(self.gpioPageSelectListsOutputs))
			self.gpioGenericSeliGuiClass.setParams(self.gpioPageSelectListsOutputs[self.currentGpioSelectPage-len(self.gpioPageSelectListsInputs)-1])
			
		self.currentGpioSelectPage+=1
		if self.currentGpioSelectPage>(len(self.gpioPageSelectListsInputs)+len(self.gpioPageSelectListsOutputs)):
			ballsSelected=self.gpioGenericSeliGuiClass.getParams()
			for ballName in ballsSelected:
				inputFunction=ballsSelected[ballName]
				if inputFunction!="NC":
					self.tempGpioMapping[ballName]=inputFunction
					if ballName in self.validGpioBallNames:
						self.validGpioBallNames.remove(ballName)
			self.AFE.systemParams.gpioMapping=self.tempGpioMapping.copy()
			self.guiInstance.mainWindow.changeTab(self.guiInstance.mainWindow.name2IndexMapping['show']['GPIO_MAP'][0])
			self.currentGpioSelectPage=0
			return 0
		else:
			self.AFE.systemParams.gpioMapping=self.tempGpioMapping.copy()
			return 1
	
	def backFuncGenericSelection(self):
		if self.currentGpioSelectPage > 1 and self.currentGpioSelectPage<len(self.gpioPageSelectListsInputs):
			self.gpioGenericSeliGuiClass.setParams(self.gpioPageSelectListsInputs[self.currentGpioSelectPage-2])
		if self.currentGpioSelectPage!=0:
			self.currentGpioSelectPage-=1


	def proceedFunc(self,guiPageName):
		if guiPageName=="genericSelection":
			self.proceedFuncGenericSelection()
		elif guiPageName=="groupSelection":
			self.proceedFuncGenericSelection()
	
	
	def backFunc(self,guiPageName):
		if guiPageName=="genericSelection":
			self.backFuncGenericSelection()
	
	
	def initializeLiteModeSwitchShortcut(self):
		Globals.mainWindowOpen=True
		self.switchLite = QtGui.QAction(self.guiInstance.mainWindow)
		self.switchLite.setShortcut("ctrl+L")
		self.switchLite.triggered.connect(self.closeMainWindow)
		
	def addGuiWindowShortCuts(self):
		self.guiInstance.mainWindow.addAction(Globals.mainWindow.actionClearLog)
		self.guiInstance.mainWindow.addAction(Globals.mainWindow.actionStopBuffer)
		self.guiInstance.mainWindow.addAction(self.switchLite)
		
	
	def guiPageAndWindowAdjustments(self):
		for i in [1,2,3,4,5,6]:
			eval("self.guiInstance.mainWindow.changeTab("+str(i)+")")
			eval("self.guiInstance.mainWindow.stackWidget.currentWidget().svgWidget.resize(1600,950)")
			self.guiInstance.mainWindow.stackWidget.currentWidget().scrollArea.setWidgetResizable(False)
			# 	eval("afe77xxiGui.mainWindow.resize(1642,992)")
		self.guiInstance.mainWindow.listWidget.hide()
		self.guiInstance.mainWindow.resize(1642,992)
		self.guiInstance.mainWindow.setMaximumWidth(1643)
		self.guiInstance.mainWindow.setMaximumHeight(992)
		self.guiInstance.mainWindow.changeTab(2)
		self.guiInstance.mainWindow.setWindowTitle("AFE77xx iGui")
		
		##
		font = self.sysParamClassInst._fpgaConnectedStatus2.gui.widgets[1].valueLabel.font()
		font.setPointSize(12)
		self.sysParamClassInst._fpgaConnectedStatus2.gui.widgets[1].valueLabel.setFont(font)
		self.additionalConfigInst._fpgaConnectedStatus2.gui.widgets[1].valueLabel.setFont(font)
		self.statusRegistersInst._fpgaConnectedStatus2.gui.widgets[1].valueLabel.setFont(font)
		self.customConfigInst._fpgaConnectedStatus2.gui.widgets[1].valueLabel.setFont(font)
		##
		
		##
		if Globals.simulationMode:
			self.sysParamClassInst._fpgaConnectedStatus1.setValue(0) 
			self.additionalConfigInst._fpgaConnectedStatus1.setValue(0) 
			self.statusRegistersInst._fpgaConnectedStatus1.setValue(0) 
			self.customConfigInst._fpgaConnectedStatus1.setValue(0) 
		else:
			try:
				V = hex(self.sysParamClassInst.FPGA.interfaceHandle.ReadControlRegister_Q(self.sysParamClassInst.FPGA.interfaceHandle.CONFIG_BASE_ADDR + 4*8, 1))
				if V[5:] in ['204c','204b']:
					self.sysParamClassInst._fpgaConnectedStatus1.setValue(1) 
					self.additionalConfigInst._fpgaConnectedStatus1.setValue(1) 
					self.statusRegistersInst._fpgaConnectedStatus1.setValue(1) 
					self.customConfigInst._fpgaConnectedStatus1.setValue(1)
					self.sysParamClassInst._fpgaConnectedStatus2.setValue("FPGA is connected") 
					self.additionalConfigInst._fpgaConnectedStatus2.setValue("FPGA is connected") 
					self.statusRegistersInst._fpgaConnectedStatus2.setValue("FPGA is connected") 
					self.customConfigInst._fpgaConnectedStatus2.setValue("FPGA is connected")
				else:
					self.sysParamClassInst._fpgaConnectedStatus1.setValue(0) 
					self.additionalConfigInst._fpgaConnectedStatus1.setValue(0) 
					self.statusRegistersInst._fpgaConnectedStatus1.setValue(0) 
					self.customConfigInst._fpgaConnectedStatus1.setValue(0)
			except:
				self.sysParamClassInst._fpgaConnectedStatus1.setValue(0) 
				self.additionalConfigInst._fpgaConnectedStatus1.setValue(0) 
				self.statusRegistersInst._fpgaConnectedStatus1.setValue(0) 
				self.customConfigInst._fpgaConnectedStatus1.setValue(0)
		##
				
	
	def closeMainWindow(self):
		if Globals.mainWindowOpen:
			Globals.mainWindow.hide()
			Globals.mainWindowOpen = False
		else:
			Globals.mainWindow.show()
			Globals.mainWindowOpen = True
			
	