import gc
gc.collect()
from mDummySignalSource import DummySignalSource
from HSCProgrammer import QPort
from KintexProgrammer import KintexSPIProgrammer
from JESDCapture import JESDCapture
import d2xx
from USBCaptureTrig import USBCaptureTrig
from USBHSCProgrammer import USBQPort

try:
	from USBHSCProgrammer import i2cPort
except:
	pass
from basicPlots import BasicPlot
import numpy as np
import time
from logPlots import Log
import globalDefs as Globals
from mKeysightVectorSignalGenerator import KeysightE8267D
from mKeithleyPowerSupply import Keithley2230G	
import fpgawrite
import sys
sys.path.append("C:\Users\a0230432\Documents\Texas Instruments\Latte\lib\Afe77xxLibraries\AFE77xxLibraryPG1P1\resourceFiles")
reload(sys)

import mpsseSPI
reload(mpsseSPI)

boardType="EVM-1DeviceJ58"#"HSC1373"##"EVM"#"EVM-1DeviceJ58"#	#"HSC1320"#"EVM-1Device"#"HSC1330"#
jesdH=False#True#
chipId=0x77
chipVersion=0x11
import Afe77xxLibraries
reload(Afe77xxLibraries)
folderName=Afe77xxLibraries.getFolderName(chipId,chipVersion)
info(folderName)

#### signal and clock source
sigSource00=DummySignalSource(addr="Null",name="Signal Source")

DevClkSource=DummySignalSource(addr="Null",name="Device Source clk")
clkSource=DummySignalSource(addr="Null",name="RF Source clk")

MPSSE=True#True#


qportName="Quad RS232-HS"
for i in range(d2xx.createDeviceInfoList()):
	qportName=d2xx.getDeviceInfoDetail(0)['description'][:-2]

try:
	if boardType=="BENCH":
		jtagregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB C")
		adcregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB D")
		lmkregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB B")
		fpgaregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB B")
		# capture_port = USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS A")
		capDev = USBCaptureTrig(name="Kintex Capture Card");#,addrB="Quad RS232-HS B",addrC="Quad RS232-HS C")
		writer=fpgawrite.fpgaWriter()
		gpioProg= USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB C") 
	elif boardType=="HSC1330":
		jtagregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB C")
		adcregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB B")
		lmkregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB D")
		fpgaregProg = USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB D")
		# capture_port = USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS A")
		capDev = USBCaptureTrig(name="Kintex Capture Card");#,addrB="Quad RS232-HS B",addrC="Quad RS232-HS C")
		writer=fpgawrite.fpgaWriter()
		gpioProg= USBQPort(name="Kintex RegProgrammer",addr="Anupam Main USB C") 
	elif boardType in ("EVM-1DeviceJ58","EVM-1Device"):
		if MPSSE==True:
			adcregProg = mpsseSPI.spi(addr=qportName+" A")#"Anupam Main USB A"
			adcregProg.clockDivider=4
		else:
			adcregProg = USBQPort(name="Kintex RegProgrammer",addr=qportName+" A")#"Anupam Main USB A"
		lmkregProg = USBQPort(name="Kintex RegProgrammer",addr=qportName+" D")#"Anupam Main USB D"
		capDev=""
		fpgaregProg=""
		writer=""
		cpldRegProg=USBQPort(name="Kintex RegProgrammer",addr=qportName+" D")#"Anupam Main USB D"
		gpioProg=""
	else:
		if boardType=="HSC1320":
			dut0_spia= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS B")
			dut1_spia= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS B") 
			dut0_spib= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS C")
			dut1_spib= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS C")
		else:
			if MPSSE==True:
				dut0_spia= mpsseSPI.spi(addr="Quad RS232-HS A")
				dut1_spia= mpsseSPI.spi(addr="Quad RS232-HS A") 
				dut0_spib= mpsseSPI.spi(addr="Quad RS232-HS A")
				dut1_spib= mpsseSPI.spi(addr="Quad RS232-HS A")
				dut0_spia.clockDivider=4
				dut0_spib.clockDivider=4
				dut1_spia.clockDivider=4
				dut1_spib.clockDivider=4
			else:
				dut0_spia= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS A")
				dut1_spia= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS A") 
				dut0_spib= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS A")
				dut1_spib= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS A")
			
		try:
			currSenseI2C = i2cPort(name="i2c Programmer",addr="Quad RS232-HS B", CLK_pin = 0, SDAI_pin = 2, SDAO_pin = 1)
			currSenseI2C.pin0 = 0
			currSenseI2C.pin1 = 1
			currSenseI2C.pin2 = 5
		except:
			currSenseI2C=""
		cpldRegProg=USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS D")
		
		info("Device handles instantiated")
		writer="Dummy"
		sys.path.append(ASTERIX_DIR+r"\lib\projectsRootDir")
		lmkregProg = USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS D")
		gpioProg=""
	simulationMode=False
except:
	error("Got an error Connecting to hardware. Running in Simulation Mode.")
	boardType="BENCH"
	writer="Dummy"
	if boardType=="BENCH":
		adcregProg = ""
		fpgaregProg = ""
		capDev=""
	else:
		dut0_spia= ""
		dut1_spia= ""
		dut0_spib= ""
		dut1_spib= ""
	lmkregProg = ""
	simulationMode=True
	gpioProg=""
	cpldRegProg=""
	
class HWReset(object):
	"""docstring for HWReset"""
	def __init__(self, regProgDevice=None, pin_no=None):
		super(HWReset, self).__init__()
		self.regProgDevice = regProgDevice
		self.pin_no = pin_no
		if self.regProgDevice!=None:
			for pin in range(8):
				exec("self.regProgDevice.pin" + str(pin) + "=5")
		else:
			pass

	def toggle(self):
		if self.regProgDevice!=None:
			exec("self.regProgDevice.pin" + str(self.pin_no) + "=3")
			delay(0.1)
			exec("self.regProgDevice.pin" + str(self.pin_no) + "=4")
		else:
			pass

if boardType == "HSC1373":
	hwResetQPort= USBQPort(name="Kintex RegProgrammer",addr="Quad RS232-HS C")		
	hwResetHandle = HWReset(regProgDevice = hwResetQPort, pin_no=0)
else:
	hwResetHandle = HWReset()
Globals.simulationMode = simulationMode
# mainWindow.runFile(r"C:\Asterix5p6_lite\code\projects\AFE77xx\bringup\devInit.py")
# mainWindow.runFile(r"C:\Asterix5p6_lite\code\projects\AFE77xx\bringup\scratchPad_1.py")