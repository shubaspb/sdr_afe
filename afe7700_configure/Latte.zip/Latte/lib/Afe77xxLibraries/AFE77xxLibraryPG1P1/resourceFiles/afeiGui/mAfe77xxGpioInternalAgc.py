
from mInstrument import *
from mAfeConstants import gpioConstants


class afe77xxInternalAgcGpioController:
	def __init__(self,parent,*args,**kwargs):
		self.parent=parent
		self.libInstance=kwargs['libInstance']
		self.gpio = kwargs['gpio']
		
		self.__agcArxcdg0=parent.agcArxcdg0
		self.__agcArxcdg0pinState=parent.agcArxcdg0pinState
		self.__agcArxcdg0dirControl=parent.agcArxcdg0dirControl

		self.__agcArxcdg1=parent.agcArxcdg1
		self.__agcArxcdg1pinState=parent.agcArxcdg1pinState
		self.__agcArxcdg1dirControl=parent.agcArxcdg1dirControl

		self.__agcArxcdg2=parent.agcArxcdg2
		self.__agcArxcdg2pinState=parent.agcArxcdg2pinState
		self.__agcArxcdg2dirControl=parent.agcArxcdg2dirControl

		self.__agcArxcdg3=parent.agcArxcdg3
		self.__agcArxcdg3pinState=parent.agcArxcdg3pinState
		self.__agcArxcdg3dirControl=parent.agcArxcdg3dirControl

		self.__agcBrxcdg0=parent.agcBrxcdg0
		self.__agcBrxcdg0pinState=parent.agcBrxcdg0pinState
		self.__agcBrxcdg0dirControl=parent.agcBrxcdg0dirControl

		self.__agcBrxcdg1=parent.agcBrxcdg1
		self.__agcBrxcdg1pinState=parent.agcBrxcdg1pinState
		self.__agcBrxcdg1dirControl=parent.agcBrxcdg1dirControl

		self.__agcBrxcdg2=parent.agcBrxcdg2
		self.__agcBrxcdg2pinState=parent.agcBrxcdg2pinState
		self.__agcBrxcdg2dirControl=parent.agcBrxcdg2dirControl

		self.__agcBrxcdg3=parent.agcBrxcdg3
		self.__agcBrxcdg3pinState=parent.agcBrxcdg3pinState
		self.__agcBrxcdg3dirControl=parent.agcBrxcdg3dirControl

		self.__agcCrxcdg0=parent.agcCrxcdg0
		self.__agcCrxcdg0pinState=parent.agcCrxcdg0pinState
		self.__agcCrxcdg0dirControl=parent.agcCrxcdg0dirControl

		self.__agcCrxcdg1=parent.agcCrxcdg1
		self.__agcCrxcdg1pinState=parent.agcCrxcdg1pinState
		self.__agcCrxcdg1dirControl=parent.agcCrxcdg1dirControl

		self.__agcCrxcdg2=parent.agcCrxcdg2
		self.__agcCrxcdg2pinState=parent.agcCrxcdg2pinState
		self.__agcCrxcdg2dirControl=parent.agcCrxcdg2dirControl

		self.__agcCrxcdg3=parent.agcCrxcdg3
		self.__agcCrxcdg3pinState=parent.agcCrxcdg3pinState
		self.__agcCrxcdg3dirControl=parent.agcCrxcdg3dirControl

		self.__agcDrxcdg0=parent.agcDrxcdg0
		self.__agcDrxcdg0pinState=parent.agcDrxcdg0pinState
		self.__agcDrxcdg0dirControl=parent.agcDrxcdg0dirControl

		self.__agcDrxcdg1=parent.agcDrxcdg1
		self.__agcDrxcdg1pinState=parent.agcDrxcdg1pinState
		self.__agcDrxcdg1dirControl=parent.agcDrxcdg1dirControl

		self.__agcDrxcdg2=parent.agcDrxcdg2
		self.__agcDrxcdg2pinState=parent.agcDrxcdg2pinState
		self.__agcDrxcdg2dirControl=parent.agcDrxcdg2dirControl

		self.__agcDrxcdg3=parent.agcDrxcdg3
		self.__agcDrxcdg3pinState=parent.agcDrxcdg3pinState
		self.__agcDrxcdg3dirControl=parent.agcDrxcdg3dirControl

		self.__agcArxlnabyp=parent.agcArxlnabyp
		self.__agcArxlnabyppinState=parent.agcArxlnabyppinState
		self.__agcArxlnabypdirControl=parent.agcArxlnabypdirControl

		self.__agcBrxlnabyp=parent.agcBrxlnabyp
		self.__agcBrxlnabyppinState=parent.agcBrxlnabyppinState
		self.__agcBrxlnabypdirControl=parent.agcBrxlnabypdirControl

		self.__agcCrxlnabyp=parent.agcCrxlnabyp
		self.__agcCrxlnabyppinState=parent.agcCrxlnabyppinState
		self.__agcCrxlnabypdirControl=parent.agcCrxlnabypdirControl

		self.__agcDrxlnabyp=parent.agcDrxlnabyp
		self.__agcDrxlnabyppinState=parent.agcDrxlnabyppinState
		self.__agcDrxlnabypdirControl=parent.agcDrxlnabypdirControl

		self.__miscelleneousTxdsasw1=parent.miscelleneousTxdsasw1
		self.__miscelleneousTxdsasw1pinState=parent.miscelleneousTxdsasw1pinState
		self.__miscelleneousTxdsasw1dirControl=parent.miscelleneousTxdsasw1dirControl

		self.__miscelleneousTxdsasw2=parent.miscelleneousTxdsasw2
		self.__miscelleneousTxdsasw2pinState=parent.miscelleneousTxdsasw2pinState
		self.__miscelleneousTxdsasw2dirControl=parent.miscelleneousTxdsasw2dirControl

		self.__miscelleneousRxdsasw=parent.miscelleneousRxdsasw
		self.__miscelleneousRxdsaswpinState=parent.miscelleneousRxdsaswpinState
		self.__miscelleneousRxdsaswdirControl=parent.miscelleneousRxdsaswdirControl

		self.__miscelleneousFbncosw=parent.miscelleneousFbncosw
		self.__miscelleneousFbncoswpinState=parent.miscelleneousFbncoswpinState
		self.__miscelleneousFbncoswdirControl=parent.miscelleneousFbncoswdirControl

		self.__miscelleneousInt1=parent.miscelleneousInt1
		self.__miscelleneousInt1pinState=parent.miscelleneousInt1pinState
		self.__miscelleneousInt1dirControl=parent.miscelleneousInt1dirControl

		self.__miscelleneousInt2=parent.miscelleneousInt2
		self.__miscelleneousInt2pinState=parent.miscelleneousInt2pinState
		self.__miscelleneousInt2dirControl=parent.miscelleneousInt2dirControl

		self.__miscelleneousSleep=parent.miscelleneousSleep
		self.__miscelleneousSleeppinState=parent.miscelleneousSleeppinState
		self.__miscelleneousSleepdirControl=parent.miscelleneousSleepdirControl


	def afe77xxGpioMap(self,function,type,state,val,ballName):
			if type == 'CPLD':
				if state == 'pinState':
					exec("self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(ballName)+".pinState = self.parent._"+function+".getValue()")
				elif state == 'dirControl':
					if val == 0:
						exec("self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(ballName)+".dirControl = 1")
					elif val == 1:
						exec("self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(ballName)+".dirControl = 0")
	def setAgcArxcdg0(self,val):
		self.__agcArxcdg0=val
	def getAgcArxcdg0(self):
		return self.__agcArxcdg0

	def setAgcArxcdg0pinState(self,val):
		self.__agcArxcdg0pinState=val
		self.afe77xxGpioMap('agcArxcdg0pinState','CPLD','pinState',val,ballName='V9')

	def getAgcArxcdg0pinState(self):
		return self.__agcArxcdg0pinState

	def setAgcArxcdg0dirControl(self,val):
		self.__agcArxcdg0dirControl=val
		self.afe77xxGpioMap('agcArxcdg0pinState','CPLD','dirControl',val,ballName='V9')

	def getAgcArxcdg0dirControl(self):
		return self.__agcArxcdg0dirControl

	def setAgcArxcdg1(self,val):
		self.__agcArxcdg1=val
	def getAgcArxcdg1(self):
		return self.__agcArxcdg1

	def setAgcArxcdg1pinState(self,val):
		self.__agcArxcdg1pinState=val
		self.afe77xxGpioMap('agcArxcdg1pinState','CPLD','pinState',val,ballName='U11')

	def getAgcArxcdg1pinState(self):
		return self.__agcArxcdg1pinState

	def setAgcArxcdg1dirControl(self,val):
		self.__agcArxcdg1dirControl=val
		self.afe77xxGpioMap('agcArxcdg1pinState','CPLD','dirControl',val,ballName='U11')

	def getAgcArxcdg1dirControl(self):
		return self.__agcArxcdg1dirControl

	def setAgcArxcdg2(self,val):
		self.__agcArxcdg2=val
	def getAgcArxcdg2(self):
		return self.__agcArxcdg2

	def setAgcArxcdg2pinState(self,val):
		self.__agcArxcdg2pinState=val
		self.afe77xxGpioMap('agcArxcdg2pinState','CPLD','pinState',val,ballName='U12')

	def getAgcArxcdg2pinState(self):
		return self.__agcArxcdg2pinState

	def setAgcArxcdg2dirControl(self,val):
		self.__agcArxcdg2dirControl=val
		self.afe77xxGpioMap('agcArxcdg2pinState','CPLD','dirControl',val,ballName='U12')

	def getAgcArxcdg2dirControl(self):
		return self.__agcArxcdg2dirControl

	def setAgcArxcdg3(self,val):
		self.__agcArxcdg3=val
	def getAgcArxcdg3(self):
		return self.__agcArxcdg3

	def setAgcArxcdg3pinState(self,val):
		self.__agcArxcdg3pinState=val
		self.afe77xxGpioMap('agcArxcdg3pinState','CPLD','pinState',val,ballName='V12')

	def getAgcArxcdg3pinState(self):
		return self.__agcArxcdg3pinState

	def setAgcArxcdg3dirControl(self,val):
		self.__agcArxcdg3dirControl=val
		self.afe77xxGpioMap('agcArxcdg3pinState','CPLD','dirControl',val,ballName='V12')

	def getAgcArxcdg3dirControl(self):
		return self.__agcArxcdg3dirControl

	def setAgcBrxcdg0(self,val):
		self.__agcBrxcdg0=val
	def getAgcBrxcdg0(self):
		return self.__agcBrxcdg0

	def setAgcBrxcdg0pinState(self,val):
		self.__agcBrxcdg0pinState=val
		self.afe77xxGpioMap('agcBrxcdg0pinState','CPLD','pinState',val,ballName='R5')

	def getAgcBrxcdg0pinState(self):
		return self.__agcBrxcdg0pinState

	def setAgcBrxcdg0dirControl(self,val):
		self.__agcBrxcdg0dirControl=val
		self.afe77xxGpioMap('agcBrxcdg0pinState','CPLD','dirControl',val,ballName='R5')

	def getAgcBrxcdg0dirControl(self):
		return self.__agcBrxcdg0dirControl

	def setAgcBrxcdg1(self,val):
		self.__agcBrxcdg1=val
	def getAgcBrxcdg1(self):
		return self.__agcBrxcdg1

	def setAgcBrxcdg1pinState(self,val):
		self.__agcBrxcdg1pinState=val
		self.afe77xxGpioMap('agcBrxcdg1pinState','CPLD','pinState',val,ballName='T5')

	def getAgcBrxcdg1pinState(self):
		return self.__agcBrxcdg1pinState

	def setAgcBrxcdg1dirControl(self,val):
		self.__agcBrxcdg1dirControl=val
		self.afe77xxGpioMap('agcBrxcdg1pinState','CPLD','dirControl',val,ballName='T5')

	def getAgcBrxcdg1dirControl(self):
		return self.__agcBrxcdg1dirControl

	def setAgcBrxcdg2(self,val):
		self.__agcBrxcdg2=val
	def getAgcBrxcdg2(self):
		return self.__agcBrxcdg2

	def setAgcBrxcdg2pinState(self,val):
		self.__agcBrxcdg2pinState=val
		self.afe77xxGpioMap('agcBrxcdg2pinState','CPLD','pinState',val,ballName='U7')

	def getAgcBrxcdg2pinState(self):
		return self.__agcBrxcdg2pinState

	def setAgcBrxcdg2dirControl(self,val):
		self.__agcBrxcdg2dirControl=val
		self.afe77xxGpioMap('agcBrxcdg2pinState','CPLD','dirControl',val,ballName='U7')

	def getAgcBrxcdg2dirControl(self):
		return self.__agcBrxcdg2dirControl

	def setAgcBrxcdg3(self,val):
		self.__agcBrxcdg3=val
	def getAgcBrxcdg3(self):
		return self.__agcBrxcdg3

	def setAgcBrxcdg3pinState(self,val):
		self.__agcBrxcdg3pinState=val
		self.afe77xxGpioMap('agcBrxcdg3pinState','CPLD','pinState',val,ballName='V7')

	def getAgcBrxcdg3pinState(self):
		return self.__agcBrxcdg3pinState

	def setAgcBrxcdg3dirControl(self,val):
		self.__agcBrxcdg3dirControl=val
		self.afe77xxGpioMap('agcBrxcdg3pinState','CPLD','dirControl',val,ballName='V7')

	def getAgcBrxcdg3dirControl(self):
		return self.__agcBrxcdg3dirControl

	def setAgcCrxcdg0(self,val):
		self.__agcCrxcdg0=val
	def getAgcCrxcdg0(self):
		return self.__agcCrxcdg0

	def setAgcCrxcdg0pinState(self,val):
		self.__agcCrxcdg0pinState=val
		self.afe77xxGpioMap('agcCrxcdg0pinState','CPLD','pinState',val,ballName='C9')

	def getAgcCrxcdg0pinState(self):
		return self.__agcCrxcdg0pinState

	def setAgcCrxcdg0dirControl(self,val):
		self.__agcCrxcdg0dirControl=val
		self.afe77xxGpioMap('agcCrxcdg0pinState','CPLD','dirControl',val,ballName='C9')

	def getAgcCrxcdg0dirControl(self):
		return self.__agcCrxcdg0dirControl

	def setAgcCrxcdg1(self,val):
		self.__agcCrxcdg1=val
	def getAgcCrxcdg1(self):
		return self.__agcCrxcdg1

	def setAgcCrxcdg1pinState(self,val):
		self.__agcCrxcdg1pinState=val
		self.afe77xxGpioMap('agcCrxcdg1pinState','CPLD','pinState',val,ballName='C11')

	def getAgcCrxcdg1pinState(self):
		return self.__agcCrxcdg1pinState

	def setAgcCrxcdg1dirControl(self,val):
		self.__agcCrxcdg1dirControl=val
		self.afe77xxGpioMap('agcCrxcdg1pinState','CPLD','dirControl',val,ballName='C11')

	def getAgcCrxcdg1dirControl(self):
		return self.__agcCrxcdg1dirControl

	def setAgcCrxcdg2(self,val):
		self.__agcCrxcdg2=val
	def getAgcCrxcdg2(self):
		return self.__agcCrxcdg2

	def setAgcCrxcdg2pinState(self,val):
		self.__agcCrxcdg2pinState=val
		self.afe77xxGpioMap('agcCrxcdg2pinState','CPLD','pinState',val,ballName='D12')

	def getAgcCrxcdg2pinState(self):
		return self.__agcCrxcdg2pinState

	def setAgcCrxcdg2dirControl(self,val):
		self.__agcCrxcdg2dirControl=val
		self.afe77xxGpioMap('agcCrxcdg2pinState','CPLD','dirControl',val,ballName='D12')

	def getAgcCrxcdg2dirControl(self):
		return self.__agcCrxcdg2dirControl

	def setAgcCrxcdg3(self,val):
		self.__agcCrxcdg3=val
	def getAgcCrxcdg3(self):
		return self.__agcCrxcdg3

	def setAgcCrxcdg3pinState(self,val):
		self.__agcCrxcdg3pinState=val
		self.afe77xxGpioMap('agcCrxcdg3pinState','CPLD','pinState',val,ballName='C12')

	def getAgcCrxcdg3pinState(self):
		return self.__agcCrxcdg3pinState

	def setAgcCrxcdg3dirControl(self,val):
		self.__agcCrxcdg3dirControl=val
		self.afe77xxGpioMap('agcCrxcdg3pinState','CPLD','dirControl',val,ballName='C12')

	def getAgcCrxcdg3dirControl(self):
		return self.__agcCrxcdg3dirControl

	def setAgcDrxcdg0(self,val):
		self.__agcDrxcdg0=val
	def getAgcDrxcdg0(self):
		return self.__agcDrxcdg0

	def setAgcDrxcdg0pinState(self,val):
		self.__agcDrxcdg0pinState=val
		self.afe77xxGpioMap('agcDrxcdg0pinState','CPLD','pinState',val,ballName='F5')

	def getAgcDrxcdg0pinState(self):
		return self.__agcDrxcdg0pinState

	def setAgcDrxcdg0dirControl(self,val):
		self.__agcDrxcdg0dirControl=val
		self.afe77xxGpioMap('agcDrxcdg0pinState','CPLD','dirControl',val,ballName='F5')

	def getAgcDrxcdg0dirControl(self):
		return self.__agcDrxcdg0dirControl

	def setAgcDrxcdg1(self,val):
		self.__agcDrxcdg1=val
	def getAgcDrxcdg1(self):
		return self.__agcDrxcdg1

	def setAgcDrxcdg1pinState(self,val):
		self.__agcDrxcdg1pinState=val
		self.afe77xxGpioMap('agcDrxcdg1pinState','CPLD','pinState',val,ballName='E5')

	def getAgcDrxcdg1pinState(self):
		return self.__agcDrxcdg1pinState

	def setAgcDrxcdg1dirControl(self,val):
		self.__agcDrxcdg1dirControl=val
		self.afe77xxGpioMap('agcDrxcdg1pinState','CPLD','dirControl',val,ballName='E5')

	def getAgcDrxcdg1dirControl(self):
		return self.__agcDrxcdg1dirControl

	def setAgcDrxcdg2(self,val):
		self.__agcDrxcdg2=val
	def getAgcDrxcdg2(self):
		return self.__agcDrxcdg2

	def setAgcDrxcdg2pinState(self,val):
		self.__agcDrxcdg2pinState=val
		self.afe77xxGpioMap('agcDrxcdg2pinState','CPLD','pinState',val,ballName='D7')

	def getAgcDrxcdg2pinState(self):
		return self.__agcDrxcdg2pinState

	def setAgcDrxcdg2dirControl(self,val):
		self.__agcDrxcdg2dirControl=val
		self.afe77xxGpioMap('agcDrxcdg2pinState','CPLD','dirControl',val,ballName='D7')

	def getAgcDrxcdg2dirControl(self):
		return self.__agcDrxcdg2dirControl

	def setAgcDrxcdg3(self,val):
		self.__agcDrxcdg3=val
	def getAgcDrxcdg3(self):
		return self.__agcDrxcdg3

	def setAgcDrxcdg3pinState(self,val):
		self.__agcDrxcdg3pinState=val
		self.afe77xxGpioMap('agcDrxcdg3pinState','CPLD','pinState',val,ballName='C7')

	def getAgcDrxcdg3pinState(self):
		return self.__agcDrxcdg3pinState

	def setAgcDrxcdg3dirControl(self,val):
		self.__agcDrxcdg3dirControl=val
		self.afe77xxGpioMap('agcDrxcdg3pinState','CPLD','dirControl',val,ballName='C7')

	def getAgcDrxcdg3dirControl(self):
		return self.__agcDrxcdg3dirControl

	def setAgcArxlnabyp(self,val):
		self.__agcArxlnabyp=val
	def getAgcArxlnabyp(self):
		return self.__agcArxlnabyp

	def setAgcArxlnabyppinState(self,val):
		self.__agcArxlnabyppinState=val
		self.afe77xxGpioMap('agcArxlnabyppinState','CPLD','pinState',val,ballName='V11')

	def getAgcArxlnabyppinState(self):
		return self.__agcArxlnabyppinState

	def setAgcArxlnabypdirControl(self,val):
		self.__agcArxlnabypdirControl=val
		self.afe77xxGpioMap('agcArxlnabyppinState','CPLD','dirControl',val,ballName='V11')

	def getAgcArxlnabypdirControl(self):
		return self.__agcArxlnabypdirControl

	def setAgcBrxlnabyp(self,val):
		self.__agcBrxlnabyp=val
	def getAgcBrxlnabyp(self):
		return self.__agcBrxlnabyp

	def setAgcBrxlnabyppinState(self,val):
		self.__agcBrxlnabyppinState=val
		self.afe77xxGpioMap('agcBrxlnabyppinState','CPLD','pinState',val,ballName='V10')

	def getAgcBrxlnabyppinState(self):
		return self.__agcBrxlnabyppinState

	def setAgcBrxlnabypdirControl(self,val):
		self.__agcBrxlnabypdirControl=val
		self.afe77xxGpioMap('agcBrxlnabyppinState','CPLD','dirControl',val,ballName='V10')

	def getAgcBrxlnabypdirControl(self):
		return self.__agcBrxlnabypdirControl

	def setAgcCrxlnabyp(self,val):
		self.__agcCrxlnabyp=val
	def getAgcCrxlnabyp(self):
		return self.__agcCrxlnabyp

	def setAgcCrxlnabyppinState(self,val):
		self.__agcCrxlnabyppinState=val
		self.afe77xxGpioMap('agcCrxlnabyppinState','CPLD','pinState',val,ballName='D11')

	def getAgcCrxlnabyppinState(self):
		return self.__agcCrxlnabyppinState

	def setAgcCrxlnabypdirControl(self,val):
		self.__agcCrxlnabypdirControl=val
		self.afe77xxGpioMap('agcCrxlnabyppinState','CPLD','dirControl',val,ballName='D11')

	def getAgcCrxlnabypdirControl(self):
		return self.__agcCrxlnabypdirControl

	def setAgcDrxlnabyp(self,val):
		self.__agcDrxlnabyp=val
	def getAgcDrxlnabyp(self):
		return self.__agcDrxlnabyp

	def setAgcDrxlnabyppinState(self,val):
		self.__agcDrxlnabyppinState=val
		self.afe77xxGpioMap('agcDrxlnabyppinState','CPLD','pinState',val,ballName='D10')

	def getAgcDrxlnabyppinState(self):
		return self.__agcDrxlnabyppinState

	def setAgcDrxlnabypdirControl(self,val):
		self.__agcDrxlnabypdirControl=val
		self.afe77xxGpioMap('agcDrxlnabyppinState','CPLD','dirControl',val,ballName='D10')

	def getAgcDrxlnabypdirControl(self):
		return self.__agcDrxlnabypdirControl

	def setMiscelleneousTxdsasw1(self,val):
		self.__miscelleneousTxdsasw1=val
	def getMiscelleneousTxdsasw1(self):
		return self.__miscelleneousTxdsasw1

	def setMiscelleneousTxdsasw1pinState(self,val):
		self.__miscelleneousTxdsasw1pinState=val
		self.afe77xxGpioMap('miscelleneousTxdsasw1pinState','CPLD','pinState',val,ballName='U13')

	def getMiscelleneousTxdsasw1pinState(self):
		return self.__miscelleneousTxdsasw1pinState

	def setMiscelleneousTxdsasw1dirControl(self,val):
		self.__miscelleneousTxdsasw1dirControl=val
		self.afe77xxGpioMap('miscelleneousTxdsasw1pinState','CPLD','dirControl',val,ballName='U13')

	def getMiscelleneousTxdsasw1dirControl(self):
		return self.__miscelleneousTxdsasw1dirControl

	def setMiscelleneousTxdsasw2(self,val):
		self.__miscelleneousTxdsasw2=val
	def getMiscelleneousTxdsasw2(self):
		return self.__miscelleneousTxdsasw2

	def setMiscelleneousTxdsasw2pinState(self,val):
		self.__miscelleneousTxdsasw2pinState=val
		self.afe77xxGpioMap('miscelleneousTxdsasw2pinState','CPLD','pinState',val,ballName='D13')

	def getMiscelleneousTxdsasw2pinState(self):
		return self.__miscelleneousTxdsasw2pinState

	def setMiscelleneousTxdsasw2dirControl(self,val):
		self.__miscelleneousTxdsasw2dirControl=val
		self.afe77xxGpioMap('miscelleneousTxdsasw2pinState','CPLD','dirControl',val,ballName='D13')

	def getMiscelleneousTxdsasw2dirControl(self):
		return self.__miscelleneousTxdsasw2dirControl

	def setMiscelleneousRxdsasw(self,val):
		self.__miscelleneousRxdsasw=val
	def getMiscelleneousRxdsasw(self):
		return self.__miscelleneousRxdsasw

	def setMiscelleneousRxdsaswpinState(self,val):
		self.__miscelleneousRxdsaswpinState=val
		self.afe77xxGpioMap('miscelleneousRxdsaswpinState','CPLD','pinState',val,ballName='U15')

	def getMiscelleneousRxdsaswpinState(self):
		return self.__miscelleneousRxdsaswpinState

	def setMiscelleneousRxdsaswdirControl(self,val):
		self.__miscelleneousRxdsaswdirControl=val
		self.afe77xxGpioMap('miscelleneousRxdsaswpinState','CPLD','dirControl',val,ballName='U15')

	def getMiscelleneousRxdsaswdirControl(self):
		return self.__miscelleneousRxdsaswdirControl

	def setMiscelleneousFbncosw(self,val):
		self.__miscelleneousFbncosw=val
	def getMiscelleneousFbncosw(self):
		return self.__miscelleneousFbncosw

	def setMiscelleneousFbncoswpinState(self,val):
		self.__miscelleneousFbncoswpinState=val
		self.afe77xxGpioMap('miscelleneousFbncoswpinState','CPLD','pinState',val,ballName='D15')

	def getMiscelleneousFbncoswpinState(self):
		return self.__miscelleneousFbncoswpinState

	def setMiscelleneousFbncoswdirControl(self,val):
		self.__miscelleneousFbncoswdirControl=val
		self.afe77xxGpioMap('miscelleneousFbncoswpinState','CPLD','dirControl',val,ballName='D15')

	def getMiscelleneousFbncoswdirControl(self):
		return self.__miscelleneousFbncoswdirControl

	def setMiscelleneousInt1(self,val):
		self.__miscelleneousInt1=val
	def getMiscelleneousInt1(self):
		return self.__miscelleneousInt1

	def setMiscelleneousInt1pinState(self,val):
		self.__miscelleneousInt1pinState=val
		self.afe77xxGpioMap('miscelleneousInt1pinState','CPLD','pinState',val,ballName='C17')

	def getMiscelleneousInt1pinState(self):
		return self.__miscelleneousInt1pinState

	def setMiscelleneousInt1dirControl(self,val):
		self.__miscelleneousInt1dirControl=val
		self.afe77xxGpioMap('miscelleneousInt1pinState','CPLD','dirControl',val,ballName='C17')

	def getMiscelleneousInt1dirControl(self):
		return self.__miscelleneousInt1dirControl

	def setMiscelleneousInt2(self,val):
		self.__miscelleneousInt2=val
	def getMiscelleneousInt2(self):
		return self.__miscelleneousInt2

	def setMiscelleneousInt2pinState(self,val):
		self.__miscelleneousInt2pinState=val
		self.afe77xxGpioMap('miscelleneousInt2pinState','CPLD','pinState',val,ballName='E17')

	def getMiscelleneousInt2pinState(self):
		return self.__miscelleneousInt2pinState

	def setMiscelleneousInt2dirControl(self,val):
		self.__miscelleneousInt2dirControl=val
		self.afe77xxGpioMap('miscelleneousInt2pinState','CPLD','dirControl',val,ballName='E17')

	def getMiscelleneousInt2dirControl(self):
		return self.__miscelleneousInt2dirControl

	def setMiscelleneousSleep(self,val):
		self.__miscelleneousSleep=val
	def getMiscelleneousSleep(self):
		return self.__miscelleneousSleep

	def setMiscelleneousSleeppinState(self,val):
		self.__miscelleneousSleeppinState=val
		self.afe77xxGpioMap('miscelleneousSleeppinState','CPLD','pinState',val,ballName='E16')

	def getMiscelleneousSleeppinState(self):
		return self.__miscelleneousSleeppinState

	def setMiscelleneousSleepdirControl(self,val):
		self.__miscelleneousSleepdirControl=val
		self.afe77xxGpioMap('miscelleneousSleeppinState','CPLD','dirControl',val,ballName='E16')

	def getMiscelleneousSleepdirControl(self):
		return self.__miscelleneousSleepdirControl

class afe77xxGpioInternalAgc(Interface):
	controller = afe77xxInternalAgcGpioController
	agcArxcdg0=Object(typ=Choice,choices ={0:"V9"},default=0,widgetParams={"setDisabled": True})
	agcArxcdg0dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcArxcdg0pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcArxcdg1=Object(typ=Choice,choices ={0:"U11"},default=0,widgetParams={"setDisabled": True})
	agcArxcdg1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcArxcdg1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcArxcdg2=Object(typ=Choice,choices ={0:"U12"},default=0,widgetParams={"setDisabled": True})
	agcArxcdg2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcArxcdg2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcArxcdg3=Object(typ=Choice,choices ={0:"V12"},default=0,widgetParams={"setDisabled": True})
	agcArxcdg3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcArxcdg3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcBrxcdg0=Object(typ=Choice,choices ={0:"R5"},default=0,widgetParams={"setDisabled": True})
	agcBrxcdg0dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcBrxcdg0pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcBrxcdg1=Object(typ=Choice,choices ={0:"T5"},default=0,widgetParams={"setDisabled": True})
	agcBrxcdg1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcBrxcdg1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcBrxcdg2=Object(typ=Choice,choices ={0:"U7"},default=0,widgetParams={"setDisabled": True})
	agcBrxcdg2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcBrxcdg2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcBrxcdg3=Object(typ=Choice,choices ={0:"V7"},default=0,widgetParams={"setDisabled": True})
	agcBrxcdg3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcBrxcdg3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcCrxcdg0=Object(typ=Choice,choices ={0:"C9"},default=0,widgetParams={"setDisabled": True})
	agcCrxcdg0dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcCrxcdg0pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcCrxcdg1=Object(typ=Choice,choices ={0:"C11"},default=0,widgetParams={"setDisabled": True})
	agcCrxcdg1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcCrxcdg1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcCrxcdg2=Object(typ=Choice,choices ={0:"D12"},default=0,widgetParams={"setDisabled": True})
	agcCrxcdg2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcCrxcdg2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcCrxcdg3=Object(typ=Choice,choices ={0:"C12"},default=0,widgetParams={"setDisabled": True})
	agcCrxcdg3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcCrxcdg3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcDrxcdg0=Object(typ=Choice,choices ={0:"F5"},default=0,widgetParams={"setDisabled": True})
	agcDrxcdg0dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcDrxcdg0pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcDrxcdg1=Object(typ=Choice,choices ={0:"E5"},default=0,widgetParams={"setDisabled": True})
	agcDrxcdg1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcDrxcdg1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcDrxcdg2=Object(typ=Choice,choices ={0:"D7"},default=0,widgetParams={"setDisabled": True})
	agcDrxcdg2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcDrxcdg2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcDrxcdg3=Object(typ=Choice,choices ={0:"C7"},default=0,widgetParams={"setDisabled": True})
	agcDrxcdg3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':False})

	agcDrxcdg3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcArxlnabyp=Object(typ=Choice,choices ={0:"V11"},default=0,widgetParams={"setDisabled": True})
	agcArxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcArxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcBrxlnabyp=Object(typ=Choice,choices ={0:"V10"},default=0,widgetParams={"setDisabled": True})
	agcBrxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcBrxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcCrxlnabyp=Object(typ=Choice,choices ={0:"D11"},default=0,widgetParams={"setDisabled": True})
	agcCrxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcCrxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcDrxlnabyp=Object(typ=Choice,choices ={0:"D10"},default=0,widgetParams={"setDisabled": True})
	agcDrxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcDrxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousTxdsasw1=Object(typ=Choice,choices ={0:"U13"},default=0,widgetParams={"setDisabled": True})
	miscelleneousTxdsasw1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousTxdsasw1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousTxdsasw2=Object(typ=Choice,choices ={0:"D13"},default=0,widgetParams={"setDisabled": True})
	miscelleneousTxdsasw2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousTxdsasw2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousRxdsasw=Object(typ=Choice,choices ={0:"U15"},default=0,widgetParams={"setDisabled": True})
	miscelleneousRxdsaswdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousRxdsaswpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousFbncosw=Object(typ=Choice,choices ={0:"D15"},default=0,widgetParams={"setDisabled": True})
	miscelleneousFbncoswdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousFbncoswpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousInt1=Object(typ=Choice,choices ={0:"C17"},default=0,widgetParams={"setDisabled": True})
	miscelleneousInt1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousInt1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousInt2=Object(typ=Choice,choices ={0:"E17"},default=0,widgetParams={"setDisabled": True})
	miscelleneousInt2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousInt2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousSleep=Object(typ=Choice,choices ={0:"E16"},default=0,widgetParams={"setDisabled": True})
	miscelleneousSleepdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousSleeppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	configure = Object(typ=Trigger,label='Configure',function='ConfigureFunc')
	readStates= Object(typ=Trigger,label='Read States',function='readStatesFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	ballNameChoicesList=['V9', 'U11', 'U12', 'V12', 'R5', 'T5', 'U7', 'V7', 'C9', 'C11', 'D12', 'C12', 'F5', 'E5', 'D7', 'C7', 'V11', 'V10', 'D11', 'D10', 'U13', 'D13', 'U15', 'D15', 'C17', 'E17', 'E16' ]

	def __init__(self,libInstance,gpio):
		super(afe77xxGpioInternalAgc,self).__init__(libInstance=libInstance,gpio=gpio)
		self.libInstance=libInstance
		self.gpio=gpio
		self.gui.show()
		self.gui.hide()

		self._agcArxcdg0dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcArxcdg0dirControl',val=self._agcArxcdg0dirControl.getValue()))

		self._agcArxcdg1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcArxcdg1dirControl',val=self._agcArxcdg1dirControl.getValue()))

		self._agcArxcdg2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcArxcdg2dirControl',val=self._agcArxcdg2dirControl.getValue()))

		self._agcArxcdg3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcArxcdg3dirControl',val=self._agcArxcdg3dirControl.getValue()))

		self._agcBrxcdg0dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcBrxcdg0dirControl',val=self._agcBrxcdg0dirControl.getValue()))

		self._agcBrxcdg1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcBrxcdg1dirControl',val=self._agcBrxcdg1dirControl.getValue()))

		self._agcBrxcdg2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcBrxcdg2dirControl',val=self._agcBrxcdg2dirControl.getValue()))

		self._agcBrxcdg3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcBrxcdg3dirControl',val=self._agcBrxcdg3dirControl.getValue()))

		self._agcCrxcdg0dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcCrxcdg0dirControl',val=self._agcCrxcdg0dirControl.getValue()))

		self._agcCrxcdg1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcCrxcdg1dirControl',val=self._agcCrxcdg1dirControl.getValue()))

		self._agcCrxcdg2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcCrxcdg2dirControl',val=self._agcCrxcdg2dirControl.getValue()))

		self._agcCrxcdg3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcCrxcdg3dirControl',val=self._agcCrxcdg3dirControl.getValue()))

		self._agcDrxcdg0dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcDrxcdg0dirControl',val=self._agcDrxcdg0dirControl.getValue()))

		self._agcDrxcdg1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcDrxcdg1dirControl',val=self._agcDrxcdg1dirControl.getValue()))

		self._agcDrxcdg2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcDrxcdg2dirControl',val=self._agcDrxcdg2dirControl.getValue()))

		self._agcDrxcdg3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcDrxcdg3dirControl',val=self._agcDrxcdg3dirControl.getValue()))

		self._agcArxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcArxlnabypdirControl',val=self._agcArxlnabypdirControl.getValue()))

		self._agcBrxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcBrxlnabypdirControl',val=self._agcBrxlnabypdirControl.getValue()))

		self._agcCrxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcCrxlnabypdirControl',val=self._agcCrxlnabypdirControl.getValue()))

		self._agcDrxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcDrxlnabypdirControl',val=self._agcDrxlnabypdirControl.getValue()))

		self._miscelleneousTxdsasw1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousTxdsasw1dirControl',val=self._miscelleneousTxdsasw1dirControl.getValue()))

		self._miscelleneousTxdsasw2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousTxdsasw2dirControl',val=self._miscelleneousTxdsasw2dirControl.getValue()))

		self._miscelleneousRxdsaswdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousRxdsaswdirControl',val=self._miscelleneousRxdsaswdirControl.getValue()))

		self._miscelleneousFbncoswdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousFbncoswdirControl',val=self._miscelleneousFbncoswdirControl.getValue()))

		self._miscelleneousInt1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousInt1dirControl',val=self._miscelleneousInt1dirControl.getValue()))

		self._miscelleneousInt2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousInt2dirControl',val=self._miscelleneousInt2dirControl.getValue()))

		self._miscelleneousSleepdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousSleepdirControl',val=self._miscelleneousSleepdirControl.getValue()))


	def defaultConfiguration(self):
		self._agcArxcdg0dirControl.setValue(0)
		self._agcArxcdg1dirControl.setValue(0)
		self._agcArxcdg2dirControl.setValue(0)
		self._agcArxcdg3dirControl.setValue(0)
		self._agcBrxcdg0dirControl.setValue(0)
		self._agcBrxcdg1dirControl.setValue(0)
		self._agcBrxcdg2dirControl.setValue(0)
		self._agcBrxcdg3dirControl.setValue(0)
		self._agcCrxcdg0dirControl.setValue(0)
		self._agcCrxcdg1dirControl.setValue(0)
		self._agcCrxcdg2dirControl.setValue(0)
		self._agcCrxcdg3dirControl.setValue(0)
		self._agcDrxcdg0dirControl.setValue(0)
		self._agcDrxcdg1dirControl.setValue(0)
		self._agcDrxcdg2dirControl.setValue(0)
		self._agcDrxcdg3dirControl.setValue(0)
		self._agcArxlnabypdirControl.setValue(1)
		self._agcBrxlnabypdirControl.setValue(1)
		self._agcCrxlnabypdirControl.setValue(1)
		self._agcDrxlnabypdirControl.setValue(1)
		self._miscelleneousTxdsasw1dirControl.setValue(0)
		self._miscelleneousTxdsasw2dirControl.setValue(0)
		self._miscelleneousRxdsaswdirControl.setValue(0)
		self._miscelleneousFbncoswdirControl.setValue(0)
		self._miscelleneousInt1dirControl.setValue(1)
		self._miscelleneousInt2dirControl.setValue(1)
		self._miscelleneousSleepdirControl.setValue(0)

	def directionChange(self,function,val):
		try:
			if val == 0:
				eval("self._"+str(function[:-10])+"pinState.gui.widgets[1].setDisabled(0)")
			elif val == 1:
				eval("self._"+str(function[:-10])+"pinState.gui.widgets[1].setDisabled(1)")
		except:
			log(function+"----"+str(val))

	def ConfigureFunc(self):
		for tag in self.ballNameChoicesList:
			self.libInstance.systemStatus.gpioStatus[tag] = gpioConstants.gpioInternalAgcMode[tag]
		self.libInstance.TOP.GPIO.configureAllGpio()

	def backFunc(self):
			pass
		
	def readStatesFunc(self):
		for tag in dir(self):
			if 'dirControl' in tag and '_' not in tag:
				tag = tag[:-10] 
				exec("name = self._"+str(tag)+".gui.widgets[0].combo.itemText(self._"+str(tag)+".getValue())")
				exec("self._"+str(tag)+"dirControl.setValue(not self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(name)+".dirControl)")
				exec("self._"+str(tag)+"pinState.setValue(self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(name)+"._pinState.getValue())")
