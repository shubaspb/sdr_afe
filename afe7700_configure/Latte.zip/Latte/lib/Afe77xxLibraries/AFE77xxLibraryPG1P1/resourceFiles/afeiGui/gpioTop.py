import globalDefs as Globals
from mInstrument import *
import iGui

class gpioTopController:
	def __init__(self,parent,*args,**kwargs):
		self.libInstance=kwargs['libInstance']
		self.systemParams=kwargs['libInstance'].systemParams
		self.__proceed = parent.proceed
		self.__c0 = parent.c0
		self.__c1 = parent.c1
		self.__c2 = parent.c2
		self.__c3 = parent.c3
		self.__c4 = parent.c4
		self.__c5 = parent.c5
		self.__c6 = parent.c6

		self.__s0 = parent.s0
		self.__s1 = parent.s1
		self.__s2 = parent.s2
		self.__s3 = parent.s3
		self.__s4 = parent.s4
		self.__s5 = parent.s5
		self.__s6 = parent.s6


	def setC0(self,val):
		self.__c0 = val
		self.libInstance.c0 = val

	def getC0(self):
		self.__c0 = self.libInstance.c0
		return self.__c0

	def setC1(self,val):
		self.__c1 = val
		self.libInstance.c1 = val

	def getC1(self):
		self.__c1 = self.libInstance.c1
		return self.__c1

	def setC2(self,val):
		self.__c2 = val
		self.libInstance.c2 = val

	def getC2(self):
		self.__c2 = self.libInstance.c2
		return self.__c2

	def setC3(self,val):
		self.__c3 = val
		self.libInstance.c3 = val

	def getC3(self):
		self.__c3 = self.libInstance.c3
		return self.__c3

	def setC4(self,val):
		self.__c4 = val
		self.libInstance.c4 = val

	def getC4(self):
		self.__c4 = self.libInstance.c4
		return self.__c4

	def setC5(self,val):
		self.__c5 = val
		self.libInstance.c5 = val

	def getC5(self):
		self.__c5 = self.libInstance.c5
		return self.__c5

	def setC6(self,val):
		self.__c6 = val
		self.libInstance.c6 = val

	def getC6(self):
		self.__c6 = self.libInstance.c6
		return self.__c6

	def setC7(self,val):
		self.__c7 = val
		self.libInstance.c7 = val

	def getC7(self):
		self.__c7 = self.libInstance.c7
		return self.__c7

	def setS0(self,val):
		self.getS0()

	def getS0(self):
		self.__s0 = self.libInstance.s0
		return self.__s0

	def setS1(self,val):
		self.__s1 = val

	def getS1(self):

		return self.__s1

	def setS2(self,val):
		self.__s2 = val

	def getS2(self):

		return self.__s2

	def setS3(self,val):
		self.__s3 = val

	def getS3(self):
	
		return self.__s3

	def setS4(self,val):
		self.__s4 = val

	def getS4(self):

		return self.__s4

	def setS5(self,val):
		self.__s5 = val

	def getS5(self):

		return self.__s5

	def setS6(self,val):
		self.__s6 = val

	def getS6(self):

		return self.__s6



class gpioTop(Interface):
	controller =gpioTopController
	proceed 	= Object(typ=Trigger,label='proceed',function='proceedFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	c0 	= Object(typ=Boolean,label='c0',default=0)
	c1 	= Object(typ=Boolean,label='c1',default=0)
	c2 	= Object(typ=Boolean,label='c2',default=0)
	c3 	= Object(typ=Boolean,label='c3',default=0)
	c4 	= Object(typ=Boolean,label='c4',default=0)
	c5 	= Object(typ=Boolean,label='c5',default=0)
	c6 	= Object(typ=Boolean,label='c6',default=0)
	# c7 	= Object(typ=Boolean,label='c7',default=0)
	s0 	= Object(typ=String,label='s7',default='EXTAGC_GPIOMode2')
	s1 	= Object(typ=String,label='s1',default='FSPI')
	s2 	= Object(typ=String,label='s2',default='INTAGC')
	s3 	= Object(typ=String,label='s3',default='EXTAGC')
	s4 	= Object(typ=String,label='s4',default='SPIB1')
	s5 	= Object(typ=String,label='s5',default='SPIB2')
	s6 	= Object(typ=String,label='s6',default='EXTAGC_GPIOMode1')
	# s7 	= Object(typ=String,label='s7',default='EXTAGC_GPIOMode2')
	pageName = Object(typ=String,label='func Groups',default='Select the function Groups')
	guiPageName = Object(typ=String,label='func Groups',default='groupSelection')

	############ Below are the choices List.

	def __init__(self,libInstance,guiControllerInstance):
		super(gpioTop,self).__init__(libInstance=libInstance,guiControllerInstance=guiControllerInstance)
		self.libInstance=libInstance
		self.guiControllerInstance = guiControllerInstance
		self.gui.hide()
		self._c0.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c0'))
		self._c1.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c1'))
		self._c2.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c2'))
		self._c3.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c3'))
		self._c4.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c4'))
		self._c5.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c5'))
		self._c6.gui.widgets[0].checkBox.stateChanged.connect(lambda:self.groupSelected('c6'))
		
		
		
		
	def groupSelected(self,arg):
		exec('val = self._'+arg+'.getValue()')
		if val:
			group = eval('self._s'+arg[1]+'.getValue()')
			self.guiControllerInstance.selectedGpioGroups.append(group)
		else:
			group = eval('self._s'+arg[1]+'.getValue()')
			self.guiControllerInstance.selectedGpioGroups.remove(group)

	def proceedFunc(self):
		"""  """
		
		groupSelectionIdx = self.guiControllerInstance.guiInstance.mainWindow.stackWidget.currentIndex()
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(groupSelectionIdx+1)
		self.guiControllerInstance.proceedFunc(self._guiPageName.getValue())


	def updateAllObjectsFunc(self):
		self._c0.getValue()
		self._c1.getValue()
		self._c2.getValue()
		self._c3.getValue()
		self._c4.getValue()
		self._c5.getValue()
		self._c6.getValue()
		self._c7.getValue()