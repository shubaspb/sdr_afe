
import globalDefs as Globals
from mInstrument import *
import iGui
from mDataTypes import *
import os
class gpioMapController:
	def __init__(self,parent,*args,**kwargs):
		self.libInstance=kwargs['libInstance']
		self.systemParams=kwargs['libInstance'].systemParams
		
		self.parent= parent
		self.__d8=parent.d8
		self.__d17=parent.d17
		self.__d18=parent.d18
		self.__c18=parent.c18
		self.__c17=parent.c17
		self.__c13=parent.c13
		self.__c14=parent.c14
		self.__d16=parent.d16
		self.__f18=parent.f18
		self.__e17=parent.e17
		self.__e16=parent.e16
		self.__d15=parent.d15
		self.__f17=parent.f17
		self.__e18=parent.e18
		self.__d5=parent.d5
		self.__c9=parent.c9
		self.__e5=parent.e5
		self.__c10=parent.c10
		self.__f5=parent.f5
		self.__d10=parent.d10
		self.__c6=parent.c6
		self.__c11=parent.c11
		self.__d6=parent.d6
		self.__d11=parent.d11
		self.__t16=parent.t16
		self.__v14=parent.v14
		self.__u16=parent.u16
		self.__v15=parent.v15
		self.__y18=parent.y18
		self.__w18=parent.w18
		self.__v16=parent.v16
		self.__v17=parent.v17
		self.__v18=parent.v18
		self.__c12=parent.c12
		self.__d14=parent.d14
		self.__c8=parent.c8
		self.__b5=parent.b5
		self.__e13=parent.e13
		self.__c5=parent.c5
		self.__c7=parent.c7
		self.__d12=parent.d12
		self.__d7=parent.d7
		self.__a5=parent.a5
		self.__v6=parent.v6
		self.__v11=parent.v11
		self.__u7=parent.u7
		self.__u13=parent.u13
		self.__y5=parent.y5
		self.__v10=parent.v10
		self.__u6=parent.u6
		self.__u11=parent.u11
		self.__w5=parent.w5
		self.__v5=parent.v5
		self.__u17=parent.u17
		self.__u15=parent.u15
		self.__r5=parent.r5
		self.__t5=parent.t5
		self.__t18=parent.t18
		self.__u18=parent.u18
		self.__r18=parent.r18
		self.__r17=parent.r17
		self.__v12=parent.v12
		self.__v9=parent.v9
		self.__v13=parent.v13
		self.__u10=parent.u10
		self.__u5=parent.u5
		self.__v7=parent.v7
		self.__u12=parent.u12
		self.__v8=parent.v8
		self.__u14=parent.u14
		self.__t17=parent.t17
		self.__t13=parent.t13
		self.__b18=parent.b18
		self.__a18=parent.a18
		self.__d13=parent.d13
		
		self.__gpioDescription = parent.gpioDescription
		self.__cpldPinState  = parent.cpldPinState
		
		self.__cpldSet = parent.cpldSet
		self.__mappingOrStatus = parent.mappingOrStatus
		
		self.__gpioSelList = parent.gpioSelList
		self.__inOutSel = parent.inOutSel
		self.__gpioFuncSel = parent.gpioFuncSel
		self.__addApplySel = parent.addApplySel
		self.__clearSel = parent.clearSel
		self.__spiB1CheckBox = parent.spiB1CheckBox
		self.__spiB2CheckBox = parent.spiB2CheckBox
		self.__extAgcCheckBox = parent.extAgcCheckBox
		self.__intAgcCheckBox = parent.intAgcCheckBox
		self.__extAgcMode1CheckBox = parent.extAgcMode1CheckBox
		self.__extAgcMode2CheckBox = parent.extAgcMode2CheckBox
		self.__fbIntCheckBox = parent.fbIntCheckBox
		self.__fbExtCheckBox = parent.fbExtCheckBox



	def setGpioDescription(self,val):
		#self.getGpioDescription()
		self.__gpioDescription = val

	def getGpioDescription(self):
		#self.__gpioDescription = self.gpioDescription
		return self.__gpioDescription
	
	def setCpldPinState(self,val):
		self.__cpldPinState = val
		self.cpldPinState = val

	def getCpldPinState(self):
		return self.__cpldPinState	
	
	def setMappingOrStatus(self,val):
		self.__mappingOrStatus = val
		self.mappingOrStatus = val
		
	def getMappingOrStatus(self):
		return self.__mappingOrStatus


	def setGpioSelList(self,val):
		self.__gpioSelList = val
	def getGpioSelList(self):
		return self.__gpioSelList

	def setInOutSel(self,val):
		self.__inOutSel = val
		self.parent.findValidFunctions()
		
	def getInOutSel(self):
		return self.__inOutSel

	def setGpioFuncSel(self,val):
		self.__gpioFuncSel = val

	def getGpioFuncSel(self):
		return self.__gpioFuncSel
			
	def setSpiB1CheckBox(self,val):
		self.__spiB1CheckBox = val
		if val==1:
			self.libInstance.systemParams.gpioMapping['V15']="spib1_sdo"
			self.libInstance.systemParams.gpioMapping['V16']="intbipo_spib1_sdo"
			self.libInstance.systemParams.gpioMapping['V14']="spib1_cs_n"
			self.libInstance.systemParams.gpioMapping['U16']="spib1_clk"
		else:
			if 'V15' in self.libInstance.systemParams.gpioMapping:
				if 'spib1_sdo' == self.libInstance.systemParams.gpioMapping['V15']:
					del self.libInstance.systemParams.gpioMapping['V15']
					
			if 'V16' in self.libInstance.systemParams.gpioMapping:
				if 'intbipo_spib1_sdo' == self.libInstance.systemParams.gpioMapping['V16']:
					del self.libInstance.systemParams.gpioMapping['V16']
					
			if 'V14' in self.libInstance.systemParams.gpioMapping:
				if 'spib1_cs_n' == self.libInstance.systemParams.gpioMapping['V14']:
					del self.libInstance.systemParams.gpioMapping['V14']
					
			if 'U16' in self.libInstance.systemParams.gpioMapping:
				if 'spib1_clk' == self.libInstance.systemParams.gpioMapping['U16']:
					del self.libInstance.systemParams.gpioMapping['U16']
		
		self.parent.updateStatusTab('v15')
		self.parent.updateStatusTab('v14')
		self.parent.updateStatusTab('v16')
		self.parent.updateStatusTab('u16')
			
	def getSpiB1CheckBox(self):
		return self.__spiB1CheckBox

	def setSpiB2CheckBox(self,val):
		self.__spiB2CheckBox = val
		if val==1:
			self.libInstance.systemParams.gpioMapping['T16']="spib2_sdo"
			self.libInstance.systemParams.gpioMapping['R17']="intbipo_spib2_sdo"
			self.libInstance.systemParams.gpioMapping['R18']="spib2_cs_n"
			self.libInstance.systemParams.gpioMapping['T17']="spib2_clk"
		else:
			if 'T16' in self.libInstance.systemParams.gpioMapping:
				if 'spib2_sdo' == self.libInstance.systemParams.gpioMapping['T16']:
					del self.libInstance.systemParams.gpioMapping['T16']
					
			if 'R17' in self.libInstance.systemParams.gpioMapping:
				if 'intbipo_spib2_sdo' == self.libInstance.systemParams.gpioMapping['R17']:
					del self.libInstance.systemParams.gpioMapping['R17']
					
			if 'F16' in self.libInstance.systemParams.gpioMapping:
				if 'spib2_cs_n' == self.libInstance.systemParams.gpioMapping['R18']:
					del self.libInstance.systemParams.gpioMapping['R18']
					
			if 'J14' in self.libInstance.systemParams.gpioMapping:
				if 'spib2_clk' == self.libInstance.systemParams.gpioMapping['T17']:
					del self.libInstance.systemParams.gpioMapping['T17']
		self.parent.updateStatusTab('t16')
		self.parent.updateStatusTab('r17')
		self.parent.updateStatusTab('r18')
		self.parent.updateStatusTab('t17')
			
		
	def getSpiB2CheckBox(self):
		return self.__spiB2CheckBox

	def setExtAgcCheckBox(self,val):
		self.__extAgcCheckBox = val
		self.parent.findValidFunctions()

	def getExtAgcCheckBox(self):
		return self.__extAgcCheckBox

	def setIntAgcCheckBox(self,val):
		self.__intAgcCheckBox = val
		self.parent.findValidFunctions()
		
	def getIntAgcCheckBox(self):
		return self.__intAgcCheckBox

	def setExtAgcMode1CheckBox(self,val):
		self.__extAgcMode1CheckBox = val
		self.parent.findValidFunctions()
		
	def getExtAgcMode1CheckBox(self):
		return self.__extAgcMode1CheckBox

	def setExtAgcMode2CheckBox(self,val):
		self.__extAgcMode2CheckBox = val
		self.parent.findValidFunctions()
		
	def getExtAgcMode2CheckBox(self):
		return self.__extAgcMode2CheckBox

	def setFbIntCheckBox(self,val):
		self.__fbIntCheckBox = val
		self.parent.findValidFunctions()
		
	def getFbIntCheckBox(self):
		return self.__fbIntCheckBox
		
	def setFbExtCheckBox(self,val):
		self.__fbExtCheckBox = val
		self.parent.findValidFunctions()
		
	def getFbExtCheckBox(self):
		return self.__fbExtCheckBox

class gpioMap(Interface):
	controller = gpioMapController
	
	if os.path.isdir(Globals.ASTERIX_DIR+"iGuiImages/"):
		redBulbImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/Red.png"
		greenBulbImgPath = Globals.ASTERIX_DIR+r"iGuiImages/Green.png"
		NotImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/Not.png"
		BufferImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/Buffer.png"
		onImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/switchON.png"
		offImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/switchOFF.png"
	else:
		redBulbImgPath =  Globals.ASTERIX_DIR+r"core/core/iGuiImages/Red.png"
		greenBulbImgPath = Globals.ASTERIX_DIR+r"core/core/iGuiImages/Green.png"
		NotImgPath =  Globals.ASTERIX_DIR+r"core/core/iGuiImages/Not.png"
		BufferImgPath =  Globals.ASTERIX_DIR+r"core/core/iGuiImages/Buffer.png"
		onImgPath =  Globals.ASTERIX_DIR+r"core/iGuiImages/switchON.png"
		offImgPath =  Globals.ASTERIX_DIR+r"core/iGuiImages/switchOFF.png"
	
	largeNotSelectedStyle = {"styleSheet":"QPushButton {color: #00994D; font-size: 6pt;background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:0px solid #ffffff; border-radius:3; font:bold;}QPushButton::hover {background-color:#00994D; color:white; border-color:#339;}"}
	medNotSelectedStyle = {"styleSheet":"QPushButton {color: #00994D; font-size: 5pt;background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:0px solid #ffffff; border-radius:3; font:bold;}QPushButton::hover {background-color:#00994D; color:white; border-color:#339;}"}
	smallNotSelectedStyle = {"styleSheet":"QPushButton {color: #00994D; font-size: 4pt;background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:0px solid #ffffff; border-radius:3; font:bold;}QPushButton::hover {background-color:#00994D; color:white; border-color:#339;}"}
	
	
	largeSelectedStyle = {"styleSheet":"QPushButton {color: #ffffff; font-size: 6pt;background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #00994D, stop: 1 #00994D); border:0px solid #00994D; border-radius:3; font:bold;}"}
	medSelectedStyle = {"styleSheet":"QPushButton {color: #ffffff; font-size: 5pt; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #00994D, stop: 1 #00994D); border:0px solid #00994D; border-radius:3; font:bold;}"}
	smallSelectedStyle = {"styleSheet":"QPushButton {color: #ffffff; font-size: 4pt; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #00994D, stop: 1 #00994D); border:0px solid #00994D; border-radius:3; font:bold;}"}
	
	
	lastUpdateList=[]
	
	d8= Object(typ=Trigger,function='d8Func',label='NA',widgetParams=largeNotSelectedStyle)
	d17= Object(typ=Trigger,function='d17Func',label='NA',widgetParams=largeNotSelectedStyle)
	d18= Object(typ=Trigger,function='d18Func',label='NA',widgetParams=largeNotSelectedStyle)
	c18= Object(typ=Trigger,function='c18Func',label='NA',widgetParams=largeNotSelectedStyle)
	c17= Object(typ=Trigger,function='c17Func',label='NA',widgetParams=largeNotSelectedStyle)
	c13= Object(typ=Trigger,function='c13Func',label='NA',widgetParams=largeNotSelectedStyle)
	c14= Object(typ=Trigger,function='c14Func',label='NA',widgetParams=largeNotSelectedStyle)
	d16= Object(typ=Trigger,function='d16Func',label='NA',widgetParams=largeNotSelectedStyle)
	f18= Object(typ=Trigger,function='f18Func',label='NA',widgetParams=largeNotSelectedStyle)
	e17= Object(typ=Trigger,function='e17Func',label='NA',widgetParams=largeNotSelectedStyle)
	e16= Object(typ=Trigger,function='e16Func',label='NA',widgetParams=largeNotSelectedStyle)
	d15= Object(typ=Trigger,function='d15Func',label='NA',widgetParams=largeNotSelectedStyle)
	f17= Object(typ=Trigger,function='f17Func',label='NA',widgetParams=largeNotSelectedStyle)
	e18= Object(typ=Trigger,function='e18Func',label='NA',widgetParams=largeNotSelectedStyle)
	d5= Object(typ=Trigger,function='d5Func',label='NA',widgetParams=largeNotSelectedStyle)
	c9= Object(typ=Trigger,function='c9Func',label='NA',widgetParams=largeNotSelectedStyle)
	e5= Object(typ=Trigger,function='e5Func',label='NA',widgetParams=largeNotSelectedStyle)
	c10= Object(typ=Trigger,function='c10Func',label='NA',widgetParams=largeNotSelectedStyle)
	f5= Object(typ=Trigger,function='f5Func',label='NA',widgetParams=largeNotSelectedStyle)
	d10= Object(typ=Trigger,function='d10Func',label='NA',widgetParams=largeNotSelectedStyle)
	c6= Object(typ=Trigger,function='c6Func',label='NA',widgetParams=largeNotSelectedStyle)
	c11= Object(typ=Trigger,function='c11Func',label='NA',widgetParams=largeNotSelectedStyle)
	d6= Object(typ=Trigger,function='d6Func',label='NA',widgetParams=largeNotSelectedStyle)
	d11= Object(typ=Trigger,function='d11Func',label='NA',widgetParams=largeNotSelectedStyle)
	t16= Object(typ=Trigger,function='t16Func',label='NA',widgetParams=largeNotSelectedStyle)
	v14= Object(typ=Trigger,function='v14Func',label='NA',widgetParams=largeNotSelectedStyle)
	u16= Object(typ=Trigger,function='u16Func',label='NA',widgetParams=largeNotSelectedStyle)
	v15= Object(typ=Trigger,function='v15Func',label='NA',widgetParams=largeNotSelectedStyle)
	y18= Object(typ=Trigger,function='y18Func',label='NA',widgetParams=largeNotSelectedStyle)
	w18= Object(typ=Trigger,function='w18Func',label='NA',widgetParams=largeNotSelectedStyle)
	v16= Object(typ=Trigger,function='v16Func',label='NA',widgetParams=largeNotSelectedStyle)
	v17= Object(typ=Trigger,function='v17Func',label='NA',widgetParams=largeNotSelectedStyle)
	v18= Object(typ=Trigger,function='v18Func',label='NA',widgetParams=largeNotSelectedStyle)
	c12= Object(typ=Trigger,function='c12Func',label='NA',widgetParams=largeNotSelectedStyle)
	d14= Object(typ=Trigger,function='d14Func',label='NA',widgetParams=largeNotSelectedStyle)
	c8= Object(typ=Trigger,function='c8Func',label='NA',widgetParams=largeNotSelectedStyle)
	b5= Object(typ=Trigger,function='b5Func',label='NA',widgetParams=largeNotSelectedStyle)
	e13= Object(typ=Trigger,function='e13Func',label='NA',widgetParams=largeNotSelectedStyle)
	c5= Object(typ=Trigger,function='c5Func',label='NA',widgetParams=largeNotSelectedStyle)
	c7= Object(typ=Trigger,function='c7Func',label='NA',widgetParams=largeNotSelectedStyle)
	d12= Object(typ=Trigger,function='d12Func',label='NA',widgetParams=largeNotSelectedStyle)
	d7= Object(typ=Trigger,function='d7Func',label='NA',widgetParams=largeNotSelectedStyle)
	a5= Object(typ=Trigger,function='a5Func',label='NA',widgetParams=largeNotSelectedStyle)
	v6= Object(typ=Trigger,function='v6Func',label='NA',widgetParams=largeNotSelectedStyle)
	v11= Object(typ=Trigger,function='v11Func',label='NA',widgetParams=largeNotSelectedStyle)
	u7= Object(typ=Trigger,function='u7Func',label='NA',widgetParams=largeNotSelectedStyle)
	u13= Object(typ=Trigger,function='u13Func',label='NA',widgetParams=largeNotSelectedStyle)
	y5= Object(typ=Trigger,function='y5Func',label='NA',widgetParams=largeNotSelectedStyle)
	v10= Object(typ=Trigger,function='v10Func',label='NA',widgetParams=largeNotSelectedStyle)
	u6= Object(typ=Trigger,function='u6Func',label='NA',widgetParams=largeNotSelectedStyle)
	u11= Object(typ=Trigger,function='u11Func',label='NA',widgetParams=largeNotSelectedStyle)
	w5= Object(typ=Trigger,function='w5Func',label='NA',widgetParams=largeNotSelectedStyle)
	v5= Object(typ=Trigger,function='v5Func',label='NA',widgetParams=largeNotSelectedStyle)
	u17= Object(typ=Trigger,function='u17Func',label='NA',widgetParams=largeNotSelectedStyle)
	u15= Object(typ=Trigger,function='u15Func',label='NA',widgetParams=largeNotSelectedStyle)
	r5= Object(typ=Trigger,function='r5Func',label='NA',widgetParams=largeNotSelectedStyle)
	t5= Object(typ=Trigger,function='t5Func',label='NA',widgetParams=largeNotSelectedStyle)
	t18= Object(typ=Trigger,function='t18Func',label='NA',widgetParams=largeNotSelectedStyle)
	u18= Object(typ=Trigger,function='u18Func',label='NA',widgetParams=largeNotSelectedStyle)
	r18= Object(typ=Trigger,function='r18Func',label='NA',widgetParams=largeNotSelectedStyle)
	r17= Object(typ=Trigger,function='r17Func',label='NA',widgetParams=largeNotSelectedStyle)
	v12= Object(typ=Trigger,function='v12Func',label='NA',widgetParams=largeNotSelectedStyle)
	v9= Object(typ=Trigger,function='v9Func',label='NA',widgetParams=largeNotSelectedStyle)
	v13= Object(typ=Trigger,function='v13Func',label='NA',widgetParams=largeNotSelectedStyle)
	u10= Object(typ=Trigger,function='u10Func',label='NA',widgetParams=largeNotSelectedStyle)
	u5= Object(typ=Trigger,function='u5Func',label='NA',widgetParams=largeNotSelectedStyle)
	v7= Object(typ=Trigger,function='v7Func',label='NA',widgetParams=largeNotSelectedStyle)
	u12= Object(typ=Trigger,function='u12Func',label='NA',widgetParams=largeNotSelectedStyle)
	v8= Object(typ=Trigger,function='v8Func',label='NA',widgetParams=largeNotSelectedStyle)
	u14= Object(typ=Trigger,function='u14Func',label='NA',widgetParams=largeNotSelectedStyle)
	t17= Object(typ=Trigger,function='t17Func',label='NA',widgetParams=largeNotSelectedStyle)
	t13= Object(typ=Trigger,function='t13Func',label='NA',widgetParams=largeNotSelectedStyle)
	b18= Object(typ=Trigger,function='b18Func',label='NA',widgetParams=largeNotSelectedStyle)
	a18= Object(typ=Trigger,function='a18Func',label='NA',widgetParams=largeNotSelectedStyle)
	d13= Object(typ=Trigger,function='d13Func',label='NA',widgetParams=largeNotSelectedStyle)
	
	
	gpioo = Object(typ=Trigger,label='GPIO',function='gpioFunc',widgetParams={"styleSheet":"QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {color:#white;background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #000000, stop: 1 #000000);}"})	#{"styleSheet":"QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);} QPushButton::hover {background-color:black; color:white; border-color:#ffffff;}"})
	dev0 = Object(typ=Trigger,label='Device',function='dev0Func',widgetParams={"styleSheet":"QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;} QPushButton::pressed {color:#black;background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);}"})	
		
	def dev0Func(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(2)
		self._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.sysParamClassInst._dev0.gui.widgets[1].button.setStyleSheet(white)
		self._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.sysParamClassInst._gpioo.gui.widgets[1].button.setStyleSheet(black)
		
		self._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.sysParamClassInst._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.sysParamClassInst._dev0.gui.widgets[1].button.setStyleSheet(white) 
		self.guiControllerInstance.customConfigInst._dev0.gui.widgets[1].button.setStyleSheet(white) 
		self.guiControllerInstance.statusRegistersInst._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.additionalConfigInst._dev0.gui.widgets[1].button.setStyleSheet(white)


		self._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.sysParamClassInst._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.sysParamClassInst._gpioo.gui.widgets[1].button.setStyleSheet(black) 
		self.guiControllerInstance.customConfigInst._gpioo.gui.widgets[1].button.setStyleSheet(black) 
		self.guiControllerInstance.statusRegistersInst._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.additionalConfigInst._gpioo.gui.widgets[1].button.setStyleSheet(black)

				
		
	def gpioFunc(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(8)
		self._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self._dev0.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.sysParamClassInst._gpioo.gui.widgets[1].button.setStyleSheet(white) #000000, stop: 1 #000000); border:1px solid #e3e3e3; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #000000, stop: 1 #000000);}")
		self.guiControllerInstance.sysParamClassInst._dev0.gui.widgets[1].button.setStyleSheet(black)   #ffffff, stop: 1 #ffffff); border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);} }")
		
		self._dev0.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.sysParamClassInst._dev0.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.sysParamClassInst._dev0.gui.widgets[1].button.setStyleSheet(black) 
		self.guiControllerInstance.customConfigInst._dev0.gui.widgets[1].button.setStyleSheet(black) 
		self.guiControllerInstance.statusRegistersInst._dev0.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.additionalConfigInst._dev0.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(black)

		self._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.sysParamClassInst._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.sysParamClassInst._gpioo.gui.widgets[1].button.setStyleSheet(white) 
		self.guiControllerInstance.customConfigInst._gpioo.gui.widgets[1].button.setStyleSheet(white) 
		self.guiControllerInstance.statusRegistersInst._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.additionalConfigInst._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet(white)
		
		
		
	refresh= Object(typ=Trigger,function='updateAllIndicatorsFunc',label='Refresh',widgetParams={"styleSheet":'QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49); border:2px solid #264026; border-radius:8; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49);} QPushButton::hover {background-color:white; color:black; border-color:#264026;}'})
	
	gpioDescription = Object(typ=String,label='gpioDescription',default= 'GPIO Description', widgetParams={"styleSheet":'font-size: 8pt;'})
	cpldPinState  = Object(typ=Boolean,label='cpldPinState',default=False, widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(onImgPath,offImgPath)})
	
	cpldSet 	= Object(typ=Trigger,label='CPLD Set',function='checkState',widgetParams={"styleSheet":'QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49); border:2px solid #264026; border-radius:8; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49);} QPushButton::hover {background-color:white; color:black; border-color:#264026;}'})
	
	mappingOrStatus = Object(typ=Choice,choices={0:'Set Value',1:'Configured Value'},label='mappingOrStatus',default=0, widgetParams={"styleSheet":'QComboBox {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 white, stop: 1 white); border:2px solid #FFCE9F; border-radius:0; font:bold;} QComboBox::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 white, stop: 1 white);} QComboBox::hover {background-color:white; color:black; border-color:#FFCE9F;}'})
	
	gpioSelList 	= Object(typ=String,label='gpioSelList',default='List Of GPIO Functions', widgetParams={"styleSheet":'font-size: 8pt;'})
	inOutSel 	= Object(typ=Choice,choices={0:'Input',1:'Output'},label='inOutSel',default=0)
	gpioFuncSel 	= Object(typ=Choice,choices={0:'Func1',1:'func2'},label='gpioFuncSel',default=0)
	addApplySel 	= Object(typ=Trigger,label='Apply',function='addApplySelFunc',widgetParams={"styleSheet":'QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49); border:2px solid #264026; border-radius:8; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49);} QPushButton::hover {background-color:white; color:black; border-color:#264026;}'})
	clearSel 	= Object(typ=Trigger,label='ClearPinConfig',function='clearSelFunc',widgetParams={"styleSheet":'QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49); border:2px solid #264026; border-radius:8; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #99FF99, stop: 1 #497A49);} QPushButton::hover {background-color:white; color:black; border-color:#264026;}'})
	spiB1CheckBox 	= Object(typ=Boolean,label='spiB1CheckBox',default=0)
	spiB2CheckBox 	= Object(typ=Boolean,label='spiB2CheckBox',default=0)
	extAgcCheckBox 	= Object(typ=Boolean,label='extAgcCheckBox',default=0)
	intAgcCheckBox 	= Object(typ=Boolean,label='intAgcCheckBox',default=0)
	extAgcMode1CheckBox 	= Object(typ=Boolean,label='extAgcMode1CheckBox',default=0)
	extAgcMode2CheckBox 	= Object(typ=Boolean,label='extAgcMode2CheckBox',default=0)
	fbIntCheckBox 	= Object(typ=Boolean,label='fbIntCheckBox',default=0)
	fbExtCheckBox 	= Object(typ=Boolean,label='fbExtCheckBox',default=0)
	
	
	inOutSelChoicesList = ['Input', 'Output']
	gpioFuncSelChoicesList = ['Func1', 'func2']
	
	guiPageName="GPIO-Status"
	def __init__(self,libInstance,guiControllerInstance,cpld):
		super(gpioMap,self).__init__(libInstance=libInstance,guiControllerInstance=guiControllerInstance)
		self.libInstance=libInstance
		self.guiControllerInstance=guiControllerInstance
		self.gpioConstants=guiControllerInstance.gpioConstants
		self.cpld = cpld
		self.selectedBallName=""
		self.validInputFunctions=[]
		self.validOutputFunctions=[]
		self.outputFuncDict=self.gpioConstants.outputFuncDict.copy()
		self.inputFuncDict=self.gpioConstants.inputFuncDict.copy()
		self.gpioList=self.gpioConstants.gpioList.copy()
		self.validInputFunctions=[]
		self.validOutputFunctions=[]
		for funcGroup in self.outputFuncDict:
			for func in self.outputFuncDict[funcGroup]:
				self.validOutputFunctions.append(func)
		for funcGroup in self.inputFuncDict:
			for func in self.inputFuncDict[funcGroup]:
				self.validInputFunctions.append(func)
		self.currentSelectedBall=""
		self.currentListDropDown=[]
		self.findValidFunctions()
		
	def d8Func(self):
		 self.updateStatusTab('d8')

	def d17Func(self):
		 self.updateStatusTab('d17')

	def d18Func(self):
		 self.updateStatusTab('d18')

	def c18Func(self):
		 self.updateStatusTab('c18')

	def c17Func(self):
		 self.updateStatusTab('c17')

	def c13Func(self):
		 self.updateStatusTab('c13')

	def c14Func(self):
		 self.updateStatusTab('c14')

	def d16Func(self):
		 self.updateStatusTab('d16')

	def f18Func(self):
		 self.updateStatusTab('f18')

	def e17Func(self):
		 self.updateStatusTab('e17')

	def e16Func(self):
		 self.updateStatusTab('e16')

	def d15Func(self):
		 self.updateStatusTab('d15')

	def f17Func(self):
		 self.updateStatusTab('f17')

	def e18Func(self):
		 self.updateStatusTab('e18')

	def d5Func(self):
		 self.updateStatusTab('d5')

	def c9Func(self):
		 self.updateStatusTab('c9')

	def e5Func(self):
		 self.updateStatusTab('e5')

	def c10Func(self):
		 self.updateStatusTab('c10')

	def f5Func(self):
		 self.updateStatusTab('f5')

	def d10Func(self):
		 self.updateStatusTab('d10')

	def c6Func(self):
		 self.updateStatusTab('c6')

	def c11Func(self):
		 self.updateStatusTab('c11')

	def d6Func(self):
		 self.updateStatusTab('d6')

	def d11Func(self):
		 self.updateStatusTab('d11')

	def t16Func(self):
		 self.updateStatusTab('t16')

	def v14Func(self):
		 self.updateStatusTab('v14')

	def u16Func(self):
		 self.updateStatusTab('u16')

	def v15Func(self):
		 self.updateStatusTab('v15')

	def y18Func(self):
		 self.updateStatusTab('y18')

	def w18Func(self):
		 self.updateStatusTab('w18')

	def v16Func(self):
		 self.updateStatusTab('v16')

	def v17Func(self):
		 self.updateStatusTab('v17')

	def v18Func(self):
		 self.updateStatusTab('v18')

	def c12Func(self):
		 self.updateStatusTab('c12')

	def d14Func(self):
		 self.updateStatusTab('d14')

	def c8Func(self):
		 self.updateStatusTab('c8')

	def b5Func(self):
		 self.updateStatusTab('b5')

	def e13Func(self):
		 self.updateStatusTab('e13')

	def c5Func(self):
		 self.updateStatusTab('c5')

	def c7Func(self):
		 self.updateStatusTab('c7')

	def d12Func(self):
		 self.updateStatusTab('d12')

	def d7Func(self):
		 self.updateStatusTab('d7')

	def a5Func(self):
		 self.updateStatusTab('a5')

	def v6Func(self):
		 self.updateStatusTab('v6')

	def v11Func(self):
		 self.updateStatusTab('v11')

	def u7Func(self):
		 self.updateStatusTab('u7')

	def u13Func(self):
		 self.updateStatusTab('u13')

	def y5Func(self):
		 self.updateStatusTab('y5')

	def v10Func(self):
		 self.updateStatusTab('v10')

	def u6Func(self):
		 self.updateStatusTab('u6')

	def u11Func(self):
		 self.updateStatusTab('u11')

	def w5Func(self):
		 self.updateStatusTab('w5')

	def v5Func(self):
		 self.updateStatusTab('v5')

	def u17Func(self):
		 self.updateStatusTab('u17')

	def u15Func(self):
		 self.updateStatusTab('u15')

	def r5Func(self):
		 self.updateStatusTab('r5')

	def t5Func(self):
		 self.updateStatusTab('t5')

	def t18Func(self):
		 self.updateStatusTab('t18')

	def u18Func(self):
		 self.updateStatusTab('u18')

	def r18Func(self):
		 self.updateStatusTab('r18')

	def r17Func(self):
		 self.updateStatusTab('r17')

	def v12Func(self):
		 self.updateStatusTab('v12')

	def v9Func(self):
		 self.updateStatusTab('v9')

	def v13Func(self):
		 self.updateStatusTab('v13')

	def u10Func(self):
		 self.updateStatusTab('u10')

	def u5Func(self):
		 self.updateStatusTab('u5')

	def v7Func(self):
		 self.updateStatusTab('v7')

	def u12Func(self):
		 self.updateStatusTab('u12')

	def v8Func(self):
		 self.updateStatusTab('v8')

	def u14Func(self):
		 self.updateStatusTab('u14')

	def t17Func(self):
		 self.updateStatusTab('t17')

	def t13Func(self):
		 self.updateStatusTab('t13')

	def b18Func(self):
		 self.updateStatusTab('b18')

	def a18Func(self):
		 self.updateStatusTab('a18')

	def d13Func(self):
		 self.updateStatusTab('d13')
	
	
	##--New--##
	def addApplySelFunc(self):
		"""  """
		self._mappingOrStatus.setValue(0)
		gpioFuncSel=self.currentListDropDown[self.gpioFuncSel]
		if self.currentSelectedBall!="" and self.currentListDropDown!=[]:
			if self.inOutSel==0 and self.currentSelectedBall in self.libInstance.systemParams.gpioMapping:
				if self.libInstance.systemParams.gpioMapping[self.currentSelectedBall]=="":
					self.libInstance.systemParams.gpioMapping[self.currentSelectedBall]=gpioFuncSel
				elif isinstance(self.libInstance.systemParams.gpioMapping[self.currentSelectedBall],str):
					self.libInstance.systemParams.gpioMapping[self.currentSelectedBall]=[self.libInstance.systemParams.gpioMapping[self.currentSelectedBall],gpioFuncSel]
				else:
					self.libInstance.systemParams.gpioMapping[self.currentSelectedBall].append(gpioFuncSel)
			else:
				self.libInstance.systemParams.gpioMapping[self.currentSelectedBall]=gpioFuncSel
			self.updateStatusTab(self.currentSelectedBall)
		self.updateOneBall(self.currentSelectedBall)
		
	def clearSelFunc(self):
		"""  """
		self._mappingOrStatus.setValue(0)
		if self.currentSelectedBall!="":
			del self.libInstance.systemParams.gpioMapping[self.currentSelectedBall]
		self.updateStatusTab(self.currentSelectedBall)
		self.updateOneBall(self.currentSelectedBall)
		
	def checkState(self):
		for idx,val in enumerate(self.libInstance.systemParams.gpioMapping.values()):
			self.checkDirectionFunc(val)
	
	def findValidFunctions(self):
		selectedGpioGroups=["MAIN"]
		if self.extAgcCheckBox==1:
			selectedGpioGroups.append("EXTAGC")
		elif self.intAgcCheckBox==1:
			selectedGpioGroups.append("INTAGC")
		elif self.extAgcMode1CheckBox==1:
			selectedGpioGroups.append("EXTAGC_GPIOMode1")
		elif self.extAgcMode2CheckBox==1:
			selectedGpioGroups.append("EXTAGC_GPIOMode2")
		elif self.fbIntCheckBox==1:
			selectedGpioGroups.append("FBINTAGC")
		elif self.fbExtCheckBox==1:
			selectedGpioGroups.append("FBEXTAGC")
		
		currentlySetFunctions=[]
		for funcValue in self.libInstance.systemParams.gpioMapping.values():
			if isinstance(funcValue,str):
				currentlySetFunctions.append(funcValue)
			else:
				for func in funcValue:
					currentlySetFunctions.append(func)
		listDropDown=[]
		if self.inOutSel==0:
			for funcGroup in selectedGpioGroups:
				if funcGroup in self.inputFuncDict.keys():
					for func in self.inputFuncDict[funcGroup]:
						if func not in currentlySetFunctions:
							listDropDown.append(func)
		else:
			for funcGroup in selectedGpioGroups:
				if funcGroup in self.outputFuncDict.keys():
					for func in self.outputFuncDict[funcGroup]:
						listDropDown.append(func)
		
		self.currentListDropDown=listDropDown[:]
		choicesDictParam={}
		for i in range(len(listDropDown)):
			choicesDictParam[i]=listDropDown[i]
		exec("self._gpioFuncSel.reloadItems(choicesDictParam)")
	#findValidFunctions
	
	def checkDirectionFunc(self,key):
		if self.mappingOrStatus==0:
			gpioDict=self.libInstance.systemParams.gpioMapping
		else:
			gpioDict=self.libInstance.systemStatus.gpioStatus
		
		for groupName in self.gpioConstants.outputFuncDict.keys():
			if key in self.gpioConstants.outputFuncDict[groupName].keys():
				direction = 'Output'
		for groupName in self.gpioConstants.inputFuncDict.keys():
			if key in self.gpioConstants.inputFuncDict[groupName].keys():
				direction = 'Input'
		for idx,val in enumerate(gpioDict.keys()):
			key = gpioDict.values()[idx]
			if val in self.cpld.CPLD.PINCONTROL.PINCONTROL.entities.keys():
				if direction == 'Input':
					eval("self.cpld.CPLD.PINCONTROL.PINCONTROL."+val+"._dirControl.setValue(0)")
				if direction == 'Output':
					eval("self.cpld.CPLD.PINCONTROL.PINCONTROL."+val+"._dirControl.setValue(1)")
		if self.selectedBallName.upper() in self.cpld.CPLD.PINCONTROL.PINCONTROL.entities.keys():
			eval("self.cpld.CPLD.PINCONTROL.PINCONTROL."+self.selectedBallName.upper()+"._pinState.setValue("+str(self._cpldPinState.getValue())+")")
			
	def updateAllIndicatorsFunc(self):
		self._gpioSelList.getValue()
		for ballName in self.gpioConstants.supportedBallNames:
			self.updateOneBall(ballName)
	
	def updateOneBall(self,ballName):
		if self.mappingOrStatus==0:
			gpioDict=self.libInstance.systemParams.gpioMapping
		else:
			gpioDict=self.libInstance.systemStatus.gpioStatus
		
		for widgetNo in eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets.keys()"):#self._f16.gui.widgets.keys():
			if ballName in gpioDict.keys():
				if isinstance(gpioDict[ballName],str):
					eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[widgetNo].button.setText('"+str(gpioDict[ballName])+"')")
					val = gpioDict[ballName]
					self.styleChange(ballName,False,val)
				elif isinstance(gpioDict[ballName],list):
					if len(gpioDict[ballName]) == 2:
						eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[widgetNo].button.setText('"+str(gpioDict[ballName][0])+"\\n"+str(gpioDict[ballName][1])+"')")
						for val in gpioDict[ballName]:
							self.styleChange(ballName,False,val)
					elif len(gpioDict[ballName]) > 2 :
						for val in gpioDict[ballName]:
							self.styleChange(ballName,False,val)
						eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[widgetNo].button.setText('"+str(gpioDict[ballName][0])+"\\n"+str(gpioDict[ballName][1])+"\\n"+str(gpioDict[ballName][2])+"')")	
			else:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[widgetNo].button.setText('NA')")
		
	def updateStatusTab(self,ballName):
		self.currentSelectedBall=ballName.upper()
		ballName=ballName.lower()
		if self.mappingOrStatus==0:
			gpioDict=self.libInstance.systemParams.gpioMapping
		else:
			gpioDict=self.libInstance.systemStatus.gpioStatus
		
		inputOrOutput=0
		listOfGpioFunctions="Ball "+ballName.upper()+":\n"
		desc=""
		ballName=ballName.upper()
		if ballName in gpioDict.keys():
			if isinstance(gpioDict[ballName],str):
				func=gpioDict[ballName]
				if func!="NA":
					if func in self.gpioConstants.inputFunctions.keys():
						groupName=self.gpioConstants.inputFunctions[func]['groupName']
						desc=func+": "+self.gpioConstants.inputFuncDict[groupName][func]['description']
						listOfGpioFunctions+=func+"\n"
						inputOrOutput=0
					elif func in self.gpioConstants.outputFunctions.keys():
						groupName=self.gpioConstants.outputFunctions[func]['groupName']
						desc=func+": "+self.gpioConstants.outputFuncDict[groupName][func]['description']
						listOfGpioFunctions+=func+"\n"
						inputOrOutput=1
			else:
				for func in gpioDict[ballName]:
					desc1=""
					if func in self.gpioConstants.inputFunctions.keys():
						groupName=self.gpioConstants.inputFunctions[func]['groupName']
						desc1=self.gpioConstants.inputFuncDict[groupName][func]['description']
						listOfGpioFunctions+=func+"\n"
						inputOrOutput=0
					elif func in self.gpioConstants.outputFunctions.keys():
						groupName=self.gpioConstants.outputFunctions[func]['groupName']
						desc1=self.gpioConstants.outputFuncDict[groupName][func]['description']
						listOfGpioFunctions+=func+"\n"
						inputOrOutput=1
					if desc!="":
						desc+=";\n"+func+": "+desc1
					else:
						desc=desc1
		self._gpioDescription.setValue(desc)
		ballName=ballName.lower()
		
		self.selectedBallName = ballName
		if len(self.lastUpdateList) == 0:
			self.lastUpdateList.append(ballName)
		else:
			for tag in self.lastUpdateList:
				exec('word = self._'+tag+'.gui.widgets[0].button.text()')
				self.styleChange(tag,False,word)
			self.lastUpdateList=[]
			self.lastUpdateList.append(ballName)
		exec('word = self._'+ballName+'.gui.widgets[0].button.text()')
		if '\n' in word:
			funcNameList = word.split('\n')
			for funcName in funcNameList:
				self.styleChange(ballName,True,funcName)
		else:
			funcName = word
			self.styleChange(ballName,True,funcName)
		
		self._gpioSelList.setValue(listOfGpioFunctions)
		self._inOutSel.setValue(inputOrOutput)
		
		
	def styleChange(self,ballName,selected,funcName,type=None):
		if selected:
			if len(funcName) < 16:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[1].button.setStyleSheet(self.largeSelectedStyle['styleSheet'])")
			if 18 > len(funcName) > 15:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[1].button.setStyleSheet(self.medSelectedStyle['styleSheet'])")
			elif len(funcName) > 18:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[1].button.setStyleSheet(self.smallSelectedStyle['styleSheet'])")
		else:
			if len(funcName) < 16:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[1].button.setStyleSheet(self.largeNotSelectedStyle['styleSheet'])")
			if 18 > len(funcName) > 15:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[1].button.setStyleSheet(self.medNotSelectedStyle['styleSheet'])")
			elif len(funcName) > 18:
				eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[1].button.setStyleSheet(self.smallNotSelectedStyle['styleSheet'])")

	##--New--##
	
	
	
	
	
	
	# def updateAllIndicatorsFunc(self):
		# if self.selOption==0:
			# selList=self._controller.libInstance.systemParams.gpioMapping
		# else:
			# selList=self._controller.libInstance.systemStatus.gpioStatus
		
		# for ballName in selList.keys():
			# try:
				# if isinstance(selList[ballName],str):
					# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setText('"+str(selList[ballName])+"')")
					# val = selList[ballName]
					# self.styleChange(ballName,False,val)
				# elif isinstance(selList[ballName],list):
					# if len(selList[ballName]) == 2:
						# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setText('"+str(selList[ballName][0])+"\n"+str(selList[ballName][1])+"')")
						# for val in selList[ballName]:
							# self.styleChange(ballName,False,val)
					# elif len(selList[ballName]) > 2 :
						# for val in selList[ballName]:
							# self.styleChange(ballName,False,val)
						# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setText('"+str(selList[ballName][0])+"\n"+str(selList[ballName]
# [1])+"\n"+str(selList[ballName][2])+"')")	
			# except:
				# print ballName +" is not in the Final Map GUI"

	# def updateStatusTab(self,ballName):
		# if len(self.lastUpdateList) == 0:
			# self.lastUpdateList.append(ballName)
		# else:
			# for tag in self.lastUpdateList:
				# exec('word = self._'+tag+'.gui.widgets[0].button.text()')
				# self.styleChange(tag,False,word)
			# self.lastUpdateList=[]
			# self.lastUpdateList.append(ballName)
		# exec('word = self._'+ballName[0].lower()+ballName[1:].upper()+'.gui.widgets[0].button.text()')
		# if '\n' in word:
			# funcNameList = word.split('\n')
			# for funcName in funcNameList:
				# self.styleChange(ballName,True,funcName)
		# else:
			# funcName = word
			# self.styleChange(ballName,True,funcName)
				
	# def styleChange(self,ballName,selected,funcName,type=None):
		# if selected:
			# if len(funcName) < 16:
				# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setStyleSheet(self.largeSelectedStyle['styleSheet'])")
			# if 18 > len(funcName) > 15:
				# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setStyleSheet(self.medSelectedStyle['styleSheet'])")
			# elif len(funcName) > 18:
				# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setStyleSheet(self.smallSelectedStyle['styleSheet'])")
		# else:
			# if len(funcName) < 16:
				# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setStyleSheet(self.largeNotSelectedStyle['styleSheet'])")
			# if 18 > len(funcName) > 15:
				# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setStyleSheet(self.medNotSelectedStyle['styleSheet'])")
			# elif len(funcName) > 18:
				# eval("self._"+ballName[0].lower()+ballName[1:]+".gui.widgets[0].button.setStyleSheet(self.smallNotSelectedStyle['styleSheet'])")
