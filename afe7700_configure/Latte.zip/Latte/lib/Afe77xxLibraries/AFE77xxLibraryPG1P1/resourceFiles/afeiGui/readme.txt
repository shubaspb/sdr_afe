Version 1p5:
	1.Added FPGA connection status block on iGui.
	2.Added iGui initialize functions in afeiGuiController file.
	3.Added redBulb.png and greenBulb.png pics in afeiGui folder later need to compile with dist folder

Version 1p4:
	1.Disabled 491.52 and 737.28 iq rates for FB when half rate for fb turned on
	2.Removed logging of fref select. 
Version 1p3: 
	1.Added halfRateMode Rx, Fb, Tx parameters on the iGui
	2.Updated devInit
	3.Fpga reset through software


Version 1p2: 
	Issues Fixed
	1.myfpga.Reconnect() Button
	2.pllEn LMK is default 1
	3.pll config done message at the beginning 
	4.Interrupt calling from iGui
	5.After opening generate configuration, device Bringup is not working

Version 1p1: AFE77xxLibs_V2p14p6_GuiTestVersion_1p1
	Issues Fixed
	1. Configure Pll is not working with device bringup
	2. After opening generate configuration, device Bringup is not working
	3. If AB in TDD and CD in FDD then PLL is not supported but bringup is happening
	4. In 4t4r FDD mode both PLL are configured to same frequency
	5. If interrupt is called multiple times, then each time its automatically called.
	6. DDC/DUC factor are rounding off to integer. 54X mode fails (int in configure digital)
	7. DC pll value change is not updated to systemParams after configuration

Version 1p0: AFE77xxLibs_V2p14p6_GuiTestVersion_1p0
	Issues Fixed
	1. If other usb/FTDI devices are connected, it doesn't detect EVM
	2. Fresh Bringup through Igui shows issue with systemParamClassiGui


Version 0p0: AFE77xxLibs_V2p14p6_GuiTestVersion	
	1. Initial Release of AFE77xxiGui with libs version 2p14p6 for exhaustive testing