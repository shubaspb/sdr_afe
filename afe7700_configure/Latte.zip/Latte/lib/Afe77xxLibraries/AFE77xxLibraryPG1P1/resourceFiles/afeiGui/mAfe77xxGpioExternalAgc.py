


from mInstrument import *
from mAfeConstants import gpioConstants


class afe77xxGpioExternalAgcController:
	def __init__(self,parent,*args,**kwargs):
		self.parent = parent
		self.libInstance=kwargs['libInstance']
		self.gpio = kwargs['gpio']
		self.__peakDetectorArxpkdet1=parent.peakDetectorArxpkdet1
		self.__peakDetectorArxpkdet1pinState=parent.peakDetectorArxpkdet1pinState
		self.__peakDetectorArxpkdet1dirControl=parent.peakDetectorArxpkdet1dirControl

		self.__peakDetectorArxpkdet2=parent.peakDetectorArxpkdet2
		self.__peakDetectorArxpkdet2pinState=parent.peakDetectorArxpkdet2pinState
		self.__peakDetectorArxpkdet2dirControl=parent.peakDetectorArxpkdet2dirControl

		self.__peakDetectorArxpkdet3=parent.peakDetectorArxpkdet3
		self.__peakDetectorArxpkdet3pinState=parent.peakDetectorArxpkdet3pinState
		self.__peakDetectorArxpkdet3dirControl=parent.peakDetectorArxpkdet3dirControl

		self.__peakDetectorBrxpkdet1=parent.peakDetectorBrxpkdet1
		self.__peakDetectorBrxpkdet1pinState=parent.peakDetectorBrxpkdet1pinState
		self.__peakDetectorBrxpkdet1dirControl=parent.peakDetectorBrxpkdet1dirControl

		self.__peakDetectorBrxpkdet2=parent.peakDetectorBrxpkdet2
		self.__peakDetectorBrxpkdet2pinState=parent.peakDetectorBrxpkdet2pinState
		self.__peakDetectorBrxpkdet2dirControl=parent.peakDetectorBrxpkdet2dirControl

		self.__peakDetectorBrxpkdet3=parent.peakDetectorBrxpkdet3
		self.__peakDetectorBrxpkdet3pinState=parent.peakDetectorBrxpkdet3pinState
		self.__peakDetectorBrxpkdet3dirControl=parent.peakDetectorBrxpkdet3dirControl

		self.__peakDetectorCrxpkdet1=parent.peakDetectorCrxpkdet1
		self.__peakDetectorCrxpkdet1pinState=parent.peakDetectorCrxpkdet1pinState
		self.__peakDetectorCrxpkdet1dirControl=parent.peakDetectorCrxpkdet1dirControl

		self.__peakDetectorCrxpkdet2=parent.peakDetectorCrxpkdet2
		self.__peakDetectorCrxpkdet2pinState=parent.peakDetectorCrxpkdet2pinState
		self.__peakDetectorCrxpkdet2dirControl=parent.peakDetectorCrxpkdet2dirControl

		self.__peakDetectorCrxpkdet3=parent.peakDetectorCrxpkdet3
		self.__peakDetectorCrxpkdet3pinState=parent.peakDetectorCrxpkdet3pinState
		self.__peakDetectorCrxpkdet3dirControl=parent.peakDetectorCrxpkdet3dirControl

		self.__peakDetectorDrxpkdet1=parent.peakDetectorDrxpkdet1
		self.__peakDetectorDrxpkdet1pinState=parent.peakDetectorDrxpkdet1pinState
		self.__peakDetectorDrxpkdet1dirControl=parent.peakDetectorDrxpkdet1dirControl

		self.__peakDetectorDrxpkdet2=parent.peakDetectorDrxpkdet2
		self.__peakDetectorDrxpkdet2pinState=parent.peakDetectorDrxpkdet2pinState
		self.__peakDetectorDrxpkdet2dirControl=parent.peakDetectorDrxpkdet2dirControl

		self.__peakDetectorDrxpkdet3=parent.peakDetectorDrxpkdet3
		self.__peakDetectorDrxpkdet3pinState=parent.peakDetectorDrxpkdet3pinState
		self.__peakDetectorDrxpkdet3dirControl=parent.peakDetectorDrxpkdet3dirControl

		self.__agcArxlnabyp=parent.agcArxlnabyp
		self.__agcArxlnabyppinState=parent.agcArxlnabyppinState
		self.__agcArxlnabypdirControl=parent.agcArxlnabypdirControl

		self.__agcBrxlnabyp=parent.agcBrxlnabyp
		self.__agcBrxlnabyppinState=parent.agcBrxlnabyppinState
		self.__agcBrxlnabypdirControl=parent.agcBrxlnabypdirControl

		self.__agcCrxlnabyp=parent.agcCrxlnabyp
		self.__agcCrxlnabyppinState=parent.agcCrxlnabyppinState
		self.__agcCrxlnabypdirControl=parent.agcCrxlnabypdirControl

		self.__agcDrxlnabyp=parent.agcDrxlnabyp
		self.__agcDrxlnabyppinState=parent.agcDrxlnabyppinState
		self.__agcDrxlnabypdirControl=parent.agcDrxlnabypdirControl

		self.__reliabilityPeakDetectorArxreldet=parent.reliabilityPeakDetectorArxreldet
		self.__reliabilityPeakDetectorArxreldetpinState=parent.reliabilityPeakDetectorArxreldetpinState
		self.__reliabilityPeakDetectorArxreldetdirControl=parent.reliabilityPeakDetectorArxreldetdirControl

		self.__reliabilityPeakDetectorBrxreldet=parent.reliabilityPeakDetectorBrxreldet
		self.__reliabilityPeakDetectorBrxreldetpinState=parent.reliabilityPeakDetectorBrxreldetpinState
		self.__reliabilityPeakDetectorBrxreldetdirControl=parent.reliabilityPeakDetectorBrxreldetdirControl

		self.__reliabilityPeakDetectorCrxreldet=parent.reliabilityPeakDetectorCrxreldet
		self.__reliabilityPeakDetectorCrxreldetpinState=parent.reliabilityPeakDetectorCrxreldetpinState
		self.__reliabilityPeakDetectorCrxreldetdirControl=parent.reliabilityPeakDetectorCrxreldetdirControl

		self.__reliabilityPeakDetectorDrxreldet=parent.reliabilityPeakDetectorDrxreldet
		self.__reliabilityPeakDetectorDrxreldetpinState=parent.reliabilityPeakDetectorDrxreldetpinState
		self.__reliabilityPeakDetectorDrxreldetdirControl=parent.reliabilityPeakDetectorDrxreldetdirControl

		self.__miscelleneousTxdsasw1=parent.miscelleneousTxdsasw1
		self.__miscelleneousTxdsasw1pinState=parent.miscelleneousTxdsasw1pinState
		self.__miscelleneousTxdsasw1dirControl=parent.miscelleneousTxdsasw1dirControl

		self.__miscelleneousTxdsasw2=parent.miscelleneousTxdsasw2
		self.__miscelleneousTxdsasw2pinState=parent.miscelleneousTxdsasw2pinState
		self.__miscelleneousTxdsasw2dirControl=parent.miscelleneousTxdsasw2dirControl

		self.__miscelleneousRxdsasw=parent.miscelleneousRxdsasw
		self.__miscelleneousRxdsaswpinState=parent.miscelleneousRxdsaswpinState
		self.__miscelleneousRxdsaswdirControl=parent.miscelleneousRxdsaswdirControl

		self.__miscelleneousFbncosw=parent.miscelleneousFbncosw
		self.__miscelleneousFbncoswpinState=parent.miscelleneousFbncoswpinState
		self.__miscelleneousFbncoswdirControl=parent.miscelleneousFbncoswdirControl

		self.__miscelleneousInt1=parent.miscelleneousInt1
		self.__miscelleneousInt1pinState=parent.miscelleneousInt1pinState
		self.__miscelleneousInt1dirControl=parent.miscelleneousInt1dirControl

		self.__miscelleneousInt2=parent.miscelleneousInt2
		self.__miscelleneousInt2pinState=parent.miscelleneousInt2pinState
		self.__miscelleneousInt2dirControl=parent.miscelleneousInt2dirControl

		self.__miscelleneousSleep=parent.miscelleneousSleep
		self.__miscelleneousSleeppinState=parent.miscelleneousSleeppinState
		self.__miscelleneousSleepdirControl=parent.miscelleneousSleepdirControl


	def afe77xxGpioMap(self,function,type,state,val,ballName):
			if type == 'CPLD':
				if state == 'pinState':
					exec("self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(ballName)+".pinState = self.parent._"+function+".getValue()")
				elif state == 'dirControl':
					if val == 0:
						exec("self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(ballName)+".dirControl = 1")
					elif val == 1:
						exec("self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(ballName)+".dirControl = 0")
	def setPeakDetectorArxpkdet1(self,val):
		self.__peakDetectorArxpkdet1=val
	def getPeakDetectorArxpkdet1(self):
		return self.__peakDetectorArxpkdet1

	def setPeakDetectorArxpkdet1pinState(self,val):
		self.__peakDetectorArxpkdet1pinState=val
		self.afe77xxGpioMap('peakDetectorArxpkdet1pinState','CPLD','pinState',val,ballName='V12')

	def getPeakDetectorArxpkdet1pinState(self):
		return self.__peakDetectorArxpkdet1pinState

	def setPeakDetectorArxpkdet1dirControl(self,val):
		self.__peakDetectorArxpkdet1dirControl=val
		self.afe77xxGpioMap('peakDetectorArxpkdet1pinState','CPLD','dirControl',val,ballName='V12')

	def getPeakDetectorArxpkdet1dirControl(self):
		return self.__peakDetectorArxpkdet1dirControl

	def setPeakDetectorArxpkdet2(self,val):
		self.__peakDetectorArxpkdet2=val
	def getPeakDetectorArxpkdet2(self):
		return self.__peakDetectorArxpkdet2

	def setPeakDetectorArxpkdet2pinState(self,val):
		self.__peakDetectorArxpkdet2pinState=val
		self.afe77xxGpioMap('peakDetectorArxpkdet2pinState','CPLD','pinState',val,ballName='U12')

	def getPeakDetectorArxpkdet2pinState(self):
		return self.__peakDetectorArxpkdet2pinState

	def setPeakDetectorArxpkdet2dirControl(self,val):
		self.__peakDetectorArxpkdet2dirControl=val
		self.afe77xxGpioMap('peakDetectorArxpkdet2pinState','CPLD','dirControl',val,ballName='U12')

	def getPeakDetectorArxpkdet2dirControl(self):
		return self.__peakDetectorArxpkdet2dirControl

	def setPeakDetectorArxpkdet3(self,val):
		self.__peakDetectorArxpkdet3=val
	def getPeakDetectorArxpkdet3(self):
		return self.__peakDetectorArxpkdet3

	def setPeakDetectorArxpkdet3pinState(self,val):
		self.__peakDetectorArxpkdet3pinState=val
		self.afe77xxGpioMap('peakDetectorArxpkdet3pinState','CPLD','pinState',val,ballName='U11')

	def getPeakDetectorArxpkdet3pinState(self):
		return self.__peakDetectorArxpkdet3pinState

	def setPeakDetectorArxpkdet3dirControl(self,val):
		self.__peakDetectorArxpkdet3dirControl=val
		self.afe77xxGpioMap('peakDetectorArxpkdet3pinState','CPLD','dirControl',val,ballName='U11')

	def getPeakDetectorArxpkdet3dirControl(self):
		return self.__peakDetectorArxpkdet3dirControl

	def setPeakDetectorBrxpkdet1(self,val):
		self.__peakDetectorBrxpkdet1=val
	def getPeakDetectorBrxpkdet1(self):
		return self.__peakDetectorBrxpkdet1

	def setPeakDetectorBrxpkdet1pinState(self,val):
		self.__peakDetectorBrxpkdet1pinState=val
		self.afe77xxGpioMap('peakDetectorBrxpkdet1pinState','CPLD','pinState',val,ballName='V7')

	def getPeakDetectorBrxpkdet1pinState(self):
		return self.__peakDetectorBrxpkdet1pinState

	def setPeakDetectorBrxpkdet1dirControl(self,val):
		self.__peakDetectorBrxpkdet1dirControl=val
		self.afe77xxGpioMap('peakDetectorBrxpkdet1pinState','CPLD','dirControl',val,ballName='V7')

	def getPeakDetectorBrxpkdet1dirControl(self):
		return self.__peakDetectorBrxpkdet1dirControl

	def setPeakDetectorBrxpkdet2(self,val):
		self.__peakDetectorBrxpkdet2=val
	def getPeakDetectorBrxpkdet2(self):
		return self.__peakDetectorBrxpkdet2

	def setPeakDetectorBrxpkdet2pinState(self,val):
		self.__peakDetectorBrxpkdet2pinState=val
		self.afe77xxGpioMap('peakDetectorBrxpkdet2pinState','CPLD','pinState',val,ballName='U7')

	def getPeakDetectorBrxpkdet2pinState(self):
		return self.__peakDetectorBrxpkdet2pinState

	def setPeakDetectorBrxpkdet2dirControl(self,val):
		self.__peakDetectorBrxpkdet2dirControl=val
		self.afe77xxGpioMap('peakDetectorBrxpkdet2pinState','CPLD','dirControl',val,ballName='U7')

	def getPeakDetectorBrxpkdet2dirControl(self):
		return self.__peakDetectorBrxpkdet2dirControl

	def setPeakDetectorBrxpkdet3(self,val):
		self.__peakDetectorBrxpkdet3=val
	def getPeakDetectorBrxpkdet3(self):
		return self.__peakDetectorBrxpkdet3

	def setPeakDetectorBrxpkdet3pinState(self,val):
		self.__peakDetectorBrxpkdet3pinState=val
		self.afe77xxGpioMap('peakDetectorBrxpkdet3pinState','CPLD','pinState',val,ballName='V9')

	def getPeakDetectorBrxpkdet3pinState(self):
		return self.__peakDetectorBrxpkdet3pinState

	def setPeakDetectorBrxpkdet3dirControl(self,val):
		self.__peakDetectorBrxpkdet3dirControl=val
		self.afe77xxGpioMap('peakDetectorBrxpkdet3pinState','CPLD','dirControl',val,ballName='V9')

	def getPeakDetectorBrxpkdet3dirControl(self):
		return self.__peakDetectorBrxpkdet3dirControl

	def setPeakDetectorCrxpkdet1(self,val):
		self.__peakDetectorCrxpkdet1=val
	def getPeakDetectorCrxpkdet1(self):
		return self.__peakDetectorCrxpkdet1

	def setPeakDetectorCrxpkdet1pinState(self,val):
		self.__peakDetectorCrxpkdet1pinState=val
		self.afe77xxGpioMap('peakDetectorCrxpkdet1pinState','CPLD','pinState',val,ballName='D12')

	def getPeakDetectorCrxpkdet1pinState(self):
		return self.__peakDetectorCrxpkdet1pinState

	def setPeakDetectorCrxpkdet1dirControl(self,val):
		self.__peakDetectorCrxpkdet1dirControl=val
		self.afe77xxGpioMap('peakDetectorCrxpkdet1pinState','CPLD','dirControl',val,ballName='D12')

	def getPeakDetectorCrxpkdet1dirControl(self):
		return self.__peakDetectorCrxpkdet1dirControl

	def setPeakDetectorCrxpkdet2(self,val):
		self.__peakDetectorCrxpkdet2=val
	def getPeakDetectorCrxpkdet2(self):
		return self.__peakDetectorCrxpkdet2

	def setPeakDetectorCrxpkdet2pinState(self,val):
		self.__peakDetectorCrxpkdet2pinState=val
		self.afe77xxGpioMap('peakDetectorCrxpkdet2pinState','CPLD','pinState',val,ballName='C12')

	def getPeakDetectorCrxpkdet2pinState(self):
		return self.__peakDetectorCrxpkdet2pinState

	def setPeakDetectorCrxpkdet2dirControl(self,val):
		self.__peakDetectorCrxpkdet2dirControl=val
		self.afe77xxGpioMap('peakDetectorCrxpkdet2pinState','CPLD','dirControl',val,ballName='C12')

	def getPeakDetectorCrxpkdet2dirControl(self):
		return self.__peakDetectorCrxpkdet2dirControl

	def setPeakDetectorCrxpkdet3(self,val):
		self.__peakDetectorCrxpkdet3=val
	def getPeakDetectorCrxpkdet3(self):
		return self.__peakDetectorCrxpkdet3

	def setPeakDetectorCrxpkdet3pinState(self,val):
		self.__peakDetectorCrxpkdet3pinState=val
		self.afe77xxGpioMap('peakDetectorCrxpkdet3pinState','CPLD','pinState',val,ballName='C11')

	def getPeakDetectorCrxpkdet3pinState(self):
		return self.__peakDetectorCrxpkdet3pinState

	def setPeakDetectorCrxpkdet3dirControl(self,val):
		self.__peakDetectorCrxpkdet3dirControl=val
		self.afe77xxGpioMap('peakDetectorCrxpkdet3pinState','CPLD','dirControl',val,ballName='C11')

	def getPeakDetectorCrxpkdet3dirControl(self):
		return self.__peakDetectorCrxpkdet3dirControl

	def setPeakDetectorDrxpkdet1(self,val):
		self.__peakDetectorDrxpkdet1=val
	def getPeakDetectorDrxpkdet1(self):
		return self.__peakDetectorDrxpkdet1

	def setPeakDetectorDrxpkdet1pinState(self,val):
		self.__peakDetectorDrxpkdet1pinState=val
		self.afe77xxGpioMap('peakDetectorDrxpkdet1pinState','CPLD','pinState',val,ballName='D7')

	def getPeakDetectorDrxpkdet1pinState(self):
		return self.__peakDetectorDrxpkdet1pinState

	def setPeakDetectorDrxpkdet1dirControl(self,val):
		self.__peakDetectorDrxpkdet1dirControl=val
		self.afe77xxGpioMap('peakDetectorDrxpkdet1pinState','CPLD','dirControl',val,ballName='D7')

	def getPeakDetectorDrxpkdet1dirControl(self):
		return self.__peakDetectorDrxpkdet1dirControl

	def setPeakDetectorDrxpkdet2(self,val):
		self.__peakDetectorDrxpkdet2=val
	def getPeakDetectorDrxpkdet2(self):
		return self.__peakDetectorDrxpkdet2

	def setPeakDetectorDrxpkdet2pinState(self,val):
		self.__peakDetectorDrxpkdet2pinState=val
		self.afe77xxGpioMap('peakDetectorDrxpkdet2pinState','CPLD','pinState',val,ballName='C7')

	def getPeakDetectorDrxpkdet2pinState(self):
		return self.__peakDetectorDrxpkdet2pinState

	def setPeakDetectorDrxpkdet2dirControl(self,val):
		self.__peakDetectorDrxpkdet2dirControl=val
		self.afe77xxGpioMap('peakDetectorDrxpkdet2pinState','CPLD','dirControl',val,ballName='C7')

	def getPeakDetectorDrxpkdet2dirControl(self):
		return self.__peakDetectorDrxpkdet2dirControl

	def setPeakDetectorDrxpkdet3(self,val):
		self.__peakDetectorDrxpkdet3=val
	def getPeakDetectorDrxpkdet3(self):
		return self.__peakDetectorDrxpkdet3

	def setPeakDetectorDrxpkdet3pinState(self,val):
		self.__peakDetectorDrxpkdet3pinState=val
		self.afe77xxGpioMap('peakDetectorDrxpkdet3pinState','CPLD','pinState',val,ballName='C9')

	def getPeakDetectorDrxpkdet3pinState(self):
		return self.__peakDetectorDrxpkdet3pinState

	def setPeakDetectorDrxpkdet3dirControl(self,val):
		self.__peakDetectorDrxpkdet3dirControl=val
		self.afe77xxGpioMap('peakDetectorDrxpkdet3pinState','CPLD','dirControl',val,ballName='C9')

	def getPeakDetectorDrxpkdet3dirControl(self):
		return self.__peakDetectorDrxpkdet3dirControl

	def setAgcArxlnabyp(self,val):
		self.__agcArxlnabyp=val
	def getAgcArxlnabyp(self):
		return self.__agcArxlnabyp

	def setAgcArxlnabyppinState(self,val):
		self.__agcArxlnabyppinState=val
		self.afe77xxGpioMap('agcArxlnabyppinState','CPLD','pinState',val,ballName='V11')

	def getAgcArxlnabyppinState(self):
		return self.__agcArxlnabyppinState

	def setAgcArxlnabypdirControl(self,val):
		self.__agcArxlnabypdirControl=val
		self.afe77xxGpioMap('agcArxlnabyppinState','CPLD','dirControl',val,ballName='V11')

	def getAgcArxlnabypdirControl(self):
		return self.__agcArxlnabypdirControl

	def setAgcBrxlnabyp(self,val):
		self.__agcBrxlnabyp=val
	def getAgcBrxlnabyp(self):
		return self.__agcBrxlnabyp

	def setAgcBrxlnabyppinState(self,val):
		self.__agcBrxlnabyppinState=val
		self.afe77xxGpioMap('agcBrxlnabyppinState','CPLD','pinState',val,ballName='V10')

	def getAgcBrxlnabyppinState(self):
		return self.__agcBrxlnabyppinState

	def setAgcBrxlnabypdirControl(self,val):
		self.__agcBrxlnabypdirControl=val
		self.afe77xxGpioMap('agcBrxlnabyppinState','CPLD','dirControl',val,ballName='V10')

	def getAgcBrxlnabypdirControl(self):
		return self.__agcBrxlnabypdirControl

	def setAgcCrxlnabyp(self,val):
		self.__agcCrxlnabyp=val
	def getAgcCrxlnabyp(self):
		return self.__agcCrxlnabyp

	def setAgcCrxlnabyppinState(self,val):
		self.__agcCrxlnabyppinState=val
		self.afe77xxGpioMap('agcCrxlnabyppinState','CPLD','pinState',val,ballName='D11')

	def getAgcCrxlnabyppinState(self):
		return self.__agcCrxlnabyppinState

	def setAgcCrxlnabypdirControl(self,val):
		self.__agcCrxlnabypdirControl=val
		self.afe77xxGpioMap('agcCrxlnabyppinState','CPLD','dirControl',val,ballName='D11')

	def getAgcCrxlnabypdirControl(self):
		return self.__agcCrxlnabypdirControl

	def setAgcDrxlnabyp(self,val):
		self.__agcDrxlnabyp=val
	def getAgcDrxlnabyp(self):
		return self.__agcDrxlnabyp

	def setAgcDrxlnabyppinState(self,val):
		self.__agcDrxlnabyppinState=val
		self.afe77xxGpioMap('agcDrxlnabyppinState','CPLD','pinState',val,ballName='D10')

	def getAgcDrxlnabyppinState(self):
		return self.__agcDrxlnabyppinState

	def setAgcDrxlnabypdirControl(self,val):
		self.__agcDrxlnabypdirControl=val
		self.afe77xxGpioMap('agcDrxlnabyppinState','CPLD','dirControl',val,ballName='D10')

	def getAgcDrxlnabypdirControl(self):
		return self.__agcDrxlnabypdirControl

	def setReliabilityPeakDetectorArxreldet(self,val):
		self.__reliabilityPeakDetectorArxreldet=val
	def getReliabilityPeakDetectorArxreldet(self):
		return self.__reliabilityPeakDetectorArxreldet

	def setReliabilityPeakDetectorArxreldetpinState(self,val):
		self.__reliabilityPeakDetectorArxreldetpinState=val
		self.afe77xxGpioMap('reliabilityPeakDetectorArxreldetpinState','CPLD','pinState',val,ballName='T5')

	def getReliabilityPeakDetectorArxreldetpinState(self):
		return self.__reliabilityPeakDetectorArxreldetpinState

	def setReliabilityPeakDetectorArxreldetdirControl(self,val):
		self.__reliabilityPeakDetectorArxreldetdirControl=val
		self.afe77xxGpioMap('reliabilityPeakDetectorArxreldetpinState','CPLD','dirControl',val,ballName='T5')

	def getReliabilityPeakDetectorArxreldetdirControl(self):
		return self.__reliabilityPeakDetectorArxreldetdirControl

	def setReliabilityPeakDetectorBrxreldet(self,val):
		self.__reliabilityPeakDetectorBrxreldet=val
	def getReliabilityPeakDetectorBrxreldet(self):
		return self.__reliabilityPeakDetectorBrxreldet

	def setReliabilityPeakDetectorBrxreldetpinState(self,val):
		self.__reliabilityPeakDetectorBrxreldetpinState=val
		self.afe77xxGpioMap('reliabilityPeakDetectorBrxreldetpinState','CPLD','pinState',val,ballName='R5')

	def getReliabilityPeakDetectorBrxreldetpinState(self):
		return self.__reliabilityPeakDetectorBrxreldetpinState

	def setReliabilityPeakDetectorBrxreldetdirControl(self,val):
		self.__reliabilityPeakDetectorBrxreldetdirControl=val
		self.afe77xxGpioMap('reliabilityPeakDetectorBrxreldetpinState','CPLD','dirControl',val,ballName='R5')

	def getReliabilityPeakDetectorBrxreldetdirControl(self):
		return self.__reliabilityPeakDetectorBrxreldetdirControl

	def setReliabilityPeakDetectorCrxreldet(self,val):
		self.__reliabilityPeakDetectorCrxreldet=val
	def getReliabilityPeakDetectorCrxreldet(self):
		return self.__reliabilityPeakDetectorCrxreldet

	def setReliabilityPeakDetectorCrxreldetpinState(self,val):
		self.__reliabilityPeakDetectorCrxreldetpinState=val
		self.afe77xxGpioMap('reliabilityPeakDetectorCrxreldetpinState','CPLD','pinState',val,ballName='E5')

	def getReliabilityPeakDetectorCrxreldetpinState(self):
		return self.__reliabilityPeakDetectorCrxreldetpinState

	def setReliabilityPeakDetectorCrxreldetdirControl(self,val):
		self.__reliabilityPeakDetectorCrxreldetdirControl=val
		self.afe77xxGpioMap('reliabilityPeakDetectorCrxreldetpinState','CPLD','dirControl',val,ballName='E5')

	def getReliabilityPeakDetectorCrxreldetdirControl(self):
		return self.__reliabilityPeakDetectorCrxreldetdirControl

	def setReliabilityPeakDetectorDrxreldet(self,val):
		self.__reliabilityPeakDetectorDrxreldet=val
	def getReliabilityPeakDetectorDrxreldet(self):
		return self.__reliabilityPeakDetectorDrxreldet

	def setReliabilityPeakDetectorDrxreldetpinState(self,val):
		self.__reliabilityPeakDetectorDrxreldetpinState=val
		self.afe77xxGpioMap('reliabilityPeakDetectorDrxreldetpinState','CPLD','pinState',val,ballName='F5')

	def getReliabilityPeakDetectorDrxreldetpinState(self):
		return self.__reliabilityPeakDetectorDrxreldetpinState

	def setReliabilityPeakDetectorDrxreldetdirControl(self,val):
		self.__reliabilityPeakDetectorDrxreldetdirControl=val
		self.afe77xxGpioMap('reliabilityPeakDetectorDrxreldetpinState','CPLD','dirControl',val,ballName='F5')

	def getReliabilityPeakDetectorDrxreldetdirControl(self):
		return self.__reliabilityPeakDetectorDrxreldetdirControl

	def setMiscelleneousTxdsasw1(self,val):
		self.__miscelleneousTxdsasw1=val
	def getMiscelleneousTxdsasw1(self):
		return self.__miscelleneousTxdsasw1

	def setMiscelleneousTxdsasw1pinState(self,val):
		self.__miscelleneousTxdsasw1pinState=val
		self.afe77xxGpioMap('miscelleneousTxdsasw1pinState','CPLD','pinState',val,ballName='U13')

	def getMiscelleneousTxdsasw1pinState(self):
		return self.__miscelleneousTxdsasw1pinState

	def setMiscelleneousTxdsasw1dirControl(self,val):
		self.__miscelleneousTxdsasw1dirControl=val
		self.afe77xxGpioMap('miscelleneousTxdsasw1pinState','CPLD','dirControl',val,ballName='U13')

	def getMiscelleneousTxdsasw1dirControl(self):
		return self.__miscelleneousTxdsasw1dirControl

	def setMiscelleneousTxdsasw2(self,val):
		self.__miscelleneousTxdsasw2=val
	def getMiscelleneousTxdsasw2(self):
		return self.__miscelleneousTxdsasw2

	def setMiscelleneousTxdsasw2pinState(self,val):
		self.__miscelleneousTxdsasw2pinState=val
		self.afe77xxGpioMap('miscelleneousTxdsasw2pinState','CPLD','pinState',val,ballName='D13')

	def getMiscelleneousTxdsasw2pinState(self):
		return self.__miscelleneousTxdsasw2pinState

	def setMiscelleneousTxdsasw2dirControl(self,val):
		self.__miscelleneousTxdsasw2dirControl=val
		self.afe77xxGpioMap('miscelleneousTxdsasw2pinState','CPLD','dirControl',val,ballName='D13')

	def getMiscelleneousTxdsasw2dirControl(self):
		return self.__miscelleneousTxdsasw2dirControl

	def setMiscelleneousRxdsasw(self,val):
		self.__miscelleneousRxdsasw=val
	def getMiscelleneousRxdsasw(self):
		return self.__miscelleneousRxdsasw

	def setMiscelleneousRxdsaswpinState(self,val):
		self.__miscelleneousRxdsaswpinState=val
		self.afe77xxGpioMap('miscelleneousRxdsaswpinState','CPLD','pinState',val,ballName='U15')

	def getMiscelleneousRxdsaswpinState(self):
		return self.__miscelleneousRxdsaswpinState

	def setMiscelleneousRxdsaswdirControl(self,val):
		self.__miscelleneousRxdsaswdirControl=val
		self.afe77xxGpioMap('miscelleneousRxdsaswpinState','CPLD','dirControl',val,ballName='U15')

	def getMiscelleneousRxdsaswdirControl(self):
		return self.__miscelleneousRxdsaswdirControl

	def setMiscelleneousFbncosw(self,val):
		self.__miscelleneousFbncosw=val
	def getMiscelleneousFbncosw(self):
		return self.__miscelleneousFbncosw

	def setMiscelleneousFbncoswpinState(self,val):
		self.__miscelleneousFbncoswpinState=val
		self.afe77xxGpioMap('miscelleneousFbncoswpinState','CPLD','pinState',val,ballName='D15')

	def getMiscelleneousFbncoswpinState(self):
		return self.__miscelleneousFbncoswpinState

	def setMiscelleneousFbncoswdirControl(self,val):
		self.__miscelleneousFbncoswdirControl=val
		self.afe77xxGpioMap('miscelleneousFbncoswpinState','CPLD','dirControl',val,ballName='D15')

	def getMiscelleneousFbncoswdirControl(self):
		return self.__miscelleneousFbncoswdirControl

	def setMiscelleneousInt1(self,val):
		self.__miscelleneousInt1=val
	def getMiscelleneousInt1(self):
		return self.__miscelleneousInt1

	def setMiscelleneousInt1pinState(self,val):
		self.__miscelleneousInt1pinState=val
		self.afe77xxGpioMap('miscelleneousInt1pinState','CPLD','pinState',val,ballName='C17')

	def getMiscelleneousInt1pinState(self):
		return self.__miscelleneousInt1pinState

	def setMiscelleneousInt1dirControl(self,val):
		self.__miscelleneousInt1dirControl=val
		self.afe77xxGpioMap('miscelleneousInt1pinState','CPLD','dirControl',val,ballName='C17')

	def getMiscelleneousInt1dirControl(self):
		return self.__miscelleneousInt1dirControl

	def setMiscelleneousInt2(self,val):
		self.__miscelleneousInt2=val
	def getMiscelleneousInt2(self):
		return self.__miscelleneousInt2

	def setMiscelleneousInt2pinState(self,val):
		self.__miscelleneousInt2pinState=val
		self.afe77xxGpioMap('miscelleneousInt2pinState','CPLD','pinState',val,ballName='E17')

	def getMiscelleneousInt2pinState(self):
		return self.__miscelleneousInt2pinState

	def setMiscelleneousInt2dirControl(self,val):
		self.__miscelleneousInt2dirControl=val
		self.afe77xxGpioMap('miscelleneousInt2pinState','CPLD','dirControl',val,ballName='E17')

	def getMiscelleneousInt2dirControl(self):
		return self.__miscelleneousInt2dirControl

	def setMiscelleneousSleep(self,val):
		self.__miscelleneousSleep=val
	def getMiscelleneousSleep(self):
		return self.__miscelleneousSleep

	def setMiscelleneousSleeppinState(self,val):
		self.__miscelleneousSleeppinState=val
		self.afe77xxGpioMap('miscelleneousSleeppinState','CPLD','pinState',val,ballName='E16')

	def getMiscelleneousSleeppinState(self):
		return self.__miscelleneousSleeppinState

	def setMiscelleneousSleepdirControl(self,val):
		self.__miscelleneousSleepdirControl=val
		self.afe77xxGpioMap('miscelleneousSleeppinState','CPLD','dirControl',val,ballName='E16')

	def getMiscelleneousSleepdirControl(self):
		return self.__miscelleneousSleepdirControl

class afe77xxGpioExternalAgc(Interface):
	controller = afe77xxGpioExternalAgcController
	peakDetectorArxpkdet1=Object(typ=Choice,choices ={0:"V12"},default=0,widgetParams={"setDisabled": True})
	peakDetectorArxpkdet1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorArxpkdet1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorArxpkdet2=Object(typ=Choice,choices ={0:"U12"},default=0,widgetParams={"setDisabled": True})
	peakDetectorArxpkdet2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorArxpkdet2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorArxpkdet3=Object(typ=Choice,choices ={0:"U11"},default=0,widgetParams={"setDisabled": True})
	peakDetectorArxpkdet3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorArxpkdet3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorBrxpkdet1=Object(typ=Choice,choices ={0:"V7"},default=0,widgetParams={"setDisabled": True})
	peakDetectorBrxpkdet1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorBrxpkdet1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorBrxpkdet2=Object(typ=Choice,choices ={0:"U7"},default=0,widgetParams={"setDisabled": True})
	peakDetectorBrxpkdet2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorBrxpkdet2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorBrxpkdet3=Object(typ=Choice,choices ={0:"V9"},default=0,widgetParams={"setDisabled": True})
	peakDetectorBrxpkdet3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorBrxpkdet3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorCrxpkdet1=Object(typ=Choice,choices ={0:"D12"},default=0,widgetParams={"setDisabled": True})
	peakDetectorCrxpkdet1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorCrxpkdet1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorCrxpkdet2=Object(typ=Choice,choices ={0:"C12"},default=0,widgetParams={"setDisabled": True})
	peakDetectorCrxpkdet2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorCrxpkdet2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorCrxpkdet3=Object(typ=Choice,choices ={0:"C11"},default=0,widgetParams={"setDisabled": True})
	peakDetectorCrxpkdet3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorCrxpkdet3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorDrxpkdet1=Object(typ=Choice,choices ={0:"D7"},default=0,widgetParams={"setDisabled": True})
	peakDetectorDrxpkdet1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorDrxpkdet1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorDrxpkdet2=Object(typ=Choice,choices ={0:"C7"},default=0,widgetParams={"setDisabled": True})
	peakDetectorDrxpkdet2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorDrxpkdet2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	peakDetectorDrxpkdet3=Object(typ=Choice,choices ={0:"C9"},default=0,widgetParams={"setDisabled": True})
	peakDetectorDrxpkdet3dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	peakDetectorDrxpkdet3pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcArxlnabyp=Object(typ=Choice,choices ={0:"V11"},default=0,widgetParams={"setDisabled": True})
	agcArxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcArxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcBrxlnabyp=Object(typ=Choice,choices ={0:"V10"},default=0,widgetParams={"setDisabled": True})
	agcBrxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcBrxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcCrxlnabyp=Object(typ=Choice,choices ={0:"D11"},default=0,widgetParams={"setDisabled": True})
	agcCrxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcCrxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	agcDrxlnabyp=Object(typ=Choice,choices ={0:"D10"},default=0,widgetParams={"setDisabled": True})
	agcDrxlnabypdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	agcDrxlnabyppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	reliabilityPeakDetectorArxreldet=Object(typ=Choice,choices ={0:"T5"},default=0,widgetParams={"setDisabled": True})
	reliabilityPeakDetectorArxreldetdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	reliabilityPeakDetectorArxreldetpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	reliabilityPeakDetectorBrxreldet=Object(typ=Choice,choices ={0:"R5"},default=0,widgetParams={"setDisabled": True})
	reliabilityPeakDetectorBrxreldetdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	reliabilityPeakDetectorBrxreldetpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	reliabilityPeakDetectorCrxreldet=Object(typ=Choice,choices ={0:"E5"},default=0,widgetParams={"setDisabled": True})
	reliabilityPeakDetectorCrxreldetdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	reliabilityPeakDetectorCrxreldetpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	reliabilityPeakDetectorDrxreldet=Object(typ=Choice,choices ={0:"F5"},default=0,widgetParams={"setDisabled": True})
	reliabilityPeakDetectorDrxreldetdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	reliabilityPeakDetectorDrxreldetpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousTxdsasw1=Object(typ=Choice,choices ={0:"U13"},default=0,widgetParams={"setDisabled": True})
	miscelleneousTxdsasw1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousTxdsasw1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousTxdsasw2=Object(typ=Choice,choices ={0:"D13"},default=0,widgetParams={"setDisabled": True})
	miscelleneousTxdsasw2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousTxdsasw2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousRxdsasw=Object(typ=Choice,choices ={0:"U15"},default=0,widgetParams={"setDisabled": True})
	miscelleneousRxdsaswdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousRxdsaswpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousFbncosw=Object(typ=Choice,choices ={0:"D15"},default=0,widgetParams={"setDisabled": True})
	miscelleneousFbncoswdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousFbncoswpinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousInt1=Object(typ=Choice,choices ={0:"C17"},default=0,widgetParams={"setDisabled": True})
	miscelleneousInt1dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousInt1pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousInt2=Object(typ=Choice,choices ={0:"E17"},default=0,widgetParams={"setDisabled": True})
	miscelleneousInt2dirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousInt2pinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	miscelleneousSleep=Object(typ=Choice,choices ={0:"E16"},default=0,widgetParams={"setDisabled": True})
	miscelleneousSleepdirControl=Object(typ=Choice,choices =  {0:'Input',1:'Output'},default=0,widgetParams={'setDisabled':True})

	miscelleneousSleeppinState=Object(typ=Choice,choices = {0:'Low',1:'High'},default=0,widgetParams={'setDisabled':False})
	configure = Object(typ=Trigger,label='Configure',function='ConfigureFunc')
	readStates= Object(typ=Trigger,label='Read States',function='readStatesFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	ballNameChoicesList=['V9', 'U11', 'U12', 'V12', 'R5', 'T5', 'U7', 'V7', 'C9', 'C11', 'D12', 'C12', 'F5', 'E5', 'D7', 'C7', 'V11', 'V10', 'D11', 'D10', 'U13', 'D13', 'U15', 'D15', 'C17', 'E17', 'E16' ]
	
	

	def __init__(self,libInstance,gpio):
		super(afe77xxGpioExternalAgc,self).__init__(libInstance=libInstance,gpio=gpio)
		self.libInstance=libInstance
		self.gpio=gpio
		self.gui.show()
		self.gui.hide()

		self._peakDetectorArxpkdet1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorArxpkdet1dirControl',val=self._peakDetectorArxpkdet1dirControl.getValue()))

		self._peakDetectorArxpkdet2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorArxpkdet2dirControl',val=self._peakDetectorArxpkdet2dirControl.getValue()))

		self._peakDetectorArxpkdet3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorArxpkdet3dirControl',val=self._peakDetectorArxpkdet3dirControl.getValue()))

		self._peakDetectorBrxpkdet1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorBrxpkdet1dirControl',val=self._peakDetectorBrxpkdet1dirControl.getValue()))

		self._peakDetectorBrxpkdet2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorBrxpkdet2dirControl',val=self._peakDetectorBrxpkdet2dirControl.getValue()))

		self._peakDetectorBrxpkdet3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorBrxpkdet3dirControl',val=self._peakDetectorBrxpkdet3dirControl.getValue()))

		self._peakDetectorCrxpkdet1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorCrxpkdet1dirControl',val=self._peakDetectorCrxpkdet1dirControl.getValue()))

		self._peakDetectorCrxpkdet2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorCrxpkdet2dirControl',val=self._peakDetectorCrxpkdet2dirControl.getValue()))

		self._peakDetectorCrxpkdet3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorCrxpkdet3dirControl',val=self._peakDetectorCrxpkdet3dirControl.getValue()))

		self._peakDetectorDrxpkdet1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorDrxpkdet1dirControl',val=self._peakDetectorDrxpkdet1dirControl.getValue()))

		self._peakDetectorDrxpkdet2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorDrxpkdet2dirControl',val=self._peakDetectorDrxpkdet2dirControl.getValue()))

		self._peakDetectorDrxpkdet3dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='peakDetectorDrxpkdet3dirControl',val=self._peakDetectorDrxpkdet3dirControl.getValue()))

		self._agcArxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcArxlnabypdirControl',val=self._agcArxlnabypdirControl.getValue()))

		self._agcBrxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcBrxlnabypdirControl',val=self._agcBrxlnabypdirControl.getValue()))

		self._agcCrxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcCrxlnabypdirControl',val=self._agcCrxlnabypdirControl.getValue()))

		self._agcDrxlnabypdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='agcDrxlnabypdirControl',val=self._agcDrxlnabypdirControl.getValue()))

		self._reliabilityPeakDetectorArxreldetdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='reliabilityPeakDetectorArxreldetdirControl',val=self._reliabilityPeakDetectorArxreldetdirControl.getValue()))

		self._reliabilityPeakDetectorBrxreldetdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='reliabilityPeakDetectorBrxreldetdirControl',val=self._reliabilityPeakDetectorBrxreldetdirControl.getValue()))

		self._reliabilityPeakDetectorCrxreldetdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='reliabilityPeakDetectorCrxreldetdirControl',val=self._reliabilityPeakDetectorCrxreldetdirControl.getValue()))

		self._reliabilityPeakDetectorDrxreldetdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='reliabilityPeakDetectorDrxreldetdirControl',val=self._reliabilityPeakDetectorDrxreldetdirControl.getValue()))

		self._miscelleneousTxdsasw1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousTxdsasw1dirControl',val=self._miscelleneousTxdsasw1dirControl.getValue()))

		self._miscelleneousTxdsasw2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousTxdsasw2dirControl',val=self._miscelleneousTxdsasw2dirControl.getValue()))

		self._miscelleneousRxdsaswdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousRxdsaswdirControl',val=self._miscelleneousRxdsaswdirControl.getValue()))

		self._miscelleneousFbncoswdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousFbncoswdirControl',val=self._miscelleneousFbncoswdirControl.getValue()))

		self._miscelleneousInt1dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousInt1dirControl',val=self._miscelleneousInt1dirControl.getValue()))

		self._miscelleneousInt2dirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousInt2dirControl',val=self._miscelleneousInt2dirControl.getValue()))

		self._miscelleneousSleepdirControl.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.directionChange(function='miscelleneousSleepdirControl',val=self._miscelleneousSleepdirControl.getValue()))

	
	
	def defaultConfiguration(self):
		self._peakDetectorArxpkdet1dirControl.setValue(1)
		self._peakDetectorArxpkdet2dirControl.setValue(1)
		self._peakDetectorArxpkdet3dirControl.setValue(1)
		self._peakDetectorBrxpkdet1dirControl.setValue(1)
		self._peakDetectorBrxpkdet2dirControl.setValue(1)
		self._peakDetectorBrxpkdet3dirControl.setValue(1)
		self._peakDetectorCrxpkdet1dirControl.setValue(1)
		self._peakDetectorCrxpkdet2dirControl.setValue(1)
		self._peakDetectorCrxpkdet3dirControl.setValue(1)
		self._peakDetectorDrxpkdet1dirControl.setValue(1)
		self._peakDetectorDrxpkdet2dirControl.setValue(1)
		self._peakDetectorDrxpkdet3dirControl.setValue(1)
		self._agcArxlnabypdirControl.setValue(0)
		self._agcBrxlnabypdirControl.setValue(0)
		self._agcCrxlnabypdirControl.setValue(0)
		self._agcDrxlnabypdirControl.setValue(0)
		self._reliabilityPeakDetectorArxreldetdirControl.setValue(0)
		self._reliabilityPeakDetectorBrxreldetdirControl.setValue(0)
		self._reliabilityPeakDetectorCrxreldetdirControl.setValue(0)
		self._reliabilityPeakDetectorDrxreldetdirControl.setValue(0)
		self._miscelleneousTxdsasw1dirControl.setValue(0)
		self._miscelleneousTxdsasw2dirControl.setValue(0)
		self._miscelleneousRxdsaswdirControl.setValue(0)
		self._miscelleneousFbncoswdirControl.setValue(0)
		self._miscelleneousInt1dirControl.setValue(1)
		self._miscelleneousInt2dirControl.setValue(1)
		self._miscelleneousSleepdirControl.setValue(0)
	

	def directionChange(self,function,val):
		try:
			if val == 0:
				eval("self._"+str(function[:-10])+"pinState.gui.widgets[1].setDisabled(0)")
			elif val == 1:
				eval("self._"+str(function[:-10])+"pinState.gui.widgets[1].setDisabled(1)")
		except:
			log(function+"----"+str(val))

	def ConfigureFunc(self):
		for tag in self.ballNameChoicesList:
			self.libInstance.systemStatus.gpioStatus[tag] = gpioConstants.gpioInternalAgcMode[tag]
		self.libInstance.TOP.GPIO.configureAllGpio()

	def backFunc(self):
			pass
		
	def readStatesFunc(self):
		for tag in dir(self):
			if 'dirControl' in tag and '_' not in tag:
				tag = tag[:-10] 
				exec("name = self._"+str(tag)+".gui.widgets[0].combo.itemText(self._"+str(tag)+".getValue())")
				exec("self._"+str(tag)+"dirControl.setValue(not self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(name)+"._dirControl.getValue())")
				exec("self._"+str(tag)+"pinState.setValue(self.gpio.CPLD.PINCONTROL.PINCONTROL."+str(name)+"._pinState.getValue())")



