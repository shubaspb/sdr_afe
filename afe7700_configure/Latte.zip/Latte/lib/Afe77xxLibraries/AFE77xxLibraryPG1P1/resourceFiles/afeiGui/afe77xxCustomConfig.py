import globalDefs as Globals
from mInstrument import *
import iGui
from PySide import QtGui,QtCore
from PySide.QtCore import Qt
from PySide.QtGui import QApplication
# from workspace import guiStorage as guiParams

class afe77xxCustomConfigController:
	def __init__(self,parent,*args,**kwargs):
		self.parent = parent
		self.libInstance=kwargs['libInstance']
		self.systemParams=kwargs['libInstance'].systemParams
		self.guiParams = kwargs['cache']
		self.__jesdablvdssync = parent.jesdablvdssync
		self.__jesdcdlvdssync = parent.jesdcdlvdssync
		self.__rxAbSyncPin = parent.rxAbSyncPin
		self.__rxCdSyncPin = parent.rxCdSyncPin
		self.__fbAbSyncPin = parent.fbAbSyncPin
		self.__fbCdSyncPin = parent.fbCdSyncPin
		self.__syncOut1 = parent.syncOut1
		self.__syncOut2 = parent.syncOut2
		self.__syncOut3 = parent.syncOut3
		self.__syncOut4 = parent.syncOut4
		self.__outputDirectoryPath = parent.outputDirectoryPath





	def setJesdablvdssync(self,val):
		self.__jesdablvdssync = val
		self.libInstance.systemParams.jesdABLvdsSync = val

	def getJesdablvdssync(self):
		self.__jesdablvdssync = self.libInstance.systemParams.jesdABLvdsSync
		return self.__jesdablvdssync

	def setJesdcdlvdssync(self,val):
		self.__jesdcdlvdssync = val
		self.libInstance.systemParams.jesdCDLvdsSync = val

	def getJesdcdlvdssync(self):
		self.__jesdcdlvdssync = self.libInstance.systemParams.jesdCDLvdsSync
		return self.__jesdcdlvdssync


	def setSerdesFirmware(self,val):
		self.__serdesFirmware = val
		self.libInstance.systemParams.serdesFirmware = val

	def getSerdesFirmware(self):
		self.__serdesFirmware = self.libInstance.systemParams.serdesFirmware
		return self.__serdesFirmware

	
	def setRxAbSyncPin(self,val):
		self.__rxAbSyncPin = val
		self.libInstance.systemParams.jesdTxRxABSyncMux = val
	
	def getRxAbSyncPin(self):
		self.__rxAbSyncPin = self.libInstance.systemParams.jesdTxRxABSyncMux
		return self.__rxAbSyncPin

	def setRxCdSyncPin(self,val):
		self.__rxCdSyncPin = val
		self.libInstance.systemParams.jesdTxRxCDSyncMux = val

	def getRxCdSyncPin(self):
		self.__rxCdSyncPin = self.libInstance.systemParams.jesdTxRxCDSyncMux
		return self.__rxCdSyncPin

	def setFbAbSyncPin(self,val):
		self.__fbAbSyncPin = val
		self.libInstance.systemParams.jesdTxFBABSyncMux = val

	def getFbAbSyncPin(self):
		self.__fbAbSyncPin = self.libInstance.systemParams.jesdTxFBABSyncMux
		return self.__fbAbSyncPin

	def setFbCdSyncPin(self,val):
		self.__fbCdSyncPin = val
		self.libInstance.systemParams.jesdTxFBCDSyncMux =  val

	def getFbCdSyncPin(self):
		self.__fbCdSyncPin = self.libInstance.systemParams.jesdTxFBCDSyncMux
		return self.__fbCdSyncPin
		
		
	def setSyncOut1(self,val):
		self.__syncOut1 = val
		self.guiParams.syncOut1 = self.parent.syncOut1ChoicesList[val]

	def getSyncOut1(self):
		self.__syncOut1 = self.parent.syncOut1ChoicesList.index(self.guiParams.syncOut1)
		return self.__syncOut1

	def setSyncOut2(self,val):
		self.__syncOut2 = val
		self.guiParams.syncOut2 = self.parent.syncOut2ChoicesList[val]

	def getSyncOut2(self):
		self.__syncOut2 = self.parent.syncOut2ChoicesList.index(self.guiParams.syncOut2)
		return self.__syncOut2

	def setSyncOut3(self,val):
		self.__syncOut3 = val
		self.guiParams.syncOut3 = self.parent.syncOut3ChoicesList[val]

	def getSyncOut3(self):
		self.__syncOut3 = self.parent.syncOut3ChoicesList.index(self.guiParams.syncOut3)
		return self.__syncOut3

	def setSyncOut4(self,val):
		self.__syncOut4 = val
		self.guiParams.syncOut4 = self.parent.syncOut4ChoicesList[val]

	def getSyncOut4(self):
		self.__syncOut4 = self.parent.syncOut4ChoicesList.index(self.guiParams.syncOut4)
		return self.__syncOut4

	def setOutputDirectoryPath(self,val):
		self.__outputDirectoryPath = val
		self.guiParams.outputDirectoryPath = val

	def getOutputDirectoryPath(self):
		self.guiParams.outputDirectoryPath=self.__outputDirectoryPath
		return self.__outputDirectoryPath

class afe77xxCustomConfig(Interface):
	controller =afe77xxCustomConfigController
	redBulb = Globals.ASTERIX_DIR+r"iGuiImages/redBulb.png"
	greenBulb = Globals.ASTERIX_DIR+r"iGuiImages/greenBulb.png"
	jesdablvdssync 	= Object(typ=Choice,choices={0:'CMOS',1:'LVDS'},label='jesdablvdssync',default=0,widgetParams={'setDisabled':True})
	jesdcdlvdssync 	= Object(typ=Choice,choices={0:'CMOS',1:'LVDS'},label='jesdcdlvdssync',default=0,widgetParams={'setDisabled':True})
	rxAbSyncPin 	= Object(typ=Choice,choices={0:'V5',1:'U5',2:'C5',3:'D5'},label='rxAbSyncPin',default=0.0)
	rxCdSyncPin 	= Object(typ=Choice,choices={0:'V5',1:'U5',2:'C5',3:'D5'},label='rxCdSyncPin',default=0.0)
	fbAbSyncPin 	= Object(typ=Choice,choices={0:'V5',1:'U5',2:'C5',3:'D5'},label='fbAbSyncPin',default=0.0)
	fbCdSyncPin 	= Object(typ=Choice,choices={0:'V5',1:'U5',2:'C5',3:'D5'},label='fbCdSyncPin',default=0.0)
	syncOut1 	= Object(typ=Choice,choices={0:'Tx AB Sync',1:'Tx CD Sync',2:'Combined Sync',3:'Tied High'},label='syncOut1',default=0.0)
	syncOut2 	= Object(typ=Choice,choices={0:'Tx AB Sync',1:'Tx CD Sync',2:'Combined Sync',3:'Tied High'},label='syncOut2',default=0.0)
	syncOut3 	= Object(typ=Choice,choices={0:'Tx AB Sync',1:'Tx CD Sync',2:'Combined Sync',3:'Tied High'},label='syncOut3',default=0.0)
	syncOut4 	= Object(typ=Choice,choices={0:'Tx AB Sync',1:'Tx CD Sync',2:'Combined Sync',3:'Tied High'},label='syncOut4',default=0.0)
	proceed = Object(typ=Trigger,label='Proceed',function='applyFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	back = Object(typ=Trigger,label='Back',function='backFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	browse = Object(typ=Trigger,label='Browse',function='browseOutputPathButtonFunc')
	outputDirectoryPath = Object(typ=StringControl,label='OutputPath',default=" ",widgetParams={"setDisabled":True})
	functionChoices 	= Object(typ=Choice,choices={0:'Device Bringup',1:'Configure PLL',2:'Configure NCOs',3:'Generate Configuration',4:'Save GUI State',5:'Load GUI State'},label='functionChoices',default='Device Bringup')
	apply 	= Object(typ=Trigger,label='Apply',function='applyFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	gpioo = Object(typ=Trigger,label='GPIO',function='gpioFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"})	
	dev0 = Object(typ=Trigger,label='Device',function='dev0Func',widgetParams={"styleSheet":"QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"})	#{"styleSheet":"QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);} QPushButton::hover {background-color:black; color:white; border-color:#ffffff;}"})
	fpgaConnectedStatus1 = Object(typ=Boolean,label='polarityCdR4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulb,redBulb)})
	fpgaConnectedStatus2 = Object(typ=String,label="FpgaStatus",default="FPGA is not connected")
	
	myfpgaReconnect = Object(typ=Trigger,label='Reconnect FPGA',function='myfpgaReconnectFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	def myfpgaReconnectFunc(self):
		self.guiControllerInstance.sysParamClassInst.myfpgaReconnectFunc()
	
	def applyFunc(self):
		"""  """
		if self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Configure PLL':
			self.guiControllerInstance.sysParamClassInst.configurePll(1)
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Device Bringup':
			self.guiControllerInstance.sysParamClassInst.deviceBringUp()
			if False in self.guiControllerInstance.sysParamClassInst.libInstance.systemStatus.validConfig:
				error("#================ Invalid Configuration - Device Bringup Aborted ================#")
			else:
				log("#================ Device Bringup Done ================#")
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Generate Configuration':
			self.guiControllerInstance.sysParamClassInst.generateConfig()
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Configure NCOs':
			self.guiControllerInstance.sysParamClassInst.ncoConfig()
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =="Save GUI State":
			self.guiControllerInstance.sysParamClassInst.saveAndLoadGuiState('save')
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =="Load GUI State":
			self.guiControllerInstance.sysParamClassInst.saveAndLoadGuiState('load')
		return
	
	def dev0Func(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(2)
		self._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(white)
		self._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet(black)
		
		
	def gpioFunc(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(8)
		self._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self._dev0.gui.widgets[1].button.setStyleSheet (black)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet (white)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(black)

	############ Below are the choices List.
	jesdABLvdsSyncChoicesList = ["CMOS","LVDS"]
	jesdCDLvdsSyncChoicesList = ["CMOS","LVDS"]
	rxAbSyncPinChoicesList = ['U5','V5','C5','D5']
	rxCdSyncPinChoicesList = ['U5','V5','C5','D5']
	fbAbSyncPinChoicesList = ['U5','V5','C5','D5']
	fbCdSyncPinChoicesList = ['U5','V5','C5','D5']
	syncOut1ChoicesList = ['Tx AB Sync','Tx CD Sync','Combined Sync','Tied High']
	syncOut2ChoicesList = ['Tx AB Sync','Tx CD Sync','Combined Sync','Tied High']
	syncOut3ChoicesList = ['Tx AB Sync','Tx CD Sync','Combined Sync','Tied High']
	syncOut4ChoicesList = ['Tx AB Sync','Tx CD Sync','Combined Sync','Tied High']
	functionChoicesChoicesList = ['Device Bringup','Configure PLL','Configure NCOs','Generate Configuration','Save GUI State','Load GUI State']
	###---All Widgets--###
	guiWidgetsList=['back', 'browse', 'enableCalibrations', 'enableRxDsaFactoryCal', 'enableRxIqmcLolPowerUpCorr', 'enableRxIqmcLolTrackingCorr', 'enableTxDsaFactoryCal', 'enableTxIqmcLolPowerUpCorr', 'enableTxIqmcLolTrackingCorr', 'fbAbSyncPin',  'fbCdSyncPin', 'internalAgc', 'jesdRxRbd0', 'jesdRxRbd1', 'jesdScr0', 'jesdScr1', 'jesdablvdssync', 'jesdcdlvdssync', 'jesdrxabsyncmux', 'jesdrxcdsyncmux', 'jesdtxfbabsyncmux', 'jesdtxfbcdsyncmux', 'jesdtxrxabsyncmux', 'jesdtxrxcdsyncmux', 'lowIfNcoFb0', 'lowIfNcoFb1', 'lowIfNcoRx0', 'lowIfNcoRx1', 'lowIfNcoTx0', 'lowIfNcoTx1', 'proceed', 'rxAbSyncPin', 'rxCdSyncPin', 'rxDsaCalibMode', 'serdesFirmwareBrowse', 'syncOut1', 'syncOut2', 'syncOut3', 'syncOut4', 'txDsaCalibMode', 'txIqMcCalibMode']

	def __init__(self,libInstance,cache,guiControllerInstance):
		super(afe77xxCustomConfig,self).__init__(libInstance=libInstance,cache=cache,guiControllerInstance=guiControllerInstance)
		self.libInstance=libInstance
		self.guiControllerInstance=guiControllerInstance
		self.gui.hide()


	def browseOutputPathButtonFunc(self):
		fname = QtGui.QFileDialog.getExistingDirectory()
		self._outputDirectoryPath.gui.widgets[1].valueLabel.setText(str(fname))
		self.libInstance.regs.rawWriteLogEn=1
		self.libInstance.regs.rawWriteLogsFile = str(fname) + r"\generatedDeviceConfigFile.txt"


	
	def backFunc(self):
		from workspace import afe77xxiGui
		addConfigIdx = afe77xxiGui.mainWindow.stackWidget.currentIndex()
		afe77xxiGui.mainWindow.changeTab(addConfigIdx-1)
		
	# def applyFunc(self):
		# from workspace import *
		# self.backFunc()
		# systemParamsWidget = afe77xxiGui.mainWindow.stackWidget.currentWidget()
		# Globals.iGuiLogWindowShow(0)
		# Globals.iGuiLogWindowShow(1)
		# systemParamsPrefix = afe77xxiGui.mainWindow.widget2PrefixMapping[id(systemParamsWidget)]
		# eval(systemParamsPrefix + "deviceBringUp()")


	def updateAllIndicatorsFunc(self):
		pass

	def updateAllObjectsFunc(self):
		self._jesdablvdssync.getValue()
		self._jesdcdlvdssync.getValue()
		self._rxAbSyncPin.getValue()
		self._rxCdSyncPin.getValue()
		self._fbAbSyncPin.getValue()
		self._fbCdSyncPin.getValue()
		self._syncOut1.getValue()
		self._syncOut2.getValue()
		self._syncOut3.getValue()
		self._syncOut4.getValue()