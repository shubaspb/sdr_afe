import globalDefs as Globals
from mInstrument import *
import iGui
from PySide.QtCore import Qt
from PySide.QtGui import QApplication
from PySide import QtGui
import sqlite3
from mAfeConstants import gpioConstants

# from workspace import guiStorage as guiParams




class afe77xxSystemParamsiGuiController:
	def __init__(self,parent,*args,**kwargs):
		self.parent = parent
		self.libInstance=kwargs['libInstance']
		self.systemParams=kwargs['libInstance'].systemParams
		self.LMKParams = kwargs['lmkParams']
		self.guiParams = kwargs['cache']
		self.__lmfsrx0 = parent.lmfsrx0
		self.__lmfsrx1 = parent.lmfsrx1
		self.__lmfsfb0 = parent.lmfsfb0
		self.__lmfsfb1 = parent.lmfsfb1
		self.__lmfstx0 = parent.lmfstx0
		self.__lmfstx1 = parent.lmfstx1
		self.__krx0 = parent.krx0
		self.__krx1 = parent.krx1
		self.__kfb0 = parent.kfb0
		self.__kfb1 = parent.kfb1
		self.__ktx0 = parent.ktx0
		self.__ktx1 = parent.ktx1
		self.__jesdAbTx1 = parent.jesdAbTx1
		self.__jesdAbTx2 = parent.jesdAbTx2
		self.__jesdAbTx3 = parent.jesdAbTx3
		self.__jesdAbTx4 = parent.jesdAbTx4
		self.__jesdCdTx1 = parent.jesdCdTx1
		self.__jesdCdTx2 = parent.jesdCdTx2
		self.__jesdCdTx3 = parent.jesdCdTx3
		self.__jesdCdTx4 = parent.jesdCdTx4
		self.__jesdAbRx1 = parent.jesdAbRx1
		self.__jesdAbRx2 = parent.jesdAbRx2
		self.__jesdAbRx3 = parent.jesdAbRx3
		self.__jesdAbRx4 = parent.jesdAbRx4
		self.__jesdCdRx1 = parent.jesdCdRx1
		self.__jesdCdRx2 = parent.jesdCdRx2
		self.__jesdCdRx3 = parent.jesdCdRx3
		self.__jesdCdRx4 = parent.jesdCdRx4
		self.__laneMuxJesdAbTx1 = parent.laneMuxJesdAbTx1
		self.__laneMuxJesdAbTx2 = parent.laneMuxJesdAbTx2
		self.__laneMuxJesdAbTx3 = parent.laneMuxJesdAbTx3
		self.__laneMuxJesdAbTx4 = parent.laneMuxJesdAbTx4
		self.__laneMuxJesdCdTx1 = parent.laneMuxJesdCdTx1
		self.__laneMuxJesdCdTx2 = parent.laneMuxJesdCdTx2
		self.__laneMuxJesdCdTx3 = parent.laneMuxJesdCdTx3
		self.__laneMuxJesdCdTx4 = parent.laneMuxJesdCdTx4
		self.__laneMuxJesdAbRx1 = parent.laneMuxJesdAbRx1
		self.__laneMuxJesdAbRx2 = parent.laneMuxJesdAbRx2
		self.__laneMuxJesdAbRx3 = parent.laneMuxJesdAbRx3
		self.__laneMuxJesdAbRx4 = parent.laneMuxJesdAbRx4
		self.__laneMuxJesdCdRx1 = parent.laneMuxJesdCdRx1
		self.__laneMuxJesdCdRx2 = parent.laneMuxJesdCdRx2
		self.__laneMuxJesdCdRx3 = parent.laneMuxJesdCdRx3
		self.__laneMuxJesdCdRx4 = parent.laneMuxJesdCdRx4
		self.__pllLo0 = parent.pllLo0
		self.__pllLo1 = parent.pllLo1
		self.__pllLo2 = parent.pllLo2
		self.__pllLo3 = parent.pllLo3
		self.__pllLo4 = parent.pllLo4
		self.__iqRateRx0 = parent.iqRateRx0
		self.__iqRateRx1 = parent.iqRateRx1
		self.__iqRateFb0 = parent.iqRateFb0
		self.__iqRateFb1 = parent.iqRateFb1
		self.__iqRateTx0 = parent.iqRateTx0
		self.__iqRateTx1 = parent.iqRateTx1
		self.__txAbLo = parent.txAbLo
		self.__rxAbLo = parent.rxAbLo
		self.__txCdLo = parent.txCdLo
		self.__rxCdLo = parent.rxCdLo
		self.__fbCdNco = parent.fbCdNco
		self.__fbAbNco = parent.fbAbNco
		self.__rxAbNco = parent.rxAbNco
		self.__rxCdNco = parent.rxCdNco
		self.__txAbNco = parent.txAbNco
		self.__txCdNco = parent.txCdNco
		self.__dataConverterPll = parent.dataConverterPll
		self.__functionChoices = parent.functionChoices
		self.__apply = parent.apply
		self.__jesdAbProtocol = parent.jesdAbProtocol
		self.__jesdCdProtocol = parent.jesdCdProtocol
		self.__jesdAbDedicatedLaneMode = parent.jesdAbDedicatedLaneMode
		self.__jesdCdDedicatedLaneMode = parent.jesdCdDedicatedLaneMode
		self.__txAbEnable = parent.txAbEnable
		self.__rxAbEnable = parent.rxAbEnable
		self.__fbAbEnable = parent.fbAbEnable
		self.__txCdEnable = parent.txCdEnable
		self.__rxCdEnable = parent.rxCdEnable
		self.__fbCdEnable = parent.fbCdEnable
		self.__frefExt = parent.frefExt
		self.__frefInt = parent.frefInt	
		self.__frefSelect = parent.frefSelect
		self.__lmkInputClk = parent.lmkInputClk
		self.__sysRef	= parent.sysRef
		self.__pllEnLmk = parent.pllEnLmk
		self.__jesdScr0 = parent.jesdScr0
		self.__jesdScr1 = parent.jesdScr1
		self.__lowIfNcoRx0 = parent.lowIfNcoRx0
		self.__lowIfNcoRx1 = parent.lowIfNcoRx1
		self.__lowIfNcoTx0 = parent.lowIfNcoTx0
		self.__lowIfNcoTx1 = parent.lowIfNcoTx1
		self.__lowIfNcoFb0 = parent.lowIfNcoFb0
		self.__lowIfNcoFb1 = parent.lowIfNcoFb1
		self.__readStatus = parent.readStatus
		self.__progressStatus = parent.progressStatus
		self.__polarityAbT1 = parent.polarityAbT1
		self.__polarityAbT2 = parent.polarityAbT2
		self.__polarityAbT3 = parent.polarityAbT3
		self.__polarityAbT4 = parent.polarityAbT4
		self.__polarityAbR1 = parent.polarityAbR1
		self.__polarityAbR2 = parent.polarityAbR2
		self.__polarityAbR3 = parent.polarityAbR3
		self.__polarityAbR4 = parent.polarityAbR4
		self.__polarityCdT1 = parent.polarityCdT1
		self.__polarityCdT2 = parent.polarityCdT2
		self.__polarityCdT3 = parent.polarityCdT3
		self.__polarityCdT4 = parent.polarityCdT4
		self.__polarityCdR1 = parent.polarityCdR1
		self.__polarityCdR2 = parent.polarityCdR2
		self.__polarityCdR3 = parent.polarityCdR3
		self.__polarityCdR4 = parent.polarityCdR4
		self.__additionalConfig = parent.additionalConfig


	
	
	
	def setLmfsrx0(self,val):
		self.__lmfsrx0 = val
		self.guiParams.LMFSRx[0] = self.parent.LMFSRxChoicesList[val]

	def getLmfsrx0(self):
		self.__lmfsrx0 = self.parent.LMFSRxChoicesList.index(self.guiParams.LMFSRx[0])
		return self.__lmfsrx0

	def setLmfsrx1(self,val):
		self.__lmfsrx1 = val
		self.guiParams.LMFSRx[1] = self.parent.LMFSRxChoicesList[val]

	def getLmfsrx1(self):
		self.__lmfsrx1 = self.parent.LMFSRxChoicesList.index(self.guiParams.LMFSRx[1])
		return self.__lmfsrx1

	def setLmfsfb0(self,val):
		self.__lmfsfb0 = val
		self.guiParams.LMFSFb[0] = self.parent.LMFSFbChoicesList[val]

	def getLmfsfb0(self):
		self.__lmfsfb0 = self.parent.LMFSFbChoicesList.index(self.guiParams.LMFSFb[0])
		return self.__lmfsfb0

	def setLmfsfb1(self,val):
		self.__lmfsfb1 = val
		self.guiParams.LMFSFb[1] = self.parent.LMFSFbChoicesList[val]

	def getLmfsfb1(self):
		self.__lmfsfb1 = self.parent.LMFSFbChoicesList.index(self.guiParams.LMFSFb[1])
		return self.__lmfsfb1

	def setLmfstx0(self,val):
		self.__lmfstx0 = val
		self.guiParams.LMFSTx[0] = self.parent.LMFSTxChoicesList[val]

	def getLmfstx0(self):
		self.__lmfstx0 = self.parent.LMFSTxChoicesList.index(self.guiParams.LMFSTx[0])
		return self.__lmfstx0

	def setLmfstx1(self,val):
		self.__lmfstx1 = val
		self.guiParams.LMFSTx[1] = self.parent.LMFSTxChoicesList[val]

	def getLmfstx1(self):
		self.__lmfstx1 = self.parent.LMFSTxChoicesList.index(self.guiParams.LMFSTx[1])
		return self.__lmfstx1

	def setKrx0(self,val):
		self.__krx0 = val
		self.guiParams.KRx[0] = val

	def getKrx0(self):
		self.__krx0 = self.guiParams.KRx[0]
		return self.__krx0

	def setKrx1(self,val):
		self.__krx1 = val
		self.guiParams.KRx[1] = val

	def getKrx1(self):
		self.__krx1 = self.guiParams.KRx[1]
		return self.__krx1

	def setKfb0(self,val):
		self.__kfb0 = val
		self.guiParams.KFb[0] = val

	def getKfb0(self):
		self.__kfb0 = self.guiParams.KFb[0]
		return self.__kfb0

	def setKfb1(self,val):
		self.__kfb1 = val
		self.guiParams.KFb[1] = val

	def getKfb1(self):
		self.__kfb1 = self.guiParams.KFb[1]
		return self.__kfb1

	def setKtx0(self,val):
		self.__ktx0 = val
		self.guiParams.KTx[0] = val

	def getKtx0(self):
		self.__ktx0 = self.guiParams.KTx[0]
		return self.__ktx0

	def setKtx1(self,val):
		self.__ktx1 = val
		self.guiParams.KTx[1] = val

	def getKtx1(self):
		self.__ktx1 = self.guiParams.KTx[1]
		return self.__ktx1

	def setJesdAbTx1(self,val):
		self.__jesdAbTx1 = val
		self.guiParams.jesdAbTx1 = self.parent.jesdAbTx1ChoicesList[val]

	def getJesdAbTx1(self):
		self.__jesdAbTx1 = self.parent.jesdAbTx1ChoicesList.index(self.guiParams.jesdAbTx1)
		return self.__jesdAbTx1

	def setJesdAbTx2(self,val):
		self.__jesdAbTx2 = val
		self.guiParams.jesdAbTx2 = self.parent.jesdAbTx2ChoicesList[val]

	def getJesdAbTx2(self):
		self.__jesdAbTx2 = self.parent.jesdAbTx2ChoicesList.index(self.guiParams.jesdAbTx2)
		return self.__jesdAbTx2

	def setJesdAbTx3(self,val):
		self.__jesdAbTx3 = val
		self.guiParams.jesdAbTx3 = self.parent.jesdAbTx3ChoicesList[val]

	def getJesdAbTx3(self):
		self.__jesdAbTx3 = self.parent.jesdAbTx3ChoicesList.index(self.guiParams.jesdAbTx3)
		return self.__jesdAbTx3

	def setJesdAbTx4(self,val):
		self.__jesdAbTx4 = val
		self.guiParams.jesdAbTx4 = self.parent.jesdAbTx4ChoicesList[val]

	def getJesdAbTx4(self):
		self.__jesdAbTx4 = self.parent.jesdAbTx4ChoicesList.index(self.guiParams.jesdAbTx4)
		return self.__jesdAbTx4

	def setJesdCdTx1(self,val):
		self.__jesdCdTx1 = val
		self.guiParams.jesdCdTx1 = self.parent.jesdCdTx1ChoicesList[val]

	def getJesdCdTx1(self):
		self.__jesdCdTx1 = self.parent.jesdCdTx1ChoicesList.index(self.guiParams.jesdCdTx1)
		return self.__jesdCdTx1

	def setJesdCdTx2(self,val):
		self.__jesdCdTx2 = val
		self.guiParams.jesdCdTx2 = self.parent.jesdCdTx2ChoicesList[val]

	def getJesdCdTx2(self):
		self.__jesdCdTx2 = self.parent.jesdCdTx2ChoicesList.index(self.guiParams.jesdCdTx2)
		return self.__jesdCdTx2

	def setJesdCdTx3(self,val):
		self.__jesdCdTx3 = val
		self.guiParams.jesdCdTx3 = self.parent.jesdCdTx3ChoicesList[val]

	def getJesdCdTx3(self):
		self.__jesdCdTx3 = self.parent.jesdCdTx3ChoicesList.index(self.guiParams.jesdCdTx3)
		return self.__jesdCdTx3

	def setJesdCdTx4(self,val):
		self.__jesdCdTx4 = val
		self.guiParams.jesdCdTx4 = self.parent.jesdCdTx4ChoicesList[val]

	def getJesdCdTx4(self):
		self.__jesdCdTx4 = self.parent.jesdCdTx4ChoicesList.index(self.guiParams.jesdCdTx4)
		return self.__jesdCdTx4

	def setJesdAbRx1(self,val):
		self.__jesdAbRx1 = val
		self.guiParams.jesdAbRx1 = self.parent.jesdAbRx1ChoicesList[val]

	def getJesdAbRx1(self):
		self.__jesdAbRx1 = self.parent.jesdAbRx1ChoicesList.index(self.guiParams.jesdAbRx1)
		return self.__jesdAbRx1

	def setJesdAbRx2(self,val):
		self.__jesdAbRx2 = val
		self.guiParams.jesdAbRx2 = self.parent.jesdAbRx2ChoicesList[val]

	def getJesdAbRx2(self):
		self.__jesdAbRx2 = self.parent.jesdAbRx2ChoicesList.index(self.guiParams.jesdAbRx2)
		return self.__jesdAbRx2

	def setJesdAbRx3(self,val):
		self.__jesdAbRx3 = val
		self.guiParams.jesdAbRx3 = self.parent.jesdAbRx3ChoicesList[val]

	def getJesdAbRx3(self):
		self.__jesdAbRx3 = self.parent.jesdAbRx3ChoicesList.index(self.guiParams.jesdAbRx3)
		return self.__jesdAbRx3

	def setJesdAbRx4(self,val):
		self.__jesdAbRx4 = val
		self.guiParams.jesdAbRx4 = self.parent.jesdAbRx4ChoicesList[val]

	def getJesdAbRx4(self):
		self.__jesdAbRx4 = self.parent.jesdAbRx4ChoicesList.index(self.guiParams.jesdAbRx4)
		return self.__jesdAbRx4

	def setJesdCdRx1(self,val):
		self.__jesdCdRx1 = val
		self.guiParams.jesdCdRx1 = self.parent.jesdCdRx1ChoicesList[val]

	def getJesdCdRx1(self):
		self.__jesdCdRx1 = self.parent.jesdCdRx1ChoicesList.index(self.guiParams.jesdCdRx1)
		return self.__jesdCdRx1

	def setJesdCdRx2(self,val):
		self.__jesdCdRx2 = val
		self.guiParams.jesdCdRx2 = self.parent.jesdCdRx2ChoicesList[val]

	def getJesdCdRx2(self):
		self.__jesdCdRx2 = self.parent.jesdCdRx2ChoicesList.index(self.guiParams.jesdCdRx2)
		return self.__jesdCdRx2

	def setJesdCdRx3(self,val):
		self.__jesdCdRx3 = val
		self.guiParams.jesdCdRx3 = self.parent.jesdCdRx3ChoicesList[val]

	def getJesdCdRx3(self):
		self.__jesdCdRx3 = self.parent.jesdCdRx3ChoicesList.index(self.guiParams.jesdCdRx3)
		return self.__jesdCdRx3

	def setJesdCdRx4(self,val):
		self.__jesdCdRx4 = val
		self.guiParams.jesdCdRx4 = self.parent.jesdCdRx4ChoicesList[val]

	def getJesdCdRx4(self):
		self.__jesdCdRx4 = self.parent.jesdCdRx4ChoicesList.index(self.guiParams.jesdCdRx4)
		return self.__jesdCdRx4

	def setLaneMuxJesdAbTx1(self,val):
		self.__laneMuxJesdAbTx1 = val
		self.guiParams.laneMuxJesdAbTx1 = self.parent.laneMuxJesdAbTx1ChoicesList[val]

	def getLaneMuxJesdAbTx1(self):
		self.__laneMuxJesdAbTx1 = self.parent.laneMuxJesdAbTx1ChoicesList.index(self.guiParams.laneMuxJesdAbTx1)
		return self.__laneMuxJesdAbTx1

	def setLaneMuxJesdAbTx2(self,val):
		self.__laneMuxJesdAbTx2 = val
		self.guiParams.laneMuxJesdAbTx2 = self.parent.laneMuxJesdAbTx2ChoicesList[val]

	def getLaneMuxJesdAbTx2(self):
		self.__laneMuxJesdAbTx2 = self.parent.laneMuxJesdAbTx2ChoicesList.index(self.guiParams.laneMuxJesdAbTx2)
		return self.__laneMuxJesdAbTx2

	def setLaneMuxJesdAbTx3(self,val):
		self.__laneMuxJesdAbTx3 = val
		self.guiParams.laneMuxJesdAbTx3 = self.parent.laneMuxJesdAbTx3ChoicesList[val]

	def getLaneMuxJesdAbTx3(self):
		self.__laneMuxJesdAbTx3 = self.parent.laneMuxJesdAbTx3ChoicesList.index(self.guiParams.laneMuxJesdAbTx3)
		return self.__laneMuxJesdAbTx3

	def setLaneMuxJesdAbTx4(self,val):
		self.__laneMuxJesdAbTx4 = val
		self.guiParams.laneMuxJesdAbTx4 = self.parent.laneMuxJesdAbTx4ChoicesList[val]

	def getLaneMuxJesdAbTx4(self):
		self.__laneMuxJesdAbTx4 = self.parent.laneMuxJesdAbTx4ChoicesList.index(self.guiParams.laneMuxJesdAbTx4)
		return self.__laneMuxJesdAbTx4

	def setLaneMuxJesdCdTx1(self,val):
		self.__laneMuxJesdCdTx1 = val
		self.guiParams.laneMuxJesdCdTx1 = self.parent.laneMuxJesdCdTx1ChoicesList[val]

	def getLaneMuxJesdCdTx1(self):
		self.__laneMuxJesdCdTx1 = self.parent.laneMuxJesdCdTx1ChoicesList.index(self.guiParams.laneMuxJesdCdTx1)
		return self.__laneMuxJesdCdTx1

	def setLaneMuxJesdCdTx2(self,val):
		self.__laneMuxJesdCdTx2 = val
		self.guiParams.laneMuxJesdCdTx2 = self.parent.laneMuxJesdCdTx2ChoicesList[val]

	def getLaneMuxJesdCdTx2(self):
		self.__laneMuxJesdCdTx2 = self.parent.laneMuxJesdCdTx2ChoicesList.index(self.guiParams.laneMuxJesdCdTx2)
		return self.__laneMuxJesdCdTx2

	def setLaneMuxJesdCdTx3(self,val):
		self.__laneMuxJesdCdTx3 = val
		self.guiParams.laneMuxJesdCdTx3 = self.parent.laneMuxJesdCdTx3ChoicesList[val]

	def getLaneMuxJesdCdTx3(self):
		self.__laneMuxJesdCdTx3 = self.parent.laneMuxJesdCdTx3ChoicesList.index(self.guiParams.laneMuxJesdCdTx3)
		return self.__laneMuxJesdCdTx3

	def setLaneMuxJesdCdTx4(self,val):
		self.__laneMuxJesdCdTx4 = val
		self.guiParams.laneMuxJesdCdTx4 = self.parent.laneMuxJesdCdTx4ChoicesList[val]

	def getLaneMuxJesdCdTx4(self):
		self.__laneMuxJesdCdTx4 = self.parent.laneMuxJesdCdTx4ChoicesList.index(self.guiParams.laneMuxJesdCdTx4)
		return self.__laneMuxJesdCdTx4

	def setLaneMuxJesdAbRx1(self,val):
		self.__laneMuxJesdAbRx1 = val
		self.guiParams.laneMuxJesdAbRx1 = self.parent.laneMuxJesdAbRx1ChoicesList[val]

	def getLaneMuxJesdAbRx1(self):
		self.__laneMuxJesdAbRx1 = self.parent.laneMuxJesdAbRx1ChoicesList.index(self.guiParams.laneMuxJesdAbRx1)
		return self.__laneMuxJesdAbRx1

	def setLaneMuxJesdAbRx2(self,val):
		self.__laneMuxJesdAbRx2 = val
		self.guiParams.laneMuxJesdAbRx2 = self.parent.laneMuxJesdAbRx2ChoicesList[val]

	def getLaneMuxJesdAbRx2(self):
		self.__laneMuxJesdAbRx2 = self.parent.laneMuxJesdAbRx2ChoicesList.index(self.guiParams.laneMuxJesdAbRx2)
		return self.__laneMuxJesdAbRx2

	def setLaneMuxJesdAbRx3(self,val):
		self.__laneMuxJesdAbRx3 = val
		self.guiParams.laneMuxJesdAbRx3 = self.parent.laneMuxJesdAbRx3ChoicesList[val]

	def getLaneMuxJesdAbRx3(self):
		self.__laneMuxJesdAbRx3 = self.parent.laneMuxJesdAbRx3ChoicesList.index(self.guiParams.laneMuxJesdAbRx3)
		return self.__laneMuxJesdAbRx3

	def setLaneMuxJesdAbRx4(self,val):
		self.__laneMuxJesdAbRx4 = val
		self.guiParams.laneMuxJesdAbRx4 = self.parent.laneMuxJesdAbRx4ChoicesList[val]

	def getLaneMuxJesdAbRx4(self):
		self.__laneMuxJesdAbRx4 = self.parent.laneMuxJesdAbRx4ChoicesList.index(self.guiParams.laneMuxJesdAbRx4)
		return self.__laneMuxJesdAbRx4

	def setLaneMuxJesdCdRx1(self,val):
		self.__laneMuxJesdCdRx1 = val
		self.guiParams.laneMuxJesdCdRx1 = self.parent.laneMuxJesdCdRx1ChoicesList[val]

	def getLaneMuxJesdCdRx1(self):
		self.__laneMuxJesdCdRx1 = self.parent.laneMuxJesdCdRx1ChoicesList.index(self.guiParams.laneMuxJesdCdRx1)
		return self.__laneMuxJesdCdRx1

	def setLaneMuxJesdCdRx2(self,val):
		self.__laneMuxJesdCdRx2 = val
		self.guiParams.laneMuxJesdCdRx2 = self.parent.laneMuxJesdCdRx2ChoicesList[val]

	def getLaneMuxJesdCdRx2(self):
		self.__laneMuxJesdCdRx2 = self.parent.laneMuxJesdCdRx2ChoicesList.index(self.guiParams.laneMuxJesdCdRx2)
		return self.__laneMuxJesdCdRx2

	def setLaneMuxJesdCdRx3(self,val):
		self.__laneMuxJesdCdRx3 = val
		self.guiParams.laneMuxJesdCdRx3 = self.parent.laneMuxJesdCdRx3ChoicesList[val]

	def getLaneMuxJesdCdRx3(self):
		self.__laneMuxJesdCdRx3 = self.parent.laneMuxJesdCdRx3ChoicesList.index(self.guiParams.laneMuxJesdCdRx3)
		return self.__laneMuxJesdCdRx3

	def setLaneMuxJesdCdRx4(self,val):
		self.__laneMuxJesdCdRx4 = val
		self.guiParams.laneMuxJesdCdRx4 = self.parent.laneMuxJesdCdRx4ChoicesList[val]

	def getLaneMuxJesdCdRx4(self):
		self.__laneMuxJesdCdRx4 = self.parent.laneMuxJesdCdRx4ChoicesList.index(self.guiParams.laneMuxJesdCdRx4)
		return self.__laneMuxJesdCdRx4

	def setPllLo0(self,val):
		self.__pllLo0 = val
		self.libInstance.systemParams.pllLo[0] = val

	def getPllLo0(self):
		self.__pllLo0 = self.libInstance.systemParams.pllLo[0]
		return self.__pllLo0

	def setPllLo1(self,val):
		self.__pllLo1 = val
		self.libInstance.systemParams.pllLo[1] = val

	def getPllLo1(self):
		self.__pllLo1 = self.libInstance.systemParams.pllLo[1]
		return self.__pllLo1

	def setPllLo2(self,val):
		self.__pllLo2 = val
		self.libInstance.systemParams.pllLo[2] = val

	def getPllLo2(self):
		self.__pllLo2 = self.libInstance.systemParams.pllLo[2]
		return self.__pllLo2

	def setPllLo3(self,val):
		self.__pllLo3 = val
		self.libInstance.systemParams.pllLo[3] = val

	def getPllLo3(self):
		self.__pllLo3 = self.libInstance.systemParams.pllLo[3]
		return self.__pllLo3

	def setPllLo4(self,val):
		self.__pllLo4 = val
		self.libInstance.systemParams.pllLo[4] = val

	def getPllLo4(self):
		self.__pllLo4 = self.libInstance.systemParams.pllLo[4]
		return self.__pllLo4

	def setIqRateRx0(self,val):
		self.__iqRateRx0 = val
		self.guiParams.iqRateRx[0] = val

	def getIqRateRx0(self):
		self.__iqRateRx0 = self.guiParams.iqRateRx[0]
		return self.__iqRateRx0

	def setIqRateRx1(self,val):
		self.__iqRateRx1 = val
		self.guiParams.iqRateRx[1] = val

	def getIqRateRx1(self):
		self.__iqRateRx1 = self.guiParams.iqRateRx[1]
		return self.__iqRateRx1

	def setIqRateFb0(self,val):
		self.__iqRateFb0 = val
		self.guiParams.iqRateFb[0] = val

	def getIqRateFb0(self):
		self.__iqRateFb0 = self.guiParams.iqRateFb[0]
		return self.__iqRateFb0

	def setIqRateFb1(self,val):
		self.__iqRateFb1 = val
		self.guiParams.iqRateFb[1] = val

	def getIqRateFb1(self):
		self.__iqRateFb1 = self.guiParams.iqRateFb[1]
		return self.__iqRateFb1

	def setIqRateTx0(self,val):
		self.__iqRateTx0 = val
		self.guiParams.iqRateTx[0] = val

	def getIqRateTx0(self):
		self.__iqRateTx0 = self.guiParams.iqRateTx[0]
		return self.__iqRateTx0

	def setIqRateTx1(self,val):
		self.__iqRateTx1 = val
		self.guiParams.iqRateTx[1] = val

	def getIqRateTx1(self):
		self.__iqRateTx1 = self.guiParams.iqRateTx[1]
		return self.__iqRateTx1

	def setTxAbLo(self,val):
		self.__txAbLo = val
		self.guiParams.txAbLo = val

	def getTxAbLo(self):
		self.__txAbLo = self.guiParams.txAbLo
		return self.__txAbLo

	def setRxAbLo(self,val):
		self.__rxAbLo = val
		self.guiParams.rxAbLo = val

	def getRxAbLo(self):
		self.__rxAbLo = self.guiParams.rxAbLo
		return self.__rxAbLo

	def setTxCdLo(self,val):
		self.__txCdLo = val
		self.guiParams.txCdLo = val

	def getTxCdLo(self):
		self.__txCdLo = self.guiParams.txCdLo
		return self.__txCdLo

	def setRxCdLo(self,val):
		self.__rxCdLo = val
		self.guiParams.rxCdLo = val

	def getRxCdLo(self):
		self.__rxCdLo = self.guiParams.rxCdLo
		return self.__rxCdLo

	def setFbCdNco(self,val):
		self.__fbCdNco = val
		self.guiParams.fbCdNco = val

	def getFbCdNco(self):
		self.__fbCdNco = self.guiParams.fbCdNco
		return self.__fbCdNco

	def setFbAbNco(self,val):
		self.__fbAbNco = val
		self.guiParams.fbAbNco = val

	def getFbAbNco(self):
		self.__fbAbNco = self.guiParams.fbAbNco
		return self.__fbAbNco

	def setRxAbNco(self,val):
		self.__rxAbNco = val
		self.guiParams.rxAbNco = val

	def getRxAbNco(self):
		self.__rxAbNco = self.guiParams.rxAbNco
		return self.__rxAbNco

	def setRxCdNco(self,val):
		self.__rxCdNco = val
		self.guiParams.rxCdNco = val

	def getRxCdNco(self):
		self.__rxCdNco = self.guiParams.rxCdNco
		return self.__rxCdNco

	def setTxAbNco(self,val):
		self.__txAbNco = val
		self.guiParams.txAbNco = val

	def getTxAbNco(self):
		self.__txAbNco = self.guiParams.txAbNco
		return self.__txAbNco

	def setTxCdNco(self,val):
		self.__txCdNco = val
		self.guiParams.txCdNco = val

	def getTxCdNco(self):
		self.__txCdNco = self.guiParams.txCdNco
		return self.__txCdNco

	def setDataConverterPll(self,val):
		self.__dataConverterPll = val
		self.guiParams.dataConverterPll = self.parent.dataConverterPllChoicesList[val]
		self.libInstance.systemParams.Fs = self.parent.dataConverterPllChoicesList[val]
		self.libInstance.systemParams.pllLo[1] = self.parent.dataConverterPllChoicesList[val]

	def getDataConverterPll(self):
		self.__dataConverterPll = self.parent.dataConverterPllChoicesList.index(self.guiParams.dataConverterPll)
		return self.__dataConverterPll

	def setFunctionChoices(self,val):
		self.__functionChoices = val
		self.guiParams.functionChoices = self.parent.functionChoicesChoicesList[val]

	def getFunctionChoices(self):
		self.__functionChoices = self.parent.functionChoicesChoicesList.index(self.guiParams.functionChoices)
		return self.__functionChoices

	def setJesdAbProtocol(self,val):
		self.__jesdAbProtocol = val
		self.guiParams.jesdAbProtocol = self.parent.jesdAbProtocolChoicesList[val]

	def getJesdAbProtocol(self):
		self.__jesdAbProtocol = self.parent.jesdAbProtocolChoicesList.index(self.guiParams.jesdAbProtocol)
		return self.__jesdAbProtocol

	def setJesdCdProtocol(self,val):
		self.__jesdCdProtocol = val
		self.guiParams.jesdCdProtocol = self.parent.jesdCdProtocolChoicesList[val]

	def getJesdCdProtocol(self):
		self.__jesdCdProtocol = self.parent.jesdCdProtocolChoicesList.index(self.guiParams.jesdCdProtocol)
		return self.__jesdCdProtocol

	def setJesdAbDedicatedLaneMode(self,val):
		self.__jesdAbDedicatedLaneMode = val
		self.guiParams.jesdAbDedicatedLaneMode = val

	def getJesdAbDedicatedLaneMode(self):
		self.__jesdAbDedicatedLaneMode = self.guiParams.jesdAbDedicatedLaneMode
		return self.__jesdAbDedicatedLaneMode

	def setJesdCdDedicatedLaneMode(self,val):
		self.__jesdCdDedicatedLaneMode = val
		self.guiParams.jesdCdDedicatedLaneMode = val

	def getJesdCdDedicatedLaneMode(self):
		self.__jesdCdDedicatedLaneMode = self.guiParams.jesdCdDedicatedLaneMode
		return self.__jesdCdDedicatedLaneMode
	
	def setTxAbEnable(self,val):
		self.__txAbEnable = val
		self.guiParams.txAbEnable = val
		self.libInstance.TOP.disableOverrideTdd()
		self.parent.gpio.CPLD.PINCONTROL.PINCONTROL.U14.pinState = val

	def getTxAbEnable(self):
		self.__txAbEnable = self.guiParams.txAbEnable
		return self.__txAbEnable

	def setRxAbEnable(self,val):
		self.__rxAbEnable = val
		self.guiParams.rxAbEnable = val
		self.libInstance.TOP.disableOverrideTdd()
		self.parent.gpio.CPLD.PINCONTROL.PINCONTROL.V13.pinState = val
		

	def getRxAbEnable(self):
		self.__rxAbEnable = self.guiParams.rxAbEnable
		return self.__rxAbEnable

	def setFbAbEnable(self,val):
		self.__fbAbEnable = val
		self.guiParams.fbAbEnable = val
		self.libInstance.TOP.disableOverrideTdd()
		self.parent.gpio.CPLD.PINCONTROL.PINCONTROL.T13.pinState = val

	def getFbAbEnable(self):
		self.__fbAbEnable = self.guiParams.fbAbEnable
		return self.__fbAbEnable

	def setTxCdEnable(self,val):
		self.__txCdEnable = val
		self.guiParams.txCdEnable = val
		self.libInstance.TOP.disableOverrideTdd()
		self.parent.gpio.CPLD.PINCONTROL.PINCONTROL.D14.pinState = val

	def getTxCdEnable(self):
		self.__txCdEnable = self.guiParams.txCdEnable
		return self.__txCdEnable

	def setRxCdEnable(self,val):
		self.__rxCdEnable = val
		self.guiParams.rxCdEnable = val
		self.libInstance.TOP.disableOverrideTdd()
		self.parent.gpio.CPLD.PINCONTROL.PINCONTROL.C13.pinState = val

	def getRxCdEnable(self):
		self.__rxCdEnable = self.guiParams.rxCdEnable
		return self.__rxCdEnable

	def setFbCdEnable(self,val):
		self.__fbCdEnable = val
		self.guiParams.fbCdEnable = val
		self.libInstance.TOP.disableOverrideTdd()
		self.parent.gpio.CPLD.PINCONTROL.PINCONTROL.E13.pinState = val

	def getFbCdEnable(self):
		self.__fbCdEnable = self.guiParams.fbCdEnable
		return self.__fbCdEnable

	def setFrefExt(self,val):
		self.__frefExt = val
		self.guiParams.frefExt = val

	def getFrefExt(self):
		self.__frefExt = self.guiParams.frefExt
		return self.__frefExt

	def setFrefInt(self,val):
		self.__frefInt = val
		self.guiParams.frefInt = val

	def getFrefInt(self):
		self.__frefExt = self.guiParams.frefInt 
		return self.__frefExt

	def setFrefSelect(self,val):
		self.__frefSelect = val
		self.guiParams.frefSelect = val
		self.LMKParams.lmkFrefClk = val


	def getFrefSelect(self):
		self.__frefSelect = self.guiParams.frefSelect 
		self.__frefSelect = self.LMKParams.lmkFrefClk
		return self.__frefSelect

	def setLmkInputClk(self,val):
		self.__lmkInputClk = val
		self.guiParams.lmkInputClk = val
		self.LMKParams.inputClk = val

	def getLmkInputClk(self):
		self.__lmkInputClk = self.guiParams.lmkInputClk
		self.__lmkInputClk = self.LMKParams.inputClk
		return self.__lmkInputClk

	def setSysRef(self,val):
		self.__sysRef = val
		self.guiParams.sysRef = val
		self.LMKParams.sysrefFreq = val

	def getSysRef(self):
		self.__sysRef = self.guiParams.sysRef
		self.__sysRef = self.LMKParams.sysrefFreq
		return self.__sysRef

	def setPllEnLmk(self,val):
		self.__pllEnLmk = val
		self.guiParams.pllEnLmk = val
		self.LMKParams.pllEn = val

	def getPllEnLmk(self):
		self.__pllEnLmk = self.guiParams.pllEnLmk
		self.__pllEnLmk = self.LMKParams.pllEn
		return self.__pllEnLmk

	def setJesdScr0(self,val):
		self.__jesdScr0 = val
		self.libInstance.systemParams.jesdScr[0] = val

	def getJesdScr0(self):
		self.__jesdScr0 = self.libInstance.systemParams.jesdScr[0]
		return self.__jesdScr0

	def setJesdScr1(self,val):
		self.__jesdScr1 = val
		self.libInstance.systemParams.jesdScr[1] = val

	def getJesdScr1(self):
		self.__jesdScr1 = self.libInstance.systemParams.jesdScr[1]
		return self.__jesdScr1

	def setLowIfNcoRx0(self,val):
		self.__lowIfNcoRx0 = val
		self.libInstance.systemParams.lowIfNcoRx[0] = val

	def getLowIfNcoRx0(self):
		self.__lowIfNcoRx0 = self.libInstance.systemParams.lowIfNcoRx[0]
		return self.__lowIfNcoRx0

	def setLowIfNcoRx1(self,val):
		self.__lowIfNcoRx1 = val
		self.libInstance.systemParams.lowIfNcoRx[1] = val

	def getLowIfNcoRx1(self):
		self.__lowIfNcoRx1 = self.libInstance.systemParams.lowIfNcoRx[1]
		return self.__lowIfNcoRx1

	def setLowIfNcoTx0(self,val):
		self.__lowIfNcoTx0 = val
		self.libInstance.systemParams.lowIfNcoTx[0] = val

	def getLowIfNcoTx0(self):
		self.__lowIfNcoTx0 = self.libInstance.systemParams.lowIfNcoTx[0]
		return self.__lowIfNcoTx0

	def setLowIfNcoTx1(self,val):
		self.__lowIfNcoTx1 = val
		self.libInstance.systemParams.lowIfNcoTx[1] = val

	def getLowIfNcoTx1(self):
		self.__lowIfNcoTx1 = self.libInstance.systemParams.lowIfNcoTx[1]
		return self.__lowIfNcoTx1

	def setLowIfNcoFb0(self,val):
		self.__lowIfNcoFb0 = val
		self.libInstance.systemParams.lowIfNcoFb[0] = val

	def getLowIfNcoFb0(self):
		self.__lowIfNcoFb0 = self.libInstance.systemParams.lowIfNcoFb[0]
		return self.__lowIfNcoFb0

	def setLowIfNcoFb1(self,val):
		self.__lowIfNcoFb1 = val
		self.libInstance.systemParams.lowIfNcoFb[1] = val

	def getLowIfNcoFb1(self):
		self.__lowIfNcoFb1 = self.libInstance.systemParams.lowIfNcoFb[1]

	def setPolarityAbT1(self,val):
		self.__polarityAbT1 = val
		self.guiParams.polarityAbT1 = val

	def getPolarityAbT1(self):
		self.__polarityAbT1 = self.guiParams.polarityAbT1
		return self.__polarityAbT1

	def setPolarityAbT2(self,val):
		self.__polarityAbT2 = val
		self.guiParams.polarityAbT2 = val

	def getPolarityAbT2(self):
		self.__polarityAbT2 = self.guiParams.polarityAbT2
		return self.__polarityAbT2

	def setPolarityAbT3(self,val):
		self.__polarityAbT3 = val
		self.guiParams.polarityAbT3 = val

	def getPolarityAbT3(self):
		self.__polarityAbT3 = self.guiParams.polarityAbT3
		return self.__polarityAbT3

	def setPolarityAbT4(self,val):
		self.__polarityAbT4 = val
		self.guiParams.polarityAbT4 = val

	def getPolarityAbT4(self):
		self.__polarityAbT4 = self.guiParams.polarityAbT4
		return self.__polarityAbT4

	def setPolarityAbR1(self,val):
		self.__polarityAbR1 = val
		self.guiParams.polarityAbR1 = val

	def getPolarityAbR1(self):
		self.__polarityAbR1 = self.guiParams.polarityAbR1
		return self.__polarityAbR1

	def setPolarityAbR2(self,val):
		self.__polarityAbR2 = val
		self.guiParams.polarityAbR2 = val

	def getPolarityAbR2(self):
		self.__polarityAbR2 = self.guiParams.polarityAbR2
		return self.__polarityAbR2

	def setPolarityAbR3(self,val):
		self.__polarityAbR3 = val
		self.guiParams.polarityAbR3 = val

	def getPolarityAbR3(self):
		self.__polarityAbR3 = self.guiParams.polarityAbR3
		return self.__polarityAbR3

	def setPolarityAbR4(self,val):
		self.__polarityAbR4 = val
		self.guiParams.polarityAbR4 = val

	def getPolarityAbR4(self):
		self.__polarityAbR4 = self.guiParams.polarityAbR4
		return self.__polarityAbR4

	def setPolarityCdT1(self,val):
		self.__polarityCdT1 = val
		self.guiParams.polarityCdT1 = val

	def getPolarityCdT1(self):
		self.__polarityCdT1 = self.guiParams.polarityCdT1
		return self.__polarityCdT1

	def setPolarityCdT2(self,val):
		self.__polarityCdT2 = val
		self.guiParams.polarityCdT2 = val

	def getPolarityCdT2(self):
		self.__polarityCdT2 = self.guiParams.polarityCdT2
		return self.__polarityCdT2

	def setPolarityCdT3(self,val):
		self.__polarityCdT3 = val
		self.guiParams.polarityCdT3 = val

	def getPolarityCdT3(self):
		self.__polarityCdT3 = self.guiParams.polarityCdT3
		return self.__polarityCdT3

	def setPolarityCdT4(self,val):
		self.__polarityCdT4 = val
		self.guiParams.polarityCdT4 = val

	def getPolarityCdT4(self):
		self.__polarityCdT4 = self.guiParams.polarityCdT4
		return self.__polarityCdT4

	def setPolarityCdR1(self,val):
		self.__polarityCdR1 = val
		self.guiParams.polarityCdR1 = val

	def getPolarityCdR1(self):
		self.__polarityCdR1 = self.guiParams.polarityCdR1
		return self.__polarityCdR1

	def setPolarityCdR2(self,val):
		self.__polarityCdR2 = val
		self.guiParams.polarityCdR2 = val

	def getPolarityCdR2(self):
		self.__polarityCdR2 = self.guiParams.polarityCdR2
		return self.__polarityCdR2

	def setPolarityCdR3(self,val):
		self.__polarityCdR3 = val
		self.guiParams.polarityCdR3 = val

	def getPolarityCdR3(self):
		self.__polarityCdR3 = self.guiParams.polarityCdR3
		return self.__polarityCdR3

	def setPolarityCdR4(self,val):
		self.__polarityCdR4 = val
		self.guiParams.polarityCdR4 = val

	def getPolarityCdR4(self):
		self.__polarityCdR4 = self.guiParams.polarityCdR4
		return self.__polarityCdR4
	
	def setHalfRateModeRx(self,val):
		self.__halfRateModeRx=val
		self.libInstance.systemParams.halfRateModeRx=val
	
	def getHalfRateModeRx(self):
		self.__halfRateModeRx = self.libInstance.systemParams.halfRateModeRx
		return self.__halfRateModeRx
	
	def setHalfRateModeFb(self,val):
		self.__halfRateModeFb=val
		self.libInstance.systemParams.halfRateModeFb=val
	
	def getHalfRateModeFb(self):
		self.__halfRateModeFb = self.libInstance.systemParams.halfRateModeFb
		return self.__halfRateModeFb
	
	def setHalfRateModeTx(self,val):
		self.__halfRateModeTx=val
		self.libInstance.systemParams.halfRateModeTx=val
	
	def getHalfRateModeTx(self):
		self.__halfRateModeTx = self.libInstance.systemParams.halfRateModeTx
		return self.__halfRateModeTx
		






class afe77xxSystemParamsiGui(Interface):
	controller =afe77xxSystemParamsiGuiController
	redBulbImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/red.png"
	greenBulbImgPath = Globals.ASTERIX_DIR+r"iGuiImages/green.png"
	switchOnImgPath = Globals.ASTERIX_DIR+r"iGuiImages/switchON.png"
	switchOffImgPath = Globals.ASTERIX_DIR+r"iGuiImages/switchOFF.png"
	NotImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/NOT.png"
	BufferImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/BUFFER.png"
	redBulb = Globals.ASTERIX_DIR+r"iGuiImages/redBulb.png"
	greenBulb = Globals.ASTERIX_DIR+r"iGuiImages/greenBulb.png"
	frefSelect = Object(typ=Choice,choices={0:'Fref External',1:'Fref Internal'},label='frefSelect',default=0)
	lmfsrx0 	= Object(typ=Choice,choices={0:'2-4-4-1-16', 1:'1-4-8-1-16', 2:'1-4-6-1-12', 3:'2-4-6-1-24', 4:'1-4-12-1-24', 5:'4-4-2-1-16', 6:'2-8-8-1-16', 7:'2-8-6-1-12', 8:'4-8-6-1-24', 9:'4-2-1-1-16', 10:'4-8-4-1-16', 11:'1-2-3-1-12', 12:'2-2-2-1-16', 13:'4-8-3-1-12', 14:'2-4-3-1-12', 15:'4-4-3-1-24', 16:'1-8-12-1-12', 17:'2-8-12-1-24', 18:'4-2-2-2-16', 19:'1-8-16-1-16', 20:'1-8-24-1-24', 21:'1-2-6-1-24', 22:'1-2-4-1-16'},label='lmfsrx0',default=0)
	lmfsrx1 	= Object(typ=Choice,choices={0:'2-4-4-1-16', 1:'1-4-8-1-16', 2:'1-4-6-1-12', 3:'2-4-6-1-24', 4:'1-4-12-1-24', 5:'4-4-2-1-16', 6:'2-8-8-1-16', 7:'2-8-6-1-12', 8:'4-8-6-1-24', 9:'4-2-1-1-16', 10:'4-8-4-1-16', 11:'1-2-3-1-12', 12:'2-2-2-1-16', 13:'4-8-3-1-12', 14:'2-4-3-1-12', 15:'4-4-3-1-24', 16:'1-8-12-1-12', 17:'2-8-12-1-24', 18:'4-2-2-2-16', 19:'1-8-16-1-16', 20:'1-8-24-1-24', 21:'1-2-6-1-24', 22:'1-2-4-1-16'},label='lmfsrx1',default=0)
	lmfsfb0 	= Object(typ=Choice,choices={0:'2-4-8-2-16', 1:'1-2-8-1-32', 2:'2-4-6-2-12', 3:'4-4-6-2-24', 4:'4-4-4-2-16', 5:'2-2-3-2-12', 6:'1-4-24-2-24', 7:'4-1-2-4-16', 8:'4-1-1-2-16', 9:'4-2-2-2-16', 10:'1-4-8-1-16', 11:'4-2-3-2-24', 12:'1-2-6-1-24', 13:'1-2-4-1-16', 14:'1-2-3-1-12', 15:'1-2-16-2-32', 16:'1-2-12-2-24', 17:'1-2-8-2-16', 18:'1-2-6-2-12', 19:'2-2-2-1-16', 20:'2-2-3-1-24', 21:'3-2-4-1-48', 22:'3-2-2-1-24', 23:'2-2-4-2-16', 24:'2-2-6-2-24', 25:'1-2-16-4-16', 26:'2-2-8-4-16', 27:'1-2-24-4-24', 28:'3-2-12-3-48', 29:'3-2-8-3-32', 30:'3-2-6-3-24', 31:'1-4-16-2-16', 32:'1-4-12-2-12'},label='lmfsfb0',default=13)
	lmfsfb1 	= Object(typ=Choice,choices={0:'2-4-8-2-16', 1:'1-2-8-1-32', 2:'2-4-6-2-12', 3:'4-4-6-2-24', 4:'4-4-4-2-16', 5:'2-2-3-2-12', 6:'1-4-24-2-24', 7:'4-1-2-4-16', 8:'4-1-1-2-16', 9:'4-2-2-2-16', 10:'1-4-8-1-16', 11:'4-2-3-2-24', 12:'1-2-6-1-24', 13:'1-2-4-1-16', 14:'1-2-3-1-12', 15:'1-2-16-2-32', 16:'1-2-12-2-24', 17:'1-2-8-2-16', 18:'1-2-6-2-12', 19:'2-2-2-1-16', 20:'2-2-3-1-24', 21:'3-2-4-1-48', 22:'3-2-2-1-24', 23:'2-2-4-2-16', 24:'2-2-6-2-24', 25:'1-2-16-4-16', 26:'2-2-8-4-16', 27:'1-2-24-4-24', 28:'3-2-12-3-48', 29:'3-2-8-3-32', 30:'3-2-6-3-24', 31:'1-4-16-2-16', 32:'1-4-12-2-12'},label='lmfsfb1',default=13)
	lmfstx0 	= Object(typ=Choice,choices={0:'2-4-4-1-16', 1:'1-4-8-1-16', 2:'1-4-6-1-12', 3:'2-4-6-1-24', 4:'1-4-12-1-24', 5:'4-4-2-1-16', 6:'1-2-8-2-16', 7:'4-8-4-1-16', 8:'2-8-8-1-16', 9:'2-8-6-1-12', 10:'4-8-6-1-24', 11:'2-8-12-1-24', 12:'2-4-8-2-16', 13:'4-8-3-1-12', 14:'2-4-3-1-12', 15:'4-4-3-1-24', 16:'1-8-12-1-12', 17:'1-8-16-1-16', 18:'3-4-2-1-12', 19:'3-8-4-1-12'},label='lmfstx0',default=0)
	lmfstx1 	= Object(typ=Choice,choices={0:'2-4-4-1-16', 1:'1-4-8-1-16', 2:'1-4-6-1-12', 3:'2-4-6-1-24', 4:'1-4-12-1-24', 5:'4-4-2-1-16', 6:'1-2-8-2-16', 7:'4-8-4-1-16', 8:'2-8-8-1-16', 9:'2-8-6-1-12', 10:'4-8-6-1-24', 11:'2-8-12-1-24', 12:'2-4-8-2-16', 13:'4-8-3-1-12', 14:'2-4-3-1-12', 15:'4-4-3-1-24', 16:'1-8-12-1-12', 17:'1-8-16-1-16', 18:'3-4-2-1-12', 19:'3-8-4-1-12'},label='lmfstx1',default=0)
	krx0 	= Object(typ=Integer,label='krx0',default=0)
	krx1 	= Object(typ=Integer,label='krx1',default=0)
	kfb0 	= Object(typ=Integer,label='kfb0',default=0)
	kfb1 	= Object(typ=Integer,label='kfb1',default=0)
	ktx0 	= Object(typ=Integer,label='ktx0',default=0)
	ktx1 	= Object(typ=Integer,label='ktx1',default=0)
	jesdAbTx1 	= Object(typ=Boolean,label='jesdAbTx1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbTx2 	= Object(typ=Boolean,label='jesdAbTx2',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbTx3 	= Object(typ=Boolean,label='jesdAbTx3',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbTx4 	= Object(typ=Boolean,label='jesdAbTx4',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdTx1 	= Object(typ=Boolean,label='jesdCdTx1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdTx2 	= Object(typ=Boolean,label='jesdCdTx2',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdTx3 	= Object(typ=Boolean,label='jesdCdTx3',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdTx4 	= Object(typ=Boolean,label='jesdCdTx4',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbRx1 	= Object(typ=Boolean,label='jesdAbRx1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbRx2 	= Object(typ=Boolean,label='jesdAbRx2',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbRx3 	= Object(typ=Boolean,label='jesdAbRx3',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdAbRx4 	= Object(typ=Boolean,label='jesdAbRx4',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdRx1 	= Object(typ=Boolean,label='jesdCdRx1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdRx2 	= Object(typ=Boolean,label='jesdCdRx2',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdRx3 	= Object(typ=Boolean,label='jesdCdRx3',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdCdRx4 	= Object(typ=Boolean,label='jesdCdRx4',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	laneMuxJesdAbTx1 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdAbTx1',default=0)
	laneMuxJesdAbTx2 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdAbTx2',default=1)
	laneMuxJesdAbTx3 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdAbTx3',default=2)
	laneMuxJesdAbTx4 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdAbTx4',default=3)
	laneMuxJesdCdTx1 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdCdTx1',default=4)
	laneMuxJesdCdTx2 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdCdTx2',default=5)
	laneMuxJesdCdTx3 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdCdTx3',default=6)
	laneMuxJesdCdTx4 	= Object(typ=Choice,choices={0:'1STX',1:'2STX',2:'3STX',3:'4STX',4:'5STX',5:'6STX',6:'7STX',7:'8STX'},label='laneMuxJesdCdTx4',default=7)
	laneMuxJesdAbRx1 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdAbRx1',default=0)
	laneMuxJesdAbRx2 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdAbRx2',default=1)
	laneMuxJesdAbRx3 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdAbRx3',default=2)
	laneMuxJesdAbRx4 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdAbRx4',default=3)
	laneMuxJesdCdRx1 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdCdRx1',default=4)
	laneMuxJesdCdRx2 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdCdRx2',default=5)
	laneMuxJesdCdRx3 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdCdRx3',default=6)
	laneMuxJesdCdRx4 	= Object(typ=Choice,choices={0:'1SRX',1:'2SRX',2:'3SRX',3:'4SRX',4:'5SRX',5:'6SRX',6:'7SRX',7:'8SRX'},label='laneMuxJesdCdRx4',default=7)
	pllLo0 	= Object(typ=RealNumber,label ='pllLo0',default=1800)
	pllLo1 	= Object(typ=RealNumber,label ='pllLo1',default=2949.12)
	pllLo2 	= Object(typ=RealNumber,label ='pllLo2',default=2400.5)
	pllLo3 	= Object(typ=RealNumber,label ='pllLo3',default=900.0)
	pllLo4 	= Object(typ=RealNumber,label ='pllLo4',default=2100.0)
	iqRateRx0 	= Object(typ=Choice,choices={0:'30.72',1:'61.44',2:'92.16',3:'122.88',4:'184.32',5:'245.76',6:'368.64'},label='iqRateRx0',default=0)
	iqRateRx1 	= Object(typ=Choice,choices={0:'30.72',1:'61.44',2:'92.16',3:'122.88',4:'184.32',5:'245.76',6:'368.64'},label='iqRateRx1',default=0)
	iqRateFb0 	= Object(typ=Choice,choices={0:'122.88',1:'184.32',2:'245.76',3:'368.64',4:'491.52',5:'737.28'},label='iqRateFb0',default=0)
	iqRateFb1 	= Object(typ=Choice,choices={0:'122.88',1:'184.32',2:'245.76',3:'368.64',4:'491.52',5:'737.28'},label='iqRateFb1',default=0)
	iqRateTx0 	= Object(typ=Choice,choices={0:'122.88',1:'184.32',2:'245.76',3:'368.64',4:'491.52',5:'737.28'},label='iqRateTx0',default=0)
	iqRateTx1 	= Object(typ=Choice,choices={0:'122.88',1:'184.32',2:'245.76',3:'368.64',4:'491.52',5:'737.28'},label='iqRateTx1',default=0)
	txAbLo 	= Object(typ=RealNumber,label ='txAbLo',default=1800.0)
	rxAbLo 	= Object(typ=RealNumber,label ='rxAbLo',default=2400.0)
	txCdLo 	= Object(typ=RealNumber,label ='txCdLo',default=900.0)
	rxCdLo 	= Object(typ=RealNumber,label ='rxCdLo',default=2100.0)
	fbCdNco 	= Object(typ=RealNumber,label ='fbCdNco',default=1800.0)
	fbAbNco 	= Object(typ=RealNumber,label ='fbAbNco',default=900.0)
	rxAbNco 	= Object(typ=RealNumber,label ='rxAbNco',default=900.0)
	rxCdNco 	= Object(typ=RealNumber,label ='rxCdNco',default=900.0)
	txAbNco 	= Object(typ=RealNumber,label ='txAbNco',default=900.0)
	txCdNco 	= Object(typ=RealNumber,label ='txCdNco',default=900.0)
	dataConverterPll 	= Object(typ=Choice,choices={0:'2949.12 MHz',1:'3317.76 MHz'},label='dataConverterPll',default=0)
	functionChoices 	= Object(typ=Choice,choices={0:'Device Bringup',1:'Configure PLL',2:'Configure NCOs',3:'Generate Configuration',4:'Save GUI State',5:'Load GUI State'},label='functionChoices',default='Device Bringup')
	apply 	= Object(typ=Trigger,label='Apply',function='applyFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	jesdAbProtocol 	= Object(typ=Choice,choices={0:' 204 B',1:' 204 C'},label='jesdAbProtocol',default=0.0)
	jesdCdProtocol 	= Object(typ=Choice,choices={0:' 204 B',1:' 204 C'},label='jesdCdProtocol',default=0.0)
	jesdAbDedicatedLaneMode 	= Object(typ=Boolean,label='jesdAbDedicatedLaneMode',default=0.0)
	jesdCdDedicatedLaneMode 	= Object(typ=Boolean,label='jesdCdDedicatedLaneMode',default=0.0)
	txAbEnable 	= Object(typ=Boolean,label='txAbEnable',default=1,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(switchOnImgPath,switchOffImgPath)})
	rxAbEnable 	= Object(typ=Boolean,label='rxAbEnable',default=1,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(switchOnImgPath,switchOffImgPath)})
	fbAbEnable 	= Object(typ=Boolean,label='fbAbEnable',default=1,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(switchOnImgPath,switchOffImgPath)})
	txCdEnable 	= Object(typ=Boolean,label='txCdEnable',default=1,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(switchOnImgPath,switchOffImgPath)})
	rxCdEnable 	= Object(typ=Boolean,label='rxCdEnable',default=1,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(switchOnImgPath,switchOffImgPath)})
	fbCdEnable 	= Object(typ=Boolean,label='fbCdEnable',default=1,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(switchOnImgPath,switchOffImgPath)})
	frefExt = Object(typ=RealNumber,label='fRefExt',default=491.52)
	frefInt = Object(typ=RealNumber,label='frefInt',default=491.52,widgetParams={"setDisabled":True})
	lmkInputClk = Object(typ=RealNumber,label='lmkInputClk',default=1474.56,widgetParams={"setDisabled":False})
	sysRef = Object(typ=RealNumber,label='sysRef',default=3.84)
	pllEnLmk = Object(typ=Boolean,label='pllEnLmk',default=0)
	jesdScr0 	= Object(typ=Boolean,label='jesdScr0',default=False)
	jesdScr1 	= Object(typ=Boolean,label='jesdScr1',default=False)
	lowIfNcoRx0 	= Object(typ=RealNumber,label ='lowIfNcoRx0',default=0)
	lowIfNcoRx1 	= Object(typ=RealNumber,label ='lowIfNcoRx1',default=0)
	lowIfNcoTx0 	= Object(typ=RealNumber,label ='lowIfNcoTx0',default=0)
	lowIfNcoTx1 	= Object(typ=RealNumber,label ='lowIfNcoTx1',default=0)
	lowIfNcoFb0 	= Object(typ=RealNumber,label ='lowIfNcoFb0',default=0)
	lowIfNcoFb1 	= Object(typ=RealNumber,label ='lowIfNcoFb1',default=0)
	readStatus = Object(typ=Trigger,label="Read Status",function="readStatusFunc",widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	progressStatus = Object(typ=String,label="",default="",widgetParams={"styleSheet":"QLabel {color:blue;}"})
	polarityAbT1 	= Object(typ=Boolean,label='polarityAbT1',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbT2 	= Object(typ=Boolean,label='polarityAbT2',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbT3 	= Object(typ=Boolean,label='polarityAbT3',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbT4 	= Object(typ=Boolean,label='polarityAbT4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbR1 	= Object(typ=Boolean,label='polarityAbR1',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbR2 	= Object(typ=Boolean,label='polarityAbR2',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbR3 	= Object(typ=Boolean,label='polarityAbR3',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityAbR4 	= Object(typ=Boolean,label='polarityAbR4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdT1 	= Object(typ=Boolean,label='polarityCdT1',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdT2 	= Object(typ=Boolean,label='polarityCdT2',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdT3 	= Object(typ=Boolean,label='polarityCdT3',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdT4 	= Object(typ=Boolean,label='polarityCdT4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdR1 	= Object(typ=Boolean,label='polarityCdR1',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdR2 	= Object(typ=Boolean,label='polarityCdR2',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdR3 	= Object(typ=Boolean,label='polarityCdR3',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	polarityCdR4 	= Object(typ=Boolean,label='polarityCdR4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(NotImgPath,BufferImgPath)})
	
	additionalConfig = Object(typ=Trigger,label='Advanced Config',function='additionalConfigFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	home = Object(typ=Trigger,label='Home',function='homeFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	gpioo = Object(typ=Trigger,label='GPIO',function='gpioFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"})	
	dev0 = Object(typ=Trigger,label='Device',function='dev0Func',widgetParams={"styleSheet":"QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"})	#{"styleSheet":"QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);} QPushButton::hover {background-color:black; color:white; border-color:#ffffff;}"})
	
	myfpgaReconnect = Object(typ=Trigger,label='Reconnect FPGA',function='myfpgaReconnectFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	
	halfRateModeRx = Object(typ=Boolean,label="halfRateMode",default=0)
	halfRateModeFb = Object(typ=Boolean,label="halfRateMode",default=0)
	halfRateModeTx = Object(typ=Boolean,label="halfRateMode",default=0)
	
	lpDisplayString = Object(typ=String,label="LP*",default="LP*",widgetParams={"setToolTip":"Data Converters operate at half frequency of DC PLL. Decimation factor is auto adjusted"})
	
	fpgaConnectedStatus1 = Object(typ=Boolean,label='fpgastatus',default=0,widgetParams={"setDisabled":True,"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulb,redBulb)})
	fpgaConnectedStatus2 = Object(typ=String,label="FpgaStatus",default="FPGA is not connected")
	
	
	
	def myfpgaReconnectFunc(self):
		from workspace import *
		if not Globals.simulationMode:
			try:
				V = hex(self.FPGA.interfaceHandle.ReadControlRegister_Q(self.FPGA.interfaceHandle.CONFIG_BASE_ADDR + 4*8, 1))
				if V[5:] in ['204c','204b']:
					r = True
					warning("FPGA is connected!")
					self._fpgaConnectedStatus1.setValue(1)
					self._fpgaConnectedStatus2.setValue("FPGA is connected")
				else:
					r = False
					fpgaHandleInstance()
					resetFpga()
					V = hex(self.FPGA.interfaceHandle.ReadControlRegister_Q(self.FPGA.interfaceHandle.CONFIG_BASE_ADDR + 4*8, 1))
					if V[5:] in ['204c','204b']:
						self._fpgaConnectedStatus1.setValue(1)
						self._fpgaConnectedStatus2.setValue("FPGA is connected")
					else:
						self._fpgaConnectedStatus1.setValue(0)
						self._fpgaConnectedStatus2.setValue("FPGA is not connected")
			except:
				self._fpgaConnectedStatus1.setValue(0)
				self._fpgaConnectedStatus2.setValue("FPGA is not connected")
				myfpga.Reconnect()
				V = hex(self.FPGA.interfaceHandle.ReadControlRegister_Q(self.FPGA.interfaceHandle.CONFIG_BASE_ADDR + 4*8, 1))
				if V[5:] in ['204c','204b']:
					self._fpgaConnectedStatus1.setValue(1)
					self._fpgaConnectedStatus2.setValue("FPGA is connected")
				else:
					fpgaHandleInstance()
					resetFpga()
					V = hex(self.FPGA.interfaceHandle.ReadControlRegister_Q(self.FPGA.interfaceHandle.CONFIG_BASE_ADDR + 4*8, 1))
					if V[5:] in ['204c','204b']:
						self._fpgaConnectedStatus1.setValue(1)
						self._fpgaConnectedStatus2.setValue("FPGA is connected")
					else:
						self._fpgaConnectedStatus1.setValue(0)
						self._fpgaConnectedStatus2.setValue("FPGA is not connected")
					
		else:
			warning("GUI is running in simulation mode")

	
				
		
	def dev0Func(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(2)
		self._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(white)
		self._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet(black)
		
		
	def gpioFunc(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(8)
		self._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self._dev0.gui.widgets[1].button.setStyleSheet (black)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet (white)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(black) 	
	
	
	def homeFunc(self):
		pass

	############ Below are the choices List.
	LMFSRxChoicesList = ['24410','14810','14610','24610','141210','44210',	'28810','28610','48610','42111','48410','12310','22210','48310','24310','44310','181210','281210','42220','181610','182410','12610','12410']
	LMFSFbChoicesList = ['24820','12810','24620','44620','44420','22320','142420','41240','41121','42220','14810','42320','12610','12410','12310','121620','121220','12820','12620','22210','22310','32411','32211','22420','22620','121640','22840','122440','321230','32830','32630','141620','141220']
	LMFSTxChoicesList = ['24410','14810','14610','24610','141210','44210','12820','48410','28810','28610','48610','281210','24820','48310','24310','44310','181210','181610','34210','38410']
	jesdAbTx1ChoicesList = ['Deactivated','Activated']
	jesdAbTx2ChoicesList = ['Deactivated','Activated']
	jesdAbTx3ChoicesList = ['Deactivated','Activated']
	jesdAbTx4ChoicesList = ['Deactivated','Activated']
	jesdCdTx1ChoicesList = ['Deactivated','Activated']
	jesdCdTx2ChoicesList = ['Deactivated','Activated']
	jesdCdTx3ChoicesList = ['Deactivated','Activated']
	jesdCdTx4ChoicesList = ['Deactivated','Activated']
	jesdAbRx1ChoicesList = ['Deactivated','Activated']
	jesdAbRx2ChoicesList = ['Deactivated','Activated']
	jesdAbRx3ChoicesList = ['Deactivated','Activated']
	jesdAbRx4ChoicesList = ['Deactivated','Activated']
	jesdCdRx1ChoicesList = ['Deactivated','Activated']
	jesdCdRx2ChoicesList = ['Deactivated','Activated']
	jesdCdRx3ChoicesList = ['Deactivated','Activated']
	jesdCdRx4ChoicesList = ['Deactivated','Activated']
	laneMuxJesdAbTx1ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdAbTx2ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdAbTx3ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdAbTx4ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdCdTx1ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdCdTx2ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdCdTx3ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdCdTx4ChoicesList = ['1STX','2STX','3STX','4STX','5STX','6STX','7STX','8STX']
	laneMuxJesdAbRx1ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdAbRx2ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdAbRx3ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdAbRx4ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdCdRx1ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdCdRx2ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdCdRx3ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	laneMuxJesdCdRx4ChoicesList = ['1SRX','2SRX','3SRX','4SRX','5SRX','6SRX','7SRX','8SRX']
	iqRateRxChoicesList = [30.72,61.44,92.16,122.88,184.32,245.76,368.64]
	iqRateFbChoicesList = [122.88,184.32,245.76,368.64,491.52,737.28]
	iqRateTxChoicesList = [122.88,184.32,245.76,368.64,491.52,737.28]
	dataConverterPllChoicesList = [2949.12,3317.76]
	functionChoicesChoicesList = ['Device Bringup','Configure PLL','Configure NCOs','Generate Configuration','Save GUI State','Load GUI State']
	jesdAbProtocolChoicesList = ['204 B','204 C']
	jesdCdProtocolChoicesList = ['204 B','204 C']
	frefSelectChoicesList = ["Fref External","Fref Internal"]
	
	
	###---All widgets---###
	guiWidgetsList = ['additionalConfig', 'apply', 'dataConverterPll', 'fbAbEnable', 'fbAbNco', 'fbCdEnable', 'fbCdNco', 'frefExt', 'frefInt', 'frefSelect', 'functionChoices', 'iqRateFb0', 'iqRateFb1', 'iqRateRx0', 'iqRateRx1', 'iqRateTx0', 'iqRateTx1', 'jesdAbDedicatedLaneMode', 'jesdAbProtocol', 'jesdAbRx1', 'jesdAbRx2', 'jesdAbRx3', 'jesdAbRx4', 'jesdAbTx1', 'jesdAbTx2', 'jesdAbTx3', 'jesdAbTx4', 'jesdCdDedicatedLaneMode', 'jesdCdProtocol', 'jesdCdRx1', 'jesdCdRx2', 'jesdCdRx3', 'jesdCdRx4', 'jesdCdTx1', 'jesdCdTx2', 'jesdCdTx3', 'jesdCdTx4', 'jesdScr0', 'jesdScr1', 'kfb0', 'kfb1', 'krx0', 'krx1', 'ktx0', 'ktx1', 'laneMuxJesdAbRx1', 'laneMuxJesdAbRx2', 'laneMuxJesdAbRx3', 'laneMuxJesdAbRx4', 'laneMuxJesdAbTx1', 'laneMuxJesdAbTx2', 'laneMuxJesdAbTx3', 'laneMuxJesdAbTx4', 'laneMuxJesdCdRx1', 'laneMuxJesdCdRx2', 'laneMuxJesdCdRx3', 'laneMuxJesdCdRx4', 'laneMuxJesdCdTx1', 'laneMuxJesdCdTx2', 'laneMuxJesdCdTx3', 'laneMuxJesdCdTx4', 'lmfsfb0', 'lmfsfb1', 'lmfsrx0', 'lmfsrx1', 'lmfstx0', 'lmfstx1', 'lmkInputClk', 'lowIfNcoFb0', 'lowIfNcoFb1', 'lowIfNcoRx0', 'lowIfNcoRx1', 'lowIfNcoTx0', 'lowIfNcoTx1', 'pllEnLmk', 'pllLo0', 'pllLo1', 'pllLo2', 'pllLo3', 'pllLo4', 'polarityAbR1', 'polarityAbR2', 'polarityAbR3', 'polarityAbR4', 'polarityAbT1', 'polarityAbT2', 'polarityAbT3', 'polarityAbT4', 'polarityCdR1', 'polarityCdR2', 'polarityCdR3', 'polarityCdR4', 'polarityCdT1', 'polarityCdT2', 'polarityCdT3', 'polarityCdT4','readStatus', 'rxAbEnable', 'rxAbLo', 'rxAbNco', 'rxCdEnable', 'rxCdLo', 'rxCdNco', 'sysRef', 'txAbEnable', 'txAbLo', 'txAbNco', 'txCdEnable', 'txCdLo', 'txCdNco']

	def __init__(self,libInstance,cache,gpio,guiControllerInstance,lmkParams,FPGA):
		super(afe77xxSystemParamsiGui,self).__init__(libInstance=libInstance,cache=cache,guiControllerInstance=guiControllerInstance,lmkParams=lmkParams,FPGA=FPGA)
		self.libInstance=libInstance
		self.guiControllerInstance = guiControllerInstance
		self.gpio = gpio
		self.cache = cache
		self.FPGA = FPGA


		self.gui.hide()

		try:
			from workspace import hwResetHandle, setupParams
			hwResetHandle.toggle()
			self._controller.guiParams.qCurrent['0p95'] = setupParams.currSensor.readCurrent('0p95')/2.0
			self._controller.guiParams.qCurrent['1p2'] = setupParams.currSensor.readCurrent('1p2')/2.0
			self._controller.guiParams.qCurrent['1p2PLL'] = setupParams.currSensor.readCurrent('1p2VPLL')/2.0
			self._controller.guiParams.qCurrent['1p8'] = setupParams.currSensor.readCurrent('1p8')/2.0
			self._controller.guiParams.qCurrent['1p8PLL'] = setupParams.currSensor.readCurrent('1p8VPLL')/2.0
			self._controller.guiParams.qCurrent['2p5'] = setupParams.currSensor.readCurrent('2p5')/2.0
		except:
			pass
	
		self._jesdAbProtocol.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onJesdProtocolChange('AB'))
		self._jesdCdProtocol.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onJesdProtocolChange('CD'))
		self._laneMuxJesdAbTx1.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(0))
		self._laneMuxJesdAbTx2.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(1))
		self._laneMuxJesdAbTx3.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(2))
		self._laneMuxJesdAbTx4.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(3))
		self._laneMuxJesdCdTx1.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(4))
		self._laneMuxJesdCdTx2.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(5))
		self._laneMuxJesdCdTx3.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(6))
		self._laneMuxJesdCdTx4.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdTxChange(7))
		self._laneMuxJesdAbRx1.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(0))
		self._laneMuxJesdAbRx2.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(1))
		self._laneMuxJesdAbRx3.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(2))
		self._laneMuxJesdAbRx4.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(3))
		self._laneMuxJesdCdRx1.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(4))
		self._laneMuxJesdCdRx2.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(5))
		self._laneMuxJesdCdRx3.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(6))
		self._laneMuxJesdCdRx4.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.onLaneMuxJesdRxChange(7))
		self._jesdAbDedicatedLaneMode.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.onJesdDedicatedLaneModeChange('AB'))
		self._jesdCdDedicatedLaneMode.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.onJesdDedicatedLaneModeChange('CD'))
		self._krx0.gui.widgets[0].numberEntryBox.textChanged.connect(lambda: self.onKChange('RX','AB'))
		self._kfb0.gui.widgets[0].numberEntryBox.textChanged.connect(lambda: self.onKChange('FB','AB'))
		self._ktx0.gui.widgets[0].numberEntryBox.textChanged.connect(lambda: self.onKChange('TX','AB'))
		self._krx1.gui.widgets[0].numberEntryBox.textChanged.connect(lambda: self.onKChange('RX','CD'))
		self._kfb1.gui.widgets[0].numberEntryBox.textChanged.connect(lambda: self.onKChange('FB','CD'))
		self._ktx1.gui.widgets[0].numberEntryBox.textChanged.connect(lambda: self.onKChange('TX','CD'))
		self._lmfsrx0.gui.widgets[0].combo.currentIndexChanged.connect(lambda:self.onLmfsChange('RX','AB'))
		self._lmfsrx1.gui.widgets[0].combo.currentIndexChanged.connect(lambda:self.onLmfsChange('RX','CD'))
		self._lmfsfb0.gui.widgets[0].combo.currentIndexChanged.connect(lambda:self.onLmfsChange('FB','AB'))
		self._lmfsfb1.gui.widgets[0].combo.currentIndexChanged.connect(lambda:self.onLmfsChange('FB','CD'))
		self._lmfstx0.gui.widgets[0].combo.currentIndexChanged.connect(lambda:self.onLmfsChange('TX','AB'))
		self._lmfstx1.gui.widgets[0].combo.currentIndexChanged.connect(lambda:self.onLmfsChange('TX','CD'))
		self._pllEnLmk.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.onPllEnLmkChange())
		self._frefSelect.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.refClkChange())
		self._halfRateModeFb.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.halfRateModeFbChange(self._halfRateModeFb.getValue()))
	
		self.sysParamsDefault()
		self.defaultConfiguration()

		
	def halfRateModeFbChange(self,val):
		if val:
			self._iqRateRx0.setValue(4)
			self._iqRateRx1.setValue(4)
			self._iqRateFb0.setValue(3)
			self._iqRateFb1.setValue(3)
			self._iqRateTx0.setValue(3)
			self._iqRateTx1.setValue(3)
			self._iqRateFb0.gui.widgets[1].combo.model().item(4).setEnabled(0)
			self._iqRateFb0.gui.widgets[1].combo.model().item(5).setEnabled(0)
			self._iqRateFb1.gui.widgets[1].combo.model().item(4).setEnabled(0)
			self._iqRateFb1.gui.widgets[1].combo.model().item(5).setEnabled(0)
		else:
			# self._iqRateFb0.setValue(4)
			# self._iqRateFb1.setValue(4)
			self._iqRateFb0.gui.widgets[1].combo.model().item(4).setEnabled(1)
			self._iqRateFb0.gui.widgets[1].combo.model().item(5).setEnabled(1)
			self._iqRateFb1.gui.widgets[1].combo.model().item(4).setEnabled(1)
			self._iqRateFb1.gui.widgets[1].combo.model().item(5).setEnabled(1)
			
	def refClkChange(self):
		tag = self._frefSelect.getValue()
		if tag == 0:
			self._frefExt.gui.widgets[1].numberEntryBox.setDisabled(0)
			self._frefInt.gui.widgets[1].numberEntryBox.setDisabled(1)
		elif tag == 1:
			self._frefExt.gui.widgets[1].numberEntryBox.setDisabled(1)
			self._frefInt.gui.widgets[1].numberEntryBox.setDisabled(0)
			
	def textParser(self,name):
		name = name.replace('.','')
		return name
		
	def saveAndLoadGuiState(self,mode):
		from workspace import *
		self.iGuiPages = []
		
		topPageIdx = afe77xxiGui.mainWindow.stackWidget.currentIndex()
		topPageId = id(afe77xxiGui.mainWindow.stackWidget.currentWidget())
		name = self.textParser(afe77xxiGui.mainWindow.widget2PrefixMapping[topPageId])
		self.iGuiPages.append(name)
		
		additionalConfigPageIdx = topPageIdx + 3
		afe77xxiGui.mainWindow.changeTab(additionalConfigPageIdx)
		additionalConfigPageId = id(afe77xxiGui.mainWindow.stackWidget.currentWidget())
		name = self.textParser(afe77xxiGui.mainWindow.widget2PrefixMapping[additionalConfigPageId])
		self.iGuiPages.append(name)
		
		# customConfigPageIdx = topPageIdx + 1
		# afe77xxiGui.mainWindow.changeTab(customConfigPageIdx)
		# customConfigPageId = id(afe77xxiGui.mainWindow.stackWidget.currentWidget())
		# name = self.textParser(afe77xxiGui.mainWindow.widget2PrefixMapping[customConfigPageId])
		self.iGuiPages.append(name)
		
		afe77xxiGui.mainWindow.changeTab(topPageIdx)
		
		# font = self._progressStatus.gui.widgets[1].valueLabel.font()
		# font.setPointSize(10)
		# self._progressStatus.gui.widgets[1].valueLabel.setFont(font)
	
		if mode == 'save':
			dataBaseFilePathname,extension = QtGui.QFileDialog.getSaveFileName(filter=('*.state'))
			if len(dataBaseFilePathname) > 2: 
				# self._progressStatus.setValue("Processing .. Please wait ..")
				self.state = sqlite3.connect(dataBaseFilePathname)
				
				for page in self.iGuiPages:
					self.state.execute('''DROP TABLE IF EXISTS '''+str(page)+'''''')
					self.state.execute('''CREATE TABLE IF NOT EXISTS '''+str(page)+''' (
							id INTEGER PRIMARY KEY AUTOINCREMENT unique,
							name TEXT 	NOT NULL unique,
							floatValue REAL ,
							integerValue INTEGER,
							stringValue TEXT 
							booleanValue INTEGER);''')
					for paramName in eval(str(page)+".guiWidgetsList"):
							# self._progressStatus.setValue("Processing .. Please wait ..")
							try:
								exec("value = "+str(page)+"._"+paramName+".getValue()")
								if isinstance(value,int):
									self.state.execute('''INSERT INTO '''+str(page)+'''(name,integerValue) VALUES(?,?)''',(paramName,value))
								elif isinstance(value,float):
									self.state.execute('''INSERT INTO '''+str(page)+'''(name,floatValue) VALUES(?,?)''',(paramName,value))
								elif isinstance(value,str):
									self.state.execute('''INSERT INTO '''+str(page)+'''(name,stringValue) VALUES(?,?)''',(paramName,value))
								elif isinstance(value,bool):
									self.state.execute('''INSERT INTO '''+str(page)+'''(name,booleanValue) VALUES(?,?)''',(paramName,value))
							except:
								pass
				self.state.commit()
				self.state.close()
				# self._progressStatus.setValue('Saved the Current GUI State.')
				return self.iGuiPages
			else:
				warning('Saving failed!')
				# self._progressStatus.setValue('Saving failed!')
		elif mode == 'load':
			self.iGuiPages = []
			dataBaseFilePathname,extension = QtGui.QFileDialog.getOpenFileName(filter='*.state')
			if len(dataBaseFilePathname) > 2:
				# self._progressStatus.setValue("Processing .. Please wait ..")
				self.retrieveState = sqlite3.connect(dataBaseFilePathname)
				tables = self.retrieveState.execute("SELECT name FROM sqlite_master WHERE type='table';")
				for table in tables:
					if table[0] != 'sqlite_sequence':
						self.iGuiPages.append(str(table[0]))
				for page in self.iGuiPages:
					cursor = self.retrieveState.execute('''SELECT * FROM '''+str(page)+'''''')
					if '1' in page:
						page = page.replace('1','')
					elif '0' in table[0]:
						page = page.replace('0','')
					else:
						page = page
					if setupParams.boardType in ("EVM","HSC1373"):
						if self.libInstance.systemStatus.dutNo == 0:
							page = page + '0'
						elif self.libInstance.systemStatus.dutNo == 1:
							page = page + '1'
					else:
						page = page
					for row in cursor:
						# self._progressStatus.setValue("Processing .. Please wait ..")
						paramName = row[1]
						for i in [2,3,4]:
							if row[i] is not None:
								try:
									eval(str(page)+"._"+str(paramName)+".setValue("+str(row[i])+")")
								except:
									log(str(page)+"._"+str(paramName)+"._"+str(row[i]))
				# self._progressStatus.setValue('Loaded the GUI State.')
				self.retrieveState.close()
			else:
				warning('Loading failed!')
				# self._progressStatus.setValue('Loading failed!')
		
	def readStatusFunc(self):
		from workspace import afe77xxiGui
		topPageIdx = afe77xxiGui.mainWindow.stackWidget.currentIndex()
		afe77xxiGui.mainWindow.changeTab(topPageIdx+2)

	def additionalConfigFunc(self):
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(5)


	def onPllEnLmkChange(self):
		pllState = self._pllEnLmk.getValue()
		if pllState == True:
			self._lmkInputClk.setValue(10)
		else:
			self._lmkInputClk.setValue(1474.56)

	def laneSwitcher(self,laneMode,rxLanes,fbLanes,txLanes,block):	
		if laneMode == True:
			laneArr = [1]*rxLanes
			subArr = 2 - len(laneArr)
			laneArr = laneArr + [0]*subArr
			for idx,val in enumerate(laneArr):
				eval("self._jesd" + block[0] + block[1].lower() + "Tx" + str(idx+1) + ".setValue(" + str(val) + ")")
			laneArr = [1]*fbLanes
			subArr = 2 - len(laneArr)
			laneArr = laneArr + [0]*subArr
			for idx,val in enumerate(laneArr):
				eval("self._jesd" + block[0] + block[1].lower() + "Tx" + str(idx+3) + ".setValue(" + str(val) + ")")
			laneArr = [1]*txLanes
			subArr = 4 - len(laneArr)
			laneArr = laneArr + [0]*subArr
			for idx,val in enumerate(laneArr):
				eval("self._jesd" + block[0] + block[1].lower() + "Rx" + str(idx+1)+ ".setValue(" + str(val) + ")")
		elif laneMode == False:
			if rxLanes > fbLanes: 
				laneArr = [1]*rxLanes
				subArr = 4 - len(laneArr)
				laneArr = laneArr + [0]*subArr
				for idx,val in enumerate(laneArr):
					eval("self._jesd" + block[0] + block[1].lower() + "Tx" + str(idx+1) + ".setValue(" + str(val) + ")")
			elif fbLanes > rxLanes:
				laneArr = [1]*fbLanes
				subArr = 4 - len(laneArr)
				laneArr = laneArr + [0]*subArr
				for idx,val in enumerate(laneArr):
					eval("self._jesd" + block[0] + block[1].lower() + "Tx" + str(idx+1) + ".setValue(" + str(val) + ")")
			elif fbLanes == rxLanes:
				laneArr = [1]*fbLanes
				subArr = 4 - len(laneArr)
				laneArr = laneArr + [0]*subArr
				for idx,val in enumerate(laneArr):
					eval("self._jesd" + block[0] + block[1].lower() + "Tx" + str(idx+1) + ".setValue(" + str(val) + ")")
			laneArr = [1]*txLanes
			subArr = 4 - len(laneArr)
			laneArr = laneArr + [0]*subArr
			for idx,val in enumerate(laneArr):
				eval("self._jesd" + block[0] + block[1].lower() + "Rx" + str(idx+1) + ".setValue(" + str(val) + ")")
		
	def onLmfsChange(self,ch,block):
		tempValidList={'RX0':[],'RX1':[],'FB0':[],'FB1':[]}
		laneMode_ab = self._jesdAbDedicatedLaneMode.getValue()
		laneMode_cd = self._jesdCdDedicatedLaneMode.getValue()
		if block =='AB':
			L_RX_AB,M_RX_AB,F_RX_AB,S_RX_AB,Hd_RX_AB,resolution_RX_AB,numBands_RX_AB = self.libInstance.jesdModeFeatures(self.LMFSRxChoicesList[self._lmfsrx0.getValue()])
			L_FB_AB,M_FB_AB,F_FB_AB,S_FB_AB,Hd_FB_AB,resolution_FB_AB,numBands_FB_AB = self.libInstance.jesdModeFeatures(self.LMFSFbChoicesList[self._lmfsfb0.getValue()])
			L_TX_AB,M_TX_AB,F_TX_AB,S_TX_AB,Hd_TX_AB,resolution_TX_AB,numBands_TX_AB = self.libInstance.jesdModeFeatures(self.LMFSTxChoicesList[self._lmfstx0.getValue()])
			if laneMode_ab == True:
				self.laneSwitcher(laneMode_ab,L_RX_AB,L_FB_AB,L_TX_AB,block)

			elif laneMode_ab == False:
				if ch =='RX':
					for idx,choice in enumerate(self.LMFSFbChoicesList):
						L_FB_AB1,M_FB_AB1,F_FB_AB1,S_FB_AB1,Hd_FB_AB1,resolution_FB_AB1,numBands_FB_AB1 = self.libInstance.jesdModeFeatures(choice)
						if F_RX_AB == F_FB_AB1:
							tempValidList['FB0'].append(choice)
							self._lmfsfb0.gui.widgets[1].combo.model().item(idx).setEnabled(1)
						else:
							self._lmfsfb0.gui.widgets[1].combo.model().item(idx).setEnabled(0)
					self._lmfsfb0.setValue(self.LMFSFbChoicesList.index(tempValidList['FB0'][0]))
					L_FB_AB,M_FB_AB,F_FB_AB,S_FB_AB,Hd_FB_AB,resolution_FB_AB,numBands_FB_AB = self.libInstance.jesdModeFeatures(self.LMFSFbChoicesList[self._lmfsfb0.getValue()])
					self.laneSwitcher(laneMode_ab,L_RX_AB,L_FB_AB,L_TX_AB,block)
				self.laneSwitcher(laneMode_ab,L_RX_AB,L_FB_AB,L_TX_AB,block)
		if block =='CD':
			L_RX_CD,M_RX_CD,F_RX_CD,S_RX_CD,Hd_RX_CD,resolution_RX_CD,numBands_RX_CD = self.libInstance.jesdModeFeatures(self.LMFSRxChoicesList[self._lmfsrx1.getValue()]) 
			L_FB_CD,M_FB_CD,F_FB_CD,S_FB_CD,Hd_FB_CD,resolution_FB_CD,numBands_FB_CD = self.libInstance.jesdModeFeatures(self.LMFSFbChoicesList[self._lmfsfb1.getValue()])
			L_TX_CD,M_TX_CD,F_TX_CD,S_TX_CD,Hd_TX_CD,resolution_TX_CD,numBands_TX_CD = self.libInstance.jesdModeFeatures(self.LMFSTxChoicesList[self._lmfstx1.getValue()])
			if laneMode_cd == True:
				self.laneSwitcher(laneMode_cd,L_RX_CD,L_FB_CD,L_TX_CD,block)
			if laneMode_cd == False:
				if ch =='RX':
					for idx,choice in enumerate(self.LMFSFbChoicesList):
						L_FB_CD1,M_FB_CD1,F_FB_CD1,S_FB_CD1,Hd_FB_CD1,resolution_FB_CD1,numBands_FB_CD1 = self.libInstance.jesdModeFeatures(choice)
						if F_RX_CD == F_FB_CD1:
							tempValidList['FB1'].append(choice)
							self._lmfsfb1.gui.widgets[1].combo.model().item(idx).setEnabled(1)
						else:
							self._lmfsfb1.gui.widgets[1].combo.model().item(idx).setEnabled(0)
					self._lmfsfb1.setValue(self.LMFSFbChoicesList.index(tempValidList['FB1'][0]))
					L_FB_CD,M_FB_CD,F_FB_CD,S_FB_CD,Hd_FB_CD,resolution_FB_CD,numBands_FB_CD = self.libInstance.jesdModeFeatures(self.LMFSFbChoicesList[self._lmfsfb1.getValue()])
					self.laneSwitcher(laneMode_cd,L_RX_CD,L_FB_CD,L_TX_CD,block)
					
				self.laneSwitcher(laneMode_cd,L_RX_CD,L_FB_CD,L_TX_CD,block)
				

	def onJesdDedicatedLaneModeChange(self, ch):
		if ch =='AB':
			laneMode_ab = self._jesdAbDedicatedLaneMode.getValue()
			if laneMode_ab == True:
				for idx,item in enumerate(self.LMFSRxChoicesList):
					if int(item[0]) in [3,4]:
						self._lmfsrx0.gui.widgets[1].combo.model().item(idx).setEnabled(0)
					else:
						self._lmfsrx0.gui.widgets[1].combo.model().item(idx).setEnabled(1)
				for idx,item in enumerate(self.LMFSFbChoicesList):
					if int(item[0]) in [3,4]:
						self._lmfsfb0.gui.widgets[1].combo.model().item(idx).setEnabled(0)
					else:
						self._lmfsfb0.gui.widgets[1].combo.model().item(idx).setEnabled(1)
				lmfsrx = self.LMFSRxChoicesList[self._lmfsrx0.getValue()]
				if int(lmfsrx[0]) in [3,4]:
					self._lmfsrx0.setValue(0)
				lmfsfb = self.LMFSFbChoicesList[self._lmfsfb0.getValue()]
				if int(lmfsfb[0]) in [3,4]:
					self._lmfsfb0.setValue(0)

				L_RX_AB,M_RX_AB,F_RX_AB,S_RX_AB,Hd_RX_AB,resolution_RX_AB,numBands_RX_AB = self.libInstance.jesdModeFeatures(self.LMFSRxChoicesList[self._lmfsrx0.getValue()])
				L_FB_AB,M_FB_AB,F_FB_AB,S_FB_AB,Hd_FB_AB,resolution_FB_AB,numBands_FB_AB = self.libInstance.jesdModeFeatures(self.LMFSFbChoicesList[self._lmfsfb0.getValue()])
				L_TX_AB,M_TX_AB,F_TX_AB,S_TX_AB,Hd_TX_AB,resolution_TX_AB,numBands_TX_AB = self.libInstance.jesdModeFeatures(self.LMFSTxChoicesList[self._lmfstx0.getValue()])

				self.laneSwitcher(laneMode_ab,L_RX_AB,L_FB_AB,L_TX_AB,ch)
				
			elif laneMode_ab == False:
				for idx,item in enumerate(self.LMFSRxChoicesList):
					self._lmfsrx0.gui.widgets[1].combo.model().item(idx).setEnabled(1)
				for idx,item in enumerate(self.LMFSFbChoicesList):
					self._lmfsfb0.gui.widgets[1].combo.model().item(idx).setEnabled(1)
				self.onLmfsChange('RX','AB')

		elif ch =='CD':
			laneMode_cd = self._jesdCdDedicatedLaneMode.getValue()
		
			if laneMode_cd == True:
				
				for idx,item in enumerate(self.LMFSRxChoicesList):
					if int(item[0]) in [3,4]:
						self._lmfsrx1.gui.widgets[1].combo.model().item(idx).setEnabled(0)
				for idx,item in enumerate(self.LMFSFbChoicesList):
					if int(item[0]) in [3,4]:
						self._lmfsfb1.gui.widgets[1].combo.model().item(idx).setEnabled(0)
				lmfsrx = self.LMFSRxChoicesList[self._lmfsrx1.getValue()]
				if int(lmfsrx[0]) in [3,4]:
					self._lmfsrx1.setValue(0)
				lmfsfb = self.LMFSFbChoicesList[self._lmfsfb1.getValue()]
				if int(lmfsfb[0]) in [3,4]:
					self._lmfsfb1.setValue(0)

				L_RX_CD,M_RX_CD,F_RX_CD,S_RX_CD,Hd_RX_CD,resolution_RX_CD,numBands_RX_CD = self.libInstance.jesdModeFeatures(self.LMFSRxChoicesList[self._lmfsrx1.getValue()]) 
				L_FB_CD,M_FB_CD,F_FB_CD,S_FB_CD,Hd_FB_CD,resolution_FB_CD,numBands_FB_CD = self.libInstance.jesdModeFeatures(self.LMFSFbChoicesList[self._lmfsfb1.getValue()])
				L_TX_CD,M_TX_CD,F_TX_CD,S_TX_CD,Hd_TX_CD,resolution_TX_CD,numBands_TX_CD = self.libInstance.jesdModeFeatures(self.LMFSTxChoicesList[self._lmfstx1.getValue()])

				self.laneSwitcher(laneMode_cd,L_RX_CD,L_FB_CD,L_TX_CD,ch)
			elif laneMode_cd == False:
				for idx,item in enumerate(self.LMFSRxChoicesList):
					self._lmfsrx1.gui.widgets[1].combo.model().item(idx).setEnabled(1)
				for idx,item in enumerate(self.LMFSFbChoicesList):
					self._lmfsfb1.gui.widgets[1].combo.model().item(idx).setEnabled(1)
				self.onLmfsChange('RX','CD')

	def onKChange(self, ch, block):
		# self._krx0.gui.widgets[1].combo.setDisabled(1)
		if ch =='RX':
			if block =='AB':
				kAb=self._krx0.getValue()
				self._kfb0.setValue(kAb)
				self._ktx0.setValue(kAb)
			if block =='CD':
				kCd=self._krx1.getValue()
				self._kfb1.setValue(kCd)
				self._ktx1.setValue(kCd)
		elif ch =='FB':
			if block =='AB':
				kAb=self._kfb0.getValue()
				self._krx0.setValue(kAb)
				self._ktx0.setValue(kAb)
			if block =='CD':
				kCd=self._kfb1.getValue()
				self._krx1.setValue(kCd)
				self._ktx1.setValue(kCd)
		elif ch =='TX':
			if block =='AB':
				kAb=self._ktx0.getValue()
				self._krx0.setValue(kAb)
				self._kfb0.setValue(kAb)
			if block =='CD':
				kCd=self._ktx1.getValue()
				self._krx1.setValue(kCd)
				self._kfb1.setValue(kCd)





	


	def onLaneMuxJesdTxChange(self, ch):
		stx1 = self._laneMuxJesdAbTx1.getValue()
		stx2 = self._laneMuxJesdAbTx2.getValue()
		stx3 = self._laneMuxJesdAbTx3.getValue()
		stx4 = self._laneMuxJesdAbTx4.getValue()
		stx5 = self._laneMuxJesdCdTx1.getValue()
		stx6 = self._laneMuxJesdCdTx2.getValue()
		stx7 = self._laneMuxJesdCdTx3.getValue()
		stx8 = self._laneMuxJesdCdTx4.getValue()
		extensive = [0,1,2,3,4,5,6,7]
		used_indexes = [stx1, stx2, stx3, stx4, stx5, stx6, stx7, stx8]
		available_index = list(set(extensive)-set(used_indexes))[0]		
		target_ch = list(set([i for i, e in enumerate(used_indexes) if e == used_indexes[ch]]) - set([ch]))[0]
		if target_ch == 0:
			self._controller.setLaneMuxJesdAbTx1(available_index)
			self._laneMuxJesdAbTx1.getValue()
		elif target_ch == 1:
			self._controller.setLaneMuxJesdAbTx2(available_index)
			self._laneMuxJesdAbTx2.getValue()
		elif target_ch == 2:
			self._controller.setLaneMuxJesdAbTx3(available_index)
			self._laneMuxJesdAbTx3.getValue()
		elif target_ch == 3:
			self._controller.setLaneMuxJesdAbTx4(available_index)
			self._laneMuxJesdAbTx4.getValue()
		elif target_ch == 4:
			self._controller.setLaneMuxJesdCdTx1(available_index)
			self._laneMuxJesdCdTx1.getValue()
		elif target_ch == 5:
			self._controller.setLaneMuxJesdCdTx2(available_index)
			self._laneMuxJesdCdTx2.getValue()
		elif target_ch == 6:
			self._controller.setLaneMuxJesdCdTx3(available_index)
			self._laneMuxJesdCdTx3.getValue()
		elif target_ch == 7:
			self._controller.setLaneMuxJesdCdTx4(available_index)
			self._laneMuxJesdCdTx4.getValue()

	def onLaneMuxJesdRxChange(self, ch):
		srx1 = self._laneMuxJesdAbRx1.getValue()
		srx2 = self._laneMuxJesdAbRx2.getValue()
		srx3 = self._laneMuxJesdAbRx3.getValue()
		srx4 = self._laneMuxJesdAbRx4.getValue()
		srx5 = self._laneMuxJesdCdRx1.getValue()
		srx6 = self._laneMuxJesdCdRx2.getValue()
		srx7 = self._laneMuxJesdCdRx3.getValue()
		srx8 = self._laneMuxJesdCdRx4.getValue()
		extensive = [0,1,2,3,4,5,6,7]
		used_indexes = [srx1, srx2, srx3, srx4, srx5, srx6, srx7, srx8]
		available_index = list(set(extensive)-set(used_indexes))[0]		
		target_ch = list(set([i for i, e in enumerate(used_indexes) if e == used_indexes[ch]]) - set([ch]))[0]
		if target_ch == 0:
			self._controller.setLaneMuxJesdAbRx1(available_index)
			self._laneMuxJesdAbRx1.getValue()
		elif target_ch == 1:
			self._controller.setLaneMuxJesdAbRx2(available_index)
			self._laneMuxJesdAbRx2.getValue()
		elif target_ch == 2:
			self._controller.setLaneMuxJesdAbRx3(available_index)
			self._laneMuxJesdAbRx3.getValue()
		elif target_ch == 3:
			self._controller.setLaneMuxJesdAbRx4(available_index)
			self._laneMuxJesdAbRx4.getValue()
		elif target_ch == 4:
			self._controller.setLaneMuxJesdCdRx1(available_index)
			self._laneMuxJesdCdRx1.getValue()
		elif target_ch == 5:
			self._controller.setLaneMuxJesdCdRx2(available_index)
			self._laneMuxJesdCdRx2.getValue()
		elif target_ch == 6:
			self._controller.setLaneMuxJesdCdRx3(available_index)
			self._laneMuxJesdCdRx3.getValue()
		elif target_ch == 7:
			self._controller.setLaneMuxJesdCdRx4(available_index)
			self._laneMuxJesdCdRx4.getValue()

	def onJesdProtocolChange(self, channel):
		if channel =='AB':
			self._controller.setJesdCdProtocol(self._jesdAbProtocol.getValue())
			self._jesdCdProtocol.getValue()
			log("The JESD protocol for both JESD AB and JESD CD block changes together. It has been set to %s."%(self.jesdAbProtocolChoicesList[self._jesdAbProtocol.getValue()]))
		elif channel =='CD':
			self._controller.setJesdAbProtocol(self._controller.getJesdCdProtocol())
			self._jesdAbProtocol.getValue()

	def defaultConfiguration(self):
		self.gpio.CPLD.PINCONTROL.PINCONTROL.V13.dirControl = 2
		self.gpio.CPLD.PINCONTROL.PINCONTROL.C13.dirControl = 2
		self.gpio.CPLD.PINCONTROL.PINCONTROL.D14.dirControl = 2
		self.gpio.CPLD.PINCONTROL.PINCONTROL.U14.dirControl = 2
		self.gpio.CPLD.PINCONTROL.PINCONTROL.T13.dirControl = 2
		self.gpio.CPLD.PINCONTROL.PINCONTROL.E13.dirControl = 2
		self._txAbEnable.setValue(True)
		self._rxAbEnable.setValue(True)
		self._fbAbEnable.setValue(True)
		self._txCdEnable.setValue(True)
		self._rxCdEnable.setValue(True)
		self._fbCdEnable.setValue(True)

		self._txAbLo.setValue(3500.001)
		self._txCdLo.setValue(3500.001)
		self._rxAbLo.setValue(3500.001)
		self._rxCdLo.setValue(3500.001)
		self._frefExt.setValue(491.52)
		self._controller.setDataConverterPll(0)
		self._dataConverterPll.getValue()
		self._jesdAbDedicatedLaneMode.setValue(1)
		self._jesdCdDedicatedLaneMode.setValue(1)
		self._controller.setLmfsrx0(0)
		self._lmfsrx0.getValue()
		self._controller.setLmfsrx1(0)
		self._lmfsrx1.getValue()
		self._controller.setLmfstx0(5)
		self._lmfstx0.getValue()
		self._controller.setLmfstx1(5)
		self._lmfstx1.getValue()
		self._controller.setLmfsfb0(23)
		self._lmfsfb0.getValue()
		self._controller.setLmfsfb1(23)
		self._lmfsfb1.getValue()
		self._controller.setIqRateRx0(5)
		self._iqRateRx0.getValue()
		self._controller.setIqRateRx1(5)
		self._iqRateRx1.getValue()
		self._controller.setIqRateTx0(4)
		self._iqRateTx0.getValue()
		self._controller.setIqRateTx1(4)
		self._iqRateTx1.getValue()
		self._controller.setIqRateFb0(4)
		self._iqRateFb0.getValue()
		self._controller.setIqRateFb1(4)
		self._iqRateFb1.getValue()
		self._fbAbNco.setValue(3500.001)
		self._fbCdNco.setValue(3500.001)
		self._krx0.setValue(16)
		self._kfb0.setValue(16)
		self._ktx0.setValue(16)
		self._krx1.setValue(16)
		self._kfb1.setValue(16)
		self._ktx1.setValue(16)
		self._polarityAbT1.setValue(False)
		self._polarityAbT2.setValue(False)
		self._polarityAbT3.setValue(False)
		self._polarityAbT4.setValue(False)
		self._polarityCdT1.setValue(False)
		self._polarityCdT2.setValue(False)
		self._polarityCdT3.setValue(False)
		self._polarityCdT4.setValue(False)
		self._polarityAbR1.setValue(False)
		self._polarityAbR2.setValue(False)
		self._polarityAbR3.setValue(False)
		self._polarityAbR4.setValue(False)
		self._polarityCdR1.setValue(False)
		self._polarityCdR2.setValue(False)
		self._polarityCdR3.setValue(False)
		# self._polarityCdR4.setValue(False)

		# self.configurePll(0)
		# self.configureDigital()
		# self.configureJESD()

	def readBackPll(self,pllNo):
		N = self.libInstance.regs.TOP.PLL[pllNo].pll1.pll1.N
		F = self.libInstance.regs.TOP.PLL[pllNo].pll1.pll1.F
		D = self.libInstance.regs.TOP.PLL[pllNo].pll1.pll1.D
		D_extra = self.libInstance.regs.TOP.PLL[pllNo].pll1.pll1.CTL_OUT_DIV
		fref = self._frefExt.getValue()
		freqPll = (fref/(2.0*D_extra))*(N + (float(F)/D))
		return freqPll


	def configurePll(self, immediate=0):
		configSupported = 1

		txab = int(1000*self._txAbLo.getValue())/1000.0
		rxab = int(1000*self._rxAbLo.getValue())/1000.0
		txcd = int(1000*self._txCdLo.getValue())/1000.0
		rxcd = int(1000*self._rxCdLo.getValue())/1000.0
		if (txab==rxab) & (rxab==txcd) & (txcd==rxcd):
			log("Configuring the device in 4T4R TDD mode.")
			self.libInstance.systemParams.pllMuxModes = 0
			self.libInstance.systemParams.systemMode = [1,1]
		elif (txab==txcd) & (rxab==rxcd) & (txab!=rxab):
			log("Configuring the device in 4T4R FDD mode.")
			self.libInstance.systemParams.pllMuxModes = 2
			self.libInstance.systemParams.systemMode = [1,1]
		elif (txab==rxab) & (txcd==rxcd) & (txab!=txcd):
			log("Configuring the device in 2T2R TDD mode.")
			critical("This mode is not supported. Aborting ..")
			configSupported = 0
		elif (txab!=rxab) & (txcd!=rxcd):
			log("Configuring the device in 2T2R FDD mode.")
			self.libInstance.systemParams.pllMuxModes = 3
			self.libInstance.systemParams.systemMode = [1,1]
		elif (txab==rxab) & (txcd!=rxcd):
			log("Configuring 2T2R AB in TDD mode and 2T2R CD in FDD mode.")
			critical("This mode is not supported. Aborting ..")
			configSupported = 0
		elif (txab!=rxab) & (txcd==rxcd):
			log("Configuring 2T2R AB in FDD mode and 2T2R CD in TDD mode.")
			self.libInstance.systemParams.pllMuxModes = 4
			self.libInstance.systemParams.systemMode = [1,2]	
		if configSupported == 1:
			if self.libInstance.systemParams.pllMuxModes != 2:
				self.libInstance.systemParams.pllLo[0] = txab
				self.libInstance.systemParams.pllLo[2] = txcd
				self.libInstance.systemParams.pllLo[3] = rxab
				self.libInstance.systemParams.pllLo[4] = rxcd
			else:
				self.libInstance.systemParams.pllLo[0] = txab
				self.libInstance.systemParams.pllLo[2] = rxab
			if immediate == 1:
				pll_readback = [0, self.libInstance.systemParams.Fs, 0, 0, 0]
				self.libInstance.TOP.requestPllSpiAccess(1)
				self.libInstance.configPllMux()
				for i in [0,2,3,4]:
					self.libInstance.TOP.PLL[i].configurePll()
					freqPll = self.readBackPll(i)
					pll_readback[i] = freqPll
				self.libInstance.TOP.requestPllSpiAccess(0)
				if self.libInstance.systemParams.pllMuxModes == 0:
					self._controller.setTxAbLo(pll_readback[0])
					self._controller.setTxCdLo(pll_readback[0])
					self._controller.setRxAbLo(pll_readback[0])
					self._controller.setRxCdLo(pll_readback[0])
				elif self.libInstance.systemParams.pllMuxModes == 2:
					self._controller.setTxAbLo(pll_readback[0])
					self._controller.setTxCdLo(pll_readback[0])
					self._controller.setRxAbLo(pll_readback[2])
					self._controller.setRxCdLo(pll_readback[2])
				elif self.libInstance.systemParams.pllMuxModes == 3:
					self._controller.setTxAbLo(pll_readback[0])
					self._controller.setTxCdLo(pll_readback[2])
					self._controller.setRxAbLo(pll_readback[3])
					self._controller.setRxCdLo(pll_readback[4])
				elif self.libInstance.systemParams.pllMuxModes == 4:
					self._controller.setTxAbLo(pll_readback[0])
					self._controller.setTxCdLo(pll_readback[2])
					self._controller.setRxAbLo(pll_readback[3])
					self._controller.setRxCdLo(pll_readback[2])
				
				self._txAbLo.getValue()
				self._txCdLo.getValue()
				self._rxAbLo.getValue()
				self._rxCdLo.getValue()
				log("PLL configuration done.")
				self.configurePllDone = 1
			else:
				log("PLL configuration done.")
				self.configurePllDone = 1
		else:
			error("PLL config failed")
			self.configurePllDone = 0
			
		
	def configureDigital(self):
		iqRateRx0 = self._iqRateRx0.getValue()
		iqRateRx1 = self._iqRateRx1.getValue()
		iqRateTx0 = self._iqRateTx0.getValue()
		iqRateTx1 = self._iqRateTx1.getValue()
		iqRateFb0 = self._iqRateFb0.getValue()
		iqRateFb1 = self._iqRateFb1.getValue()
		fbAbNCO = self._fbAbNco.getValue()
		fbCdNCO = self._fbCdNco.getValue()
		self.libInstance.systemParams.ddcFactorRx[0] = self.libInstance.systemParams.Fs/self.iqRateRxChoicesList[iqRateRx0]
		self.libInstance.systemParams.ddcFactorRx[1] = self.libInstance.systemParams.Fs/self.iqRateRxChoicesList[iqRateRx1]
		self.libInstance.systemParams.ddcFactorFb[0] = self.libInstance.systemParams.Fs/self.iqRateFbChoicesList[iqRateFb0]
		self.libInstance.systemParams.ddcFactorFb[1] = self.libInstance.systemParams.Fs/self.iqRateFbChoicesList[iqRateFb1]
		self.libInstance.systemParams.ducFactorTx[0] = self.libInstance.systemParams.Fs/self.iqRateTxChoicesList[iqRateTx0]
		self.libInstance.systemParams.ducFactorTx[1] = self.libInstance.systemParams.Fs/self.iqRateTxChoicesList[iqRateTx1]
		self.libInstance.systemParams.fbNco[0] = fbAbNCO
		self.libInstance.systemParams.fbNco[1] = fbCdNCO


	def configureJESD(self, immediate=0):

		lmfsrx0 = self._lmfsrx0.getValue()
		lmfsrx1 = self._lmfsrx1.getValue()
		lmfstx0 = self._lmfstx0.getValue()
		lmfstx1 = self._lmfstx1.getValue()
		lmfsfb0 = self._lmfsfb0.getValue()
		lmfsfb1 = self._lmfsfb1.getValue()
		k0 = self._krx0.getValue()
		k1 = self._krx1.getValue()
		jesdProtocol = self._jesdAbProtocol.getValue()
		jesdAbDedicated = 1 if self._jesdAbDedicatedLaneMode.getValue() == True else 0
		jesdCdDedicated = 1 if self._jesdCdDedicatedLaneMode.getValue() == True else 0
		stx1 = self._laneMuxJesdAbTx1.getValue()
		stx2 = self._laneMuxJesdAbTx2.getValue()
		stx3 = self._laneMuxJesdAbTx3.getValue()
		stx4 = self._laneMuxJesdAbTx4.getValue()
		stx5 = self._laneMuxJesdCdTx1.getValue()
		stx6 = self._laneMuxJesdCdTx2.getValue()
		stx7 = self._laneMuxJesdCdTx3.getValue()
		stx8 = self._laneMuxJesdCdTx4.getValue()
		srx1 = self._laneMuxJesdAbRx1.getValue()
		srx2 = self._laneMuxJesdAbRx2.getValue()
		srx3 = self._laneMuxJesdAbRx3.getValue()
		srx4 = self._laneMuxJesdAbRx4.getValue()
		srx5 = self._laneMuxJesdCdRx1.getValue()
		srx6 = self._laneMuxJesdCdRx2.getValue()
		srx7 = self._laneMuxJesdCdRx3.getValue()
		srx8 = self._laneMuxJesdCdRx4.getValue()
		self.libInstance.systemParams.LMFSHdRx = [self.LMFSRxChoicesList[lmfsrx0], self.LMFSRxChoicesList[lmfsrx1]]
		self.libInstance.systemParams.LMFSHdTx = [self.LMFSTxChoicesList[lmfstx0], self.LMFSTxChoicesList[lmfstx1]]
		self.libInstance.systemParams.LMFSHdFb = [self.LMFSFbChoicesList[lmfsfb0], self.LMFSFbChoicesList[lmfsfb1]]
		self.libInstance.systemParams.dedicatedLaneMode = [jesdAbDedicated, jesdCdDedicated]
		self.libInstance.systemParams.jesdK = [k0,k1]
		if jesdProtocol == 0:
			self.libInstance.systemParams.jesdProtocol = 0
		elif jesdProtocol == 1:
			self.libInstance.systemParams.jesdProtocol = 2
		self.libInstance.systemParams.jesdTxLaneMux = [stx1, stx2, stx3, stx4, stx5, stx6, stx7, stx8]
		self.libInstance.systemParams.jesdRxLaneMux = [srx1, srx2, srx3, srx4, srx5, srx6, srx7, srx8]
		if immediate == 1:
			self.libInstance.JESD.SUBCHIP.configJesdRxLaneMux(self.libInstance.systemParams.jesdRxLaneMux)
			self.libInstance.JESD.SUBCHIP.configJesdTxLaneMux(self.libInstance.systemParams.jesdTxLaneMux)
			log("JESD Configuration done.")
			return 1


	def sysParamsDefault(self):
		self.libInstance.systemParams.FRef = 491.52
		self.libInstance.systemParams.Fs = 2949.12
		self.libInstance.systemParams.halfRateMode = 0
		self.libInstance.systemParams.pllMuxModes = 0
		self.libInstance.systemParams.useSpiSysref = False
		self.libInstance.systemParams.pllLo = [3500.0,2949.12,3500.01,1800.24,3400.0]
		self.libInstance.systemParams.jesdLoopbackEn = 0
		self.libInstance.systemParams.LMFSHdRx = ["24410","24410"]
		self.libInstance.systemParams.LMFSHdFb = ["22420","22420"]
		self.libInstance.systemParams.LMFSHdTx = ["44210","44210"]
		self.libInstance.systemParams.systemMode = [1,1]
		self.libInstance.systemParams.dedicatedLaneMode = [0,0]
		self.libInstance.systemParams.jesdProtocol = 0
		self.libInstance.systemParams.serdesFirmware = True
		self.libInstance.systemParams.jesdTxLaneMux = [0,1,2,3,4,5,6,7]
		self.libInstance.systemParams.jesdRxLaneMux = [0,1,2,3,4,5,6,7]
		self.libInstance.systemParams.jesdRxRbd = [15,15]
		self.libInstance.systemParams.jesdScr = [False, False]
		self.libInstance.systemParams.jesdK = [16,16]
		self.libInstance.systemParams.ddcFactorRx = [12,12]
		self.libInstance.systemParams.ddcFactorFb = [6,6]
		self.libInstance.systemParams.fbNco = [3500,3500]
		self.libInstance.systemParams.ducFactorTx = [6,6]
		self.libInstance.systemParams.setTxLoFbNcoFreqForTxCalib = True
		self.libInstance.systemParams.customerConfig = False
		self.libInstance.systemParams.lowIfNcoRx = [0,0]
		self.libInstance.systemParams.lowIfNcoTx = [0,0]
		self.libInstance.systemParams.lowIfNcoFb = [0,0]
		self.libInstance.systemParams.bitFileType = 0
		#self.libInstance.systemParams.sysrefFreqDiv = int(round(2949.12/(7.68)))
		self.libInstance.systemParams.agcRegConfigParams[0]['enableIa'] = 0
		self.libInstance.systemParams.agcRegConfigParams[1]['enableIa'] = 0
		self.libInstance.systemParams.agcRegConfigParams[2]['enableIa'] = 0
		self.libInstance.systemParams.agcRegConfigParams[3]['enableIa'] = 0
		self.libInstance.systemParams.jesdABLvdsSync = True
		self.libInstance.systemParams.jesdCDLvdsSync = True
		self.libInstance.systemParams.jesdTxFBABSyncMux = 2
		self.libInstance.systemParams.jesdTxFBCDSyncMux = 2
		self.libInstance.systemParams.txIqMcCalibMode = 0
		self.libInstance.systemParams.enableTxIqmcLolTrackingCorr = False
		self.libInstance.systemParams.enableRxIqmcLolTrackingCorr = True
		self.libInstance.systemParams.rxDsaCalibMode = 0
		self.libInstance.systemParams.enableTxDsaFactoryCal = False
		self.libInstance.systemParams.enableRxDsaFactoryCal = False
		self.libInstance.systemParams.enableTxIqmcLolPowerUpCorr = False
		self.libInstance.systemParams.enableRxIqmcLolPowerUpCorr = False



	def deviceBringUp(self):
		try:
			from workspace import hwResetHandle, setupParams
			hwResetHandle.toggle()
		except:
			pass
		self.libInstance.systemParams.FRef = float(self._frefExt.getValue())
		self.lmkConfig(0)
		self.configurePll(0)
		if self.configurePllDone:
			pass
		else:
			return
		self.configureDigital()
		self.configureJESD(0)
		polTx1 = self._polarityAbT1.getValue()
		polTx2 = self._polarityAbT2.getValue()
		polTx3 = self._polarityAbT3.getValue()
		polTx4 = self._polarityAbT4.getValue()
		polTx5 = self._polarityCdT1.getValue()
		polTx6 = self._polarityCdT2.getValue()
		polTx7 = self._polarityCdT3.getValue()
		polTx8 = self._polarityCdT4.getValue()
		polTx = [polTx1, polTx2, polTx3, polTx4, polTx5, polTx6, polTx7, polTx8]
		for idx,item in enumerate(polTx):
			self.libInstance.systemParams.serdesTxLanePolarity[idx]=item
		polRx1 = self._polarityAbR1.getValue()
		polRx2 = self._polarityAbR2.getValue()
		polRx3 = self._polarityAbR3.getValue()
		polRx4 = self._polarityAbR4.getValue()
		polRx5 = self._polarityCdR1.getValue()
		polRx6 = self._polarityCdR2.getValue()
		polRx7 = self._polarityCdR3.getValue()
		polRx8 = self._polarityCdR4.getValue()
		polRx = [polRx1, polRx2, polRx3, polRx4, polRx5, polRx6, polRx7, polRx8]
		for idx,item in enumerate(polRx):
			self.libInstance.systemParams.serdesRxLanePolarity[idx]=item
		self.libInstance.deviceBringup()
		self.libInstance.TOP.disableOverrideTdd()


	
	def generateConfig(self):
		from workspace import afe77xxiGui
		# sysParamsIdx = afe77xxiGui.mainWindow.stackWidget.currentIndex()
		afe77xxiGui.mainWindow.changeTab(3)


	def lmkConfig(self, immediate=0):
		from workspace import LMKParams
		LMKParams.pllEn = self._pllEnLmk.getValue()
		LMKParams.inputClk = self._lmkInputClk.getValue()
		LMKParams.sysrefFreq = self._sysRef.getValue()
		if immediate == 1:
			self.libInstance.LMK.lmkConfig()

	def ncoConfig(self):
		fbAbNCO = self._fbAbNco.getValue()
		fbCdNCO = self._fbCdNco.getValue()
		self.libInstance.systemParams.fbNco[0] = fbAbNCO
		self.libInstance.systemParams.fbNco[1] = fbCdNCO
		self.libInstance.setFbNcoWord(0,fbAbNCO)
		self.libInstance.setFbNcoWord(1,fbCdNCO)
		log("NCO configuration done.")


	

	def applyFunc(self):
		"""  """
		if self.functionChoicesChoicesList[self._controller.getFunctionChoices()] =='Configure PLL':
			self.configurePll(1)
		elif self.functionChoicesChoicesList[self._controller.getFunctionChoices()] =='Device Bringup':
			self.deviceBringUp()
			if False in self.libInstance.systemStatus.validConfig:
				error("#================ Invalid Configuration - Device Bringup Aborted ================#")
			else:
				log("#================ Device Bringup Done ================#")
		elif self.functionChoicesChoicesList[self._controller.getFunctionChoices()] =='Generate Configuration':
			self.generateConfig()
		elif self.functionChoicesChoicesList[self._controller.getFunctionChoices()] =='Configure NCOs':
			self.ncoConfig()
		elif self.functionChoicesChoicesList[self._controller.getFunctionChoices()] =="Save GUI State":
			self.saveAndLoadGuiState('save')
		elif self.functionChoicesChoicesList[self._controller.getFunctionChoices()] =="Load GUI State":
			self.saveAndLoadGuiState('load')
		return

	def updateAllIndicatorsFunc(self):
		pass

	def updateAllObjectsFunc(self):
		self._lmfsrx0.getValue()
		self._lmfsrx1.getValue()
		self._lmfsfb0.getValue()
		self._lmfsfb1.getValue()
		self._lmfstx0.getValue()
		self._lmfstx1.getValue()
		self._krx0.getValue()
		self._krx1.getValue()
		self._kfb0.getValue()
		self._kfb1.getValue()
		self._ktx0.getValue()
		self._ktx1.getValue()
		self._jesdAbTx1.getValue()
		self._jesdAbTx2.getValue()
		self._jesdAbTx3.getValue()
		self._jesdAbTx4.getValue()
		self._jesdCdTx1.getValue()
		self._jesdCdTx2.getValue()
		self._jesdCdTx3.getValue()
		self._jesdCdTx4.getValue()
		self._jesdAbRx1.getValue()
		self._jesdAbRx2.getValue()
		self._jesdAbRx3.getValue()
		self._jesdAbRx4.getValue()
		self._jesdCdRx1.getValue()
		self._jesdCdRx2.getValue()
		self._jesdCdRx3.getValue()
		self._jesdCdRx4.getValue()
		self._laneMuxJesdAbTx1.getValue()
		self._laneMuxJesdAbTx2.getValue()
		self._laneMuxJesdAbTx3.getValue()
		self._laneMuxJesdAbTx4.getValue()
		self._laneMuxJesdCdTx1.getValue()
		self._laneMuxJesdCdTx2.getValue()
		self._laneMuxJesdCdTx3.getValue()
		self._laneMuxJesdCdTx4.getValue()
		self._laneMuxJesdAbRx1.getValue()
		self._laneMuxJesdAbRx2.getValue()
		self._laneMuxJesdAbRx3.getValue()
		self._laneMuxJesdAbRx4.getValue()
		self._laneMuxJesdCdRx1.getValue()
		self._laneMuxJesdCdRx2.getValue()
		self._laneMuxJesdCdRx3.getValue()
		self._laneMuxJesdCdRx4.getValue()
		self._pllLo0.getValue()
		self._pllLo1.getValue()
		self._pllLo2.getValue()
		self._pllLo3.getValue()
		self._pllLo4.getValue()
		self._iqRateRx0.getValue()
		self._iqRateRx1.getValue()
		self._iqRateFb0.getValue()
		self._iqRateFb1.getValue()
		self._iqRateTx0.getValue()
		self._iqRateTx1.getValue()
		self._txAbLo.getValue()
		self._rxAbLo.getValue()
		self._txCdLo.getValue()
		self._rxCdLo.getValue()
		self._fbCdNco.getValue()
		self._fbAbNco.getValue()
		self._rxAbNco.getValue()
		self._rxCdNco.getValue()
		self._txAbNco.getValue()
		self._txCdNco.getValue()
		self._dataConverterPll.getValue()
		self._functionChoices.getValue()
		self._jesdAbProtocol.getValue()
		self._jesdCdProtocol.getValue()
		self._jesdAbDedicatedLaneMode.getValue()
		self._jesdCdDedicatedLaneMode.getValue()
		self._txAbEnable.getValue()
		self._rxAbEnable.getValue()
		self._fbAbEnable.getValue()
		self._txCdEnable.getValue()
		self._rxCdEnable.getValue()
		self._fbCdEnable.getValue()
		self._lowIfNcoRx0.getValue()
		self._lowIfNcoRx1.getValue()
		self._lowIfNcoTx0.getValue()
		self._lowIfNcoTx1.getValue()
		self._lowIfNcoFb0.getValue()
		self._lowIfNcoFb1.getValue()
		self._polarityAbT1.getValue()
		self._polarityAbT2.getValue()
		self._polarityAbT3.getValue()
		self._polarityAbT4.getValue()
		self._polarityAbR1.getValue()
		self._polarityAbR2.getValue()
		self._polarityAbR3.getValue()
		self._polarityAbR4.getValue()
		self._polarityCdT1.getValue()
		self._polarityCdT2.getValue()
		self._polarityCdT3.getValue()
		self._polarityCdT4.getValue()
		self._polarityCdR1.getValue()
		self._polarityCdR2.getValue()
		self._polarityCdR3.getValue()
		self._polarityCdR4.getValue()