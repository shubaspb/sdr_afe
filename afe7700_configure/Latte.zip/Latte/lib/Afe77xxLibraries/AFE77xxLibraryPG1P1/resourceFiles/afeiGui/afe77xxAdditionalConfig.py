import globalDefs as Globals
from mInstrument import *
import iGui

class afe77xxAdditionalConfigController:
    def __init__(self,parent,*args,**kwargs):
        self.parent = parent
        self.libInstance=kwargs['libInstance']
        self.cache=kwargs['cache']
        self.systemParams=kwargs['libInstance'].systemParams
        self.__enableRxDsaFactoryCal = parent.enableRxDsaFactoryCal
        self.__enableTxDsaFactoryCal = parent.enableTxDsaFactoryCal
        self.__enableTxIqmcLolTrackingCorr = parent.enableTxIqmcLolTrackingCorr
        self.__enableRxIqmcLolTrackingCorr = parent.enableRxIqmcLolTrackingCorr
        self.__rxDsaCalibMode = parent.rxDsaCalibMode
        self.__txDsaCalibMode = parent.txDsaCalibMode
        self.__txIqMcCalibMode = parent.txIqMcCalibMode
        self.__internalAgcRxA = parent.internalAgcRxA
        self.__internalAgcRxB = parent.internalAgcRxB
        self.__internalAgcRxC = parent.internalAgcRxC
        self.__internalAgcRxD = parent.internalAgcRxD
        self.__txIqmcConnection = parent.txIqmcConnection
        self.__gpioModes = parent.gpioModes

    def setEnableRxDsaFactoryCal(self,val):
        self.__enableRxDsaFactoryCal = val
        self.libInstance.systemParams.enableRxDsaFactoryCal = val

    def getEnableRxDsaFactoryCal(self):
        self.__enableRxDsaFactoryCal = self.libInstance.systemParams.enableRxDsaFactoryCal
        return self.__enableRxDsaFactoryCal

    def setEnableTxDsaFactoryCal(self,val):
        self.__enableTxDsaFactoryCal = val
        self.libInstance.systemParams.enableTxDsaFactoryCal = val

    def getEnableTxDsaFactoryCal(self):
        self.__enableTxDsaFactoryCal = self.libInstance.systemParams.enableTxDsaFactoryCal
        return self.__enableTxDsaFactoryCal

    def setEnableTxIqmcLolTrackingCorr(self,val):
        self.__enableTxIqmcLolTrackingCorr = val
        self.libInstance.systemParams.enableTxIqmcLolTrackingCorr = val

    def getEnableTxIqmcLolTrackingCorr(self):
        self.__enableTxIqmcLolTrackingCorr = self.libInstance.systemParams.enableTxIqmcLolTrackingCorr
        return self.__enableTxIqmcLolTrackingCorr

    def setEnableRxIqmcLolTrackingCorr(self,val):
        self.__enableRxIqmcLolTrackingCorr = val
        self.libInstance.systemParams.enableRxIqmcLolTrackingCorr = val

    def getEnableRxIqmcLolTrackingCorr(self):
        self.__enableRxIqmcLolTrackingCorr = self.libInstance.systemParams.enableRxIqmcLolTrackingCorr
        return self.__enableRxIqmcLolTrackingCorr

    def setRxDsaCalibMode(self,val):
        self.__rxDsaCalibMode = val
        self.libInstance.systemParams.rxDsaCalibMode = val

    def getRxDsaCalibMode(self):
        self.__rxDsaCalibMode = self.libInstance.systemParams.rxDsaCalibMode
        return self.__rxDsaCalibMode

    def setTxDsaCalibMode(self,val):
        self.__txDsaCalibMode = val
        self.libInstance.systemParams.txDsaCalibMode = val

    def getTxDsaCalibMode(self):
        self.__txDsaCalibMode = self.libInstance.systemParams.txDsaCalibMode
        return self.__txDsaCalibMode

    def setTxIqMcCalibMode(self,val):
        self.__txIqMcCalibMode = val
        self.libInstance.systemParams.txIqMcCalibMode = val

    def getTxIqMcCalibMode(self):
        self.__txIqMcCalibMode = self.libInstance.systemParams.txIqMcCalibMode
        return self.__txIqMcCalibMode

    def setInternalAgcRxA(self,val):
        self.__internalAgcRxA = val
        self.libInstance.systemParams.agcRegConfigParams[0]['enableIa'] = val
        self.cache.internalAgcRxA = val

    def getInternalAgcRxA(self):
        self.__internalAgcRxA = self.libInstance.systemParams.agcRegConfigParams[0]['enableIa']
        return self.__internalAgcRxA

    def setInternalAgcRxB(self,val):
        self.__internalAgcRxB = val
        self.libInstance.systemParams.agcRegConfigParams[1]['enableIa'] = val
        self.cache.internalAgcRxB = val

    def getInternalAgcRxB(self):
        self.__internalAgcRxB = self.libInstance.systemParams.agcRegConfigParams[1]['enableIa']
        return self.__internalAgcRxB

    def setInternalAgcRxC(self,val):
        self.__internalAgcRxC = val
        self.libInstance.systemParams.agcRegConfigParams[2]['enableIa'] = val
        self.cache.internalAgcRxC = val

    def getInternalAgcRxC(self):
        self.__internalAgcRxC = self.libInstance.systemParams.agcRegConfigParams[2]['enableIa']
        return self.__internalAgcRxC

    def setInternalAgcRxD(self,val):
        self.__internalAgcRxD = val
        self.libInstance.systemParams.agcRegConfigParams[3]['enableIa'] = val
        self.cache.internalAgcRxD = val

    def getInternalAgcRxD(self):
        self.__internalAgcRxD = self.libInstance.systemParams.agcRegConfigParams[3]['enableIa']
        return self.__internalAgcRxD

    def setTxIqmcConnection(self,val):
        self.__txIqmcConnection = val
        self.cache.txIqmcConnection = self.parent.txIqmcConnectionChoicesList[val]

    def getTxIqmcConnection(self):
        self.__txIqmcConnection = self.parent.txIqmcConnectionChoicesList.index(self.cache.txIqmcConnection)
        return self.__txIqmcConnection

    def setGpioModes(self,val):
        self.__gpioModes = val
        self.cache.gpioModes = val

    def getGpioModes(self):
        self.__gpioModes = self.cache.gpioModes
        return self.__gpioModes

class afe77xxAdditionalConfig(Interface):
    controller =afe77xxAdditionalConfigController
    redBulb = Globals.ASTERIX_DIR+r"iGuiImages/redBulb.png"
    greenBulb = Globals.ASTERIX_DIR+r"iGuiImages/greenBulb.png"
    enableRxDsaFactoryCal 	= Object(typ=Boolean,label='enableRxDsaFactoryCal',default=0)
    enableTxDsaFactoryCal 	= Object(typ=Boolean,label='enableTxDsaFactoryCal',default=0)
    enableTxIqmcLolTrackingCorr 	= Object(typ=Boolean,label='enableTxIqmcLolTrackingCorr',default=0)
    enableRxIqmcLolTrackingCorr 	= Object(typ=Boolean,label='enableRxIqmcLolTrackingCorr',default=0)
    rxDsaCalibMode 	= Object(typ=Choice,choices={0:'One channel at a time',1:' A&C at once and B&D at once',2:'All 4 channels at once'},label='rxDsaCalibMode',default=0,widgetParams={"setDisabled":True})
    txDsaCalibMode 	= Object(typ=Choice,choices={0:'Single Fb Mode FB AB ',1:'Single Fb Mode FB CD ',2:'Dual Fb_Mode'},label='txDsaCalibMode',default=0,widgetParams={"setDisabled":True})
    txIqMcCalibMode 	= Object(typ=Choice,choices={0:'Single Fb Mode FB AB ',1:'Single Fb Mode FB CD ',2:'Dual Fb_Mode '},label='txIqMcCalibMode',default=0,widgetParams={"setDisabled":True})
    internalAgcRxA 	= Object(typ=Choice,choices={0:'Disabled',1:'Enabled'},label='internalAgcRxA',default=0)
    internalAgcRxB 	= Object(typ=Choice,choices={0:'Disabled',1:'Enabled'},label='internalAgcRxB',default=0)
    internalAgcRxC 	= Object(typ=Choice,choices={0:'Disabled',1:'Enabled'},label='internalAgcRxC',default=0)
    internalAgcRxD 	= Object(typ=Choice,choices={0:'Disabled',1:'Enabled'},label='internalAgcRxD',default=0)
    txIqmcConnection 	= Object(typ=Choice,choices={0:'TX A to FB AB',1:'TX B to FB AB',2:'TX C to FB AB',3:'TX D to FB AB'},label='txIqmcConnection',default=0,widgetParams={"setDisabled":True})
    gpioModes 	= Object(typ=Choice,choices={0:'Manual Selection',1:'Internal AGC Mode',2:'External AGC Mode'},label='gpioModes',default=0)
    back = Object(typ=Trigger,label='Back',function='backFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
    proceed = Object(typ=Trigger,label='Proceed',function='proceedFunc')
    additionalConfig = Object(typ=Trigger,label='Advanced Config',function='additionalConfigFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
    readStatus = Object(typ=Trigger,label="Read Status",function="readStatusFunc",widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
    functionChoices 	= Object(typ=Choice,choices={0:'Device Bringup',1:'Configure PLL',2:'Configure NCOs',3:'Generate Configuration',4:'Save GUI State',5:'Load GUI State'},label='functionChoices',default='Device Bringup')
    apply 	= Object(typ=Trigger,label='Apply',function='applyFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
    home = Object(typ=Trigger,label='Home',function='homeFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
    gpioo = Object(typ=Trigger,label='GPIO',function='gpioFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"})	
    dev0 = Object(typ=Trigger,label='Device',function='dev0Func',widgetParams={"styleSheet":"QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"})	#{"styleSheet":"QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);} QPushButton::hover {background-color:black; color:white; border-color:#ffffff;}"})
    fpgaConnectedStatus1 = Object(typ=Boolean,label='polarityCdR4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulb,redBulb)})
    fpgaConnectedStatus2 = Object(typ=String,label="FpgaStatus",default="FPGA is not connected")
    
    myfpgaReconnect = Object(typ=Trigger,label='Reconnect FPGA',function='myfpgaReconnectFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})

    def myfpgaReconnectFunc(self):
        self.guiControllerInstance.sysParamClassInst.myfpgaReconnectFunc()
    
    def applyFunc(self):
        """  """
        if self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Configure PLL':
            self.guiControllerInstance.sysParamClassInst.configurePll(1)
        elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Device Bringup':
            self.guiControllerInstance.sysParamClassInst.deviceBringUp()
            if False in self.guiControllerInstance.sysParamClassInst.libInstance.systemStatus.validConfig:
                error("#================ Invalid Configuration - Device Bringup Aborted ================#")
            else:
                log("#================ Device Bringup Done ================#")
        elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Generate Configuration':
            self.guiControllerInstance.sysParamClassInst.generateConfig()
        elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Configure NCOs':
            self.guiControllerInstance.sysParamClassInst.ncoConfig()
        elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =="Save GUI State":
            self.guiControllerInstance.sysParamClassInst.saveAndLoadGuiState('save')
        elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =="Load GUI State":
            self.guiControllerInstance.sysParamClassInst.saveAndLoadGuiState('load')
        return
    
    def additionalConfigFunc(self):
        pass
    
    def readStatusFunc(self):
        self.guiControllerInstance.guiInstance.mainWindow.changeTab(4)
        
    def dev0Func(self):
        white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
        black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
        self.guiControllerInstance.guiInstance.mainWindow.changeTab(2)
        self._dev0.gui.widgets[1].button.setStyleSheet(white)
        self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(white)
        self._gpioo.gui.widgets[1].button.setStyleSheet(black)
        self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet(black)
        
        
    def gpioFunc(self):
        white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
        black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
        self.guiControllerInstance.guiInstance.mainWindow.changeTab(8)
        self._gpioo.gui.widgets[1].button.setStyleSheet(white)
        self._dev0.gui.widgets[1].button.setStyleSheet (black)
        self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet (white)
        self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(black)
    
    def homeFunc(self):
        self.backFunc()
    
    
    def backFunc(self):
        from workspace import afe77xxiGui
        addConfigPageIdx = afe77xxiGui.mainWindow.stackWidget.currentIndex()
        afe77xxiGui.mainWindow.changeTab(addConfigPageIdx-3)
    
    def proceedFunc(self):
        pass
        


    ############ Below are the choices List.
    rxDsaCalibModeChoicesList = ['One channel at a time',' A&C at once and B&D at once', 'All 4 channels at once']
    txDsaCalibModeChoicesList = ['Single Fb Mode FB AB ','Single Fb Mode FB CD ', 'Dual Fb_Mode']
    txIqMcCalibModeChoicesList = ['Single Fb Mode FB AB','Single Fb Mode FB CD' ,'Dual Fb_Mode']
    internalAgcRxAChoicesList = ["Disabled","Enabled"]
    internalAgcRxBChoicesList = ["Disabled","Enabled"]
    internalAgcRxCChoicesList = ["Disabled","Enabled"]
    internalAgcRxDChoicesList = ["Disabled","Enabled"]
    txIqmcConnectionChoicesList = ['TX A to FB AB','TX B to FB AB','TX C to FB AB','TX D to FB AB']
    txIqmcConnectionChoicesListFbAb = ['TX A to FB AB','TX B to FB AB','TX C to FB AB','TX D to FB AB']
    txIqmcConnectionChoicesListFbCd = ['TX A to FB CD','TX B to FB CD','TX C to FB CD','TX D to FB CD']
    txIqmcConnectionChoicesListFbDual = ['TX A to FB AB','TX B to FB AB','TX C to FB CD','TX D to FB CD']
    gpioModesChoiceList = ['Manual Selection','Internal AGC Mode','External AGC Mode']
    functionChoicesChoicesList = ['Device Bringup','Configure PLL','Configure NCOs','Generate Configuration','Save GUI State','Load GUI State']
    
    ###---All widgets---###
    guiWidgetsList = ['back', 'enableRxDsaFactoryCal', 'enableRxIqmcLolTrackingCorr', 'enableTxDsaFactoryCal', 'enableTxIqmcLolTrackingCorr', 'gpioModes', 'internalAgcRxA', 'internalAgcRxB', 'internalAgcRxC', 'internalAgcRxD', 'proceed', 'rxDsaCalibMode', 'txDsaCalibMode', 'txIqMcCalibMode', 'txIqmcConnection']

    def __init__(self,libInstance,cache,guiControllerInstance):
        super(afe77xxAdditionalConfig,self).__init__(libInstance=libInstance,cache=cache,guiControllerInstance=guiControllerInstance)
        self.libInstance=libInstance
        self.cache=cache
        self.guiControllerInstance=guiControllerInstance
        self.gui.hide()
        
        self._enableTxIqmcLolTrackingCorr.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.calibModeEnable('txIqMcCalibMode',self._enableTxIqmcLolTrackingCorr.getValue()))
        self._txIqMcCalibMode.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.txIqmcModeChange(self.txIqMcCalibModeChoicesList[self._txIqMcCalibMode.getValue()]))
        self._gpioModes.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.gpioModeChange(self.gpioModesChoiceList[self._gpioModes.getValue()]))
        self._txIqmcConnection.gui.widgets[0].combo.currentIndexChanged.connect(lambda: self.gpioModeChange(self.gpioModesChoiceList[self._gpioModes.getValue()]))
        self._enableRxDsaFactoryCal.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.calibModeEnable('rxDsaCalibMode',self._enableRxDsaFactoryCal.getValue()))
        self._enableTxDsaFactoryCal.gui.widgets[0].checkBox.stateChanged.connect(lambda: self.calibModeEnable('txDsaCalibMode',self._enableTxDsaFactoryCal.getValue()))
        self.defaultConfiguration()
    
    def defaultConfiguration(self):
        self._internalAgcRxA.setValue(1)
        self._internalAgcRxB.setValue(1)
        self._internalAgcRxC.setValue(1)
        self._internalAgcRxD.setValue(1)
        self._enableRxIqmcLolTrackingCorr.setValue(1)
        
    
    def gpioModeChange(self,mode):
        from workspace import gpioStatusiGuiClass
        from mAfeConstants import gpioConstants
        mode = self.gpioModesChoiceList[self._gpioModes.getValue()]
        if mode =='Internal AGC Mode':
            self.libInstance.systemParams.gpioConfigMode=0
            self.libInstance.systemParams.gpioMapping=gpioConstants.gpioInternalAgcMode.copy()
        elif mode =='External AGC Mode':
            self.libInstance.systemParams.gpioConfigMode=1
            self.libInstance.systemParams.gpioMapping=gpioConstants.gpioExternalAgcMode.copy()
        else:
            self.libInstance.systemParams.gpioConfigMode=3
            
        gpioStatusiGuiClass.updateAllIndicatorsFunc()
    
    def txIqmcModeChange(self,mode):
        if mode == 'Single Fb Mode FB AB':
            tempDict={}	
            self._txIqmcConnection.gui.widgets[1].combo.clear()
            self._txIqmcConnection.gui.widgets[1].combo.addItems(self.txIqmcConnectionChoicesListFbAb)
            self._txIqmcConnection.gui.widgets[1].combo.update()
            for idx,val in enumerate(self.txIqmcConnectionChoicesListFbAb):
                tempDict[idx] = val
            self._txIqmcConnection.gui.widgets[1].choices = tempDict
        elif mode == 'Single Fb Mode FB CD':
            tempDict={}	
            self._txIqmcConnection.gui.widgets[1].combo.clear()
            self._txIqmcConnection.gui.widgets[1].combo.addItems(self.txIqmcConnectionChoicesListFbCd)
            self._txIqmcConnection.gui.widgets[1].combo.update()
            for idx,val in enumerate(self.txIqmcConnectionChoicesListFbCd):
                tempDict[idx] = val
            self._txIqmcConnection.gui.widgets[1].choices = tempDict
        elif mode == 'Dual Fb_Mode':
            tempDict={}	
            self._txIqmcConnection.gui.widgets[1].combo.clear()
            self._txIqmcConnection.gui.widgets[1].combo.addItems(self.txIqmcConnectionChoicesListFbDual)
            self._txIqmcConnection.gui.widgets[1].combo.update()
            for idx,val in enumerate(self.txIqmcConnectionChoicesListFbDual):
                tempDict[idx] = val
            self._txIqmcConnection.gui.widgets[1].choices = tempDict
                
    def calibModeEnable(self,calib,enabled):
        if calib == 'txIqMcCalibMode':
            if enabled:
                self._txIqMcCalibMode.gui.widgets[1].combo.setDisabled(0)
            else:
                self._txIqMcCalibMode.gui.widgets[1].combo.setDisabled(1)
        if calib == 'rxDsaCalibMode':
            if enabled:
                self._rxDsaCalibMode.gui.widgets[1].combo.setDisabled(0)
            else:
                self._rxDsaCalibMode.gui.widgets[1].combo.setDisabled(1)
        if calib == 'txDsaCalibMode':
            if enabled:
                self._txDsaCalibMode.gui.widgets[1].combo.setDisabled(0)
            else:
                self._txDsaCalibMode.gui.widgets[1].combo.setDisabled(1)

    def updateAllIndicatorsFunc(self):
        pass

    def updateAllObjectsFunc(self):
        self._enableRxDsaFactoryCal.getValue()
        self._enableTxDsaFactoryCal.getValue()
        self._enableTxIqmcLolTrackingCorr.getValue()
        self._enableRxIqmcLolTrackingCorr.getValue()
        self._rxDsaCalibMode.getValue()
        self._txDsaCalibMode.getValue()
        self._txIqMcCalibMode.getValue()
        self._internalAgcRxA.getValue()
        self._internalAgcRxB.getValue()
        self._internalAgcRxC.getValue()
        self._internalAgcRxD.getValue()
        self._txIqmcConnection.getValue()
        self._gpioModes.getValue()