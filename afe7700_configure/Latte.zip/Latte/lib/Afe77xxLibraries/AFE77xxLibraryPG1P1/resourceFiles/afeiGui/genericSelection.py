import globalDefs as Globals
from mInstrument import *
import iGui
from PySide import QtCore
class genericSelectionController:
	def __init__(self,parent,*args,**kwargs):
		self.libInstance=kwargs['libInstance']
		self.parent=parent
		self.systemParams=kwargs['libInstance'].systemParams
		self.__proceed = parent.proceed
		self.__back = parent.back
		self.__c0 = parent.c0
		self.__c1 = parent.c1
		self.__c2 = parent.c2
		self.__c3 = parent.c3
		self.__c4 = parent.c4
		self.__c5 = parent.c5
		self.__c6 = parent.c6
		self.__c7 = parent.c7
		self.__c8 = parent.c8
		self.__c9 = parent.c9
		self.__c10 = parent.c10
		self.__c11 = parent.c11
		self.__c12 = parent.c12
		self.__c13 = parent.c13
		self.__c14 = parent.c14
		self.__c15 = parent.c15
		self.__c16 = parent.c16
		self.__c17 = parent.c17
		self.__c18 = parent.c18
		self.__c19 = parent.c19
		self.__c20 = parent.c20
		self.__c21 = parent.c21
		self.__c22 = parent.c22
		self.__c23 = parent.c23
		self.__c24 = parent.c24
		self.__c25 = parent.c25
		self.__c26 = parent.c26
		self.__c27 = parent.c27
		self.__c28 = parent.c28
		self.__c29 = parent.c29
		self.__c30 = parent.c30
		self.__c31 = parent.c31
		self.__c32 = parent.c32
		self.__c33 = parent.c33
		self.__c34 = parent.c34
		self.__c35 = parent.c35
		self.__c36 = parent.c36
		self.__c37 = parent.c37
		self.__c38 = parent.c38
		self.__c39 = parent.c39
		self.__c40 = parent.c40
		self.__c41 = parent.c41
		self.__c42 = parent.c42
		self.__c43 = parent.c43
		self.__s0 = parent.s0
		self.__s1 = parent.s1
		self.__s2 = parent.s2
		self.__s3 = parent.s3
		self.__s4 = parent.s4
		self.__s5 = parent.s5
		self.__s6 = parent.s6
		self.__s7 = parent.s7
		self.__s8 = parent.s8
		self.__s9 = parent.s9
		self.__s10 = parent.s10
		self.__s11 = parent.s11
		self.__s12 = parent.s12
		self.__s13 = parent.s13
		self.__s14 = parent.s14
		self.__s15 = parent.s15
		self.__s16 = parent.s16
		self.__s17 = parent.s17
		self.__s18 = parent.s18
		self.__s19 = parent.s19
		self.__s20 = parent.s20
		self.__s21 = parent.s21
		self.__s22 = parent.s22
		self.__s23 = parent.s23
		self.__s24 = parent.s24
		self.__s25 = parent.s25
		self.__s26 = parent.s26
		self.__s27 = parent.s27
		self.__s28 = parent.s28
		self.__s29 = parent.s29
		self.__s30 = parent.s30
		self.__s31 = parent.s31
		self.__s32 = parent.s32
		self.__s33 = parent.s33
		self.__s34 = parent.s34
		self.__s35 = parent.s35
		self.__s36 = parent.s36
		self.__s37 = parent.s37
		self.__s38 = parent.s38
		self.__s39 = parent.s39
		self.__s40 = parent.s40
		self.__s41 = parent.s41
		self.__s42 = parent.s42
		self.__s43 = parent.s43

	def setC0(self,val):
		self.__c0 = val

	def getC0(self):
		return self.__c0

	def setC1(self,val):
		self.__c1 = val

	def getC1(self):
		return self.__c1

	def setC2(self,val):
		self.__c2 = val

	def getC2(self):
		return self.__c2

	def setC3(self,val):
		self.__c3 = val

	def getC3(self):
		return self.__c3

	def setC4(self,val):
		self.__c4 = val

	def getC4(self):
		return self.__c4

	def setC5(self,val):
		self.__c5 = val

	def getC5(self):
		return self.__c5

	def setC6(self,val):
		self.__c6 = val

	def getC6(self):
		return self.__c6

	def setC7(self,val):
		self.__c7 = val

	def getC7(self):
		return self.__c7

	def setC8(self,val):
		self.__c8 = val

	def getC8(self):
		return self.__c8

	def setC9(self,val):
		self.__c9 = val

	def getC9(self):
		return self.__c9

	def setC10(self,val):
		self.__c10 = val

	def getC10(self):
		return self.__c10

	def setC11(self,val):
		self.__c11 = val

	def getC11(self):
		return self.__c11

	def setC12(self,val):
		self.__c12 = val

	def getC12(self):
		return self.__c12

	def setC13(self,val):
		self.__c13 = val

	def getC13(self):
		return self.__c13

	def setC14(self,val):
		self.__c14 = val

	def getC14(self):
		return self.__c14

	def setC15(self,val):
		self.__c15 = val

	def getC15(self):
		return self.__c15

	def setC16(self,val):
		self.__c16 = val

	def getC16(self):
		return self.__c16

	def setC17(self,val):
		self.__c17 = val

	def getC17(self):
		return self.__c17

	def setC18(self,val):
		self.__c18 = val

	def getC18(self):
		return self.__c18

	def setC19(self,val):
		self.__c19 = val

	def getC19(self):
		return self.__c19

	def setC20(self,val):
		self.__c20 = val

	def getC20(self):
		return self.__c20

	def setC21(self,val):
		self.__c21 = val

	def getC21(self):
		return self.__c21

	def setC22(self,val):
		self.__c22 = val

	def getC22(self):
		return self.__c22

	def setC23(self,val):
		self.__c23 = val

	def getC23(self):
		return self.__c23

	def setC24(self,val):
		self.__c24 = val

	def getC24(self):
		return self.__c24

	def setC25(self,val):
		self.__c25 = val

	def getC25(self):
		return self.__c25

	def setC26(self,val):
		self.__c26 = val

	def getC26(self):
		return self.__c26

	def setC27(self,val):
		self.__c27 = val

	def getC27(self):
		return self.__c27

	def setC28(self,val):
		self.__c28 = val

	def getC28(self):
		return self.__c28

	def setC29(self,val):
		self.__c29 = val

	def getC29(self):
		return self.__c29

	def setC30(self,val):
		self.__c30 = val

	def getC30(self):
		return self.__c30

	def setC31(self,val):
		self.__c31 = val

	def getC31(self):
		return self.__c31

	def setC32(self,val):
		self.__c32 = val

	def getC32(self):
		return self.__c32

	def setC33(self,val):
		self.__c33 = val

	def getC33(self):
		return self.__c33

	def setC34(self,val):
		self.__c34 = val

	def getC34(self):
		return self.__c34

	def setC35(self,val):
		self.__c35 = val

	def getC35(self):
		return self.__c35

	def setC36(self,val):
		self.__c36 = val

	def getC36(self):
		return self.__c36

	def setC37(self,val):
		self.__c37 = val

	def getC37(self):
		return self.__c37

	def setC38(self,val):
		self.__c38 = val

	def getC38(self):
		return self.__c38

	def setC39(self,val):
		self.__c39 = val

	def getC39(self):
		return self.__c39

	def setC40(self,val):
		self.__c40 = val

	def getC40(self):
		return self.__c40

	def setC41(self,val):
		self.__c41 = val

	def getC41(self):
		return self.__c41

	def setC42(self,val):
		self.__c42 = val

	def getC42(self):
		return self.__c42

	def setC43(self,val):
		self.__c43 = val

	def getC43(self):
		return self.__c43


	def setS0(self,val):
		self.__s0 = val
	def getS0(self):
		return self.__s0

	def setS1(self,val):
		self.__s1 = val
	def getS1(self):
		return self.__s1

	def setS2(self,val):
		self.__s2 = val
	def getS2(self):
		return self.__s2

	def setS3(self,val):
		self.__s3 = val
	def getS3(self):
		return self.__s3

	def setS4(self,val):
		self.__s4 = val
	def getS4(self):
		return self.__s4

	def setS5(self,val):
		self.__s5 = val
	def getS5(self):
		return self.__s5

	def setS6(self,val):
		self.__s6 = val
	def getS6(self):
		return self.__s6

	def setS7(self,val):
		self.__s7 = val
	def getS7(self):
		return self.__s7

	def setS8(self,val):
		self.__s8 = val
	def getS8(self):
		return self.__s8

	def setS9(self,val):
		self.__s9 = val
	def getS9(self):
		return self.__s9

	def setS10(self,val):
		self.__s10 = val
	def getS10(self):
		return self.__s10

	def setS11(self,val):
		self.__s11 = val
	def getS11(self):
		return self.__s11

	def setS12(self,val):
		self.__s12 = val
	def getS12(self):
		return self.__s12

	def setS13(self,val):
		self.__s13 = val
	def getS13(self):
		return self.__s13

	def setS14(self,val):
		self.__s14 = val
	def getS14(self):
		return self.__s14

	def setS15(self,val):
		self.__s15 = val
	def getS15(self):
		return self.__s15

	def setS16(self,val):
		self.__s16 = val
	def getS16(self):
		return self.__s16

	def setS17(self,val):
		self.__s17 = val
	def getS17(self):
		return self.__s17

	def setS18(self,val):
		self.__s18 = val
	def getS18(self):
		return self.__s18

	def setS19(self,val):
		self.__s19 = val
	def getS19(self):
		return self.__s19

	def setS20(self,val):
		self.__s20 = val
	def getS20(self):
		return self.__s20

	def setS21(self,val):
		self.__s21 = val
	def getS21(self):
		return self.__s21

	def setS22(self,val):
		self.__s22 = val
	def getS22(self):
		return self.__s22

	def setS23(self,val):
		self.__s23 = val
	def getS23(self):
		return self.__s23

	def setS24(self,val):
		self.__s24 = val
	def getS24(self):
		return self.__s24

	def setS25(self,val):
		self.__s25 = val
	def getS25(self):
		return self.__s25

	def setS26(self,val):
		self.__s26 = val
	def getS26(self):
		return self.__s26

	def setS27(self,val):
		self.__s27 = val
	def getS27(self):
		return self.__s27

	def setS28(self,val):
		self.__s28 = val
	def getS28(self):
		return self.__s28

	def setS29(self,val):
		self.__s29 = val
	def getS29(self):
		return self.__s29

	def setS30(self,val):
		self.__s30 = val
	def getS30(self):
		return self.__s30

	def setS31(self,val):
		self.__s31 = val
	def getS31(self):
		return self.__s31

	def setS32(self,val):
		self.__s32 = val
	def getS32(self):
		return self.__s32

	def setS33(self,val):
		self.__s33 = val
	def getS33(self):
		return self.__s33

	def setS34(self,val):
		self.__s34 = val
	def getS34(self):
		return self.__s34

	def setS35(self,val):
		self.__s35 = val
	def getS35(self):
		return self.__s35

	def setS36(self,val):
		self.__s36 = val
	def getS36(self):
		return self.__s36

	def setS37(self,val):
		self.__s37 = val
	def getS37(self):
		return self.__s37

	def setS38(self,val):
		self.__s38 = val
	def getS38(self):
		return self.__s38

	def setS39(self,val):
		self.__s39 = val
	def getS39(self):
		return self.__s39

	def setS40(self,val):
		self.__s40 = val
	def getS40(self):
		return self.__s40

	def setS41(self,val):
		self.__s41 = val
	def getS41(self):
		return self.__s41

	def setS42(self,val):
		self.__s42 = val
	def getS42(self):
		return self.__s42

	def setS43(self,val):
		self.__s43 = val
	def getS43(self):
		return self.__s43


class genericSelection(Interface):
	controller =genericSelectionController
	proceed 	= Object(typ=Trigger,label='proceed',function='proceedFunc')
	back 	= Object(typ=Trigger,label='back',function='backFunc')
	c0 	= Object(typ=Choice,choices={0:'NA'},label='c0',default=0)
	c1 	= Object(typ=Choice,choices={0:'NA'},label='c1',default=0)
	c2 	= Object(typ=Choice,choices={0:'NA'},label='c2',default=0)
	c3 	= Object(typ=Choice,choices={0:'NA'},label='c3',default=0)
	c4 	= Object(typ=Choice,choices={0:'NA'},label='c4',default=0)
	c5 	= Object(typ=Choice,choices={0:'NA'},label='c5',default=0)
	c6 	= Object(typ=Choice,choices={0:'NA'},label='c6',default=0)
	c7 	= Object(typ=Choice,choices={0:'NA'},label='c7',default=0)
	c8 	= Object(typ=Choice,choices={0:'NA'},label='c8',default=0)
	c9 	= Object(typ=Choice,choices={0:'NA'},label='c9',default=0)
	c10 	= Object(typ=Choice,choices={0:'NA'},label='c10',default=0)
	c11 	= Object(typ=Choice,choices={0:'NA'},label='c11',default=0)
	c12 	= Object(typ=Choice,choices={0:'NA'},label='c12',default=0)
	c13 	= Object(typ=Choice,choices={0:'NA'},label='c13',default=0)
	c14 	= Object(typ=Choice,choices={0:'NA'},label='c14',default=0)
	c15 	= Object(typ=Choice,choices={0:'NA'},label='c15',default=0)
	c16 	= Object(typ=Choice,choices={0:'NA'},label='c16',default=0)
	c17 	= Object(typ=Choice,choices={0:'NA'},label='c17',default=0)
	c18 	= Object(typ=Choice,choices={0:'NA'},label='c18',default=0)
	c19 	= Object(typ=Choice,choices={0:'NA'},label='c19',default=0)
	c20 	= Object(typ=Choice,choices={0:'NA'},label='c20',default=0)
	c21 	= Object(typ=Choice,choices={0:'NA'},label='c21',default=0)
	c22 	= Object(typ=Choice,choices={0:'NA'},label='c22',default=0)
	c23 	= Object(typ=Choice,choices={0:'NA'},label='c23',default=0)
	c24 	= Object(typ=Choice,choices={0:'NA'},label='c24',default=0)
	c25 	= Object(typ=Choice,choices={0:'NA'},label='c25',default=0)
	c26 	= Object(typ=Choice,choices={0:'NA'},label='c26',default=0)
	c27 	= Object(typ=Choice,choices={0:'NA'},label='c27',default=0)
	c28 	= Object(typ=Choice,choices={0:'NA'},label='c28',default=0)
	c29 	= Object(typ=Choice,choices={0:'NA'},label='c29',default=0)
	c30 	= Object(typ=Choice,choices={0:'NA'},label='c30',default=0)
	c31 	= Object(typ=Choice,choices={0:'NA'},label='c31',default=0)
	c32 	= Object(typ=Choice,choices={0:'NA'},label='c32',default=0)
	c33 	= Object(typ=Choice,choices={0:'NA'},label='c33',default=0)
	c34 	= Object(typ=Choice,choices={0:'NA'},label='c34',default=0)
	c35 	= Object(typ=Choice,choices={0:'NA'},label='c35',default=0)
	c36 	= Object(typ=Choice,choices={0:'NA'},label='c36',default=0)
	c37 	= Object(typ=Choice,choices={0:'NA'},label='c37',default=0)
	c38 	= Object(typ=Choice,choices={0:'NA'},label='c38',default=0)
	c39 	= Object(typ=Choice,choices={0:'NA'},label='c39',default=0)
	c40 	= Object(typ=Choice,choices={0:'NA'},label='c40',default=0)
	c41 	= Object(typ=Choice,choices={0:'NA'},label='c41',default=0)
	c42 	= Object(typ=Choice,choices={0:'NA'},label='c42',default=0)
	c43 	= Object(typ=Choice,choices={0:'NA'},label='c43',default=0)
	s0 	= Object(typ=StringControl,label='s0',default='NA')
	s1 	= Object(typ=StringControl,label='s1',default='NA')
	s2 	= Object(typ=StringControl,label='s2',default='NA')
	s3 	= Object(typ=StringControl,label='s3',default='NA')
	s4 	= Object(typ=StringControl,label='s4',default='NA')
	s5 	= Object(typ=StringControl,label='s5',default='NA')
	s6 	= Object(typ=StringControl,label='s6',default='NA')
	s7 	= Object(typ=StringControl,label='s7',default='NA')
	s8 	= Object(typ=StringControl,label='s8',default='NA')
	s9 	= Object(typ=StringControl,label='s9',default='NA')
	s10 	= Object(typ=StringControl,label='s10',default='NA')
	s11 	= Object(typ=StringControl,label='s11',default='NA')
	s12 	= Object(typ=StringControl,label='s12',default='NA')
	s13 	= Object(typ=StringControl,label='s13',default='NA')
	s14 	= Object(typ=StringControl,label='s14',default='NA')
	s15 	= Object(typ=StringControl,label='s15',default='NA')
	s16 	= Object(typ=StringControl,label='s16',default='NA')
	s17 	= Object(typ=StringControl,label='s17',default='NA')
	s18 	= Object(typ=StringControl,label='s18',default='NA')
	s19 	= Object(typ=StringControl,label='s19',default='NA')
	s20 	= Object(typ=StringControl,label='s20',default='NA')
	s21 	= Object(typ=StringControl,label='s21',default='NA')
	s22 	= Object(typ=StringControl,label='s22',default='NA')
	s23 	= Object(typ=StringControl,label='s23',default='NA')
	s24 	= Object(typ=StringControl,label='s24',default='NA')
	s25 	= Object(typ=StringControl,label='s25',default='NA')
	s26 	= Object(typ=StringControl,label='s26',default='NA')
	s27 	= Object(typ=StringControl,label='s27',default='NA')
	s28 	= Object(typ=StringControl,label='s28',default='NA')
	s29 	= Object(typ=StringControl,label='s29',default='NA')
	s30 	= Object(typ=StringControl,label='s30',default='NA')
	s31 	= Object(typ=StringControl,label='s31',default='NA')
	s32 	= Object(typ=StringControl,label='s32',default='NA')
	s33 	= Object(typ=StringControl,label='s33',default='NA')
	s34 	= Object(typ=StringControl,label='s34',default='NA')
	s35 	= Object(typ=StringControl,label='s35',default='NA')
	s36 	= Object(typ=StringControl,label='s36',default='NA')
	s37 	= Object(typ=StringControl,label='s37',default='NA')
	s38 	= Object(typ=StringControl,label='s38',default='NA')
	s39 	= Object(typ=StringControl,label='s39',default='NA')
	s40 	= Object(typ=StringControl,label='s40',default='NA')
	s41 	= Object(typ=StringControl,label='s41',default='NA')
	s42 	= Object(typ=StringControl,label='s42',default='NA')
	s43 	= Object(typ=StringControl,label='s43',default='NA')
	groupName 	= Object(typ=String,label='groupName',default='Select GPIO Map')
	pageName 	= Object(typ=String,label='pageName',default='Select GPIO Map')


	############ Below are the choices List.
	c0ChoicesList = []
	c1ChoicesList = []
	c2ChoicesList = []
	c3ChoicesList = []
	c4ChoicesList = []
	c5ChoicesList = []
	c6ChoicesList = []
	c7ChoicesList = []
	c8ChoicesList = []
	c9ChoicesList = []
	c10ChoicesList = []
	c11ChoicesList = []
	c12ChoicesList = []
	c13ChoicesList = []
	c14ChoicesList = []
	c15ChoicesList = []
	c16ChoicesList = []
	c17ChoicesList = []
	c18ChoicesList = []
	c19ChoicesList = []
	c20ChoicesList = []
	c21ChoicesList = []
	c22ChoicesList = []
	c23ChoicesList = []
	c24ChoicesList = []
	c25ChoicesList = []
	c26ChoicesList = []
	c27ChoicesList = []
	c28ChoicesList = []
	c29ChoicesList = []
	c30ChoicesList = []
	c31ChoicesList = []
	c32ChoicesList = []
	c33ChoicesList = []
	c34ChoicesList = []
	c35ChoicesList = []
	c36ChoicesList = []
	c37ChoicesList = []
	c38ChoicesList = []
	c39ChoicesList = []
	c40ChoicesList = []
	c41ChoicesList = []
	c42ChoicesList = []
	c43ChoicesList = []

	def __init__(self,libInstance,guiControllerInstance):
		super(genericSelection,self).__init__(libInstance=libInstance,guiControllerInstance=guiControllerInstance)
		self.gui.hide()
		self.libInstance=libInstance
		self.guiControllerInstance=guiControllerInstance
		self.maxValid=-1
		self.guiPageName="genericSelection"

	def setParams(self,choicesDict):
		self.choicesDict=choicesDict
		count=0
		for param in choicesDict.keys():
			if count>43:
				break
			choicesDictParam={}
			for i in range(len(choicesDict[param])):
				choicesDictParam[i]=choicesDict[param][i]
			exec("self._c"+str(count)+".reloadItems(choicesDictParam)")
			exec("noWidgets=len(self._c"+str(count)+".gui.widgets)")
			for widgetNo in range(noWidgets):
				exec("self._c"+str(count)+".gui.widgets[widgetNo].setDisabled(0)")
			exec("noWidgets=len(self._s"+str(count)+".gui.widgets)")
			for widgetNo in range(noWidgets):
				exec("self._s"+str(count)+".gui.widgets[widgetNo].setDisabled(1)")
			exec("self._s"+str(count)+".setValue(param)")
			count+=1
		self.maxValid=count-1
		for invalidNos in range(count,44):
			exec("self._c"+str(invalidNos)+".gui.widgets[0].setDisabled(1)")
			exec("self._s"+str(invalidNos)+".gui.widgets[0].setDisabled(1)")
			exec("self._s"+str(invalidNos)+".setValue('NC')")
	#setParams
		
	def getParams(self):
		choicesDict={}
		count=0
		for count in range(self.maxValid):
			exec("paramVal=self._s"+str(count)+".getValue()")
			exec("choiceVal=self._c"+str(count)+".getValue()")
			choicesDict[paramVal]=self.choicesDict[paramVal][choiceVal]
		return choicesDict
						
	def proceedFunc(self):
		"""  """
		self.guiControllerInstance.proceedFunc(self.guiPageName)

	def backFunc(self):
		"""  """
		self.guiControllerInstance.backFunc(self.guiPageName)

	def updateIndicatorsFunc(self):
		self._s0.getValue()
		self._s1.getValue()
		self._s2.getValue()
		self._s3.getValue()
		self._s4.getValue()
		self._s5.getValue()
		self._s6.getValue()
		self._s7.getValue()
		self._s8.getValue()
		self._s9.getValue()
		self._s10.getValue()
		self._s11.getValue()
		self._s12.getValue()
		self._s13.getValue()
		self._s14.getValue()
		self._s15.getValue()
		self._s16.getValue()
		self._s17.getValue()
		self._s18.getValue()
		self._s19.getValue()
		self._s20.getValue()
		self._s21.getValue()
		self._s22.getValue()
		self._s23.getValue()
		self._s24.getValue()
		self._s25.getValue()
		self._s26.getValue()
		self._s27.getValue()
		self._s28.getValue()
		self._s29.getValue()
		self._s30.getValue()
		self._s31.getValue()
		self._s32.getValue()
		self._s33.getValue()
		self._s34.getValue()
		self._s35.getValue()
		self._s36.getValue()
		self._s37.getValue()
		self._s38.getValue()
		self._s39.getValue()
		self._s40.getValue()
		self._s41.getValue()
		self._s42.getValue()
		self._s43.getValue()

	def updateObjectsFunc(self):
		self._c0.getValue()
		self._c1.getValue()
		self._c2.getValue()
		self._c3.getValue()
		self._c4.getValue()
		self._c5.getValue()
		self._c6.getValue()
		self._c7.getValue()
		self._c8.getValue()
		self._c9.getValue()
		self._c10.getValue()
		self._c11.getValue()
		self._c12.getValue()
		self._c13.getValue()
		self._c14.getValue()
		self._c15.getValue()
		self._c16.getValue()
		self._c17.getValue()
		self._c18.getValue()
		self._c19.getValue()
		self._c20.getValue()
		self._c21.getValue()
		self._c22.getValue()
		self._c23.getValue()
		self._c24.getValue()
		self._c25.getValue()
		self._c26.getValue()
		self._c27.getValue()
		self._c28.getValue()
		self._c29.getValue()
		self._c30.getValue()
		self._c31.getValue()
		self._c32.getValue()
		self._c33.getValue()
		self._c34.getValue()
		self._c35.getValue()
		self._c36.getValue()
		self._c37.getValue()
		self._c38.getValue()
		self._c39.getValue()
		self._c40.getValue()
		self._c41.getValue()
		self._c42.getValue()
		self._c43.getValue()