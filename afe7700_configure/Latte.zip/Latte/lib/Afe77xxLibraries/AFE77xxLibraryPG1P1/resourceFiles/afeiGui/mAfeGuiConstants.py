class afeGuiConstants:
	genericGuiInstance=None
	gpioStatusiGuiInstance=None
	guiController=None
	noSelsInGenericGuiInstance=45