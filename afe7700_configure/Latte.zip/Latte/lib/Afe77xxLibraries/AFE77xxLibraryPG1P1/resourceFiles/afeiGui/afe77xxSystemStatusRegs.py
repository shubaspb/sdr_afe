import globalDefs as Globals
from mInstrument import *
import iGui
from mDevice import Device
class afe77xxSystemStatusRegsController:
	def __init__(self,parent,*args,**kwargs):
		self.libInstance=kwargs['libInstance']
		self.systemParams=kwargs['libInstance'].systemParams
		self.__chipId = parent.chipId
		self.__chipType = parent.chipType
		self.__chipVersion = parent.chipVersion
		self.__rxLoPllIndex0 = parent.rxLoPllIndex0
		self.__rxLoPllIndex1 = parent.rxLoPllIndex1
		self.__txLoPllIndex0 = parent.txLoPllIndex0
		self.__txLoPllIndex1 = parent.txLoPllIndex1
		self.__laneRateRx0 = parent.laneRateRx0
		self.__laneRateRx1 = parent.laneRateRx1
		self.__laneRateFb0 = parent.laneRateFb0
		self.__laneRateFb1 = parent.laneRateFb1
		self.__laneRateTx0 = parent.laneRateTx0
		self.__laneRateTx1 = parent.laneRateTx1
		self.__validConfig0 = parent.validConfig0
		self.__validConfig1 = parent.validConfig1
		self.__jesdRxLink0 = parent.jesdRxLink0
		self.__jesdRxLink1 = parent.jesdRxLink1
		self.__pllValid0 = parent.pllValid0
		self.__pllValid1 = parent.pllValid1
		self.__pllValid2 = parent.pllValid2
		self.__pllValid3 = parent.pllValid3
		self.__pllValid4 = parent.pllValid4
		self.__pllLockStatus0 = parent.pllLockStatus0
		self.__pllLockStatus1 = parent.pllLockStatus1
		self.__pllLockStatus2 = parent.pllLockStatus2
		self.__pllLockStatus3 = parent.pllLockStatus3
		self.__pllLockStatus4 = parent.pllLockStatus4
		self.__back = parent.back

	def setChipId(self,val):
		self.getChipId()

	def getChipId(self):
		self.__chipId = hex(self.libInstance.systemStatus.chipId)
		return self.__chipId

	def setChipType(self,val):
		self.getChipType()

	def getChipType(self):
		self.__chipType = hex(self.libInstance.systemStatus.chipType)
		return self.__chipType

	def setChipVersion(self,val):
		self.getChipVersion()

	def getChipVersion(self):
		self.__chipVersion = hex(self.libInstance.systemStatus.chipVersion)
		return self.__chipVersion

	def setRxLoPllIndex0(self,val):
		self.getRxLoPllIndex0()

	def getRxLoPllIndex0(self):
		self.__rxLoPllIndex0 = self.libInstance.systemStatus.rxLoPllIndex[0]
		return self.__rxLoPllIndex0

	def setRxLoPllIndex1(self,val):
		self.getRxLoPllIndex1()

	def getRxLoPllIndex1(self):
		self.__rxLoPllIndex1 = self.libInstance.systemStatus.rxLoPllIndex[1]
		return self.__rxLoPllIndex1

	def setTxLoPllIndex0(self,val):
		self.getTxLoPllIndex0()

	def getTxLoPllIndex0(self):
		self.__txLoPllIndex0 = self.libInstance.systemStatus.txLoPllIndex[0]
		return self.__txLoPllIndex0

	def setTxLoPllIndex1(self,val):
		self.getTxLoPllIndex1()

	def getTxLoPllIndex1(self):
		self.__txLoPllIndex1 = self.libInstance.systemStatus.txLoPllIndex[1]
		return self.__txLoPllIndex1

	def setLaneRateRx0(self,val):
		self.getLaneRateRx0()

	def getLaneRateRx0(self):
		self.__laneRateRx0 = self.libInstance.systemStatus.laneRateRx[0]
		return self.__laneRateRx0

	def setLaneRateRx1(self,val):
		self.getLaneRateRx1()

	def getLaneRateRx1(self):
		self.__laneRateRx1 = self.libInstance.systemStatus.laneRateRx[1]
		return self.__laneRateRx1

	def setLaneRateFb0(self,val):
		self.getLaneRateFb0()

	def getLaneRateFb0(self):
		self.__laneRateFb0 = self.libInstance.systemStatus.laneRateFb[0]
		return self.__laneRateFb0

	def setLaneRateFb1(self,val):
		self.getLaneRateFb1()

	def getLaneRateFb1(self):
		self.__laneRateFb1 = self.libInstance.systemStatus.laneRateFb[1]
		return self.__laneRateFb1

	def setLaneRateTx0(self,val):
		self.getLaneRateTx0()

	def getLaneRateTx0(self):
		self.__laneRateTx0 = self.libInstance.systemStatus.laneRateTx[0]
		return self.__laneRateTx0

	def setLaneRateTx1(self,val):
		self.getLaneRateTx1()

	def getLaneRateTx1(self):
		self.__laneRateTx1 = self.libInstance.systemStatus.laneRateTx[1]
		return self.__laneRateTx1

	def setValidConfig0(self,val):
		self.getValidConfig0()

	def getValidConfig0(self):
		self.__validConfig0 = self.libInstance.systemStatus.validConfig[0]
		return self.__validConfig0

	def setValidConfig1(self,val):
		self.getValidConfig1()

	def getValidConfig1(self):
		self.__validConfig1 = self.libInstance.systemStatus.validConfig[1]
		return self.__validConfig1

	def setJesdRxLink0(self,val):
		self.getJesdRxLink0()

	def getJesdRxLink0(self):
		self.__jesdRxLink0 = self.libInstance.systemStatus.jesdRxLink[0]
		return self.__jesdRxLink0

	def setJesdRxLink1(self,val):
		self.getJesdRxLink1()

	def getJesdRxLink1(self):
		self.__jesdRxLink1 = self.libInstance.systemStatus.jesdRxLink[1]
		return self.__jesdRxLink1

	def setPllValid0(self,val):
		self.getPllValid0()

	def getPllValid0(self):
		self.__pllValid0 = self.libInstance.systemStatus.pllValid[0]
		return self.__pllValid0

	def setPllValid1(self,val):
		self.getPllValid1()

	def getPllValid1(self):
		self.__pllValid1 = self.libInstance.systemStatus.pllValid[1]
		return self.__pllValid1

	def setPllValid2(self,val):
		self.getPllValid2()

	def getPllValid2(self):
		self.__pllValid2 = self.libInstance.systemStatus.pllValid[2]
		return self.__pllValid2

	def setPllValid3(self,val):
		self.getPllValid3()

	def getPllValid3(self):
		self.__pllValid3 = self.libInstance.systemStatus.pllValid[3]
		return self.__pllValid3

	def setPllValid4(self,val):
		self.getPllValid4()

	def getPllValid4(self):
		self.__pllValid4 = self.libInstance.systemStatus.pllValid[4]
		return self.__pllValid4

	def setPllLockStatus0(self,val):
		self.getPllLockStatus0()

	def getPllLockStatus0(self):
		self.__pllLockStatus0 = self.libInstance.systemStatus.pllLockStatus[0]
		return self.__pllLockStatus0

	def setPllLockStatus1(self,val):
		self.getPllLockStatus1()

	def getPllLockStatus1(self):
		self.__pllLockStatus1 = self.libInstance.systemStatus.pllLockStatus[1]
		return self.__pllLockStatus1

	def setPllLockStatus2(self,val):
		self.getPllLockStatus2()

	def getPllLockStatus2(self):
		self.__pllLockStatus2 = self.libInstance.systemStatus.pllLockStatus[2]
		return self.__pllLockStatus2

	def setPllLockStatus3(self,val):
		self.getPllLockStatus3()

	def getPllLockStatus3(self):
		self.__pllLockStatus3 = self.libInstance.systemStatus.pllLockStatus[3]
		return self.__pllLockStatus3

	def setPllLockStatus4(self,val):
		self.getPllLockStatus4()

	def getPllLockStatus4(self):
		self.__pllLockStatus4 = self.libInstance.systemStatus.pllLockStatus[4]
		return self.__pllLockStatus4

class afe77xxSystemStatusRegs(Interface):
	controller =afe77xxSystemStatusRegsController
	redBulbImgPath =  Globals.ASTERIX_DIR+r"iGuiImages/red.png"
	greenBulbImgPath = Globals.ASTERIX_DIR+r"iGuiImages/green.png"
	redBulb = Globals.ASTERIX_DIR+r"iGuiImages/redBulb.png"
	greenBulb = Globals.ASTERIX_DIR+r"iGuiImages/greenBulb.png"
	chipId 	= Object(typ=String,label = 'chipId',default="0x00")
	chipType 	= Object(typ=String,label = 'chipType',default="0x00")
	chipVersion 	= Object(typ=String,label = 'chipVersion',default="0x00")
	rxLoPllIndex0 	= Object(typ=Integer,label = 'rxLoPllIndex0',default=0)
	rxLoPllIndex1 	= Object(typ=Integer,label = 'rxLoPllIndex1',default=0)
	txLoPllIndex0 	= Object(typ=Integer,label = 'txLoPllIndex0',default=0)
	txLoPllIndex1 	= Object(typ=Integer,label = 'txLoPllIndex1',default=0)
	laneRateRx0 	= Object(typ=RealNumber,label = 'laneRateRx0',default=0)
	laneRateRx1 	= Object(typ=RealNumber,label = 'laneRateRx1',default=0)
	laneRateFb0 	= Object(typ=RealNumber,label = 'laneRateFb0',default=0)
	laneRateFb1 	= Object(typ=RealNumber,label = 'laneRateFb1',default=0)
	laneRateTx0 	= Object(typ=RealNumber,label = 'laneRateTx0',default=0)
	laneRateTx1 	= Object(typ=RealNumber,label = 'laneRateTx1',default=0)
	validConfig0 	= Object(typ=Boolean,label='validConfig0',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	validConfig1 	= Object(typ=Boolean,label='validConfig1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdRxLink0 	= Object(typ=Boolean,label='jesdRxLink0',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	jesdRxLink1 	= Object(typ=Boolean,label='jesdRxLink1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllValid0 	= Object(typ=Boolean,label='pllValid0',default=True,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllValid1 	= Object(typ=Boolean,label='pllValid1',default=True,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllValid2 	= Object(typ=Boolean,label='pllValid2',default=True,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllValid3 	= Object(typ=Boolean,label='pllValid3',default=True,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllValid4 	= Object(typ=Boolean,label='pllValid4',default=True,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllLockStatus0 	= Object(typ=Boolean,label='pllLockStatus0',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllLockStatus1 	= Object(typ=Boolean,label='pllLockStatus1',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllLockStatus2 	= Object(typ=Boolean,label='pllLockStatus2',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllLockStatus3 	= Object(typ=Boolean,label='pllLockStatus3',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	pllLockStatus4 	= Object(typ=Boolean,label='pllLockStatus4',default=False,widgetParams={"setDisabled":True, "styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulbImgPath,redBulbImgPath)})
	refresh = Object(typ=Trigger,label="Refresh",function="updateAllIndicatorsFunc",widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	back = Object(typ=Trigger,label="Back",function="backFunc",widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	additionalConfig = Object(typ=Trigger,label='Advanced Config',function='additionalConfigFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	readStatus = Object(typ=Trigger,label="Read Status",function="readStatusFunc",widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	functionChoices 	= Object(typ=Choice,choices={0:'Device Bringup',1:'Configure PLL',2:'Configure NCOs',3:'Generate Configuration',4:'Save GUI State',5:'Load GUI State'},label='functionChoices',default='Device Bringup')
	apply 	= Object(typ=Trigger,label='Apply',function='applyFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	home = Object(typ=Trigger,label='Home',function='homeFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})
	fpgaConnectedStatus1 = Object(typ=Boolean,label='polarityCdR4',default=0,widgetParams={"styleSheet":"QCheckBox::indicator::checked {image: url(%s);} QCheckBox::indicator::unchecked {image: url(%s);}"%(greenBulb,redBulb)})
	fpgaConnectedStatus2 = Object(typ=String,label="FpgaStatus",default="FPGA is not connected")
	
	myfpgaReconnect = Object(typ=Trigger,label='Reconnect FPGA',function='myfpgaReconnectFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000ff, stop: 1 #0000aa); border:2px solid #339; border-radius:7; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #0000aa, stop: 1 #0000ff);} QPushButton::hover {background-color:white; color:blue; border-color:#339;}"})

	def myfpgaReconnectFunc(self):
		self.guiControllerInstance.sysParamClassInst.myfpgaReconnectFunc()
	
	def applyFunc(self):
		"""  """
		if self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Configure PLL':
			self.guiControllerInstance.sysParamClassInst.configurePll(1)
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Device Bringup':
			self.guiControllerInstance.sysParamClassInst.deviceBringUp()
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Generate Configuration':
			self.guiControllerInstance.sysParamClassInst.generateConfig()
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =='Configure NCOs':
			self.guiControllerInstance.sysParamClassInst.ncoConfig()
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =="Save GUI State":
			self.guiControllerInstance.sysParamClassInst.saveAndLoadGuiState('save')
		elif self.guiControllerInstance.sysParamClassInst.functionChoicesChoicesList[self._functionChoices.getValue()] =="Load GUI State":
			self.guiControllerInstance.sysParamClassInst.saveAndLoadGuiState('load')
		return

	
	def readStatusFunc(self):
		pass
	
	
	def additionalConfigFunc(self):
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(5)
	def homeFunc(self):
		self.backFunc()
		
	
	gpioo = Object(typ=Trigger,label='GPIO',function='gpioFunc',widgetParams={"styleSheet":"QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"})	
	dev0 = Object(typ=Trigger,label='Device',function='dev0Func',widgetParams={"styleSheet":"QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"})	#{"styleSheet":"QPushButton {color: black; background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff); border:2px solid #ffffff; border-radius:0; font:bold;} QPushButton::pressed {background-color:QLinearGradient( x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #ffffff, stop: 1 #ffffff);} QPushButton::hover {background-color:black; color:white; border-color:#ffffff;}"})
		
	def dev0Func(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(2)
		self._dev0.gui.widgets[1].button.setStyleSheet(white)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(white)
		self._gpioo.gui.widgets[1].button.setStyleSheet(black)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet(black)
		
		
	def gpioFunc(self):
		white = "QPushButton {color: black; background-color:#ffffff; border:2px solid #ffffff; border-radius:0; font:bold;}"
		black = "QPushButton {color: white; background-color:#000000; border:2px solid #e3e3e3; border-radius:0; font:bold;}"
		self.guiControllerInstance.guiInstance.mainWindow.changeTab(8)
		self._gpioo.gui.widgets[1].button.setStyleSheet(white)
		self._dev0.gui.widgets[1].button.setStyleSheet (black)
		self.guiControllerInstance.gpioStatusiGuiClass._gpioo.gui.widgets[1].button.setStyleSheet (white)
		self.guiControllerInstance.gpioStatusiGuiClass._dev0.gui.widgets[1].button.setStyleSheet(black)
	
	
	
	############ Below are the choices List.

	def __init__(self,libInstance,guiControllerInstance):
		super(afe77xxSystemStatusRegs,self).__init__(libInstance=libInstance,guiControllerInstance=guiControllerInstance)
		self.libInstance=libInstance
		self.guiControllerInstance = guiControllerInstance

		self.gui.hide()

	def backFunc(self):
		from workspace import afe77xxiGui
		statusPageIdx = afe77xxiGui.mainWindow.stackWidget.currentIndex()
		afe77xxiGui.mainWindow.changeTab(statusPageIdx-2)


	def updateAllIndicatorsFunc(self):
		self._chipId.getValue()
		self._chipType.getValue()
		self._chipVersion.getValue()
		self._rxLoPllIndex0.getValue()
		self._rxLoPllIndex1.getValue()
		self._txLoPllIndex0.getValue()
		self._txLoPllIndex1.getValue()
		self._laneRateRx0.getValue()
		self._laneRateRx1.getValue()
		self._laneRateFb0.getValue()
		self._laneRateFb1.getValue()
		self._laneRateTx0.getValue()
		self._laneRateTx1.getValue()
		self._validConfig0.getValue()
		self._validConfig1.getValue()
		self._jesdRxLink0.getValue()
		self._jesdRxLink1.getValue()
		self._pllValid0.getValue()
		self._pllValid1.getValue()
		self._pllValid2.getValue()
		self._pllValid3.getValue()
		self._pllValid4.getValue()
		self._pllLockStatus0.getValue()
		self._pllLockStatus1.getValue()
		self._pllLockStatus2.getValue()
		self._pllLockStatus3.getValue()
		self._pllLockStatus4.getValue()

	def updateAllObjectsFunc(self):
		pass