from globalDefs import *

class CurrentSensor():
	def __init__(self, regProgDevice):
		self.regProgDevice = regProgDevice
		self.addresses={}
		self.addresses['1p2'    ] = 0x41
		self.addresses['1p8'    ] = 0x40
		self.addresses['0p95'   ] = 0x45
		self.addresses['3p3'    ] = 0x44
		self.addresses['1p2VPLL'] = 0x42
		self.addresses['1p8VPLL'] = 0x43
		self.addresses['2p5'    ] = 0x4a
		for name in self.addresses.keys():
			self.configure(name,0.001,0.01)
		
	def configure(self, name, curr_res, res_value):
		slave_addr=self.addresses[name]
		data = 0.00512/(curr_res*res_value)
		data = int(data)
		data_lsb = data&(0xff)
		data_msb = (data&(0xff00))>>8
		self.regProgDevice.writeReg(slave_addr, 0x05, data_msb, data_lsb)
		
	def readCurrent(self, name):
		slave_addr=self.addresses[name]
		self.regProgDevice.writeReg(slave_addr, 0x04)
		delay(0.01)
		return self.regProgDevice.readReg(slave_addr,16)
		
	def readVoltage(self, name):
		slave_addr=self.addresses[name]
		self.regProgDevice.writeReg(slave_addr, 0x02)
		delay(0.01)
		return 1.25e-3*(self.regProgDevice.readReg(slave_addr,16))


#mySensor = CurrentSensor(regProgDevice = i2c)
#
#addresses = [0x41, 0x40, 0x45, 0x44, 0x42, 0x43, 0x4a]
#labels = ['1.2V', '1.8V', '0.9V', '3.3V', '1.2V PLL', '1.8V PLL', '2.5V']
#
#for addr, label in zip(addresses,labels):
#	mySensor.configure(addr, 0.001, 0.01)
#	critical("%s : %sV / %smA"%(label, mySensor.readVoltage(addr), mySensor.readCurrent(addr)))