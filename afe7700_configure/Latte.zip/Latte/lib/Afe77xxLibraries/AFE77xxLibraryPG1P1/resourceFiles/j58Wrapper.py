from mDevice import *
import time
import numpy as np
import math
import copy,os,re
import mHSC1287Interface
reload(mHSC1287Interface)
from mHSC1287Interface import HSC1287Interface
from globalDefs import *

class j58WrapperClass():	
	def __init__(self):
		#self.interfaceHandle = HSC1257Capture(name="CaptureCard",fileName=ASTERIX_DIR+DEVICES_DIR+"HSC1287\\HSC1257\\test_JESD204B.dml")
		self.interfaceHandle=None
		self.laneOffset = 192*4
		try:
			self.start()
		except:
			error("Reset the FPGA and try again.")
			raise
			
	def start(self):
		self.interfaceHandle = HSC1287Interface()
		self.interfaceHandle.connectToCard()
		if self.interfaceHandle.isConnected==False:
			error("Reset the FPGA and try again.")
			return
		r = self.interfaceHandle.CheckConnection()	

		self.byte_swap = 0
		self.mult_fact = 1
		self.frame_phase= 0
		
		self.dropAlternateFrames=0
		self.sampleConverterOrderReverse=0
		self.dropAlternateSamplesPerConverter=0
		self.LMFSHd="44210"
		self.converterOrder=(0,1)
		self.reverseFourSamplesInLane=0
		self.printCommentsForDebug=0
		
		self.doReorder= True	# Converts 2 consecutive 16-bits per lane into lane-interleaved 16-bits
		return r
		
	def rawCapture(self,nSamples):	
		laneWiseData8Bit = self.interfaceHandle.capture(nSamples+self.laneOffset,self.frame_phase)
		laneWiseData16Bit =[]
		for laneData in laneWiseData8Bit:
			laneData=laneData[self.laneOffset*2:]
			laneData16BitPreorder=[0]*(len(laneData)/2)
			laneData16BitPreorder=list(np.frombuffer(np.asarray(laneData,'uint8'),dtype='uint16'))
			# for sample in range(0,len(laneData),4):
				# laneData16Bit[sample/2+1] = laneData[sample]+(laneData[sample+1]<<8)
				# laneData16Bit[sample/2] = laneData[sample+2]+(laneData[sample+3]<<8)
			laneData16Bit=laneData16BitPreorder[:]
			laneData16Bit[::2]=laneData16BitPreorder[1::2]
			laneData16Bit[1::2]=laneData16BitPreorder[0::2]
			laneWiseData16Bit.append(laneData16Bit)
		return laneWiseData16Bit
		
	def rawCaptureOld(self,nSamples):	
		LanesRequired = self.interfaceHandle.LanesToCapture		
		#Capture Samples
		#nSamples=nSamples-nSamples%(LanesRequired*2)
		s = self.interfaceHandle.capture(nSamples+self.offset)
		
		for i in range(len(s)):
			s[i] = s[i][self.offset:]
			
		import numpy as np		
		x = np.array(s).transpose().tobytes()
		dt = np.dtype('int16')	
		dt = dt.newbyteorder(self.interfaceHandle.byteorder)	
		y = np.frombuffer(x,dtype=dt)
		
		
		if (self.doReorder == True):
			# Converts 2 consecutive 16-bits per lane into lane-interleaved 16-bits
			jesdModeIn=self.LMFSHd.lower()
			if "_real" in jesdModeIn:
				realMode=1
				jesdMode=jesdModeIn.replace("_real","")
			elif "_" in jesdModeIn:
				jesdMode=jesdModeIn[:jesdModeIn.find("_")]
				realMode=0
			else:
				jesdMode=jesdModeIn
				realMode=0
			
			
			L=int(jesdMode[0])
			M=int(jesdMode[1])
			r=M/L
			if L > 1:
				a=np.zeros(len(y),'int16')
				for i in range(L):
					for j in range(r):
						a[(r*i+j)::r*L] = y[(i+j*r)::r*L]
				return a,0
			else:
				return y,0
		else:
			return y,0
			

	def capture(self,captureSampleNo):
		errorCode=0x00
		try:		
			printCommentsForDebug=self.printCommentsForDebug
			jesdModeIn=self.LMFSHd.lower()
			if "_real" in jesdModeIn:
				realMode=1
				jesdMode=jesdModeIn.replace("_real","")
			elif "_" in jesdModeIn:
				jesdMode=jesdModeIn[:jesdModeIn.find("_")]
				realMode=0
			else:
				jesdMode=jesdModeIn
				realMode=0
			L=int(jesdMode[0])
			M=int(jesdMode[1])
			if len(jesdMode)==5:
				F=int(jesdMode[2])
				S=int(jesdMode[3])
				Hd=int(jesdMode[4])
			elif len(jesdMode)==6:
				F=int(jesdMode[2:4])
				S=int(jesdMode[4])
				Hd=int(jesdMode[5])
			
			resolution=16*(F*L)/(M*S*2.0)
			self.converterOrder=list(self.converterOrder)
			for i in range(len(self.converterOrder)):
				if self.converterOrder[i] >=M:
					del self.converterOrder[i]
			converterOrderOutofRange=False
			if len(self.converterOrder)==0:
				converterOrderOutofRange=True
				self.converterOrder=range(M)
			captureSampleNo = self.mult_fact*captureSampleNo
			captureSampleNo=int(captureSampleNo*resolution/(16.0))	# To get required number of samples even if it is 12/24-bit
			#captureSampleNoNeeded=int(math.ceil(captureSampleNo*M/len(self.converterOrder)))		#To account for the number of converters needed out of total ones.
			captureSampleNo=int(math.ceil(captureSampleNo*M/(2.*L)))
			
			laneWiseData=self.rawCapture(captureSampleNo)
			#values_a0=self.rawCapture(captureSampleNo+self.frame_phase)[0]
			#dataInput=values_a0[(self.frame_phase):(captureSampleNo*L*2+self.frame_phase)]
			#
			#if len(values_a0)!=(captureSampleNo+self.frame_phase):
			#	values_a0=self.rawCapture(captureSampleNo+self.frame_phase)[0]					
			#	dataInput=values_a0[(self.frame_phase)*L*2:(captureSampleNo+self.frame_phase)*L*2]

			#if self.byte_swap:
			#	dataInput=((dataInput&0xff00)>>8)+((dataInput&0x00ff)<<8)
            #
			#
			#laneWiseData=[]
			#if L == 1:
			#	laneWiseData.append(dataInput)
			#elif L == 2:
			#	if len(dataInput)%2!=0:
			#		dataInput=dataInput[:-1]
			#	laneWiseData.append(dataInput[0::2])
			#	laneWiseData.append(dataInput[1::2])
			#else:
			#	if len(dataInput)%4!=0:
			#		dataInput=dataInput[:len(dataInput)-len(dataInput)%4]
			#	laneWiseData.append(dataInput[0::4])
			#	laneWiseData.append(dataInput[1::4])
			#	laneWiseData.append(dataInput[2::4])
			#	laneWiseData.append(dataInput[3::4])
            #
			#if (self.reverseFourSamplesInLane==1): # Due to Bug in FPGA
			#	for laneData in laneWiseData:
			#		laneData1=laneData[0::4].tolist()
			#		laneData2=laneData[1::4].tolist()
			#		laneData3=laneData[2::4].tolist()
			#		laneData4=laneData[3::4].tolist()
			#		laneData[0::4]=np.asarray(laneData4)
			#		laneData[1::4]=np.asarray(laneData3)
			#		laneData[2::4]=np.asarray(laneData2)
			#		laneData[3::4]=np.asarray(laneData1)
			#elif (self.reverseFourSamplesInLane==2): # Due to Bug in FPGA
			#	for laneData in laneWiseData:
			#		laneData1=laneData[0::4].tolist()
			#		laneData2=laneData[1::4].tolist()
			#		laneData3=laneData[2::4].tolist()
			#		laneData4=laneData[3::4].tolist()
			#		laneData[0::4]=np.asarray(laneData3)
			#		laneData[1::4]=np.asarray(laneData4)
			#		laneData[2::4]=np.asarray(laneData1)
			#		laneData[3::4]=np.asarray(laneData2)
			#
				
			if Hd==1 and F==1:
				if printCommentsForDebug:
					info("if Hd==1 and F==1:")
				if L==4:
					lane0=[(((laneWiseData[0][i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1][i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					lane1=[(((laneWiseData[2][i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[3][i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))
					laneWiseData.append(np.asarray(lane1))
				elif L==2:
					lane0=[(((laneWiseData[0][i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1][i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))	
				L=L/2
				F=F*2
					
			if resolution!=16 and not (L==3 and Hd==1 and F!=1):
				if printCommentsForDebug:
					info("Unwrapping: if resolution!=16 and not (L==3 and Hd==1 and F!=1):")
				unwrappedLaneWiseData=[]
				totalSampleNumber=0
				if F==3:
					noSamplesMultipleOfFactor=3
				else:
					noSamplesMultipleOfFactor=(F/2)
				for laneData in laneWiseData:
					unwrappedLaneData=[]
					if resolution == 24:
						for laneSampleNo in range(0,len(laneData)-(len(laneData)%noSamplesMultipleOfFactor),3):
							a=laneData[laneSampleNo]
							b=laneData[laneSampleNo+1]
							c=laneData[laneSampleNo+2]
							unwrappedLaneData.append(a)
							unwrappedLaneData.append(((b&0xFF)<<8)+((c&0xFF00)>>8))
							totalSampleNumber+=2
					elif resolution == 12:
						for laneSampleNo in range(0,len(laneData)-(len(laneData)%noSamplesMultipleOfFactor),3):
							a=laneData[laneSampleNo]
							b=laneData[laneSampleNo+1]
							c=laneData[laneSampleNo+2]
							unwrappedLaneData.append(a&0xFFF0)
							unwrappedLaneData.append(((a&0xF)<<12)+((b&0xFF00)>>4))
							unwrappedLaneData.append(((b&0x00FF)<<8)+((c&0xF000)>>8))
							unwrappedLaneData.append((c&0x0FFF)<<4)
							totalSampleNumber+=4
					elif resolution == 32:
						unwrappedLaneData=laneData[::2]
						totalSampleNumber+=len(laneData)/2
					unwrappedLaneWiseData.append(unwrappedLaneData)
				laneWiseData=unwrappedLaneWiseData
			else:
				totalSampleNumber=len(laneWiseData[0])*len(laneWiseData)
			
			if Hd==1 and F!=1 and resolution==24:
				noSamplesPerLanePerFrame=int(round(F/2.0))
			else:
				noSamplesPerLanePerFrame=int(round(F/(resolution/8.0)))
			if printCommentsForDebug:
				info("First noSamplesPerLanePerFrame: "+str(noSamplesPerLanePerFrame))
			#info("L: "+str(L))
			#info("M: "+str(M))
			#info("F: "+str(F))
			#info("S: "+str(S))
			#info("Hd: "+str(Hd))
			#info("noSamplesPerLanePerFrame: "+str(noSamplesPerLanePerFrame))
			#info("totalSampleNumber: "+str(totalSampleNumber))
			
				
				
			frameInterleavedData=np.zeros(totalSampleNumber,dtype=int)
			for laneNo in range(L):
				for sampleNo in range(noSamplesPerLanePerFrame):
					frameInterleavedData[(laneNo*noSamplesPerLanePerFrame)+sampleNo::(L*noSamplesPerLanePerFrame)]=laneWiseData[laneNo][sampleNo::noSamplesPerLanePerFrame]
			if printCommentsForDebug:
				info("Calculated frameInterleavedData")
			if self.dropAlternateFrames==True:
				if printCommentsForDebug:
					info("if self.dropAlternateFrames==True:")
				lenOfFrameInterleavedData=len(frameInterleavedData)
				frameInterleavedData=frameInterleavedData.reshape(lenOfFrameInterleavedData/(L*noSamplesPerLanePerFrame),L*noSamplesPerLanePerFrame)[::2]
				frameInterleavedData=frameInterleavedData.reshape(len(frameInterleavedData)*L*noSamplesPerLanePerFrame)
				totalSampleNumber=len(frameInterleavedData)
			#self.frameInterleavedData=frameInterleavedData
			#self.laneWiseData=laneWiseData
			
			if Hd==1 and F!=1 and F%2==0 and resolution==24:
				if printCommentsForDebug:
					info("special case unwrapping: if Hd==1 and F!=1 and resolution==24:")
				if F==3:
					noSamplesMultipleOfFactor=3*L
				else:
					noSamplesMultipleOfFactor=(F*L/2)
				unwrappedFrameData=[]
				totalSampleNumber=0
				for laneSampleNo in range(0,len(frameInterleavedData)-(len(frameInterleavedData)%noSamplesMultipleOfFactor),3):
					a=frameInterleavedData[laneSampleNo]
					b=frameInterleavedData[laneSampleNo+1]
					c=frameInterleavedData[laneSampleNo+2]
					unwrappedFrameData.append(a)
					unwrappedFrameData.append(((b&0xFF)<<8)+((c&0xFF00)>>8))
					totalSampleNumber+=2
				frameInterleavedData=unwrappedFrameData
				noSamplesPerLanePerFrame=int(round(F/(2.0)))
				L=2
			
			converterWiseData=[]
			if printCommentsForDebug:
				info("going in for converterNo in range(M):")
			for converterNo in range(M):
				converterData=np.zeros(totalSampleNumber/M,dtype=int)
				for sampleNo in range(S):
					if self.sampleConverterOrderReverse:
						converterData[sampleNo::S]=frameInterleavedData[sampleNo+(converterNo*(L*noSamplesPerLanePerFrame)/M)::(L*noSamplesPerLanePerFrame)]
					else:
						converterData[sampleNo::S]=frameInterleavedData[converterNo+(sampleNo*(L*noSamplesPerLanePerFrame)/S)::(L*noSamplesPerLanePerFrame)]
				converterWiseData.append(converterData)
			#self.converterWiseData=converterWiseData
			if printCommentsForDebug:
				info("converterInterleavedData=np.zeros")
			if self.dropAlternateSamplesPerConverter:
				converterInterleavedData=np.zeros(len(converterWiseData[0])*len(self.converterOrder)/2,dtype=int)
			else:
				converterInterleavedData=np.zeros(len(converterWiseData[0])*len(self.converterOrder),dtype=int)
			index=0
			if len(self.converterOrder)>1:
				for converterIndex in self.converterOrder:
					#if converterIndex>=M:
					#	continue
					if self.dropAlternateSamplesPerConverter:
						converterInterleavedData[index::len(self.converterOrder)]=converterWiseData[converterIndex][::2]
					else:
						converterInterleavedData[index::len(self.converterOrder)]=converterWiseData[converterIndex]
					index+=1
			else:
				converterInterleavedData=converterWiseData[self.converterOrder[0]]
			if converterOrderOutofRange==False:
				values=converterInterleavedData[:2**int(math.log(len(converterInterleavedData),2))]
			else:
				values=np.zeros(65536,dtype=int)
			
			
			#if self.dropAlternateSamplesPerConverter==True:
			#	if printCommentsForDebug:
			#		info("if self.dropAlternateSamplesPerLane==True:")
			#	laneWiseDataAfterDropping=[]
			#	for laneData in laneWiseData:
			#		laneWiseDataAfterDropping.append(laneData[::2])
			#	laneWiseData=laneWiseDataAfterDropping
			#	totalSampleNumber=totalSampleNumber/2
			#self.converterInterleavedData=converterInterleavedData
			#if captureSamples!=totalSampleNumber:
			#	raise ValueError("Enough samples not received. Got: "+str(totalSampleNumber)+"; Expected: "+str(captureSamples))	


			#if self.head.page.Common.Final_Options.samp_drop == 1 or self.head.page.Common.Final_Options.samp_drop == 2:
			##keeps 1, drops 1 sample
			#	values = values[(self.head.page.Common.Final_Options.samp_drop-1)::2]			
			#elif self.head.page.Common.Final_Options.samp_drop == 3 or self.head.page.Common.Final_Options.samp_drop == 4 or self.head.page.Common.Final_Options.samp_drop == 5 or self.head.page.Common.Final_Options.samp_drop == 6:				
			##keeps 1, drops 3 samples
			#	values = values[(self.head.page.Common.Final_Options.samp_drop-3)::4]								
			#elif self.head.page.Common.Final_Options.samp_drop == 7 or self.head.page.Common.Final_Options.samp_drop == 8:
			##keeps 2, drops 2 samples
			#	values1 = values[(2*(self.head.page.Common.Final_Options.samp_drop-7))::4]					
			#	values2 = values[((2*(self.head.page.Common.Final_Options.samp_drop-7))+1)::4]									
			#	values = np.insert(values2,np.arange(len(values1)),values1)		
				
		except Exception,E:
			info(str(E))
			error(str(E))
			errorCode=-1
			values=[]
		return values, errorCode
		
	def captureOld(self,nSamples):	
	
		ChannelsRequired = self.ConvertersToGet		
		nChannels = self.interfaceHandle.NumberofConverters_RX
		if(len(ChannelsRequired)>self.interfaceHandle.NumberofConverters_RX):
			error("Excusez-moi ! : Not Configured for {0} Channels ! max[{1}]".format(len(ChannelsRequired),nChannels))
		
		#Capture Samples
		s = self.interfaceHandle.Capture(nSamples)
		r = []
		import numpy as np	
		dt = np.dtype('int16')	
		dt = dt.newbyteorder(self.interfaceHandle.byteorder)		
		y = np.frombuffer(s,dtype=dt)
		
		#Get The Required Converters
		for i in ChannelsRequired:
			r.append(y[i:nSamples*nChannels:nChannels].tolist())					
		
		#Hand off to Engine
		y = np.asarray(r).transpose().reshape(nSamples*self.nConverters)
		return y,0
		
		
	def Reconnect(self):
		self.interfaceHandle = []
		return self.start()
		