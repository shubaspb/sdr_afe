from globalDefs import *
from mFuncDecorator import *
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
#from mAfeParameters import lmkParams
from mSetupParams import setupParams
from mAfeConstants import gpioConstants
class cpldLib(object):
	""" self.regs=cpld """
	
	@initDecorator
	def __init__(self,regs,systemStatus):
		self.systemStatus=systemStatus
		self.regs=regs
		self.laneRate=0
	#__init__
	
	def gpioConfig(self):
		for gpioBallName in self.systemStatus.gpioStatus.keys():
			if gpioBallName not in gpioConstants.gpioMapping.keys():
				error(gpioBallName+" Not in gpioConstants.gpioMapping")
				continue
			pinStatus= self.systemStatus.gpioStatus[gpioBallName]
			if pinStatus in gpioConstants.gpioMapping[gpioBallName].keys():
				if gpioBallName in self.regs.CPLD.PINCONTROL.PINCONTROL.entities.keys() and gpioConstants.gpioMapping[gpioBallName][pinStatus]!='NA':
					try:
						if gpioConstants.gpioMapping[gpioBallName][pinStatus]['direction'] ==1:
							exec("self.regs.CPLD.PINCONTROL.PINCONTROL."+ gpioBallName +".dirControl=1")
							#CPLD pin should be mapped to o/p
						else:
							exec("self.regs.CPLD.PINCONTROL.PINCONTROL."+ gpioBallName +".dirControl =0")
							#CPLD pin should be mapped to o/p
						exec("setupParams.gpioiGuiCpldClass."+ gpioBallName.lower() +"func= gpioConstants.gpioMapping[gpioBallName][pinStatus]['displayName']")
					except:
						error("Couldn't do GPIO setting for "+gpioBallName)
			elif pinStatus > 0 :
				if gpioBallName in self.regs.CPLD.PINCONTROL.PINCONTROL.entities.keys() :
					Value = pinStatus - len(gpioConstants.gpioMapping[gpioBallName].keys()) 
					try:
						if "intpi"  in gpioConstants.gpioCrossBarMapping[Value]['funcName']:
							exec("self.regs.CPLD.PINCONTROL.PINCONTROL."+ gpioBallName +".dirControl=1")							
							#CPLD pin should be mapped to o/p						
						elif "intbipi"  in gpioConstants.gpioCrossBarMapping[Value]['funcName']:
							exec("self.regs.CPLD.PINCONTROL.PINCONTROL."+ gpioBallName +".dirControl=1")
						else:
							exec("self.regs.CPLD.PINCONTROL.PINCONTROL."+ gpioBallName +".dirControl =0")
							#CPLD pin should be mapped to o/p
						exec("setupParams.gpioiGuiCpldClass."+ gpioBallName.lower() +"func= gpioConstants.gpioCrossBarMapping[Value]['funcName']")
					except:
						error("Couldn't set for "+gpioBallName)
			
			else:
				pass
			