from HSCDevices import *
from mConnect import *
import globalDefs as Globals
import numpy as np
import math
import copy,os,re

class JESD204H(Device):
	#ADCRes = Object(typ=Integer,label="ADC Resolution",default=13)
	delay_time=0.01
	logTesterFormatEn=0
	logEn = Object(typ = Boolean, label = "log Enable")
	rawWriteEn=0
		
	byte_swap = 0
	mult_fact = 1
	frame_phase	= 0
	
	printCommentsForDebug=0
	rawWriteLogEn=0
	rawWriteLogsFile=r"C:/rawWriteLogs1.txt"
	commentForWrite=""
	rewriteFile=False
	
	dropAlternateFrames=0
	sampleConverterOrderReverse=0
	dropAlternateSamplesPerConverter=0
	LMFSHd="44210"
	converterOrder=(0,1)
	reverseFourSamplesInLane=0
	read16bit=1
	#captureTx=0
	printCommentsForDebug=0
	oldCaptureFunc=True
	
	#listOfOffset0=("device.MASTER.MASTER_PAGE","device.JESD.CREDO[","device.FB[0].FB_ANA","device.FB[1].FB_ANA","device.FB[0].FB_ANA","device.FB[1].FB_ANA","device.FB[0].FB_DIG","device.FB[1].FB_DIG","device.RX.DIG_AB[")
	hardReadAlways = Object(typ = Boolean, label = "Hard Read Always", desc='Ignores the rawRegisters data and does a register read everytime during a register write.')
	def __init__(self,*args,**kwargs):
		super(JESD204H,self).__init__(*args,**kwargs)
		self.lastSelectGroup = None
		#logEn=0
		
	def rawWriteLog(self,msg=''):
		rawWriteLogsFile=self.rawWriteLogsFile
		testerLogsFile=self.rawWriteLogsFile.replace(".txt","Tester.txt")
		msg=msg.replace("CREDO","SERDES")
		if not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')]) and not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind('\\')]):
			self.rawWriteLogsFile=Globals.ASTERIX_DIR+"test.txt"
			error(r"Path "+str(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')])+" doesn't exist. Writing into file: "+str(self.rawWriteLogsFile))
			rawWriteLogsFile=self.rawWriteLogsFile
		if self.rawWriteLogEn:
			printNewSection=False
			if not os.path.exists(rawWriteLogsFile) or self.rewriteFile==True:
				text_file = open(rawWriteLogsFile, "w")
				testerLog = open(testerLogsFile, "w")
				self.rewriteFile=False
				printNewSection=True
			else:
				text_file = open(rawWriteLogsFile, "r")
				for line in reversed(text_file.readlines()):
					if not ((line.strip()[0:2].lower() == "0x") or (line.strip() == "FPGA_WRITE")):
						printNewSection=True
					elif line.strip() == "FPGA_WRITE":
						break
				text_file.close()
				text_file = open(rawWriteLogsFile, "a")
				testerLog = open(testerLogsFile, "a")
			if printNewSection:		
				text_file.write('FPGA_WRITE\n')
			
			msg=msg+self.commentForWrite
			reMatch=re.match("(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)(.*)",msg.replace('//',''))
			if reMatch:
				if reMatch.group(3).strip()=='':
					testerLog.write("WriteSPI_FPGA("+reMatch.group(1)+", "+reMatch.group(2)+");\n")
				else:
					testerLog.write("WriteSPI_FPGA("+reMatch.group(1)+", "+reMatch.group(2)+");\t{"+reMatch.group(3).strip()+"}\n")
			else:
				testerLog.write("{"+msg+"}"+'\n')
			testerLog.close()
			text_file.write(msg+"\n")
			self.commentForWrite=""
			text_file.close()
	#rawWriteLog
	
	def writeProperty(self,prop,value,soft=False):
		#print prop.fqn, value, prop._value,soft
		if not soft:
			if isinstance(prop.parent,(RegEntity,RegEntityList)):
				prop.parent.selectPage(prop,prop)
			if hasattr(prop.parent,'parent') and (prop.parent.parent is self.MASTER.MASTER_PAGE.PAGE_SEL):
				currentGroup = prop
				if currentGroup != self.lastSelectGroup:
					if self.lastSelectGroup is not None: self.lastSelectGroup.reset()
					self.lastSelectGroup = currentGroup
					
				#	return
		propertyString=str(prop.fqn)
		offset=0
		#if(propertyString[0:25]=="device.MASTER.MASTER_PAGE"):
		#	offset=0
		#else:
		#	offset=32
		
		#print propertyString[0:25],offset
		if prop.rawRegIndex is None: return
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			address=r.address
			if self.hardReadAlways:
				regVal = self.readReg(address+offset)
			else:
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal = (regVal & r.zeros()) | (r.shift(value) & r.ones())
			if self.hardReadAlways or True:#(regVal != self._rawRegisters[(prop.rawRegIndex,r.address)]):
				self._rawRegisters[(prop.rawRegIndex,r.address)]=regVal
				if not soft:
					if "device.JESD.CREDO[" not in propertyString:
						if not (r.msb<24):
							self.writeReg((address+offset+3),(regVal>>24)&0xff)
						if not (r.lsb>=24 or r.msb<16):
							self.writeReg((address+offset+2),(regVal>>16)&0xff)
					if (not (r.lsb>=16 or r.msb<8))  or "device.JESD.CREDO[" in propertyString:
						self.writeReg((address+offset+1),(regVal>>8)&0xff)
					if r.lsb<8 or "device.JESD.CREDO[" in propertyString:
						self.writeReg((address+offset),(regVal>>0)&0xff)
							
			value = value >> r.size()

	def readProperty(self,prop,soft=False):
		val = 0
		lsb = 0
		
		propertyString=str(prop.fqn)
		offset=0
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			address=r.address
			if (not soft) or self.hardReadAlways:
				if isinstance(prop.parent,(RegEntity,RegEntityList)):
					prop.parent.selectPage(prop,prop,disableBroadcast=True)
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
				
				if "device.JESD.CREDO[" not in propertyString:
					if not (r.msb<24):
						regVal=(regVal&0x00ffffff)|self.readReg((address+offset+3))<<24
					if not (r.lsb>=24 or r.msb<16):
						regVal=(regVal&0xff00ffff)|self.readReg((address+offset+2))<<16
				if (not (r.lsb>=16 or r.msb<8))  or "device.JESD.CREDO[" in propertyString:
					regVal=(regVal&0xffff00ff)|self.readReg((address+offset+1))<<8
					if "device.JESD.CREDO[" in propertyString:
						regVal=(regVal&0xffff00ff)|self.readReg((address+offset+1))<<8
				if r.lsb<8 or "device.JESD.CREDO[" in propertyString:
					regVal=(regVal&0xffffff00)|(self.readReg((address+offset)))
					if "device.JESD.CREDO[" in propertyString:
						regVal=(regVal&0xffffff00)|(self.readReg((address+offset)))
							
				#regVal = self.readReg(r.address)
				self._rawRegisters[(prop.rawRegIndex,r.address)] = regVal
			else:
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal &= r.ones()
			val |= r.unshift(regVal)<<lsb
			lsb += r.size()
			
			
		if prop.signed:
			val=prop.get2sComplement(val)		
		return val
		
	def writeReg(self,addr,val):
		#self.log('address '+str(addr)+'='+str(val))
		addr=addr&0x7fff
		print "FPGA writing into ",hex(addr), "value ", hex(val)
		self.log("%s.writeReg(0x%02X,0x%02X)"%(self.fqn,addr,val))
		if self.rawWriteLogEn:
			self.rawWriteLog(str("0x{:04x}".format(addr).lower().replace('l',''))+"    "+str("0x{:02x}".format(val).lower().replace('l','')))
		if self.regProgDevice:
			self.regProgDevice.writeReg(addr,val&0xFF)
			Globals.delay(self.delay_time)
		
	def writeReg32(self,addr,val):
		addr=addr&0x7fff
		#self.log('address '+str(addr)+'='+str(val))
		print "FPGA writing into ",hex(addr), "value ", hex(val)
		self.log("%s.writeReg(0x%08X,0x%08X)"%(self.fqn,addr,val))
# 4 data writes are required since the registers are all 32bits and SIP read is only 8 bits at a time.
#Modified by Nags

		if self.regProgDevice:
			self.regProgDevice.writeReg(addr,val&0xFF)
			self.regProgDevice.writeReg(addr+1,(val&0xFF00)>>8)
			self.regProgDevice.writeReg(addr+2,(val&0xFF0000)>>16)
			self.regProgDevice.writeReg(addr+3,(val&0xFF000000)>>24)
			Globals.delay(self.delay_time)
			
	def readReg(self,addr):
		addr=addr&0x7fff
		Globals.delay(self.delay_time)
		data = self.regProgDevice.readReg(0x8000 + addr)
		print "Read from ",hex(addr), "value ", hex(data)
		self.log("%s.writeReg(0x%08X,0x%08X)"%(self.fqn,addr,data))
		return data&0xff 
					
	def readReg32(self,addr):
		addr=addr&0x7fff
		Globals.delay(self.delay_time)
# 4 data reads are required since the registers are all 32bits and SIP read is only 8 bits at a time.
#Modified by phani and prajay on 31-July-2017 : 1800 hrs
		
		data1 = self.regProgDevice.readReg(0x8000 + addr)
		data2 = self.regProgDevice.readReg(0x8000 + addr + 1)
		data3 = self.regProgDevice.readReg(0x8000 + addr + 2)
		data4 = self.regProgDevice.readReg(0x8000 + addr + 3)
		data = (data4 << 24) + (data3 << 16) + (data2 << 8) + data1
		return data 
		
			
	def RecursiveSearchAndReset(self,entity):
		#log(entity.name)
		for childEntity in entity.entityList:
			childEntity.setDepth()
			if childEntity.depth==1:
				if childEntity.name.startswith('TP__TM'):
					for prop in childEntity.stateVariableList:
						if prop.value:
							prop.setValue(0)
			else:
				self.RecursiveSearchAndReset(childEntity)
			
	def resetTP(self):
		self.RecursiveSearchAndReset(self)
#########################################
		
##################### log all TP which are enabled
	def findTPon(self):
		self.RecursiveSearchAndReturn(self)
	 
	def RecursiveSearchAndReturn(self,entity):
		#log(entity.name)
		for childEntity in entity.entityList:
			childEntity.setDepth()
			if childEntity.depth==1:
				if childEntity.name.startswith('TP__TM'):
					for TPStateVariable in childEntity.stateVariableList:
						if TPStateVariable.value:
							log(TPStateVariable.fqn)
						
			else:
				self.RecursiveSearchAndReturn(childEntity)
##############################################
	def log(self,msg):
		if self.logEn:
			log(msg)
			text_file = open("D:/backup/4t4r/rawWrites.txt", "a")
			text_file.write(msg)
			text_file.write('\n')
			text_file.close()
	
	def rawWrite(self,msg):
		if self.rawWriteEn:
			text_file = open("D:/backup/4t4r/rawWrites1.txt", "a")
			text_file.write(msg)
			text_file.write('\n')
			text_file.close()
			
	def logTester(self,msg):
		if self.logTesterFormatEn:
			warning(msg)


	def capture(self,captureSampleNo):
		if self.oldCaptureFunc==True:
			return super(JESD204H,self).capture(captureSampleNo)
		errorCode=0x00
		try:		
			printCommentsForDebug=self.printCommentsForDebug
			jesdModeIn=self.LMFSHd.lower()
			if "_real" in jesdModeIn:
				realMode=1
				jesdMode=jesdModeIn.replace("_real","")
			elif "_" in jesdModeIn:
				jesdMode=jesdModeIn[:jesdModeIn.find("_")]
				realMode=0
			else:
				jesdMode=jesdModeIn
				realMode=0
			L=int(jesdMode[0])
			M=int(jesdMode[1])
			if len(jesdMode)==5:
				F=int(jesdMode[2])
				S=int(jesdMode[3])
				Hd=int(jesdMode[4])
			elif len(jesdMode)==6:
				F=int(jesdMode[2:4])
				S=int(jesdMode[4])
				Hd=int(jesdMode[5])
			
			resolution=16*(F*L)/(M*S*2.0)
			self.converterOrder=list(self.converterOrder)
			for i in range(len(self.converterOrder)):
				if self.converterOrder[i] >=M:
					del self.converterOrder[i]
			converterOrderOutofRange=False
			if len(self.converterOrder)==0:
				converterOrderOutofRange=True
				self.converterOrder=range(M)
			captureSampleNo = self.mult_fact*captureSampleNo
			captureSamples = captureSampleNo
			captureSampleNo=int(captureSampleNo*resolution/(16.0))	# To get required number of samples even if it is 12/24-bit
			captureSampleNoNeeded=int(math.ceil(captureSampleNo*M/len(self.converterOrder)))		#To account for the number of converters needed out of total ones.
			if captureSampleNoNeeded<=(32768*L):
				captureSampleNo=captureSampleNoNeeded
			else:
				captureSampleNo=int(captureSampleNoNeeded/math.ceil((65536.0*L)/captureSampleNoNeeded))

			values_a0=super(JESD204H,self).capture(captureSampleNo+self.frame_phase)[0]		
			dataInput=values_a0[self.frame_phase:(captureSampleNo+self.frame_phase)]
			
			if len(values_a0)!=(captureSampleNo+self.frame_phase):
				values_a0=super(JESD204H,self).capture(captureSampleNo+self.frame_phase)[0]					
				dataInput=values_a0[self.frame_phase:(captureSampleNo+self.frame_phase)]

			
			if self.byte_swap:
				dataInput=((dataInput&0xff00)>>8)+((dataInput&0x00ff)<<8)

			
			laneWiseData=[]
			if (self.read16bit==1):
				if L == 1:
					laneWiseData.append(dataInput)
				elif L == 2:
					if len(dataInput)%2!=0:
						dataInput=dataInput[:-1]
					laneWiseData.append(dataInput[0::2])
					laneWiseData.append(dataInput[1::2])
				else:
					if len(dataInput)%4!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%4]
					laneWiseData.append(dataInput[0::4])
					laneWiseData.append(dataInput[1::4])
					laneWiseData.append(dataInput[2::4])
					laneWiseData.append(dataInput[3::4])
			else:
				if L == 1:
					laneWiseData.append(dataInput)
				elif L == 2:
					if len(dataInput)%4!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%4]
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[::2].reshape(len(dataInput)/2))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[1::2].reshape(len(dataInput)/2))
				elif L==3:
					del laneWiseData[3]
				else:
					if len(dataInput)%16!=0:
						dataInput=dataInput[:len(dataInput)-len(dataInput)%16]
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[::4].reshape(len(dataInput)/4))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[1::4].reshape(len(dataInput)/4))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[2::4].reshape(len(dataInput)/4))
					laneWiseData.append(dataInput.reshape(len(dataInput)/4.0,4)[3::4].reshape(len(dataInput)/4))

			if (self.reverseFourSamplesInLane==1): # Due to Bug in FPGA
				for laneData in laneWiseData:
					laneData1=laneData[0::4].tolist()
					laneData2=laneData[1::4].tolist()
					laneData3=laneData[2::4].tolist()
					laneData4=laneData[3::4].tolist()
					laneData[0::4]=np.asarray(laneData4)
					laneData[1::4]=np.asarray(laneData3)
					laneData[2::4]=np.asarray(laneData2)
					laneData[3::4]=np.asarray(laneData1)
			elif (self.reverseFourSamplesInLane==2): # Due to Bug in FPGA
				for laneData in laneWiseData:
					laneData1=laneData[0::4].tolist()
					laneData2=laneData[1::4].tolist()
					laneData3=laneData[2::4].tolist()
					laneData4=laneData[3::4].tolist()
					laneData[0::4]=np.asarray(laneData3)
					laneData[1::4]=np.asarray(laneData4)
					laneData[2::4]=np.asarray(laneData1)
					laneData[3::4]=np.asarray(laneData2)
			
				
			if Hd==1 and F==1:
				if printCommentsForDebug:
					info("if Hd==1 and F==1:")
				if L==4:
					lane0=[(((laneWiseData[0].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					lane1=[(((laneWiseData[2].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[3].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))
					laneWiseData.append(np.asarray(lane1))
				elif L==2:
					lane0=[(((laneWiseData[0].tolist()[i/2]>>((1-(i%2))*8))&0xff)<<8)+((laneWiseData[1].tolist()[i/2]>>((1-(i%2))*8))&0xff) for i in range(len(laneWiseData[0])*2)]
					laneWiseData=[]	
					laneWiseData.append(np.asarray(lane0))	
				L=L/2
				F=F*2
					
			if resolution!=16 and not (L==3 and Hd==1 and F!=1):
				if printCommentsForDebug:
					info("Unwrapping: if resolution!=16 and not (L==3 and Hd==1 and F!=1):")
				unwrappedLaneWiseData=[]
				totalSampleNumber=0
				if F==3:
					noSamplesMultipleOfFactor=3
				else:
					noSamplesMultipleOfFactor=(F/2)
				for laneData in laneWiseData:
					unwrappedLaneData=[]
					if resolution == 24:
						for laneSampleNo in range(0,len(laneData)-(len(laneData)%noSamplesMultipleOfFactor),3):
							a=laneData[laneSampleNo]
							b=laneData[laneSampleNo+1]
							c=laneData[laneSampleNo+2]
							unwrappedLaneData.append(a)
							unwrappedLaneData.append(((b&0xFF)<<8)+((c&0xFF00)>>8))
							totalSampleNumber+=2
					elif resolution == 12:
						for laneSampleNo in range(0,len(laneData)-(len(laneData)%noSamplesMultipleOfFactor),3):
							a=laneData[laneSampleNo]
							b=laneData[laneSampleNo+1]
							c=laneData[laneSampleNo+2]
							unwrappedLaneData.append(a&0xFFF0)
							unwrappedLaneData.append(((a&0xF)<<12)+((b&0xFF00)>>4))
							unwrappedLaneData.append(((b&0x00FF)<<8)+((c&0xF000)>>8))
							unwrappedLaneData.append((c&0x0FFF)<<4)
							totalSampleNumber+=4
					elif resolution == 32:
						unwrappedLaneData=laneData[::2]
						totalSampleNumber+=len(laneData.tolist())/2
					unwrappedLaneWiseData.append(unwrappedLaneData)
				laneWiseData=unwrappedLaneWiseData
			else:
				totalSampleNumber=len(laneWiseData[0])*len(laneWiseData)
			
			if Hd==1 and F!=1 and resolution==24:
				noSamplesPerLanePerFrame=int(round(F/2.0))
			else:
				noSamplesPerLanePerFrame=int(round(F/(resolution/8.0)))
			if printCommentsForDebug:
				info("First noSamplesPerLanePerFrame: "+str(noSamplesPerLanePerFrame))
			#info("L: "+str(L))
			#info("M: "+str(M))
			#info("F: "+str(F))
			#info("S: "+str(S))
			#info("Hd: "+str(Hd))
			#info("noSamplesPerLanePerFrame: "+str(noSamplesPerLanePerFrame))
			#info("totalSampleNumber: "+str(totalSampleNumber))
			
				
				
			frameInterleavedData=np.zeros(totalSampleNumber,dtype=int)
			for laneNo in range(L):
				for sampleNo in range(noSamplesPerLanePerFrame):
					frameInterleavedData[(laneNo*noSamplesPerLanePerFrame)+sampleNo::(L*noSamplesPerLanePerFrame)]=laneWiseData[laneNo][sampleNo::noSamplesPerLanePerFrame]
			if printCommentsForDebug:
				info("Calculated frameInterleavedData")
			if self.dropAlternateFrames==True:
				if printCommentsForDebug:
					info("if self.dropAlternateFrames==True:")
				lenOfFrameInterleavedData=len(frameInterleavedData)
				frameInterleavedData=frameInterleavedData.reshape(lenOfFrameInterleavedData/(L*noSamplesPerLanePerFrame),L*noSamplesPerLanePerFrame)[::2]
				frameInterleavedData=frameInterleavedData.reshape(len(frameInterleavedData)*L*noSamplesPerLanePerFrame)
				totalSampleNumber=len(frameInterleavedData)
			#self.frameInterleavedData=frameInterleavedData
			#self.laneWiseData=laneWiseData
			
			if Hd==1 and F!=1 and F%2==0 and resolution==24:
				if printCommentsForDebug:
					info("special case unwrapping: if Hd==1 and F!=1 and resolution==24:")
				if F==3:
					noSamplesMultipleOfFactor=3*L
				else:
					noSamplesMultipleOfFactor=(F*L/2)
				unwrappedFrameData=[]
				totalSampleNumber=0
				for laneSampleNo in range(0,len(frameInterleavedData)-(len(frameInterleavedData)%noSamplesMultipleOfFactor),3):
					a=frameInterleavedData[laneSampleNo]
					b=frameInterleavedData[laneSampleNo+1]
					c=frameInterleavedData[laneSampleNo+2]
					unwrappedFrameData.append(a)
					unwrappedFrameData.append(((b&0xFF)<<8)+((c&0xFF00)>>8))
					totalSampleNumber+=2
				frameInterleavedData=unwrappedFrameData
				noSamplesPerLanePerFrame=int(round(F/(2.0)))
				L=2
			
			converterWiseData=[]
			if printCommentsForDebug:
				info("going in for converterNo in range(M):")
			for converterNo in range(M):
				converterData=np.zeros(totalSampleNumber/M,dtype=int)
				for sampleNo in range(S):
					if self.sampleConverterOrderReverse:
						converterData[sampleNo::S]=frameInterleavedData[sampleNo+(converterNo*(L*noSamplesPerLanePerFrame)/M)::(L*noSamplesPerLanePerFrame)]
					else:
						converterData[sampleNo::S]=frameInterleavedData[converterNo+(sampleNo*(L*noSamplesPerLanePerFrame)/S)::(L*noSamplesPerLanePerFrame)]
				converterWiseData.append(converterData)
			#self.converterWiseData=converterWiseData
			if printCommentsForDebug:
				info("converterInterleavedData=np.zeros")
			if self.dropAlternateSamplesPerConverter:
				converterInterleavedData=np.zeros(len(converterWiseData[0])*len(self.converterOrder)/2,dtype=int)
			else:
				converterInterleavedData=np.zeros(len(converterWiseData[0])*len(self.converterOrder),dtype=int)
			index=0
			if len(self.converterOrder)>1:
				for converterIndex in self.converterOrder:
					#if converterIndex>=M:
					#	continue
					if self.dropAlternateSamplesPerConverter:
						converterInterleavedData[index::len(self.converterOrder)]=converterWiseData[converterIndex][::2]
					else:
						converterInterleavedData[index::len(self.converterOrder)]=converterWiseData[converterIndex]
					index+=1
			else:
				converterInterleavedData=converterWiseData[self.converterOrder[0]]
			if converterOrderOutofRange==False:
				values=converterInterleavedData[:2**int(math.log(len(converterInterleavedData),2))]
			else:
				values=np.zeros(65536,dtype=int)
			
			
			#if self.dropAlternateSamplesPerConverter==True:
			#	if printCommentsForDebug:
			#		info("if self.dropAlternateSamplesPerLane==True:")
			#	laneWiseDataAfterDropping=[]
			#	for laneData in laneWiseData:
			#		laneWiseDataAfterDropping.append(laneData[::2])
			#	laneWiseData=laneWiseDataAfterDropping
			#	totalSampleNumber=totalSampleNumber/2
			#self.converterInterleavedData=converterInterleavedData
			#if captureSamples!=totalSampleNumber:
			#	raise ValueError("Enough samples not received. Got: "+str(totalSampleNumber)+"; Expected: "+str(captureSamples))	


			#if self.head.page.Common.Final_Options.samp_drop == 1 or self.head.page.Common.Final_Options.samp_drop == 2:
			##keeps 1, drops 1 sample
			#	values = values[(self.head.page.Common.Final_Options.samp_drop-1)::2]			
			#elif self.head.page.Common.Final_Options.samp_drop == 3 or self.head.page.Common.Final_Options.samp_drop == 4 or self.head.page.Common.Final_Options.samp_drop == 5 or self.head.page.Common.Final_Options.samp_drop == 6:				
			##keeps 1, drops 3 samples
			#	values = values[(self.head.page.Common.Final_Options.samp_drop-3)::4]								
			#elif self.head.page.Common.Final_Options.samp_drop == 7 or self.head.page.Common.Final_Options.samp_drop == 8:
			##keeps 2, drops 2 samples
			#	values1 = values[(2*(self.head.page.Common.Final_Options.samp_drop-7))::4]					
			#	values2 = values[((2*(self.head.page.Common.Final_Options.samp_drop-7))+1)::4]									
			#	values = np.insert(values2,np.arange(len(values1)),values1)		
				
		except Exception,E:
			info(str(E))
			error(str(E))
			errorCode=-1
			values=[]
		return values, errorCode
		

