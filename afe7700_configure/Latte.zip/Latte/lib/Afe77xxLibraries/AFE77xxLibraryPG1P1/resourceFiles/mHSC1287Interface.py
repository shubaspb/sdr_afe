
import sys

import ftd3xx

if sys.platform == 'win32':
    import ftd3xx._ftd3xx_win32 as _ft
elif sys.platform == 'linux2':
    import ftd3xx._ftd3xx_linux as _ft
if sys.version_info.major == 3:
    import queue
elif sys.version_info.major == 2:
    import Queue as queue
	
import datetime
import time
import timeit
import binascii
import itertools
import ctypes
import threading
import logging
import os
import platform
import argparse
import random
import string

from mDevice import *
import time
import globalDefs as Globals
import numpy as np
import math
import copy,os,re

	
import ftd3xx.FTDIInterface as Tester
	
from time import sleep

class HSC1287Interface():

	CMD_CONFIG   = 0;
	CMD_DDRWADDR = 4;
	CMD_DDRRADDR = 8;
	CMD_DDRRLEN  = 12;
	CMD_DDRWLEN  = 16;
	CMD_DDRWRFIFO= 20;
	CMD_DDRRDFIFO= 24;
	CMD_DDRTRIGREAD= 28;

	CONFIG_BASE_ADDR= 0*4096;
	DDR0_BASE_ADDR  = 1*4096;
	DDR1_BASE_ADDR  = 2*4096;
	ADC_BASE_ADDR   = 3*4096;
	JESD_BASE_ADDR_CONFIG  = 1*65536 + 0*4096;
	JESD_BASE_ADDR_TX0     = 1*65536 + 1*4096;
	JESD_BASE_ADDR_RX0     = 1*65536 + 2*4096;
	JESD_BASE_ADDR_PHY0    = 1*65536 + 3*4096;
	JESD_BASE_ADDR_TX1     = 1*65536 + 4*4096;
	JESD_BASE_ADDR_RX1     = 1*65536 + 5*4096;
	JESD_BASE_ADDR_PHY1    = 1*65536 + 6*4096;
	
	commentForWrite=""
	TXLanesInUse           = 0
	RXLanesInUse           = 0
	RXValidLanes		   = 0
	NumberofConverters_RX  = 0
	NumberofConverters_TX  = 0
	CaptureSyncMode        = 0
	MaxWait                = 4
	
	ConvertersPerFrame     = 0
	
	LanesToCapture         = 0
	LanesCaptured          = 0
	
	LanesToDrive           = 0
	LanesDriven            = 0
	
	
	LaneRate               = 0
	
	jesdRxSettings		 		= {}
	jesdRxSettings['convertersPerLane']	= 1
	jesdRxSettings['scr']		= True
	jesdRxSettings['K']			= 16
	jesdRxSettings['protocol']	= 0		# Protocol
	
	jesdTxSettings		 		= {}
	jesdTxSettings['convertersPerLane']	= 1
	jesdTxSettings['scr']		= True
	jesdTxSettings['K']			= 16
	jesdTxSettings['protocol']	= 0		# Protocol
	bitFileVersion				=0
	BitsPerLane                 = 32
	def connectToCard(self):
		self.isConnected = False ;
		self.isConnected = Tester.ConnectToFTDI()		
		if not self.isConnected:
			print "FTDI Not Connected"
		self.SamplesCaptured = 0
		self.dTester     = Tester
	
	def __del__(self):
		print "Deleting Handle.."
		self.dTester.DisConnectFTDI()
		
	def close(self):
		print "DisConnecting"
		self.dTester.DisConnectFTDI()
	def CheckIfPresent(self):
		return "Capture : " + Tester.CheckIfPresent()
		
	def WriteStreamToSerial(self,stream):
		#print "W : ", stream
		#print "Creating"
		ss = ''
		for s in stream:
			ss = ss + chr(s)
		#print ss
		#print "Loading"
		try:
			self.dTester.WriteToCh0(ss)
		except:
			error("Unable to write to FPGA. Ensure that the board is connected and try resetting the FPGA.")
		#print "Done"
		
	def ReadStreamFromSerial(self,count):
		try:
			stream = self.dTester.ReadFromCh0(count)	
		except:
			error("Unable to Read from FPGA. Ensure that the board is connected and try resetting the FPGA.")
			raise
		#print len(stream	)
		return stream
		
	def WriteControlRegister0(self,reg,val):	
		
		s = [];
		cmd = (1<<31)  + reg;	
		S ="{0:08X}\n".format(cmd)
		s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]
		S ="{0:08X}\n".format(len(val)-1)
		s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]
		for v in val:
			S = "{0:08X}\n".format(v)
			s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]			
		self.WriteStreamToSerial(s)

	
	def WriteControlRegister(self,reg,val):	
		
		s = [];
		cmd = (1<<31)  + reg;	
		S ="{0:08X}\n".format(cmd)
		s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]
		
		if(isinstance(val,int)):
			l = 1
		elif(isinstance(val,bytes)):
			l = len(val)/4
		elif (isinstance(val,list)):
			l = len(val)
		elif (isinstance(val,np.ndarray)):
			l = len(val)
		else:
			print "Cannot Write !"
			return 
				
		S ="{0:08X}\n".format(l-1)
		s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]		
		
		if(isinstance(val,int)):
			S = "{0:08X}\n".format(val)
			s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]
			self.WriteStreamToSerial(s)
		elif (isinstance(val,list)):
			for v in val:
				S = "{0:08X}\n".format(int(v))
				s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]			
			self.WriteStreamToSerial(s)
		elif (isinstance(val,np.ndarray)):
			self.WriteStreamToSerial(s)
			try:
				self.dTester.WriteToCh0(val.tobytes())
			except:
				error("Unable to write to FPGA. Ensure that the board is connected and try resetting the FPGA.")
		
		elif (isinstance(val,bytes)):
			self.WriteStreamToSerial(s)
			try:
				self.dTester.WriteToCh0(val)
			except:
				error("Unable to write to FPGA. Ensure that the board is connected and try resetting the FPGA.")
		
		else:
			"Cannot Write !"
			
	def ReadControlRegister(self,reg,n):	
		
		s = [];
		cmd = (0<<31)  + reg;
		S = "{0:08X}\n".format(cmd)
		s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]
		S = "{0:08X}\n".format((n-1))
		s = s + [(int(S,16) >> i & 0xff) for i in (0,8,16,24)]
		
		self.WriteStreamToSerial(s)
		
		
		s = self.ReadStreamFromSerial(4*n)		
		return s
		
	def ReadControlRegister_Q(self,reg,n):			
		s = self.ReadControlRegister(reg,n)	
		v = 0
		sc = 1
		for b in s:
			v = v + ord(b)*sc
			sc = sc*256
		return v		
	def ReadControlRegister_P(self,reg,n):			
		v = self.ReadControlRegister_Q(reg,n)		
		print "{0:08X} {1:08X}".format(reg,v)
		return v		
	def writeProperty(self,prop,value,soft=False):
		if prop.rawRegIndex is None: return
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal = (regVal & r.zeros()) | (r.shift(value) & r.ones())
			if regVal != self._rawRegisters[(prop.rawRegIndex,r.address)]:
				self._rawRegisters[(prop.rawRegIndex,r.address)]=regVal
				if not soft:
					if self.commentForWrite not in self.commentForWrite:
						self.commentForWrite+="\t// "+self.commentForWrite
					print "B: " , r.bankId
					print str(prop.fqn)
					self.writeReg(r.address,regVal)
			value = value >> r.size()
			
	def readProperty(self,prop,soft=False):
		val = 0
		lsb = 0
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			if not soft:
				regVal = self.readReg(r.address)
				if regVal is None:
					regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
					warning("%s, Dummy read \t: %d = %d"%(self.fqn,r.address,regVal))
				else:
					self._rawRegisters[(prop.rawRegIndex,r.address)] = regVal
			else:
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal &= r.ones()
			val |= r.unshift(regVal)<<lsb
			lsb += r.size()
		if prop.signed:
			val=prop.get2sComplement(val)		
		return val
		

	def Read_DDR(self,DDR_BASE,DDR_OFFSET,words_to_read):
		ddr_len = words_to_read*32/384
		self.WriteControlRegister(DDR_BASE + self.CMD_CONFIG,[0x00000000])
		self.WriteControlRegister(DDR_BASE + self.CMD_DDRRLEN ,[ddr_len])
		self.WriteControlRegister(DDR_BASE + self.CMD_DDRWLEN ,[ddr_len])
		self.WriteControlRegister(DDR_BASE + self.CMD_DDRRADDR,[DDR_OFFSET]) #TRIGGERS READ		
		s= self.ReadControlRegister (DDR_BASE+ self.CMD_DDRRDFIFO,words_to_read)
		return s
	
	def Load_DDR(self,DDR_BASE,DDR_OFFSET,nparray):
		self.WriteControlRegister(DDR_BASE + self.CMD_CONFIG,[0x00000000])
		self.WriteControlRegister(DDR_BASE + self.CMD_DDRWADDR,[DDR_OFFSET])
		self.WriteControlRegister(DDR_BASE + self.CMD_DDRWRFIFO,nparray)			
		
	def ReadDRPCommonRegister(self,PHY,reg):

		print "DRP Read : " , "{0:08X}".format(reg)
		reg = reg + 0x40000000
		
		self.WriteControlRegister (PHY + 0x104 ,[reg])
		r = self.ReadControlRegister_P(PHY + 0x10C ,1)	
		print ""
		return r
		
		
	def WriteDRPTRXRegister(self,PHY,reg,val):

		print "DRP Write : " , "{0:08X} : {1:08X}".format(reg,val)
		reg = reg + 0x80000000
		
		self.WriteControlRegister (PHY + 0x208 ,[val])
		self.WriteControlRegister (PHY + 0x204 ,[reg])

	def ReadDRPTRXRegister(self,PHY,reg):

		print "DRP Read : " , "{0:08X}".format(reg)
		reg = reg + 0x40000000
		
		self.WriteControlRegister (PHY + 0x204 ,[reg])
		r = self.ReadControlRegister_P(PHY + 0x20C ,1)	

		print ""
		
		return r
		
	def WriteDRPCommonRegister(self,PHY,reg,val):

		print "DRP Write : " , "{0:08X} : {1:08X}".format(reg,val)
		reg = reg + 0x80000000
		
		self.WriteControlRegister (PHY + 0x108 ,[val])
		self.WriteControlRegister (PHY + 0x104 ,[reg])	

		print ""	
	
	
	def PLLReset(self):
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY0 + 0x424 ,[0x00000001]) #RX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY0 + 0x420 ,[0x00000001]) #TX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY0 + 0x424 ,[0x00000000]) #RX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY0 + 0x420 ,[0x00000000]) #TX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY1 + 0x424 ,[0x00000001]) #RX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY1 + 0x420 ,[0x00000001]) #TX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY1 + 0x424 ,[0x00000000]) #RX_RST
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY1 + 0x420 ,[0x00000000]) #TX_RST
		
	def ChangePLLRate(self,Rate):

		print "Common"
		
		PHY0 = self.JESD_BASE_ADDR_PHY0
		PHY1 = self.JESD_BASE_ADDR_PHY1
		self.ReadControlRegister_P(PHY0 + 0x08 ,1)   #Read Number of Common Interface
		self.ReadControlRegister_P(PHY1 + 0x08 ,1)   #Read Number of Common Interface
		
		print "Select interface"
		self.WriteControlRegister (PHY0 + 0x20 ,[0x00000001]) # Select Common Interface 0
		self.WriteControlRegister (PHY1 + 0x20 ,[0x00000001]) # Select Common Interface 0
		
				
		print "HALFRATE " , self.ReadDRPCommonRegister(PHY0,0x0E) 
		print "FBDIV"    , self.ReadDRPCommonRegister(PHY0,0x14)
		print "HALFRATE " , self.ReadDRPCommonRegister(PHY1,0x0E) 
		print "FBDIV"    , self.ReadDRPCommonRegister(PHY1,0x14)
		
		
	
			
		self.WriteControlRegister (PHY0 + 0x20 ,[0x00000000]) # Select Common Interface 0
		self.WriteControlRegister (PHY1 + 0x20 ,[0x00000000]) # Select Common Interface 0		
		self.WriteControlRegister (PHY0 + 0x304 ,[0x00000001]) #PowerDown QPLL0
		self.WriteControlRegister (PHY1 + 0x304 ,[0x00000001]) #PowerDown QPLL0		
		self.WriteDRPCommonRegister(PHY0,0x14,Rate-2) #N
		self.WriteDRPCommonRegister(PHY1,0x14,Rate-2) #N			
		self.WriteControlRegister (PHY0 + 0x304 ,[0x00000000]) #PowerUp QPLL0
		self.WriteControlRegister (PHY1 + 0x304 ,[0x00000000]) #PowerUp QPLL0
		
		self.WriteControlRegister (PHY0 + 0x20 ,[0x00000001]) # Select Common Interface 1
		self.WriteControlRegister (PHY1 + 0x20 ,[0x00000001]) # Select Common Interface 1		
		self.WriteControlRegister (PHY0 + 0x304 ,[0x00000001]) #PowerDown QPLL0
		self.WriteControlRegister (PHY1 + 0x304 ,[0x00000001]) #PowerDown QPLL0		
		self.WriteDRPCommonRegister(PHY0,0x14,Rate-2) #N
		self.WriteDRPCommonRegister(PHY1,0x14,Rate-2) #N			
		self.WriteControlRegister (PHY0 + 0x304 ,[0x00000000]) #PowerUp QPLL0
		self.WriteControlRegister (PHY1 + 0x304 ,[0x00000000]) #PowerUp QPLL0
			
		sleep(1)	
		#RX DATAPATH RESET,TX DATAPATH RESET : ALso resets PLL
		
		self.PLLReset()
		#PHY RESET
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[0x00000001]) #
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[0x00000000]) #
	def Change_TXDIV(self,divide): 
	
		PHY0 = self.JESD_BASE_ADDR_PHY0
		PHY1 = self.JESD_BASE_ADDR_PHY1
		nTransrecievers=self.ReadControlRegister_P(PHY0 + 0x0C ,1)   #Read Number of TRX Interface
		OUTDIVs = {1:0,2:1,4:2,8:3}
		OUTDIV  = OUTDIVs[divide]
		for nTRx in range(nTransrecievers):
			
			self.WriteControlRegister (PHY0 + 0x24 ,[nTRx]) # Select TRX Interface 
			self.WriteControlRegister (PHY1 + 0x24 ,[nTRx]) # Select TRX Interface 
		
			print "TXOUT"     , hex(self.ReadDRPTRXRegister(PHY0,0x7C))
			print "RXOUT"     , hex(self.ReadDRPTRXRegister(PHY0,0x63))
			print "TXOUT"     , hex(self.ReadDRPTRXRegister(PHY1,0x7C))
			print "RXOUT"     , hex(self.ReadDRPTRXRegister(PHY1,0x63))
			
			v = self.ReadDRPTRXRegister(PHY0,0x7C) 
			self.WriteDRPTRXRegister(PHY0,0x7C,(v&(~(0x7<<8)))|(OUTDIV<<8))
			v = self.ReadDRPTRXRegister(PHY0,0x63) 
			self.WriteDRPTRXRegister(PHY0,0x63,(v&(~(0x7<<0)))|(OUTDIV<<0))
			v = self.ReadDRPTRXRegister(PHY1,0x7C) 
			self.WriteDRPTRXRegister(PHY1,0x7C,(v&(~(0x7<<8)))|(OUTDIV<<8))
			v = self.ReadDRPTRXRegister(PHY1,0x63) 
			self.WriteDRPTRXRegister(PHY1,0x63,(v&(~(0x7<<0)))|(OUTDIV<<0))
			
	def SetLanePolarities(self,tx_polarity,rx_polarity):
	
		print "Configuring Lane Polarity TX {0}".format(tx_polarity)
		print "Configuring Lane Polarity RX {0}".format(rx_polarity)
		PHY0 = self.JESD_BASE_ADDR_PHY0
		PHY1 = self.JESD_BASE_ADDR_PHY1

		for i in range(8):
			self.WriteControlRegister (PHY0 + 0x24 ,[i]) # Select Transreciever
			self.WriteControlRegister (PHY1 + 0x24 ,[i]) # Select Transreciever
			self.WriteControlRegister (PHY0 + 0x510 ,[tx_polarity[0 + i]])
			self.WriteControlRegister (PHY1 + 0x510 ,[tx_polarity[8 + i]])
			self.WriteControlRegister (PHY0 + 0x604 ,[rx_polarity[0 + i]])
			self.WriteControlRegister (PHY1 + 0x604 ,[rx_polarity[8 + i]])
	
	def JESD_Reset(self):
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020000]) 	
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020001])  # Reset JESD_ALL
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020000])  #	
	
	def SetupStreamSwitches_TX(self,Mode,tx_lanes,line_rate):
	
		print "TX Lanes : ",tx_lanes
		
		tx_lane_switch = range(16)
		
		nTXLanes = len(tx_lanes)
		
		self.TXLanesInUse = 0
		
		for i in range(16):
			tx_lane_switch[i] = 0
			
		for i in range(nTXLanes):
			tx_lane_switch[tx_lanes[i]] = i
			self.TXLanesInUse = (self.TXLanesInUse << 1) + 1
			
		sw = [0,0]		;
		for i in range(8):
			sw[0] = sw[0] + (tx_lane_switch[i+0]<<(i*4)) #TX0
			sw[1] = sw[1] + (tx_lane_switch[i+8]<<(i*4)) #TX1
		
		print "TX_SW0 : {0:08X}".format(sw[0])
		print "TX_SW1 : {0:08X}".format(sw[1])
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 16 ,[sw[0]]) #TX Stream Switchs 1
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 20 ,[sw[1]]) #TX Stream Switchs 2	

		#Channel Scaling
		
		if Mode == '204C':
			#Number of Lanes to Configurations possible 0,1,2,4,8,9,10,12,16
			LaneNumberMap ={0:0,1:1,2:2,3:4,4:4,5:8,6:8,7:8,8:8,9:9,10:10,11:12,12:12,13:16,14:16,15:16,16:16}
			DataRatePerChannel = (line_rate/1000)*64.0/66
			BitsPerChannel     = 64
		else:
			LaneNumberMap ={0:0,1:2,2:2,3:4,4:4,5:8,6:8,7:8,8:8,9:10,10:10,11:12,12:12,13:16,14:16,15:16,16:16}
			DataRatePerChannel = (line_rate/1000)*32.0/40
			BitsPerChannel     = 32
			
		LaneScale = {0:3,32:3,64:3,128:2,256:1,512:0} #FIFO based Scaler to 512bits
		nTXLanes1 = LaneNumberMap[nTXLanes]
		
		self.LanesToDrive           = nTXLanes
		self.LanesDriven            = nTXLanes1
		
		DataRateStream0    = 0
		DataRateStream1    = 0
		
		
		if nTXLanes1 > 8:		
			nTXBits_Ch1 = LaneScale[8*BitsPerChannel]
			nTXBits_Ch2 = LaneScale[(nTXLanes1-8)*BitsPerChannel]
			nTXStream1Enable = 0x6 #Enable, Select 0
			nTXStream2Enable = 0x7 #Enable, Select 1 
			DataRateStream0  = DataRateStream0 + 8*DataRatePerChannel
			DataRateStream1  = DataRateStream1 + (nTXLanes1-8)*DataRatePerChannel
		else:
			nTXBits_Ch1 =  LaneScale[nTXLanes1*BitsPerChannel]
			nTXBits_Ch2 =  LaneScale[0]
			nTXStream1Enable = 0x6    #Enable, Select 0
			nTXStream2Enable = 0x0    #Disable
			DataRateStream0  = DataRateStream0 + nTXLanes1*DataRatePerChannel			
	
		nRXBits_Ch1         = 0
		nRXBits_Ch2         = 0
		nRXStream1Enable    = 0
		nRXStream2Enable    = 0 
		DDRStream1_Inactive = 1
		DDRStream0_Inactive = 1
			
		
		#self.NumberofConverters_TX = nTXLanes1*converters_per_lane		
		#self.FramesPerSample_TX       = converters_per_lane/(BitsPerChannel/16)
		
		DDRStreamDataRate = 300*384.0/1000;
		
		#DDR Stream Switch and scale
		StreamConfig = 	(  (nTXBits_Ch1<<0 ) 
						+  (nTXBits_Ch2<<4 )
						+  (nRXBits_Ch1<<8 )
						+  (nRXBits_Ch2<<12)
						+  (nTXStream1Enable<<16)
						+  (nTXStream2Enable<<20)
						+  (nRXStream1Enable<<24)
						+  (nRXStream2Enable<<28)
						)
		DDRInConfig  =  (
							(DDRStream0_Inactive << 0)
						+	(DDRStream1_Inactive << 4)
						)
		StreamConfigMask = (0xF) | (0xF<<4) | (0xF<<16) | (0xF<<20)				
		StreamConfig = (StreamConfig & StreamConfigMask) | (self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG + 32 ,1) & (~StreamConfigMask))
		print "StreamConfig : {0:08X}".format(StreamConfig)
		
		print "Stream 0 : {0}/{1} Gbps {2:2.2f}%".format(DataRateStream0,DDRStreamDataRate,DataRateStream0*100.0/DDRStreamDataRate)
		print "Stream 1 : {0}/{1} Gbps {2:2.2f}%".format(DataRateStream1,DDRStreamDataRate,DataRateStream1*100.0/DDRStreamDataRate)
		
		#DDR Stream Switch and scale
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 32 ,[StreamConfig]) #<Channel Select and Scale>
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 36 ,[DDRInConfig])
		
	def SetupStreamSwitches_RX(self,Mode,rx_lanes,line_rate):
	
		print "RX Lanes : ",rx_lanes
		
		rx_lane_switch = range(16)
		nRXLanes = len(rx_lanes)
		
		self.RXLanesInUse = 0
		
		for i in range(16):
			rx_lane_switch[i] = 0

			
		for i in range(nRXLanes):
			rx_lane_switch[i] = rx_lanes[i]
			self.RXLanesInUse = (self.RXLanesInUse << 1) + 1		
		for i in range(nRXLanes,16):
			rx_lane_switch[i] = rx_lane_switch[0]
		self.RXValidLanes	  = self.RXLanesInUse	
		if Mode == '204C':
			#Duplicate RX LANE 0 to other lanes_in_use
			for i in range(nRXLanes,16):
				rx_lane_switch[i] = rx_lanes[0]
				self.RXLanesInUse = (self.RXLanesInUse << 1) + 1
			
		sw = [0,0]		;
		for i in range(8):
			sw[0] = sw[0] + (rx_lane_switch[i+0]<<(i*4)) #RX0
			sw[1] = sw[1] + (rx_lane_switch[i+8]<<(i*4)) #RX1
		
		print "RX_SW0 : {0:08X}".format(sw[0])
		print "RX_SW1 : {0:08X}".format(sw[1])
			
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 24 ,[sw[0]]) #RX Stream Switchs 1
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 28 ,[sw[1]]) #RX Stream Switchs 2

		#Channel Scaling
		
		if Mode == '204C':
			#Number of Lanes to Configurations possible 0,1,2,4,8,9,10,12,16
			LaneNumberMap ={0:0,1:1,2:2,3:4,4:4,5:8,6:8,7:8,8:8,9:9,10:10,11:12,12:12,13:16,14:16,15:16,16:16}
			DataRatePerChannel = (line_rate/1000)*64.0/66
			BitsPerChannel     = 64
		else:
			LaneNumberMap ={0:0,1:2,2:2,3:4,4:4,5:8,6:8,7:8,8:8,9:10,10:10,11:12,12:12,13:16,14:16,15:16,16:16}
			DataRatePerChannel = (line_rate/1000)*32.0/40
			BitsPerChannel     = 32
			
		LaneScale = {0:3,32:3,64:3,128:2,256:1,512:0} #FIFO based Scaler to 512bits

		nRXLanes1 			= LaneNumberMap[nRXLanes]
		self.LanesToCapture = nRXLanes
		self.LanesCaptured  = nRXLanes1		
			
		DataRateStream0    = 0
		DataRateStream1    = 0
		
		
		nTXBits_Ch1 = 0
		nTXBits_Ch2 = 0
		nTXStream1Enable = 0
		nTXStream2Enable = 0
		
		if nRXLanes1 > 8:		
			nRXBits_Ch1 = LaneScale[8*BitsPerChannel]
			nRXBits_Ch2 = LaneScale[(nRXLanes1-8)*BitsPerChannel]
			nRXStream2Enable = 0x2 #Enable, Select0
			nRXStream1Enable = 0x3 #Enable, Select1
			DDRStream1_Inactive = 0
			DDRStream0_Inactive = 0
			DataRateStream0  = DataRateStream0 + (nRXLanes1-8)*DataRatePerChannel
			DataRateStream1  = DataRateStream1 + 8*DataRatePerChannel
		else:
			nRXBits_Ch1 = LaneScale[nRXLanes1*BitsPerChannel]
			nRXBits_Ch2 = LaneScale[0]
			nRXStream2Enable = 0x2 #Enable, Select0
			nRXStream1Enable = 0x0 #Disable
			DDRStream1_Inactive = 0
			DDRStream0_Inactive = 1
			DataRateStream1  = DataRateStream1 + nRXLanes1*DataRatePerChannel
		
		#self.NumberofConverters_RX = nRXLanes1*converters_per_lane
		#self.NumberofConverters_TX = nTXLanes1*converters_per_lane
		
		#self.FramesPerSample_RX       = converters_per_lane/(BitsPerChannel/16)
		
		DDRStreamDataRate = 300*384.0/1000;
		
		#DDR Stream Switch and scale
		StreamConfig = 	(  (nTXBits_Ch1<<0 ) 
						+  (nTXBits_Ch2<<4 )
						+  (nRXBits_Ch1<<8 )
						+  (nRXBits_Ch2<<12)
						+  (nTXStream1Enable<<16)
						+  (nTXStream2Enable<<20)
						+  (nRXStream1Enable<<24)
						+  (nRXStream2Enable<<28)
						)
		DDRInConfig  =  (
							(DDRStream0_Inactive << 0)
						+	(DDRStream1_Inactive << 4)
						)
						
		StreamConfigMask = (0xF<<8) | (0xF<<12) | (0xF<<24) | (0xF<<28)				
		StreamConfig = (StreamConfig & StreamConfigMask) | (self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG + 32 ,1) & (~StreamConfigMask))
		
		print "StreamConfig : {0:08X}".format(StreamConfig)
		print "DDRInConfig  : {0:08X}".format(DDRInConfig )
		
		print "Stream 0 : {0}/{1} Gbps {2:2.2f}%".format(DataRateStream0,DDRStreamDataRate,DataRateStream0*100.0/DDRStreamDataRate)
		print "Stream 1 : {0}/{1} Gbps {2:2.2f}%".format(DataRateStream1,DDRStreamDataRate,DataRateStream1*100.0/DDRStreamDataRate)
		
		#DDR Stream Switch and scale
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 32 ,[StreamConfig]) #<Channel Select and Scale>
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 36 ,[DDRInConfig])
		
	def Setup_JESDC_TX(self,tx_lanes,line_rate,K):
	
		self.byteorder = '<'
		self.CaptureSyncMode = 5
		self.ConvertersPerFrame = (64/16)
		self.BitsPerLane     = 64
		
		#self.PLLReset()
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000000F]) #SYNC PINS		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*11 ,[0x00000080])#PLL CLK DIV
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*12  ,[0x00000000]) #TESTMODE
	
		
		
		self.SetupStreamSwitches_TX('204C',tx_lanes,line_rate)
	
		
		SYNC_IGNORE = (self.ReadControlRegister_P(self.JESD_BASE_ADDR_CONFIG + 4*1  ,1)>>16)&0xFFFF
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[SYNC_IGNORE|0x0000])  # Ignore Sync assert from 1		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[SYNC_IGNORE|0x0001])  # Reset JESD_ALL
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[SYNC_IGNORE|0x0000])  #		
		
		#TX Configuration
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x40 ,[self.TXLanesInUse&0xFF]) #Enable only one TX
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x34 ,[0x00000000]) #Subclass 1
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x38 ,[0x00000000]) #MetaMode : CRC
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x24 ,[0x00000002])	
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x30 ,[0x00000000+K])	 #E value
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x20 ,[0x00000001]) #Reset on parameter change	
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 + 0x20 ,[0x00000001]) #Reset on parameter change	
		time.sleep(1)
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 0x20 ,[0x00000000]) #Reset on parameter change
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 + 0x20 ,[0x00000000]) #Reset on parameter change	
		
	def Setup_JESDC_RX(self,rx_lanes,line_rate,K):
	
		self.byteorder = '<'
		self.CaptureSyncMode = 5
		self.ConvertersPerFrame = (64/16)
		self.BitsPerLane     = 64
		
		#self.PLLReset()
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000000F]) #SYNC PINS		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*11 ,[0x00000080])#PLL CLK DIV
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*12  ,[0x00000000]) #TESTMODE
			
		
		self.SetupStreamSwitches_RX('204C',rx_lanes,line_rate)
		
		SYNC_IGNORE = 0
		for i in rx_lanes:
			SYNC_IGNORE = SYNC_IGNORE + (1<<i)
		SYNC_IGNORE=(~SYNC_IGNORE)&0xFFFF
		print "{0:8X}".format(SYNC_IGNORE)
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*15  ,[SYNC_IGNORE]) # Ignore Sync assert from 1	
		
		SYNC_IGNORE = SYNC_IGNORE << 16
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[SYNC_IGNORE|0x0000])  # Ignore Sync assert from 1		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[SYNC_IGNORE|0x0001])  # Reset JESD_ALL
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1  ,[SYNC_IGNORE|0x0000])  #		
		
		#RX Configuration		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000002])  #Clear Capture
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000000])
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x40 ,[self.RXLanesInUse&0xFF]) #Enable  RX
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x34 ,[0x00000001]) #Subclass 0
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x38 ,[0x00000000]) #MetaMode : CRC
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x24 ,[0x00000003])	
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x64 ,[0x00000000])		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x30 ,[0x00000000+K]) #E Value
		
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x20 ,[0x00000001]) #Reset on parameter change			
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 + 0x20 ,[0x00000001]) #Reset on parameter change
		time.sleep(1)
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 + 0x20 ,[0x00000000]) #Reset on parameter change
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 + 0x20 ,[0x00000000]) #Reset on parameter change	

	def Setup_JESDB_TX(self,tx_lanes,line_rate,F=4,K=16,Scramble = 0):	
		
		M = 4
		Nt= 16
		N = 16		
		CS= Nt-N
		
		self.byteorder = '>'
		self.CaptureSyncMode = 5
		self.ConvertersPerFrame = (32/16)
		self.BitsPerLane     = 32
		
		#self.PLLReset()
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000000F]) #SYNC PINS		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*11 ,[0x00000080])#PLL CLK DIV
		
		self.SetupStreamSwitches_TX('204B',tx_lanes,line_rate)
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*15  ,[0x00000002]) # Ignore Sync assert from 1	
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020000]) 	
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020001])  # Reset JESD_ALL
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020000])  #		
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000002])  #Clear Capture
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  ,[0x00000000])
		
		#TX0 Configuration
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 + 8 ,[0x00000001]) # Support ILA
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +12 ,[Scramble]) # Scrambling dissabled
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +16 ,[0x00000000]) # Sysref once
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +20 ,[4]) # Multiframes in ILA = 4
		#self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +20 ,[K-1]) # Multiframes in ILA = 4
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +24 ,[0x00000000]) # Test mode = Normal operation
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +32 ,[F-1]) # Octets per Frame F
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +36 ,[K-1]) # Frames per Multiframe K
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +40 ,[self.TXLanesInUse&0xFF]) # Lanes in use
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +44 ,[0x00000001]) # Device subclass 1
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +515*4 ,[0x01000A55]) #   // L, DID, BID
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +516*4 ,[0x00101004]) #   // CS, N', N, M
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +517*4 ,[0x01000000]) #   // CF, HD, S, SCR
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +518*4 ,[0x0000A55A]) #   // RES1, RES2 checksum generated automatically
		
		#TX1 Configuration
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 + 8 ,[0x00000001]) # Support ILA
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +12 ,[Scramble]) # Scrambling dissabled
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +16 ,[0x00000000]) # Sysref once
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +20 ,[4]) # Multiframes in ILA = 4
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +24 ,[0x00000000]) # Test mode = Normal operation
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +32 ,[F-1]) # Octets per Frame F
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +36 ,[K-1]) # Frames per Multiframe K
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +40 ,[(self.TXLanesInUse>>8)&0xFF]) # Lanes in use
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +44 ,[0x00000001]) # Device subclass 1
		
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +515*4 ,[0x01000A55]) #   // L, DID, BID
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +516*4 ,[0x00101004]) #   // CS, N', N, M
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +517*4 ,[0x01000000]) #   // CF, HD, S, SCR
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +518*4 ,[0x0000A55A]) #   // RES1
		
	
		#Resetting both TX and RX
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +0x04 ,[0x00000001]) # Reset
		self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +0x04 ,[0x00000001]) # Reset	
	
	def Setup_JESDB_RX(self,rx_lanes,line_rate,F=4,K=16,Scramble = 0):
		
		M = 4
		Nt= 16
		N = 16		
		CS= Nt-N
		
		self.byteorder = '>'
		self.CaptureSyncMode = 5
		self.ConvertersPerFrame = (32/16)
		self.BitsPerLane     = 32
		
		#self.PLLReset()
		r = self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG + 4*2  ,1) #SYNC PINS
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[r|0xF]) #SYNC PINS			
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*11 ,[0x00000080])#PLL CLK DIV
		
		self.SetupStreamSwitches_RX('204B',rx_lanes,line_rate)
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*15  ,[0x00000002]) # Ignore Sync assert from 1	
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020000]) 	
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020001])  # Reset JESD_ALL
		#self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1   ,[0x00020000])  #		
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000002])  #Clear Capture
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  ,[0x00000000])
		
		
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x08 ,[0x00000001]) # Support ILA
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x0C ,[Scramble]) # Scrambling dissabled
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x10 ,[0x00000000]) # Sysref once
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x18 ,[0x00000000]) # Test mode = Normal operation
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x20 ,[F-1]) # Octets per Frame F=4
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x24 ,[K-1]) # Frames per Multiframe K=16
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x28 ,[self.RXLanesInUse&0xFF]) # Lanes in use
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x2C ,[0x00000001]) # Device subclass 
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x30 ,[0x00000000]) # Rx buffer delay
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x34 ,[0x00000000]) # Error Reporting
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x08 ,[0x00000001]) # Support ILA
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x0C ,[Scramble]) # Scrambling dissabled
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x10 ,[0x00000000]) # Sysref once
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x18 ,[0x00000000]) # Test mode = Normal operation
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x20 ,[F-1]) # Octets per Frame F=4
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x24 ,[K-1]) # Frames per Multiframe K=16
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x28 ,[(self.RXLanesInUse>>8)&0xFF]) # Lanes in use
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x2C ,[0x00000001]) # Device subclass 
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x30 ,[0x00000000]) # Rx buffer delay
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x34 ,[0x00000000]) # Error Reporting
		
		#Resetting both TX and RX
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x04 ,[0x00000001]) 
		self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x04 ,[0x00000001]) 
	#Setup_JESDB_RX
	
	def SetDDR1ForADCCapture(self,ddr_len):
	
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_DDRWADDR,[0x00000000])
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_DDRWLEN ,[ddr_len])
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_CONFIG,[0x00000001])		
	
	def doCapture(self,nSamples):
		#print "Capture"		
		 
		ddr_len = (nSamples*self.LanesCaptured*self.BitsPerLane)/384
		
		
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000000|(self.CaptureSyncMode<<4)])
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000002|(self.CaptureSyncMode<<4)])  #Clear Capture
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*3   , [nSamples]) #Samples to Capture by ADC	
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000000|(self.CaptureSyncMode<<4)])	

		self.SetDDR1ForADCCapture(ddr_len)	
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*10  , [0x00000001|(self.CaptureSyncMode<<4)])#Enable Capture
		
		i = 0
		
		while ((self.ReadControlRegister_Q(self.DDR1_BASE_ADDR + self.CMD_DDRTRIGREAD,1)&0x00000001==0) & (i<self.MaxWait)):
			i = i + 1
			
		if(i<self.MaxWait):
			return 0
		else:
			self.CaptureHealth()
			return 1
	
	
	def Read64Bit(self,base):
		n = self.ReadControlRegister_Q(base+4,1) 
		n = n*2**32 + self.ReadControlRegister_Q(base,1) 
		return n
		
	def	CaptureHealth(self):
		capH = self
		jesd_status      = capH.ReadControlRegister_Q(capH.JESD_BASE_ADDR_CONFIG + 80*4,1)
		samples_captured = capH.ReadControlRegister_Q(capH.JESD_BASE_ADDR_CONFIG + 85*4,1)
		mis_rx0          = capH.ReadControlRegister_Q(capH.JESD_BASE_ADDR_CONFIG + 81*4,1)
		mis_rx1          = capH.ReadControlRegister_Q(capH.JESD_BASE_ADDR_CONFIG + 82*4,1)
		mis_tx0          = capH.ReadControlRegister_Q(capH.JESD_BASE_ADDR_CONFIG + 83*4,1)
		mis_tx1          = capH.ReadControlRegister_Q(capH.JESD_BASE_ADDR_CONFIG + 84*4,1)
		
		log ("JESD_STATUS : {0:08X}".format(jesd_status))	
		print "JESD_SAMPLES CAPTURED : {0:d}".format(samples_captured)
		print "JESD_SAMPLES MIS_RX0: {0:d}".format(mis_rx0)
		print "JESD_SAMPLES MIS_RX1: {0:d}".format(mis_rx1)
		print "JESD_SAMPLES MIS_TX0: {0:d}".format(mis_tx0)
		print "JESD_SAMPLES MIS_TX1: {0:d}".format(mis_tx1)
		
		ddr0_status  = capH.ReadControlRegister_Q(capH.DDR0_BASE_ADDR + 28,1)
		ddr0_cyccntr = capH.ReadControlRegister_Q(capH.DDR0_BASE_ADDR + 32,1)
		ddr0_wbusy   = capH.ReadControlRegister_Q(capH.DDR0_BASE_ADDR + 36,1)
		ddr0_apunavl = capH.ReadControlRegister_Q(capH.DDR0_BASE_ADDR + 40,1)
		ddr0_rdunavl = capH.ReadControlRegister_Q(capH.DDR0_BASE_ADDR + 44,1)
		
		print "DDR0 : STATUS   :{0:08X}".format(ddr0_status)
		print "DDR0 : CYCCNTR  :{0:d}".format(ddr0_cyccntr)
		print "DDR0 : WBUSY    :{0:d}".format(ddr0_wbusy)
		print "DDR0 : APUAVL   :{0:d}".format(ddr0_apunavl)
		print "DDR0 : RDUAVL   :{0:d}".format(ddr0_rdunavl)
		
		ddr1_status  = capH.ReadControlRegister_Q(capH.DDR1_BASE_ADDR + 28,1)
		ddr1_cyccntr = capH.ReadControlRegister_Q(capH.DDR1_BASE_ADDR + 32,1)
		ddr1_wbusy   = capH.ReadControlRegister_Q(capH.DDR1_BASE_ADDR + 36,1)
		ddr1_apunavl = capH.ReadControlRegister_Q(capH.DDR1_BASE_ADDR + 40,1)
		ddr1_rdunavl = capH.ReadControlRegister_Q(capH.DDR1_BASE_ADDR + 44,1)
		
		print "DDR1 : STATUS   :{0:08X}".format(ddr1_status)
		print "DDR1 : CYCCNTR  :{0:d}".format(ddr1_cyccntr)
		print "DDR1 : WBUSY    :{0:d}".format(ddr1_wbusy)
		print "DDR1 : APUAVL   :{0:d}".format(ddr1_apunavl)
		print "DDR1 : RDUAVL   :{0:d}".format(ddr1_rdunavl)
		
			
		print "Fraction Busy 0 : {0:2.2f}".format(100.0*(ddr0_apunavl*1.0/ddr0_cyccntr))
		print "Fraction Busy 1 : {0:2.2f}".format(100.0*(ddr1_apunavl*1.0/ddr1_cyccntr))	
		
			
		stream_1_wch_vld = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+0*2)*4)
		stream_1_wch_cnt = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+1*2)*4)
		stream_1_rch_rdy = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+2*2)*4)
		stream_1_rch_cnt = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+3*2)*4)
		stream_0_wch_vld = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+4*2)*4)
		stream_0_wch_cnt = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+5*2)*4)
		stream_0_rch_rdy = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+6*2)*4)
		stream_0_rch_cnt = capH.Read64Bit(capH.JESD_BASE_ADDR_CONFIG + (64+7*2)*4)
		
		if stream_0_wch_cnt > 0:
			print "Stream 0 Write Channel Enabled : {0:d} Write : {1:d} Occupancy : {2:2.2f}".format(stream_0_wch_cnt,stream_0_wch_vld,100.0*(stream_0_wch_vld*1.0/stream_0_wch_cnt))
		
		if stream_0_rch_cnt > 0:
			print "Stream 0 Read Channel Enabled : {0:d}  Read : {1:d} Occupancy : {2:2.2f}".format(stream_0_rch_cnt,stream_0_rch_rdy,100.0*(stream_0_rch_rdy*1.0/stream_0_rch_cnt))
		
		if stream_1_wch_cnt > 0:
			print "Stream 1 Write Channel Enabled : {0:d} Write : {1:d} Occupancy : {2:2.2f}".format(stream_1_wch_cnt,stream_1_wch_vld,100.0*(stream_1_wch_vld*1.0/stream_1_wch_cnt))
		if stream_1_rch_cnt > 0:
			print "Stream 1 Read Channel Enabled : {0:d}  Read : {1:d} Occupancy : {2:2.2f}".format(stream_1_rch_cnt,stream_1_rch_rdy,100.0*(stream_1_rch_rdy*1.0/stream_1_rch_cnt))
		

						
	def readCaptureMem(self,SamplesRequired):
		nSamples  = int(math.ceil(math.ceil(SamplesRequired/24.0)))*24
		a = self.doCapture(nSamples)
		
		
		ddr_len = (nSamples*self.LanesCaptured*self.BitsPerLane)/384
		s = []
		
			
		if a == 0:
			words_to_read = int(round(ddr_len*384/32))
			s = self.Read_DDR(self.DDR1_BASE_ADDR,0x00000000,words_to_read)	

		return s
		
	def capture(self,SamplesRequired,offset):
		dt = np.dtype('uint32')	
		#dt = dt.newbyteorder(self.interfaceHandle.byteorder)		
		y = np.frombuffer(self.readCaptureMem(SamplesRequired+offset),dtype=dt)
		y = y[offset:]
		words_per_lane = int((self.BitsPerLane/32))
		
		laneWiseData = []		# 32bit data
		for i in range(self.LanesToCapture):
			perLaneData=[0]*(len(y)/self.LanesToCapture)
			for j in range(words_per_lane):
				perLaneData[j::words_per_lane]=y[j+(i*words_per_lane)::self.LanesCaptured*words_per_lane]
			laneWiseData.append(perLaneData)
		
		laneWiseData8Bit=[]
		for laneData in laneWiseData:
			laneData8Bit=[0]*(4*len(laneData))
			if self.jesdRxSettings['protocol']==0:
				laneData8BitPreOrder=list(np.frombuffer(np.asarray(laneData,'uint32'),dtype='uint8'))
				laneData8Bit[0::4]=laneData8BitPreOrder[3::4]
				laneData8Bit[1::4]=laneData8BitPreOrder[2::4]
				laneData8Bit[2::4]=laneData8BitPreOrder[1::4]
				laneData8Bit[3::4]=laneData8BitPreOrder[0::4]
			else:
				laneData8BitPreOrder=laneData[:]#list(np.frombuffer(np.asarray(laneData,'uint32'),dtype='uint8'))
				laneData8BitPreOrder[::2]=laneData[1::2]
				laneData8BitPreOrder[1::2]=laneData[0::2]
				laneData8Bit=list(np.frombuffer(np.asarray(laneData8BitPreOrder,'uint32'),dtype='uint8'))
				# laneData8Bit[0::4]=laneData8BitPreOrder[0::4]
				# laneData8Bit[1::4]=laneData8BitPreOrder[1::4]
				# laneData8Bit[2::4]=laneData8BitPreOrder[2::4]
				# laneData8Bit[3::4]=laneData8BitPreOrder[3::4]
				
				#laneData8Bit[0::8]=laneData8BitPreOrder[4::8]
				#laneData8Bit[1::8]=laneData8BitPreOrder[5::8]
				#laneData8Bit[2::8]=laneData8BitPreOrder[6::8]
				#laneData8Bit[3::8]=laneData8BitPreOrder[7::8]
				#laneData8Bit[4::8]=laneData8BitPreOrder[0::8]
				#laneData8Bit[5::8]=laneData8BitPreOrder[1::8]
				#laneData8Bit[6::8]=laneData8BitPreOrder[2::8]
				#laneData8Bit[7::8]=laneData8BitPreOrder[3::8]
			laneWiseData8Bit.append(laneData8Bit)
		return laneWiseData8Bit
	
						
	def captureBase(self,SamplesRequired):
	
		nSamples  = int(math.ceil(math.ceil(SamplesRequired/24.0)))*24
		a = self.doCapture(nSamples)
		
		
		ddr_len = (nSamples*self.LanesCaptured*self.BitsPerLane)/384
		s = []
		
			
		if a == 0:
			words_to_read = int(round(ddr_len*384/32))
			s = self.Read_DDR(self.DDR1_BASE_ADDR,0x00000000,words_to_read)	
			
		r = []
		
		import numpy as np	
		dt = np.dtype('int32')	
		#dt = dt.newbyteorder(self.interfaceHandle.byteorder)		
		y = np.frombuffer(s,dtype=dt)
		
		words_per_lane = int((self.BitsPerLane/32))
		for i in range(self.LanesToCapture):
			for j in range(words_per_lane):
				r.append(y[(i*words_per_lane+j):SamplesRequired*self.LanesCaptured*words_per_lane:self.LanesCaptured*words_per_lane])
			
		return r
	
	def CaptureToFile(self,nSamples,nChannels,ChannelsRequired,filename):
	
		ddr_len = (nSamples*(16*nChannels))/384
		self.doCapture(nSamples,nChannels)	
	
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_CONFIG,[0x00000000])
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_DDRRLEN ,[ddr_len])
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_DDRWLEN ,[ddr_len])
		self.WriteControlRegister(self.DDR1_BASE_ADDR + self.CMD_DDRRADDR,[0x00000000]) #TRIGGERS READ
		
		
		words_to_read = ddr_len*384/32
		
		size_to_read = 65536*4
		
		print("Removing file: " + os.path.abspath(filename))
		os.remove(os.path.abspath(filename))
		with open(filename,'ab') as f:
		
			while(words_to_read>0):
			
				print "Words Left : " ,words_to_read
				words_read = size_to_read
				if (words_to_read < size_to_read):
					words_read = words_to_read
				words_to_read = words_to_read - words_read
				
				t0 = time.time()		
				s= self.ReadControlRegister (self.DDR1_BASE_ADDR + self.CMD_DDRRDFIFO,words_read)	
				t1 = time.time()
				total_n = t1-t0			
				
				bytes = len(s)		

				
				print len(s)
				print total_n
				print "Data Rate : " , (words_read*4/total_n)/(1024*1024) , " MBps"	
				
				import numpy as np	
				dt = np.dtype('int16')	
				dt = dt.newbyteorder('>')						
				
				y = np.frombuffer(s,dtype=dt)
				r = []
				for i in ChannelsRequired:
					r.append(y[i:nSamples*nChannels:nChannels].tolist())
			
				r=np.transpose(r)
				np.savetxt(f,r,fmt="%d",delimiter=',')
		
	def UpLoadDACData_0_file(self,filename):
		import pickle
		print "Uploading from file : " ,filename
		y = pickle.load(open(filename,"rb"))
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_CONFIG,[0x00000000])
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_DDRWADDR,[0x0000000])
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_DDRWRFIFO,y)			
		return len(y)
		
	def StartDAC_0(self,SamplesToPlay):		
	
		print "Samples to Play : " , SamplesToPlay
		ddr_words_to_read = SamplesToPlay*32/384
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_DDRRLEN ,[ddr_words_to_read])
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_CONFIG,[0x00000003])
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_DDRRADDR,[0x00000000])		
		print "Trigger"
		self.ReadControlRegister (self.DDR0_BASE_ADDR + self.CMD_DDRTRIGREAD,1)	
		

	def StartDAC(self,nparray,force=1):
		"Running DAC"
		SamplesToPlay = len(nparray) 
		self.Load_DDR(self.DDR0_BASE_ADDR,0,nparray)
		self.StartDAC_0(SamplesToPlay)
		
		if force == 1:
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x000010F]) #SYNC PINS	
		else :
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x000004F]) #SYNC PINS

		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*13 ,[0x00000001]) #DRIVE_CONTROL			
			
	def StopDACSamples(self):
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_CONFIG,[0x00000001])
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*13 ,[0x00000000]) #DRIVE_CONTROL
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000000F]) #SYNC PINS
		self.WriteControlRegister(self.DDR0_BASE_ADDR + self.CMD_CONFIG,[0x00000000])
	
	def print_buffer(self,s,bitsize=32):
		bytes = len(s)			
		bytespersample    = bitsize/8
		for i in range(0,len(s)/bytespersample):
			H = "".join(['%02X' % ord(b) for b in s[i*bytespersample:(i*bytespersample+bytespersample)]]) 
			H =  "{0:03d} ".format(i) + H
			print H
			
			
	def print_bits (self,bits,value):
		for bit in bits:
			if value&(1<<bit) != 0:
				state = "SET" 
				s = '%s : %s' % (state,bits[bit]) 
				critical(s) 
			else:
				state = "CLR" 
				s = '%s : %s' % (state,bits[bit])
				info(s) 
				
	def STAT_STATUS(self,ch='A'):
	
		if ch == 'A':
			base = self.JESD_BASE_ADDR_RX0
		else :
			base = self.JESD_BASE_ADDR_RX1
			
		value = self.ReadControlRegister_Q(base+0x60,1)
		
		bits = { 
				0 : "Interrupt pending",
				1 : "SYSREF captured",
				2 : "SYSREF error. A sysref was detected out of phase",
				4 : "64b66b Sync Header Lock Status Sync Header lock achieved on all lanes." ,
				5 : "Multi-block Lock Status",
				10 : "Buffer overflow error"
				}
		self.print_bits (bits,value)
		
	def STAT_IRQ(self,ch='A'):

		if ch == 'A':
			base = self.JESD_BASE_ADDR_RX0
		else :
			base = self.JESD_BASE_ADDR_RX1
			
		value = self.ReadControlRegister_Q(base+0x68,1)
		
		bits = {
				1 : "SYSREF Received Interrupt triggered" ,
				2 : "SYSREF Error Interrupt triggered" ,
				4 : "64b66b Sync Header Lock Status Interrupt triggered" ,
				5 : "Multi-block Lock Status Interrupt triggered" ,
				6 : "Block Sync Error detected Interrupt triggered" ,
				7 : "Multi-block Error detected Interrupt triggered",
				8 : " CRC Error detected Interrupt triggered" ,
				9 : "TBD FEC Error detected Interrupt triggered" ,
				10 : "Overflow Error Interrupt triggered" 
				} 
		self.print_bits (bits,value)
		
	def STAT_JESD(self,ch='A'):
		value = self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG+80*4,1) 
		bits = {
				31: "rxblock_sync[15]",
				30: "rxblock_sync[14]",
				29: "rxblock_sync[13]",
				28: "rxblock_sync[12]",
				27: "rxblock_sync[11]",
				26: "rxblock_sync[10]",
				25: "rxblock_sync[9]",
				24: "rxblock_sync[8]",				
				23: "rxblock_sync[7]",
				22: "rxblock_sync[6]",
				21: "rxblock_sync[5]",
				20: "rxblock_sync[4]",
				19: "rxblock_sync[3]",
				18: "rxblock_sync[2]",
				17: "rxblock_sync[1]",
				16: "rxblock_sync[0]",
				14: "pll_clk_div_out",
				9: "tx_sync",
				8: "rx_sync",
				7: "rx_tvalid",
				6: "tx_tready",
				5: "rx_aresetn",
				4: "tx_aresetn",
				3: "gt_powergood",
				2: "common0_qpll0_lock_out",
				1: "gt_resetdone_rx",
				0: "gt_resetdone_tx"
		}
		self.print_bits(bits, value)
	
	def LINK_JESDB(self,ch='A'):
		if ch == 'A':
			base = self.JESD_BASE_ADDR_RX0
		else :
			base = self.JESD_BASE_ADDR_RX1
			
		value = self.ReadControlRegister_Q(base+0x1C,1) 
		
		bits = {
				31 : "Lane Alignment Error Detected Alarm",
				30 : "SYSREF LMFC Alarm",
				29 : "RX Buffer Overflow Alarm",
				23 : "L7 Unexpected K-character(s) received",		
				22 : "L7 Disparity Error(s) received",
				21 : "L7 Not in Table Error(s) received",
				20 : "L6 Unexpected K-character(s) received",		
				19 : "L6 Disparity Error(s) received",
				18 : "L6 Not in Table Error(s) received",		
				17 : "L5 Unexpected K-character(s) received",		
				16 : "L5 Disparity Error(s) received",
				15 : "L5 Not in Table Error(s) received",
				14 : "L4 Unexpected K-character(s) received",		
				13 : "L4 Disparity Error(s) received",
				12 : "L4 Not in Table Error(s) received",
				11 : "L3 Unexpected K-character(s) received",		
				10 : "L3 Disparity Error(s) received",
				9 : "L3 Not in Table Error(s) received",
				8 : "L2 Unexpected K-character(s) received",		
				7 : "L2 Disparity Error(s) received",
				6 : "L2 Not in Table Error(s) received",		
				5 : "L1 Unexpected K-character(s) received",		
				4 : "L1 Disparity Error(s) received",
				3 : "L1 Not in Table Error(s) received",
				2 : "L0 Unexpected K-character(s) received",		
				1 : "L0 Disparity Error(s) received",
				0 : "L0 Not in Table Error(s) received"
		}
		self.print_bits(bits, value)
		
	def SYNC_JESDB(self,ch='A'):
		if ch == 'A':
			base = self.JESD_BASE_ADDR_RX0
		else :
			base = self.JESD_BASE_ADDR_RX1
			
		value = self.ReadControlRegister_Q(base+0x38,1) 
		bits = {
				1 : " A SYSREF event has been captured",		
				0 : "Link SYNC achieved"
		}
		self.print_bits(bits, value)
		
	def DEBUG_JESDB(self,ch='A'):
	
		if ch == 'A':
			base = self.JESD_BASE_ADDR_RX0
		else :
			base = self.JESD_BASE_ADDR_RX1
			
		value = self.ReadControlRegister_Q(base+0x3C,1) 
		bits = {
				31 : "L7 Start of Data was Detected ",		
				30 : "L7 Start of ILA was Detected",
				29 : "L7 Lane has Code Group Sync",		
				28 : "L7 Lane is currently receiving K28.5's (BC alignment characters)",
				27 : "L6 Start of Data was Detected ",		
				26 : "L6 Start of ILA was Detected",
				25 : "L6 Lane has Code Group Sync",		
				24 : "L6 Lane is currently receiving K28.5's (BC alignment characters)",
				23 : "L5 Start of Data was Detected ",		
				22 : "L5 Start of ILA was Detected",
				21 : "L5 Lane has Code Group Sync",		
				20 : "L5 Lane is currently receiving K28.5's (BC alignment characters)",
				19 : "L4 Start of Data was Detected ",		
				18 : "L4 Start of ILA was Detected",
				17 : "L4 Lane has Code Group Sync",		
				16 : "L4 Lane is currently receiving K28.5's (BC alignment characters)",		
				15 : "L3 Start of Data was Detected ",		
				14 : "L3 Start of ILA was Detected",
				13 : "L3 Lane has Code Group Sync",		
				12 : "L3 Lane is currently receiving K28.5's (BC alignment characters)",
				11 : "L2 Start of Data was Detected ",		
				10 : "L2 Start of ILA was Detected",
				9 : "L2 Lane has Code Group Sync",		
				8 : "L2 Lane is currently receiving K28.5's (BC alignment characters)",
				7 : "L1 Start of Data was Detected ",		
				6 : "L1 Start of ILA was Detected",
				5 : "L1 Lane has Code Group Sync",		
				4 : "L1 Lane is currently receiving K28.5's (BC alignment characters)",
				3 : "L0 Start of Data was Detected ",		
				2 : "L0 Start of ILA was Detected",
				1 : "L0 Lane has Code Group Sync",		
				0 : "L0 Lane is currently receiving K28.5's (BC alignment characters)"
		}
		self.print_bits(bits, value)	
	def STAT_StreamMapper(self):
		value = self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG+87*4,1) 
		bits = {
				31 : "tx_tdata_1_wvalid[1]" ,
				30 : "wready[1]           " , 
				29 : "tx_tdata_1_wvalid[0]" ,
				28 : "wready[0]           " ,
				27 : "jesd_tx_ready_i[1]  " ,
				26 : "jesd_tx_valid_i[1]  " ,
				25 : "jesd_tx_ready_i[0]  " ,
				24 : "jesd_tx_valid_i[0]  " ,
				23 : "rx_data_1_rready[1] " ,
				22 : "rx_data_1_rvalid[1] " ,
				21 : "rx_data_1_rready[0] " ,
				20 : "rx_data_1_rvalid[0] " ,
				19 : "jesd_rx_ready_i[1]  " ,
				18 : "jesd_rx_valid_i[1]  " ,
				17 : "jesd_rx_ready_i[0]  " ,
				16 : "jesd_rx_valid_i[0]  " ,
				15 : "wr_en[3]            " ,
				14 : "wr_en[2]            " ,
				13 : "wr_en[1]            " ,
				12 : "wr_en[0]            " ,
				11 : "rd_en[3]            " , 
				10 : "rd_en[2]            " , 
				9 : "rd_en[1]            " , 
				8 : "rd_en[0]            " , 
				7 : "full[3]             " , 
				6 : "full[2]             " , 
				5 : "full[1]             " , 
				4 : "full[0]             " , 
				3 : "empty[3]            " ,  
				2 : "empty[2]            " ,  
				1 : "empty[1]            " ,  
				0 : "empty[0]            " 
		}
		self.print_bits(bits, value)
	def STAT_JESDSub(self):
		value = self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG+88*4,1) 
		bits = {
		    16 : "tx_soemb_capture",
            15 : "drive_enable_c  ",
            14 : "tx_soemb_i[0]   ",
            13 : "rx_soemb_capture",
            12 : "tdd_edge_capture",
			11 : "stream_rvalid_1" ,  
			10 : "stream_rready_1" , 
			9  : "stream_rvalid_0" , 
			8  : "stream_rready_0" ,
			7  : "stream_wvaild_1" ,
			6  : "stream_wready_1" ,
			5  : "stream_wvaild_0" ,
			4  : "stream_wready_0" ,
			3  : "drive_enable   " , 
			2  : "capture_on     " , 
			1  : "capture_enable " , 
			0  : "en_capture     "    
		}
		self.print_bits(bits, value)
		
	#setLaneRate: Does the Lane rate configuration for lane.
	#fpgaRxConfig: This should configure the LMFS parameters and lane enables for FPGA JESD RX.
	#fpgaTxConfig: This should configure the LMFS parameters and lane enables for FPGA JESD TX.
	#selectRxLanes: selects the RX lanes to capture.
	#selectTxLanes: selects the TX lanes to capture


	def setLaneRate(self,LaneRate=9830.4,ref_clk  = 245.76):
		self.LaneRate       = LaneRate
		self.PLLReset()
		self.JESD_Reset()	
		o,h,N=self.find_pll_setting(LaneRate,ref_clk)
		self.Change_TXDIV(o)
		self.ChangePLLRateMode(h)
		self.ChangePLLRate(N)

	def setLaneRateOld(self,LaneRate=9830.4):
		self.LaneRate       = LaneRate
		ref_clk  		    = 245.76
		if LaneRate>=9830.4:
			pll_div             = int(round(LaneRate/ref_clk,4))
			self.Change_TXDIV(1)
		else:
			pll_div             = int(round(LaneRate/ref_clk*2,4))
			self.Change_TXDIV(2)
		self.PLLReset()
		self.JESD_Reset()
		self.ChangePLLRate(pll_div)
		
	def fpgaRxConfig(self,convertersPerLane=None,F=None,K=None,scrambler=None,jesdProtocol=None):
		if convertersPerLane!=None:
			self.jesdRxSettings['convertersPerLane']=convertersPerLane
		if scrambler!=None:
			self.jesdRxSettings['scr']=scrambler
		if F!=None:
			self.jesdRxSettings['F']=F
		if K!=None:
			self.jesdRxSettings['K']=K
		if jesdProtocol!=None:
			self.jesdRxSettings['protocol']=jesdProtocol
	#fpgaRxConfig
		
	def fpgaTxConfig(self,convertersPerLane=None,F=None,K=None,scrambler=None,jesdProtocol=None):
		if convertersPerLane!=None:
			self.jesdTxSettings['convertersPerLane']=convertersPerLane
		if scrambler!=None:
			self.jesdTxSettings['scr']=scrambler
		if F!=None:
			self.jesdTxSettings['F']=F
		if K!=None:
			self.jesdTxSettings['K']=K
		if jesdProtocol!=None:
			self.jesdTxSettings['protocol']=jesdProtocol
	#fpgaTxConfig
		
	def selectRxLanes(self,rx_lanes):		
		converters_per_lane= self.jesdRxSettings['convertersPerLane']
		F = self.jesdRxSettings['F']
		K = self.jesdRxSettings['K']
		Scramble = self.jesdRxSettings['scr']
		if self.jesdRxSettings['protocol']==0:
			self.Setup_JESDB_RX(rx_lanes,self.LaneRate,F,K,Scramble)
		else:
			self.Setup_JESDC_RX(rx_lanes,self.LaneRate,K)
	#selectRxLanes
		
	def selectTxLanes(self,tx_lanes):	
		converters_per_lane = self.jesdTxSettings['convertersPerLane']
		F = self.jesdTxSettings['F']
		K = self.jesdTxSettings['K']
		Scramble = self.jesdTxSettings['scr']
		if self.jesdTxSettings['protocol']==0:
			self.Setup_JESDB_TX(tx_lanes,self.LaneRate,F,K,Scramble)
		else:
			self.Setup_JESDC_TX(tx_lanes,self.LaneRate,K)
	#selectTxLanes

	def Check_PHY_TX_Driver_Settings(self,lanes):

		PHY = [self.JESD_BASE_ADDR_PHY0,self.JESD_BASE_ADDR_PHY1]
		PRECURSOR    = 0x418
		POSTCURSOR  = 0x414
		DIFFCTRL    = 0x508
		PD          = 0x504
		for l in lanes:
			phy = l/8
			tr  = l%8
			self.WriteControlRegister (PHY[phy] + 0x24 ,[tr]) # Select TRX Interface 
			
			v = self.ReadControlRegister_Q(PHY[phy]+DIFFCTRL,1) 		
			info("Lane {1} : TX DIFFCTRL 0x{0:02X}".format(v,l))
			v = self.ReadControlRegister_Q(PHY[phy]+PRECURSOR,1) 		
			info("Lane {1} : TX PRECURSOR 0x{0:02X}".format(v,l))
			v = self.ReadControlRegister_Q(PHY[phy]+POSTCURSOR,1) 		
			info("Lane {1} : TX POSTCURSOR 0x{0:02X}".format(v,l))
			v = self.ReadControlRegister_Q(PHY[phy]+PD,1) 		
			info("Lane {1} : TX PD 0x{0:02X}".format(v,l))
			
	def powerDownLanes(self,lanes,powerDown=True):
		PHY = [self.JESD_BASE_ADDR_PHY0,self.JESD_BASE_ADDR_PHY1]
		PD          = 0x504
		for l in lanes:
			phy = l/8
			tr  = l%8
			self.WriteControlRegister (PHY[phy] + 0x24 ,[tr]) # Select TRX Interface 
			if powerDown==True:
				v = self.WriteControlRegister(PHY[phy]+PD, 3) 
			else:
				v = self.WriteControlRegister(PHY[phy]+PD, 0) 
	#powerDownLanes	

	def Set_PHY_TX_Driver_Settings(self,lanes,TXDIFFCTRL=0xC0,TXPRECURSOR=0,TXPOSTCURSOR=0,TXPD=0):
		
		PHY = [self.JESD_BASE_ADDR_PHY0,self.JESD_BASE_ADDR_PHY1]
		PRECURSOR    = 0x418
		POSTCURSOR  = 0x414
		DIFFCTRL    = 0x508
		PD          = 0x504
		for l in lanes:
			phy = l/8
			tr  = l%8
			self.WriteControlRegister (PHY[phy] + 0x24 ,[tr]) # Select TRX Interface 
			
			v = self.WriteControlRegister(PHY[phy]+DIFFCTRL   , TXDIFFCTRL) 		
			v = self.WriteControlRegister(PHY[phy]+PRECURSOR  , TXPRECURSOR) 		
			v = self.WriteControlRegister(PHY[phy]+POSTCURSOR , TXPOSTCURSOR) 	
			v = self.WriteControlRegister(PHY[phy]+PD         , TXPD       ) 
			
	def ConfigurePulseGen(self,id,period_ms,pulse_pattern_ms):
		R = self.ReadControlRegister_Q(self.JESD_BASE_ADDR_CONFIG + 4*1 ,1)
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*1 ,[R|0x400]) #Trigger Source	
		
		period = int(period_ms*1e-3*245.76e6)
		start  = [period+1]*4
		stop   = [period+1]*4
		for i in range(len(pulse_pattern_ms)):
			start[i]  = int(pulse_pattern_ms[i][0]*1e-3*245.76e6+1)
			stop[i]   = int(pulse_pattern_ms[i][1]*1e-3*245.76e6+1)

		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 1 + 10*id),period)
		
		for i in range(len(start)):
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 2 + i+ 10*id), start[i])
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 6 + i+ 10*id),stop[i])

	def StartPulseGen(self,mode='free'):
		self.StopPulseGen()
		trigger_mode = {'dac_sync' : 0 , 'capture_sync': 1 , 'free' : 2, 'rx_sync' : 3  }
		mode = trigger_mode[mode]
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 0),((4+mode)<<0))
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 10),((4+mode)<<0))
		
	def StopPulseGen(self):
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 0), (0x00<<0)) #Disable
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*(16 + 10), (0x00<<0)) #Disable

	#Temporary function to trigger DAC Data after Start_DAC / sendSingleTone functions are called
	def TriggerDAC(self):
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*13, 0) 
		self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG + 4*13, 1) 

	def find_pll_setting(self,line_rate,ref_clk):
		
		pll_range = (9800,16375)
		N_range   = (16,160)
		out_div_options   = {1:0,2:1,4:2,8:3,16:4,32:5}
		half_rate_options = {2:0,1:1}
		
		
		out_div   = None
		half_rate = None
		pll_rate  = None
		N         = None
		M         = None
		for h in half_rate_options:
			flag = 0
			for o in out_div_options:
				pll_rate = (line_rate/2)*o*h
				print o,pll_rate
				if pll_rate > pll_range[0] and pll_rate < pll_range[1]:		
					if h == 1 and o > 1:
						h = 2
						o = o/2
					out_div    = o
					half_rate  = h
					print "PLL Rate Configured : {0}".format(pll_rate)
					flag = 1
					break
			if flag==1:
				break
		
		import math

		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY0 + 0x20 ,[0]) # Select Common Interface 0
		r = self.ReadDRPCommonRegister(self.JESD_BASE_ADDR_PHY0,0x18)
		ref_div_options = {16:1,0:2,1:3,2:4}
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_PHY1 + 0x20, [0])
		self.WriteDRPCommonRegister(self.JESD_BASE_ADDR_PHY1,0x18,r)
		
		self.WriteControlRegister (self.JESD_BASE_ADDR_PHY0 + 0x20 ,[1]) # Select Common Interface 0
		r1 = self.ReadDRPCommonRegister(self.JESD_BASE_ADDR_PHY0,0x18)
		
		self.WriteControlRegister(self.JESD_BASE_ADDR_PHY1 + 0x20, [1])
		self.WriteDRPCommonRegister(self.JESD_BASE_ADDR_PHY1,0x18,r1)
		
		r = (r>>7)&0x1F
		r = ref_div_options[r]
		
		N_try = pll_rate/(ref_clk/r)
		if (N_try - int(N_try)) < 0.01:
			print N_try
			if (N_try >= N_range[0] and N_try <= N_range[1]):
				N = int(N_try)
				
		print "Selected OUTDIV   {0}".format(out_div)
		print "Selected HalfRate {0}".format(half_rate)
		print "Selected N        {0}".format(N)
		
		return out_div,half_rate_options[half_rate],N
	
	def ChangePLLRateMode(self,full_rate):
		PHYS = [self.JESD_BASE_ADDR_PHY0,self.JESD_BASE_ADDR_PHY1]
		
		for PHY in PHYS:
			nC = self.ReadControlRegister_P(PHY + 0x08 ,1)
			for n in range(nC):
				self.WriteControlRegister (PHY + 0x20 ,[n]) # Select Common Interface
				self.WriteDRPCommonRegister(PHY,0x0E,full_rate) 		
			
			
	def CheckConnection(self):
		self.bitFileVersion=self.ReadControlRegister_Q(self.CONFIG_BASE_ADDR + 4*8, 1)
		V = hex(self.bitFileVersion)
		info('Version : {0}'.format(V))
		if V[5:] in ['204c','204b'] or V[2:6] in ['204c','204b']:
			info("Connected to Capture Card")
			r = True
		else:
			error("Could not connect to capture card. Reset Card and Reconnect( myfpga.Reconnect() )")
			r = False
		return r
		
	def checkRxSync(self,protocol = -1):
		if(protocol == -1):
			protocol	=	self.jesdRxSettings['protocol']
		if(protocol == 0):
			if(self.RXValidLanes <= 255):
				rx_sync_1 = (self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0 + 0x38,1))&0x1
				rx_sync	  = [rx_sync_1,rx_sync_1] 	
			else:
				rx_sync	=	[0,0]
				rx_sync[0]	= (self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0 + 0x38,1))&0x1
				rx_sync[1]	= (self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX1 + 0x38,1))&0x1
			if ((rx_sync[0] == 1) and (rx_sync[1]==1)):
				log('Rx Sync is achieved')
			else:
				error('Rx Sync failed')
				self.getRxSyncErrors(protocol)
		elif(protocol == 2):
			self.getRxSyncErrors(protocol)
	
	def getRxSyncErrors(self,protocol=-1):
		if(protocol==-1):
			protocol	=	self.jesdRxSettings['protocol']
		if(protocol==0):
			BIT_ERROR_MAP = {'0':'Not in table error','1':'Disparity Error','2':'Unexpected K-Character received'}
			if(self.RXValidLanes <=255):
				errorStatus		= self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0+0x1C,1)
			else:
				errorStatus1	= self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0+0x1C,1)
				errorStatus2	= self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX1+0x1C,1)
				errorStatus		= (errorStatus1 & (0xffffff))+((errorStatus2 & (0xffffff))<<24)
			
			validLanes		= int(np.log2(self.RXValidLanes+1))
			laneErrorStatus =	[]
			for i in range(validLanes):
				laneErrorStatus.append((errorStatus>>(i*3))&(0x7))
			
					
			for i in range(len(laneErrorStatus)):
				syncError 	=	laneErrorStatus[i]
				if(syncError == -1):
					pass
				elif(syncError==0):
					log('Lane '+str(i)+' has no errors')
				else:
					syncError	=	(format(syncError,'#05b'))[2:]
					syncError 	=	syncError[::-1]
					
					print_error	=	[]
					for bit in range(len(syncError)):
						if(int(syncError[bit]) == 1):
							print_error.append(BIT_ERROR_MAP[str(bit)])
					
					error('Lane '+str(i)+' errors: ')
					for prerr in print_error:
						error(prerr)
		elif(protocol==2):
			if(self.RXValidLanes <=255):
				errorStatus		= self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0+0x54,1)
				syncHeaderStatus	=	errorStatus&0xff
				multiBlockAlignStatus=	(errorStatus>>16)&0xff
			else:
				errorStatus1	= self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0+0x54,1)
				errorStatus2	= self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX1+0x54,1)
				syncHeaderStatus= (errorStatus1&0xff)+((errorStatus2&0xff)<<8)
				multiBlockAlignStatus	=	((errorStatus1>>16)&0xff)+(((errorStatus2>>16)&0xff)<<8)
			
			validLanes		=int(np.log2(self.RXValidLanes+1))
			syncHeaderBit	=	format(syncHeaderStatus,'#016b')[2:][::-1]
			mbHeaderBit		=	format(multiBlockAlignStatus,'#016b')[2:][::-1]
			
			for i in range(validLanes):
				syncStatus	=''
				mbStatus	=''
				if(syncHeaderBit[i]==0):
					syncStatus	=	'Sync Header Lock not achieved'
				else:
					syncStatus	=	'Sync Header Lock achieved'
				if(mbHeaderBit[i]==0):
					mbStatus	=	'Multi Block Alignment not achieved'
				else:
					mbStatus	=	'Multi Block Alignment Status Achieved'
				
				log('lane'+str(i)+':'+syncStatus+';'+mbStatus)
				
	def resetJesdTx(self,protocol=0):
		if(protocol == 0):
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +0x04 ,[0x00000001]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +0x04 ,[0x00000001]) # Reset	
			time.sleep(1)
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +0x04 ,[0x00000000]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +0x04 ,[0x000000000]) # Reset	
			
			val = self.ReadControlRegister_P(self.JESD_BASE_ADDR_TX0 + 0x04,1)
			
		elif(protocol == 2):
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +0x20 ,[0x00000001]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +0x20 ,[0x00000001]) # Reset	
			time.sleep(1)
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX0 +0x20 ,[0x00000000]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_TX1 +0x20 ,[0x000000000]) # Reset	
			
			val = self.ReadControlRegister_P(self.JESD_BASE_ADDR_TX0 + 0x20,1)
			
		return val
	
	def resetJesdRx(self,protocol=0):
		if(protocol == 0):
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x04 ,[0x00000001]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x04 ,[0x00000001]) # Reset	
			time.sleep(1)
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x04 ,[0x00000000]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x04 ,[0x000000000]) # Reset	
			
			val = self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0 + 0x04,1)
		elif(protocol == 2):
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x20 ,[0x00000001]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x20 ,[0x00000001]) # Reset	
			time.sleep(1)
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX0 +0x20 ,[0x00000000]) # Reset
			self.WriteControlRegister(self.JESD_BASE_ADDR_RX1 +0x20 ,[0x000000000]) # Reset	
			
			val = self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0 + 0x20,1)
			
		return val
		
	def fpgaSysref(self,pinSysref = True):
		if(pinSysref):
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG +1*4,[0x0000])
		else:
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG +1*4,[0x0200])
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG +1*4,[0x0a00])
			self.WriteControlRegister(self.JESD_BASE_ADDR_CONFIG +1*4,[0x0200])
			
	def fpgaSysrefCheck(self,protocol=-1):
		if(protocol==-1):
			protocol = self.jesdTxSettings['protocol']
			
		if(protocol==2):
			r = self.ReadControlRegister_P(self.JESD_BASE_ADDR_TX0+0x60,1)
			txflag = (r>>1)&0x1
			r = self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0+0x60,1)
			rxflag = (r>>1)&0x1
		elif(protocol==0):
			r = self.ReadControlRegister_P(self.JESD_BASE_ADDR_TX0+0x38,1)
			txflag= (r>>16)&0x1
			r = self.ReadControlRegister_P(self.JESD_BASE_ADDR_RX0+0x38,1)
			rxflag= (r>>16)&0x1	
		if(txflag ==0):
			error('FPGA Tx did not capture sysref')
		else:
			log('FPGA Tx sysref captured')
		if(rxflag==0):
			error('FPGA Rx did not capture sysref')
		else:
			log('FPGA Rx sysref captured')
	
	
		