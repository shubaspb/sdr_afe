from globalDefs import *

class DeviceConstants(object):

	#Simulation mode configurations
	SIM_MODE_DEVICE = 0
	SIM_MODE_FPGA   = 1
	
	ADC_FULL_RATE_MHZ= 3000
	ADC_HALF_RATE_MHZ= 1500
	
	
	#ADC Mode configurations
	ADC_FULL_RATE_MODE = 0
	ADC_HALF_RATE_MODE = 1
	
	#RXTOP IDs
	RXTOP_DIG_0   = 0
	RXTOP_DIG_1   = 1
	
	#TXTOP IDs
	TXTOP_DIG_0   = 0
	TXTOP_DIG_1   = 1
	
	#FBTOP IDs
	FBTOP_DIG_0   = 0
	FBTOP_DIG_1   = 1
	
	NO_OF_FBTOP			= 2
	NO_OF_CH_PER_FBTOP	= 1
	NO_OF_RXTOP			= 2
	NO_OF_CH_PER_RXTOP	= 2
	NO_OF_TXTOP			= 2
	NO_OF_CH_PER_TXTOP	= 2
	
	#Datatype in the capture
	RX_TESTSOURCE_DATA=0
	RX_DIG_JESD_BYPASS_DATA=1
	RX_DIG_JESD_DATA=2
	FB_TESTSOURCE_DATA=3
	FB_DIG_JESD_BYPASS_DATA=4
	FB_DIG_JESD_DATA=5
	TX_TESTSOURCE_DATA=6
	TX_DIG_JESD_BYPASS_DATA=7
	TX_DIG_JESD_DATA=8
	
	DAC_MODE_48X=1


#DeviceConstants	
	
	

