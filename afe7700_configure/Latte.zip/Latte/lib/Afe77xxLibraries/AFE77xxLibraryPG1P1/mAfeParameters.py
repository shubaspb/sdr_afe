
class systemParams(object):
	"""Contains all the parameters of the system
	All the frequencies are in MHz"""
	chipType=0x10
	chipId=0x77
	chipVersion=1
	bitFileType=0
	X						= 62.5
	
	
	agcParamsDict={}
	# Small Step Attack
	agcParamsDict['thresholdSa']=-3.0
	agcParamsDict['windowLenSa']=128
	agcParamsDict['thresholdLowSa']=-3.0
	agcParamsDict['stepSizeSa']=1
	agcParamsDict['numHitsSa']=8
	agcParamsDict['enableSa']=True
	
	# Big Step Attack
	agcParamsDict['thresholdBa']=-1.0
	agcParamsDict['windowLenBa']=32
	agcParamsDict['thresholdLowBa']=-1.0
	agcParamsDict['stepSizeBa']=3
	agcParamsDict['numHitsBa']=8
	agcParamsDict['enableBa']=False
	
	# Small Step Decay
	agcParamsDict['thresholdSd']=-8.0
	agcParamsDict['windowLenSd']=131072
	agcParamsDict['thresholdLowSd']=0
	agcParamsDict['numHitsSd']=8
	agcParamsDict['stepSizeSd']=1
	agcParamsDict['enableSd']=True
	
	# Big Step Decay
	agcParamsDict['thresholdBd']=-12.0
	agcParamsDict['windowLenBd']=32768
	agcParamsDict['thresholdLowBd']=-12.0
	agcParamsDict['stepSizeBd']=3
	agcParamsDict['numHitsBd']=8
	agcParamsDict['enableBd']=False
	
	# Power Attack
	agcParamsDict['modePa']=0
	agcParamsDict['thresholdPa']=-9.0
	agcParamsDict['windowLenPa']=6
	agcParamsDict['stepSizePa']=1
	agcParamsDict['enablePa']=True
	
	# Power Decay
	agcParamsDict['modePd']=0
	agcParamsDict['thresholdPd']=-18.0
	agcParamsDict['windowLenPd']=32768
	agcParamsDict['stepSizePd']=1
	agcParamsDict['enablePd']=False
	
	# External LNA control
	agcParamsDict['enableEl']=False
	agcParamsDict['lnabypassGain']=16
	agcParamsDict['gainMargin']=2
	
	# Misc Operations
	agcParamsDict['freeze']=0
	agcParamsDict['regFreeze']=0
	agcParamsDict['pinFreezeEn']=0
	
	# DGC settings
	agcParamsDict['dgcEnable']=0
	agcParamsDict['dgcMode']=3			
		#0: IEEE Floating Point Mode after gain distribution
		#1: reserved
		#2: Coarse_Fine Gain Mode. Coarse Gain Indicated in every output sample.  replicated ion both I  and  QCoarse_Fine Gain Mode. Coarse Gain Indicated in every output sample.  replicated ion both I  and  Q
		#3: Coarse_Fine Gain Mode. Coarse Gain distributed  in (I,Q) sample together
		#4: Coarse_Fine Gain Mode. Coarse Gain sent  over  ALC pins
		#5: Coarse_Fine Gain Mode. Coarse Gain comes as input over ALC pins
		#6: Dynamic Coarse Index 16 bit
		#7: Dynamic Coarse Index 12 bit
	agcParamsDict['coarseIndexBits']=3	# 0-All bits allocated for Data
										# 1- Invalid
										# 2- 2 Bits used for DGC mode 2,3,4,5. (Coarse_Fine Gain Mode)
										# 3- 3 Bits used for DGC mode 2,4,5. (Coarse_Fine Gain Mode)
										# 4- 4 Bits used for DGC mode 3. (Coarse_Fine Gain Mode)
	agcParamsDict['coarseStep']=6		# 0-6dB
	agcParamsDict['floatingPointMode']=0 	# 0-	Don't send MSB if Exponent>0.
											# 1-	Send MSB always.
	agcParamsDict['floatingPointFormat']=0	# 0-	2-bit Exponent, 13-bit Mantissa, 1-Bit Exponent
											# 1-	3-bit Exponent, 12-bit Mantissa, 1-Bit Exponent
											# 2-	4-bit Exponent, 11-bit Mantissa, 1-Bit Exponent
	
	
	# Internal AGC enable
	agcParamsDict['enableIa']=0		# 0-Enable External AGC
									# 1-Enable Internal AGC
	agcParamsDict['gainControl']=3	# Valid in External AGC Mode
									# 0-Fast DSA
									# 1-Pin AGC 8- Pin
									# 2-Invalid
									# 3-SPI
									# 4-Fast DSA
									# 5-Pin AGC 4-Pin
	agcParamsDict['phmOvrEn']=0
	agcParamsDict['fdsaOffset']=0	# Valid only when the gainControl is 4 (Fast DSA)
	
	
	srParamsDict={}
	srParamsDict['GainStepSize']=30		# This is the ramp step size while gaining up (actualSampleStep=GainStepSize*(last good sample)/1024)
	srParamsDict['AttnStepSize']=30		# This is the ramp step size while Ramping down (actualSampleStep=GainStepSize*(last good sample)/1024)
	srParamsDict['AmplUpdateCycles']=5.0	# Time of each step in ns.
	srParamsDict['threshold']=30.0			# This is the percentage of the theshold with respect to full scale
	srParamsDict['mode']=0				
	srParamsDict['enable']=False
	srParamsDict['alarmMask']=0x0f80 # [0:unmask,1:mask], Bit-[4:0]:PLL,5:JESD/SERDES,6:alarm A detect,7:alarm saturate overflow,8:alarm FIFO overflow,9:alarm B,10:alarm C,11:alarm D,12:alarm A to output
	
	intPinsParamsDict={}
	intPinsParamsDict['JESD']=True
	intPinsParamsDict['SPI']=True
	intPinsParamsDict['SRTXA']=True
	intPinsParamsDict['SRTXB']=True
	intPinsParamsDict['SRTXC']=True
	intPinsParamsDict['SRTXD']=True
	intPinsParamsDict['PLL0']=True
	intPinsParamsDict['PLL1']=True
	intPinsParamsDict['PLL2']=True
	intPinsParamsDict['PLL3']=True
	intPinsParamsDict['PLL4']=True
	
	rxAdcBw=100
	def __init__(self):
		self.latteLibVersion="2.20"
		# System Parameters
		self.FRef                    = 250
		self.Fs                      = 3000
		self.halfRateModeRx			= 0
		self.halfRateModeFb			= 0
		self.halfRateModeTx			= 0
		self.enableFbCd				= True
		self.mode2t2r				= False
									#0: single pin is used for 2T/2R/1F AB TDD and 2T/2R/1F CD TDD.
									#1: AB and CD TDDs are enabled through different pins.
									#2: AB: TDD, CD: FDD
									#3: AB: FDD, CD: TDD

									
		self.pllMuxModes				= 0	#0: 4T4R Mode with PLL0 as Master
									#1: 4T4R Mode with PLL2 as Master
									#2: 4T4R FDD Mode
									#3: 2*2T2R FDD Mode: PLL0 AB-TX;PLL3 AB-RX; PLL2 CD TX; PLL4 CD RX
									#4: 2T2R FDD - TDD Mode: PLL0 AB-TX; PLL3-AB-RX; PLL2 CD
		self.jesdLoopbackEn			= 0 #Make it 1 to Enable the JESDTX to JESDRX internal loopback
		self.useSpiSysref			= False#True
		
		# LO Settings
		self.pllLo					=[3500,3000,4500.5,2600.0,2100.0]
		self.usePllExternalLoClock		=[False,False]	#This is for External LO 1 (TDD clock, goes to PLL2) and 2 (FDD clock, goes to PLL0)
													# Note that twice the PLL LO frequency should be given as input to the corresponding PLL.
		
		# JESD and Serdes Parameters
		self.LMFSHdRx                = ["24410","24410"]
		self.LMFSHdFb                = ["22420","22420"]
		self.LMFSHdTx                = ["44210","44210"]
		self.systemMode              = [1,1]			# 0-Identical, 1-FDD, 2-TDD
		self.dedicatedLaneMode       = [0,0]
		self.sampDropByRx            = [1,1]
		self.sampDropByFb            = [1,1]
		self.jesdProtocol            = 0
		self.serdesFirmware			 = True
		self.serdesTxLanePolarity	= [False]*8
		self.serdesRxLanePolarity	= [False]*8
			
		self.jesdTxLaneMux			= [0,1,2,3,4,5,6,7]	# Enter which lanes you want in each location. 
														# Note that across 2T Mux is not possible in 0.5.
														# For example, if you want to exchange the first two lines of each 2T, this should be [[1,0,2,3],[5,4,6,7]]
		self.jesdRxLaneMux			= [0,1,2,3,4,5,6,7]	# Enter which lanes you want in each location.
																# Note that across 2R Mux is not possible in 0.5.
																# For example, if you want to exchange the first two lines of each 2R, this should be [[1,0,2,3],[5,4,6,7]]
		self.jesdRxRbd				= [4, 4]
		self.jesdScr					= [False,False]		# Does the Same config for JESD TX and RX
		self.jesdK					= [16,16]
		self.jesdTxRxABSyncMux		= 0
		self.jesdTxRxCDSyncMux		= 0
		self.jesdTxFBABSyncMux		= 0
		self.jesdTxFBCDSyncMux		= 0
		self.jesdRxABSyncMux			= 0
		self.jesdRxCDSyncMux			= 0
		self.jesdABLvdsSync			= 0
		self.jesdCDLvdsSync			= 0
		self.executeLinkUpSequenceSeparately	=False
		self.enableRxFbJesdLinks				=[1,1]
		self.enableTxJesdLinks					=[1,1]
		# Decimation and interpolation Parameters
		self.ddcFactorRx             = [12   , 12   ]
		self.ddcFactorFb             = [6   , 6   ]
		self.fbNco					= [1800, 2100]
		self.fbNcoBand1					= [1800, 2100]
		self.ducFactorTx             = [6,	6]
		
		self.lowIfNcoRx				= [0,0]
		self.lowIfNcoFb				= [0,0]
		self.lowIfNcoTx				= [0,0]
		
		self.sysrefFreqDiv			= 1
		self.useMacros				= True
		self.setTxLoFbNcoFreqForTxCalib	= False
		self.txIqMcCalibMode			= 0   				# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode; 3- Internal Loopback
		self.txDsaCalibMode			= 0   				# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
		self.rxDsaCalibMode			= 0					# 0 -One channel at a time; 1- A&C at once and B&D at once; 2- All 4 channels at once.
		
		self.gpioConfigMode			= 0				#0-Internal AGC. 1- External AGC, 2- Custom Mode				
		#loadEfuseTrims			= False
		
		self.enableRxDsaFactoryCal 		= False
		self.enableTxDsaFactoryCal 		= False
		self.enableTxIqmcLolTrackingCorr = False
		self.enableTxIqmcDelayChar		= False # For TX-FB delay calculation, set to True. Linkup will be skipped. After bringup, AFE.txIqLoExtLpbkDlyChar(ch) or AFE.txIqLoIntLpbkDlyChar() can be used to get delay value.
		self.enableTxIqmcLolPowerUpCorr 	= False
		self.enableRxIqmcLolPowerUpCorr 	= False
		self.enableRxIqmcLolTrackingCorr = True
		self.enableTxIqmcLolHostUpdateMode=False
		self.rxDsaPacketFilePath	=""
		self.txDsaPacketFilePath	=""
		self.txDsaUpdateMode				=		0		#0- Normal SPI. 1- Through Gain Smoothening. 2- Update in TX TDD off state
		self.txDsaGainStepDelay	=		5		# this number*125ns will be the step time
		self.txIqmcExternalDelayValue	= [0,0,0,0]
		self.txIqmcFullBandEstimation	= False
		self.enableTxSigGen				= False
		self.enableReliabilityDetector	= True
		self.customerConfig=False
		self.syncLoopBack=False
		self.setLoForCoherence=True		# If this is True, the LO will be set to coherence of 2**15 samples
		self.releaseTxMuxControlToPins=False
		
		self.defaultRxDsa=[28,28,28,28]
		self.defaultTxDsa=[30,30,30,30]
		self.defaultFbDsa=[20,20]

		self.serdesManualCTLEEn=False
		self.serdesManualCTLE=[6,6,6,6,6,6,6,6]
		self.serdesTxPreCursor=[0,0,0,0,0,0,0,0]
		self.serdesTxPostCursor=[0,0,0,0,0,0,0,0]
		self.serdesTxMainCursor=[3,0,0,0,0,0,0,3]

		
		self.fbDsaPerTxEn=False
		self.fbDsaPerTx=[0,0,0,0]
		
		self.agcRegConfigParams =[self.agcParamsDict.copy(),self.agcParamsDict.copy(),self.agcParamsDict.copy(),self.agcParamsDict.copy()]
		self.srConfigParams =[self.srParamsDict.copy(),self.srParamsDict.copy(),self.srParamsDict.copy(),self.srParamsDict.copy()]
		self.intPinsParams=[self.intPinsParamsDict.copy(),self.intPinsParamsDict.copy()]
		self.gpioMapping={}
		
#systemParams

class systemStatus(object):
	chipType=0
	chipId=1
	chipVersion=1
	validConfig=[False,False]
	dutNo=0
	useOldSerDesConfig=False
	oldRxAnaWrites=False
	pllLo=[1800,3000,2400.5,900.0,2100.0]
	pllValid=[True]*5
	pllLockStatus=[False]*5
	
	jesdConfigParams=[{'scr': 1, 'RX_RBD': 7},{'scr': 1, 'RX_RBD': 7}]		# Dictionary containing JESD Config parameters
	serdesConfig	=[{},{}]		# Dictionary containing Serdes Config parameters 
	
	laneRateRx=[0,0]
	laneRateFb=[0,0]
	laneRateTx=[0,0]
	
	serdesTxLaneRate=[0]*8
	serdesRxLaneRate=[0]*8
	serdesTxLaneRatePreReorder=[0]*8
	serdesRxLaneRatePreReorder=[0]*8
	
	jesdRxLink=[False,False]	# Shows if the link is up or not
	jesdTxLink=[False,False]	# Shows if the link is up or not
	
	serdesTxLaneValid=[False]*8
	serdesRxLaneValid=[False]*8
	
	rxLoPllIndex=[0,0]
	txLoPllIndex=[0,0]
	
	rxLowIfRate=[12,12]
	fbLowIfRate=[6,6]
	txLowIfRate=[6,6]

	pllSpiAccess=False
	jesdRxAlarms=""
	
	lowIfParams={}
	
	agcStatusDict={}
	agcStatusDict['currAttn']=0
	agcStatusDict['currExtLnaEn']=0
	agcStatusDict['currDvgaAttn']=0
	agcStatusDict['maxAttnUsed']=0
	agcStatusDict['minAttnUsed']=0
	agcStatusDict['maxDvgaAttnUsed']=0
	agcStatusDict['minDvgaAttnUsed']=0
	agcStatusDict['lnaBypassChanged']=0
	agcStatusDict['attnChanged']=0
	
	agcStatusConfig=[agcStatusDict.copy(),agcStatusDict.copy(),agcStatusDict.copy(),agcStatusDict.copy()]
	mcuParams={}
	useTxIqmcPatchVersion=2		# Don't change
	gpioStatus={
			}

#systemStatus
	

class SettingsClass(object):
	def __init__(self):
		#Configs for RxIQMC testing
		self.rxIqmcTopSimSettings={}
		self.rxIqmcRegConfigSettings={}
		self.rxDigConfigSettings={}
		self.rxSigSourceConfigSettings={}
		self.rxIqmcTSMismatchSettings={}
		self.rxIqmcTestSettings={}
		self.rxIqmcCaptureSettings={}
		
		#Configs for TXIQMC testing
		self.txIqmcTopSimSettings={}
		self.txIqmcRegConfigSettings={}
		self.txDigConfigSettings={}
		self.txSigSourceConfigSettings={}
		self.txIqmcTSMismatchSettings={}
		self.txIqmcTestSettings={}
		self.txIqmcCaptureSettings={}		
		
		#Configs for calibTopControl testing
		
		
		#Configs for JESD testinfg
#settingsClass