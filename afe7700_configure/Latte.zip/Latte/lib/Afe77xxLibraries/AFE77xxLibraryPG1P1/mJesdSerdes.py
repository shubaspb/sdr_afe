from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math
import numpy
import sys
import matplotlib.pyplot

import mSetupParams
from mSetupParams import setupJesdParams

class serdesLib(projectBaseClass):
	"""Contains Serdes specific functions. self.regs=device.JESD.SERDES """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.topno=topno
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
	
	#__init__

	@funcDecorator
	def serdesReset(self):
		""" "Resetting Serdes" "Done resetting Serdes" This function resets the SERDES Phy Layer"""
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x888
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x000
		self.delay(0.1)
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x777
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x000
		self.delay(0.1)
	#serdesReset
	
	@funcDecorator
	def enableRxToTxLoopback(self,en):
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE3.getValue()
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE2.getValue()
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE1.getValue()
		self.regs.Common.IO_MODE_CONTROL._BUS_WIDTH_LANE0.getValue()
		self.regs.Common.IO_MODE_CONTROL.LOOPBACK_EN=en
	#enableRxToTxLoopback
	
	@funcDecorator
	def setLanePolarity(self):
		temp=self.deviceRefs.device.hardReadAlways
		self.deviceRefs.device.hardReadAlways=True
		tx_polarity = setupJesdParams.boardLaneSettings[setupParams.boardType][self.systemStatus.dutNo]['tx_polarity']
		rx_polarity = setupJesdParams.boardLaneSettings[setupParams.boardType][self.systemStatus.dutNo]['rx_polarity']
		for i in range(4):
			self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_POLARITY_FLIP = tx_polarity[(self.topno*4)+i]
			self.regs.laneRegisters[i].RX_PRBS_CONFIGURATION.RX_POLARITY_FLIP = rx_polarity[(self.topno*4)+i]
		self.deviceRefs.device.hardReadAlways=temp
	
	@funcDecorator
	def serdes1010Pattern(self,laneEna=0xf):
		""" "Sending 1010 pattern on SERDES Lanes" Makes the output of serdes as 1010 for the selected lanes. Each bit of the parameter laneEna is for one lane."""
		laneEna=laneEna&0xf
		for i in range(4):
			if (laneEna>>i)&1==1:
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_DATA_SOURCE=0
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_CLOCK_EN=0
				self.regs.laneRegisters[i].TX_TEST_PATTERN_HIGH.TX_TEST_PATTERN_HIGH=0xaaaa
				self.regs.laneRegisters[i].TX_TEST_PATTERN_LOW.TX_TEST_PATTERN_LOW=0xaaaa
	#serdes1010Pattern
	
	@funcDecorator
	def serdesPrbsPattern(self,laneEna=0xf,PRBSPattern=0):
		""" "Sending PRBS pattern on SERDES Lanes" Makes the output of serdes as PRBS for the selected lanes. Each bit of the parameter laneEna is for one lane."""
		laneEna=laneEna&0xf
		for i in range(4):
			if (laneEna>>i)&1==1:
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_DATA_SOURCE=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_GEN_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_CLOCK_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_EN=1
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_MODE=PRBSPattern
	#serdesPrbsPattern
	
	@funcDecorator
	def serdesSendData(self,laneEna=0xf):
		""" "Sending Data on SERDES Lanes" Sends Data on the selected lanes. Each bit of the parameter laneEna is for one lane."""
		for i in range(4):
			if (laneEna>>i)&1==1:
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_EN=0
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_TEST_DATA_SOURCE=0
				self.regs.laneRegisters[i].NRZ_TX_TEST_PATTERN_CONFIGURATION.TX_PRBS_CLOCK_EN=0
	#serdesSendData
	
	@funcDecorator
	def serdesPdn(self,pdn=0):
		""" "Powering down SERDES Lanes" """
		self.regs.Common.PLL_REFCLK_DIVIDER.PU_RX_AGC_MASTER=pdn
		self.regs.Common.PLL_REFCLK_DIVIDER.PU_RX_BANDGAP=pdn
		self.regs.Common.PLL_REFCLK_DIVIDER.RX_PLL_BIAS1=pdn
		self.regs.Common.RX_PLL_MULTIPLIER.PU_RX_PLL=pdn
		self.regs.Common.TX_REFCLK_SELECT.TX_PLL_BIAS4=pdn
		self.regs.Common.TX_REFCLK_SELECT.PU_RVDD_TX=pdn
		self.regs.Common.TX_REFCLK_SELECT.PU_TX_BANDGAP=pdn
		self.regs.Common.TX_PLL_MULTIPLIER.PU_TX_PLL=pdn
	#serdesPdn
	
	@funcDecorator
	def enableTxPllTp(self,en=1):
		self.regs.Common.TEST_MUX_B_CONTROL.TEST_MUX_SEL_B=0
		self.regs.Common.TX_POWER_UP_MASTER.ENTTSTPGROUP_TX=en
		self.regs.Common.TX_POWER_UP_MASTER.TEST_MODE_TX=2
		self.regs.Common.TX_POWER_UP_MASTER.VTSTPGROUP_TX=13
	#enableTxPllTp
	
	@funcDecorator
	def enableRxPllTp(self,en=1):
		self.regs.Common.TX_POWER_UP_MASTER.ENTTSTPGROUP_TX=0
		self.regs.Common.TEST_MUX_B_CONTROL.TEST_MUX_SEL_B=0b010011011
		#val=self.serdesRead(0x84f7)
		#val=(val&0x7f)+(0b010011011)<<7
		#self.serdesWrite(0x84f7,)
	#enableRxPllTp
	
	@funcDecorator
	def getSerdesEye(self,fileName=ASTERIX_DIR+DEVICES_DIR+r"\eyeDiagram.txt"):
		self.regs.Common.FIRMWARE_WATCHDOG_TIMER._FIRMWARE_WATCHDOG.getValue()
		REG_CMD = 0x9815
		REG_CMD_DETAIL = 0x9816
		
		#chip = Chip()
		
		def parse_response():
			while True:
				response = self.serdesRead(REG_CMD)
				if response>>12 == 0:
					break;
			status = (response>>8) & 0xf
			data = response & 0xff
			if status == 0x3:
				if data == 0x02:
					print 'Invalid input'
				elif data == 0x03:
					print 'Phy not ready'
				elif data == 0x05:
					print 'Eye monitor going on'
				elif data == 0x06:
					print 'Eye monitor cancelled'
				elif data == 0x07:
					print 'Eye monitor not started'
				else:
					print hex(data)
			return status, data
		
		def em_start(lane_num, ber_exp, mode):
			command = 0x1000 | (lane_num&0xF) | ((ber_exp&0xF)<<4)
			detail = mode
			self.serdesWrite(REG_CMD_DETAIL, detail)
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x0:
				print 'Eye monitor starts...'
		
		def em_report_progress():
			command = 0x2000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x1:
				return data
			return None
		
		def em_read():
			ber=numpy.zeros((95, 33))
			for phase in range(-16,17):
				pindex = phase+16
				for margin in range(-47, 48, 16):
					self.serdesWrite(REG_CMD_DETAIL, margin&0xffff)
					self.serdesWrite(REG_CMD, (phase&0xFF) | 0x3000)
					status, data = parse_response()
					if status == 0x2:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = self.serdesRead(0x9f00+i)
					else:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = 0
			
			#log_file = open("em_data.txt", "w")
			#for margin in range(95):
			#	for phase in range(33):
			#		value = ber[margin, phase]
			#		log_file.write('%.0f ' % value)
			#	log_file.write('\n')
			#log_file.close()
			return ber
		
		def em_draw(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			f=matplotlib.pyplot.figure()
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			c=matplotlib.pyplot.pcolor(x, y, ber/-16, cmap='jet', vmin=-8, vmax=0, figure=f)
			cax=f.add_axes([0.9, 0.1, 0.02, 0.8])
			f.colorbar(mappable=c, cax=cax)
			matplotlib.pyplot.show()
		
		def em_print(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			for margin in range(95):
				if margin%10 == 0:
					print '%4d | ' % y[margin],
				else:
					print '	 | ',
				for phase in range(33):
					value = ber[margin, phase]
					magnitude = int(value/16)
					if magnitude == 15:
						sys.stdout.write(' '*2)
					else:
						sys.stdout.write(str(magnitude)+' '*1)
				print ''
			print '%4d | ' % y[-1]
			sys.stdout.write(' '*5 + '----'*len(x)+'\n')
			sys.stdout.write(' '*5)
			for idx, x_point in enumerate(x):
				if idx%5 == 0:
					if x_point >= 0:
						if idx == 30:
							sys.stdout.write(' '*4)
						else:
							sys.stdout.write(('%.2f' % x_point) + ' '*6)
					else:
						sys.stdout.write(('%.2f' % x_point) + ' '*5)
			print '%.2f' % x[-1]
			
		def em_cancel():
			command = 0x4000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
		
		#em_cancel()
		
		em_start(0, 7, 1) #lane0, ber_exp 10^7, mode 1
		old_progress = 0
		while True:
			progress = em_report_progress()
			if progress == None: break
			if old_progress != progress:
				print '%d%%' % progress
			if progress == 100: break
			old_progress = progress
		ber = em_read()
		em_print(ber)
		em_draw(ber)
	#getSerdesEye

	@funcDecorator
	def getSerdesEye25Gbps(self,instance):
		self.regs.Common.FIRMWARE_WATCHDOG_TIMER._FIRMWARE_WATCHDOG.getValue()
		REG_CMD = 0x9815
		REG_CMD_DETAIL = 0x9816
		
		#chip = Chip()
		
		def parse_response():
			count=0
			while True:
				response = self.serdesRead(REG_CMD)
				if response>>12 == 0:
					break;
				if count>500:
					error("Error in parse_response. Invalid read. Check if firmware loaded.")
			status = (response>>8) & 0xf
			data = response & 0xff
			if status == 0x3:
				if data == 0x02:
					info('Invalid input')
				elif data == 0x03:
					info('Phy not ready')
				elif data == 0x05:
					info('Eye monitor going on')
				elif data == 0x06:
					info('Eye monitor cancelled')
				elif data == 0x07:
					info('Eye monitor not started')
				else:
					info(hex(data))
			return status, data
		
		def em_start(lane_num, ber_exp, mode):
			command = 0x1000 | (lane_num&0xF) | ((ber_exp&0xF)<<4)
			detail = mode
			self.serdesWrite(REG_CMD_DETAIL, detail)
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x0:
				info('Eye monitor starts...')
		
		def em_report_progress():
			command = 0x2000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
			if status == 0x1:
				return data
			return None
		
		def em_read():
			ber=numpy.zeros((95, 33))
			for phase in range(-16,17):
				pindex = phase+16
				for margin in range(-47, 48, 16):
					self.serdesWrite(REG_CMD_DETAIL, margin&0xffff)
					self.serdesWrite(REG_CMD, (phase&0xFF) | 0x3000)
					status, data = parse_response()
					if status == 0x2:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = self.serdesRead(0x9f00+i)
					else:
						for i in range(16):
							m=margin+i
							if m<48:
								ber[47+m, pindex] = 0
			
			#log_file = open("em_data.txt", "w")
			#for margin in range(95):
			#	for phase in range(33):
			#		value = ber[margin, phase]
			#		log_file.write('%.0f ' % value)
			#	log_file.write('\n')
			#log_file.close()
			return ber
		
		def em_draw(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			f=matplotlib.pyplot.figure()
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			c=matplotlib.pyplot.pcolor(x, y, ber/-16, cmap='jet', vmin=-8, vmax=0, figure=f)
			cax=f.add_axes([0.9, 0.1, 0.02, 0.8])
			f.colorbar(mappable=c, cax=cax)
			matplotlib.pyplot.show()
		
		def em_print(ber):
			extent = self.serdesRead(REG_CMD_DETAIL)
			x=numpy.arange(-16.5, 17.5)*0.0232
			y=numpy.arange(-47.5, 48.5)*extent/47
			for margin in range(95):
				if margin%10 == 0:
					print '%4d | ' % y[margin],
				else:
					print '	 | ',
				for phase in range(33):
					value = ber[margin, phase]
					magnitude = int(value/16)
					if magnitude == 15:
						sys.stdout.write(' '*2)
					else:
						sys.stdout.write(str(magnitude)+' '*1)
				print ''
			print '%4d | ' % y[-1]
			sys.stdout.write(' '*5 + '----'*len(x)+'\n')
			sys.stdout.write(' '*5)
			for idx, x_point in enumerate(x):
				if idx%5 == 0:
					if x_point >= 0:
						if idx == 30:
							sys.stdout.write(' '*4)
						else:
							sys.stdout.write(('%.2f' % x_point) + ' '*6)
					else:
						sys.stdout.write(('%.2f' % x_point) + ' '*5)
			print '%.2f' % x[-1]
			
		def em_cancel():
			command = 0x4000
			self.serdesWrite(REG_CMD, command)
			status, data = parse_response()
		
		#em_cancel()

		em_start(1, 7, 1) #lane0, ber_exp 10^7, mode 1
		old_progress = 0
		while True:
			progress = em_report_progress()
			if progress == None: break
			if old_progress != progress:
				info('%d%%' % progress)
			if progress == 100: break
			old_progress = progress
		ber = em_read()
		em_print(ber)
		em_draw(ber)	
	#getSerdesEye25Gbps
	
	
	@funcDecorator
	def postLinkupSerdesWrites(self):
		""" "Writing Post Link up SERDES writes" "Done writing Post Link up SERDES writes" """
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=(1<<self.topno)
		#temp=self.deviceRefs.device.rawWriteLogEn
		#self.deviceRefs.device.rawWriteLogEn=0
		for i in range(4):
			self.serdesWrite(0x80fd+(0x100*i),0x0246)
		#	self.regs.laneRegisters[i].RX_INTPOLATOR_CONTROL._VREF_DELAY_DAC_BOT.getValue()
		#self.deviceRefs.device.rawWriteLogEn=temp
		#for i in range(4):
		#	val=self.serdesRead(0x80fd+(0x100*i))
		#	val=val&0xbfff
		#	self.serdesWrite(0x80fd+(0x100*i),val)#0x0246)
	#postLinkupSerdesWrites

	
	@funcDecorator
	def postFwDownloadSerdesWrites(self):
		if True in [(True if laneRate<17000 else False) for laneRate in self.systemStatus.laneRateRx+self.systemStatus.laneRateFb+self.systemStatus.laneRateTx]:
			self.regs.Common.FIRMWARE_WATCHDOG_TIMER._FIRMWARE_WATCHDOG.getValue()
			self.serdesWrite(0x9816,5)
			self.serdesWrite(0x9812,8)
			self.serdesWrite(0x9815,0xe020)
			self.delay(0.1)
			
			self.serdesWrite(0x9816,2)
			self.serdesWrite(0x9812,80)
			self.serdesWrite(0x9815,0xe020)
			self.delay(0.1)
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x777
		self.regs.Common.SOFTWARE_RESET.DOMAIN_RESET=0x000
		self.delay(0.1)
		if self.systemStatus.useOldSerDesConfig==True:
			highSpeed=True
			for i in self.systemStatus.laneRateRx+self.systemStatus.laneRateTx+self.systemStatus.laneRateFb:
				if i>20000:
					highSpeed=True
				else:
					highSpeed=False
			if highSpeed==True:
				val=0x106b
			else:
				val=0x10Eb
		else:
			val=0x106b
		self.serdesWrite(0x8000,val|0x8000)
		self.serdesWrite(0x8000,val)
		self.serdesWrite(0x8100,val|0x8000)
		self.serdesWrite(0x8100,val)
		self.serdesWrite(0x8200,val|0x8000)
		self.serdesWrite(0x8200,val)
		self.serdesWrite(0x8300,val|0x8000)
		self.serdesWrite(0x8300,val)
		self.delay(8)
	#postFwDownloadSerdesWrites
	
#serdesLib