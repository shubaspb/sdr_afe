from mFuncDecorator import *
from globalDefs import *
import mAfeConstants
reload(mAfeConstants)
from mAfeConstants import jesdConstants
from mAfeConstants import pllConstants
from mAfeConstants import afeConstants
import mHWAccess
reload(mHWAccess)
from mHWAccess import HWAccess
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
from fractions import Fraction,gcd
import random,math
from functools import reduce
import fractions

class projectBaseClass(HWAccess):

	def updateDeviceRefsInBaseClass(self,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInHwAccessClass(deviceRefs)
	#updateDeviceRefsInHwAccessClass
	
	@funcDecorator
	def timerWaitForMilliSec(self,waitPeriodInMilliSec):
		'''Waits for waitPeriodInMilliSec Milliseconds'''
		time.sleep((waitPeriodInMilliSec/1000))
	#timerWaitForMilliSec
	
	@funcDecorator
	def timerWaitForSec(self,waitPeriodInSec):
		'''Waits for waitPeriodInSec seconds'''
		time.sleep(waitPeriodInSec)
	#timerWaitForSec
	
	@funcDecorator
	def errorinDb(self,data1,data2):
		'''calculate the error in dB'''
		data1Mod = 10.0**(float(data1/20.0))
		data2Mod = 10.0**(float(data2/20.0))
		diff     = np.abs(data1Mod-data2Mod)
		errorDb = 20.0*np.log10(diff)
		return(errorDb)
	#errorinDb	
	
	def findPllFreq(self,topno):
		FRef=self.systemParams.FRef
		Fout=self.systemParams.pllLo[topno]
		if topno!=1:
			Fout=Fout*2
		if topno==1:
			pllOpDivFactors=pllConstants.pllDcPllOpDivFactors
		else:
			pllOpDivFactors=pllConstants.pllOpDivFactors
		pllOpDivFactors1=pllOpDivFactors
		found=False	
		enFracMode=True
		#if self.pll6G==False:
		#	vcoMin=6000.0#pllConstants.pllVcoRange[0]
		#else:
		vcoMin=5700.0#		
		for ipDiv in pllConstants.pllIpDivFactors:
			for opDiv in pllOpDivFactors:
				if opDiv not in pllOpDivFactors:
					continue
				Fvco=Fout*opDiv+0.000000000000001
				divFactor=Fvco*ipDiv/FRef	
				N=int(round(divFactor,10))
				if self.systemStatus.chipVersion>0x10:
					if (FRef*1000.0>2**18):
						numMulFact=math.ceil(FRef*1000.0/2.**18)
						D=int(round(FRef*1000.0/numMulFact))
					else:
						D=int(round(FRef*1000.0))
						numMulFact=1
					F=int(round((divFactor-N)*D,4))
					if F!=0:
						numMulFact=numMulFact*opDiv
					
					#if (((N*D)+F)%numMulFact)!=0:
					#	if F>=(((N*D)+F)%numMulFact):
					#		F=F-(((N*D)+F)%numMulFact)
					#	else:
					#		N=N-1
					#		F=D+F-(((N*D)+F)%numMulFact)
				else:
					
					F=int(round((divFactor-N)*2**15,4))*(2**3)
					D=2**18
				if N in pllConstants.pllNfactors and Fvco>vcoMin and Fvco<pllConstants.pllVcoRange[1] and (F==0 or F in pllConstants.pllFfactors) and D in pllConstants.pllDfactors and F<D: 
					found=True
					break
			if found==True:
				break
		if found==False:
			F = 0#pllConstants.pllFfactors[0]
			D = pllConstants.pllDfactors[0]
			N = pllConstants.pllNfactors[0]
			ipDiv = pllConstants.pllIpDivFactors[0]
			opDiv = pllConstants.pllOpDivFactors[0]
			error("Could not find suitable factors for PLL"+str(topno)+": refClk="+str(FRef)+"\t Fout="+str(Fout))
		if enFracMode==False:
			if (F*1.0/D)>0.5:
				N=N+1
			F=0
		if F==0:
			enFrac=False
		else:
			enFrac=True
		
		if topno==1:
			self.systemParams.pllLo[topno]=round(FRef*(N+(F*1.0/D))/(ipDiv*opDiv),10)
		else:
			self.systemParams.pllLo[topno]=round(FRef*(N+(F*1.0/D))/(2*ipDiv*opDiv),10)	
		return found
	#findPllFreq
	
	@funcDecorator
	def jesdModeFeatures(self,jesdModeIn):
		jesdModeIn=str(jesdModeIn).lower()
		if "_" in jesdModeIn:
			jesdMode=jesdModeIn[:jesdModeIn.find('_')]
		else:
			jesdMode=jesdModeIn
			
		L=int(jesdMode[0])
		M=int(jesdMode[1])
		if "_real" in jesdModeIn:
			numBands=(M/2)-1
		else:
			numBands=(M/4)-1
		
		if len(jesdMode)==5:
			F=int(jesdMode[2])
			S=int(jesdMode[3])
			Hd=int(jesdMode[4])
		elif len(jesdMode)==6:
			F=int(jesdMode[2:4])
			S=int(jesdMode[4])
			Hd=int(jesdMode[5])
		resolution=int(round(16*(F*L)/(M*S*2.0)))
		return(L,M,F,S,Hd,resolution,numBands)
	#jesdModeFeatures
	
	@funcDecorator
	def checkValidityOfDigChain(self,rxOrFbOrTx,factor,halfRateMode):
		if rxOrFbOrTx==0:
			decimModeAct=factor/2.0
			if halfRateMode==1:
				stage1Setting=1
			else:
				stage1Setting=2
				
			found=False
			for u in (1,2,4):
				for stage4p5Setting in (1,2):
					for stage3Setting in (1,2):
						for stage4Setting in (1.0,7.0/6,9.0/8):
							for stage2Setting in (2.0,3.0):
								if round(u*stage1Setting*stage2Setting*stage3Setting*stage4Setting*stage4p5Setting,3)==round(decimModeAct,3):
									found=True
									break
							if found==True:
								break
						if found==True:
							break
					if found==True:
						break
			settings=(stage1Setting,stage2Setting,stage3Setting,stage4Setting,stage4p5Setting)
		elif rxOrFbOrTx==1:
			if halfRateMode==0:
				decimModeAct=factor/2.0
			else:
				decimModeAct=factor
			found=False
			for u in (1,2):
				for stage3p5Setting in (1,2):
					for stage1Setting in (1,2):
						for stage3Setting in (1.0,7.0/6,9.0/8):
							for stage2Setting in (2.0,3.0):
								if round(u*stage1Setting*stage2Setting*stage3Setting*stage3p5Setting,3)==round(decimModeAct,3):
									found=True
									break
							if found==True:
								break
						if found==True:
							break
					if found==True:
						break
			settings=(stage1Setting,stage2Setting,stage3Setting,stage3p5Setting)
		elif rxOrFbOrTx==2:
			found=False
			for stage1p5Setting in (1,2):
				for stage2Setting in (1,9.0/8,7.0/6):
					for stage4Setting in (1,2):
						for stage3Setting in (1,1.5,2,3):
							for stage1Setting in (1,2):
								if round(stage1Setting*stage1p5Setting*stage2Setting*stage3Setting*stage4Setting,3)==round(factor,3):
									found=True
									break
							if found==True:
								break
						if found==True:
							break
					if found==True:
						break	
				if found==True:
					break
			settings=(stage1Setting,stage1p5Setting,stage2Setting,stage3Setting,stage4Setting)
			found=True
		return (found,settings)
	
	@funcDecorator
	def findLoNcoPossibleFrequency(self,Fout):
		if self.systemStatus.chipVersion>0x10:
			return
		def largestPowerOfTwoThatIsAFactorOf(num):
			if num % 2 != 0: return 1
			factor = 0
			while num % 2 == 0:
				num /= 2
				factor += 1
			return 2 ** factor
		Fout=Fout*2
		FRef=self.systemParams.FRef
		pllOpDivFactors=pllConstants.pllOpDivFactors
		found=False
		
		for ipDiv in pllConstants.pllIpDivFactors:
			for opDiv in pllOpDivFactors:
				if opDiv not in pllOpDivFactors:
					continue
				Fvco=Fout*opDiv
				divFactor=Fvco*ipDiv/FRef
				N=int(divFactor)
				if self.systemStatus.chipVersion>0x10:
					if (FRef*1000.0>2**18):
						numMulFact=math.ceil(FRef*1000.0/2.**18)
						D=int(round(FRef*1000.0/numMulFact))
					else:
						D=int(round(FRef*1000.0))
						numMulFact=1
					F=int(round((divFactor-N)*D,4))
					if F!=0:
						numMulFact=numMulFact*opDiv
					
					if (((N*D)+F)%numMulFact)!=0:
						if F>=(((N*D)+F)%numMulFact):
							F=F-(((N*D)+F)%numMulFact)
						else:
							N=N-1
							F=D+F-(((N*D)+F)%numMulFact)
				else:
					F=int(round((divFactor-N)*2**15,4))*(2**3)#int(round((divFactor-N)*2**18,4))#Fraction(divFactor-N).limit_denominator(2**19).numerator
					D=2**18#Fraction(divFactor-N).limit_denominator(2**19).denominator
					denominator=Fraction(opDiv*D*self.systemParams.Fs*1.0/FRef).limit_denominator(2**21).numerator
					denominator=denominator/min(largestPowerOfTwoThatIsAFactorOf(denominator),2**32)
					Foffset=((N*D)+F)%denominator
					if F>Foffset:
						F=F-Foffset
					else:
						F=F+denominator-Foffset
				#mulfact=int(2.0**19/D)
				#D=D*mulfact
				#F=F*mulfact
				Fvco=FRef*(N+(F*1.0/D))/(ipDiv*opDiv)
				if round(Fvco*(2.0**31)/self.systemParams.Fs,12)%1==0 and N in pllConstants.pllNfactors and Fvco>pllConstants.pllVcoRange[0] and Fvco<pllConstants.pllVcoRange[1] and (F==0 or F in pllConstants.pllFfactors) and D in pllConstants.pllDfactors and F<D:
					found=True
					break
			if found==True:
				break
		Fout=round(Fvco/2.0,6)
		return Fout
	#findLoNcoPossibleFrequency
	
	@funcDecorator
	def initializeConfig(self):
		self.getRatesForMcu()
		X=self.systemParams.X
		FRef                =self.systemParams.FRef               
		FadcRx              =self.systemParams.Fs
		FadcFb              =self.systemParams.Fs
		Fdac                =self.systemParams.Fs
		halfRateModeRx        =self.systemParams.halfRateModeRx
		halfRateModeFb        =self.systemParams.halfRateModeFb
		halfRateModeTx        =self.systemParams.halfRateModeTx
		if self.systemStatus.chipVersion>0x10:
			for pllNo in (0,2,3,4):
				self.findPllFreq(pllNo)
		elif self.systemParams.setTxLoFbNcoFreqForTxCalib==True and self.systemStatus.chipVersion<=0x10:
			for pllNo in (0,2,3,4):
				self.systemParams.pllLo[pllNo]=self.findLoNcoPossibleFrequency(self.systemParams.pllLo[pllNo])			
		if self.systemParams.pllMuxModes==0:			#0: 4T4R Mode with PLL0 as Master. PLL 0 for all the LOs.
			self.systemStatus.pllValid[0]=True
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=False
			self.systemStatus.pllValid[3]=False
			self.systemStatus.pllValid[4]=False
			self.systemStatus.rxLoPllIndex=[0,0]
			self.systemStatus.txLoPllIndex=[0,0]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[0]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[0]
		elif self.systemParams.pllMuxModes==1:			#1: 4T4R Mode with PLL2 as Master. PLL 2 for all the LOs.
			self.systemStatus.pllValid[0]=False
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=True
			self.systemStatus.pllValid[3]=False
			self.systemStatus.pllValid[4]=False
			self.systemStatus.rxLoPllIndex=[2,2]
			self.systemStatus.txLoPllIndex=[2,2]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[2]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[2]
		elif self.systemParams.pllMuxModes==2:			#2: 4T4R FDD Mode. PLL0 for TX and PLL2 for RX.
			self.systemStatus.pllValid[0]=True
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=True
			self.systemStatus.pllValid[3]=False
			self.systemStatus.pllValid[4]=False
			self.systemStatus.rxLoPllIndex=[2,2]
			self.systemStatus.txLoPllIndex=[0,0]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[0]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[0]
		elif self.systemParams.pllMuxModes==3:			#3: 2*2T2R FDD Mode: PLL0 AB-TX;PLL3 AB-RX; PLL2 CD TX; PLL4 CD RX
			self.systemStatus.pllValid[0]=True
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=True
			self.systemStatus.pllValid[3]=True
			self.systemStatus.pllValid[4]=True
			self.systemStatus.rxLoPllIndex=[3,4]
			self.systemStatus.txLoPllIndex=[0,2]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[0]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[2]
		elif self.systemParams.pllMuxModes==4:			#4: 2T2R FDD - TDD Mode: PLL0 AB-TX; PLL3-AB-RX; PLL2 CD
			self.systemStatus.pllValid[0]=True
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=True
			self.systemStatus.pllValid[3]=True
			self.systemStatus.pllValid[4]=False
			self.systemStatus.rxLoPllIndex=[3,2]
			self.systemStatus.txLoPllIndex=[0,2]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[0]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[2]
		elif self.systemParams.pllMuxModes==5:			#5: 2T2R FDD - TDD Mode: PLL0 CD-TX; PLL4-CD-RX; PLL2 AB
			self.systemStatus.pllValid[0]=True
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=True
			self.systemStatus.pllValid[3]=False
			self.systemStatus.pllValid[4]=True
			self.systemStatus.rxLoPllIndex=[2,4]
			self.systemStatus.txLoPllIndex=[2,0]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[2]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[0]
		else:
			error("Invalid PLL Mux Mode. Doing config for '4T4R Mode with PLL0 as Master. PLL 0 for all the LOs.'")
			self.systemParams.pllMuxModes=0
			self.systemStatus.pllValid[0]=True
			self.systemStatus.pllValid[1]=True
			self.systemStatus.pllValid[2]=False
			self.systemStatus.pllValid[3]=False
			self.systemStatus.pllValid[4]=False
			self.systemStatus.rxLoPllIndex=[0,0]
			self.systemStatus.txLoPllIndex=[0,0]
			if self.systemParams.setTxLoFbNcoFreqForTxCalib==True:
				self.systemParams.fbNco[0]=self.systemParams.pllLo[0]
				self.systemParams.fbNco[1]=self.systemParams.pllLo[0]
		
		interfaceRateLowIfRx=[round(self.systemParams.Fs/self.systemParams.ddcFactorRx[0]/X,6),round(self.systemParams.Fs/self.systemParams.ddcFactorRx[1]/X,6)]
		interfaceRateLowIfFb=[round(self.systemParams.Fs/self.systemParams.ddcFactorFb[0]/X,6),round(self.systemParams.Fs/self.systemParams.ddcFactorFb[1]/X,6)]
		interfaceRateLowIfTx=[round(self.systemParams.Fs/self.systemParams.ducFactorTx[0]/X,6),round(self.systemParams.Fs/self.systemParams.ducFactorTx[1]/X,6)]
		digValid=[False,False]
		lcmGenClk=self.systemParams.Fs/2
		lcmGenDiv=8
		def getNearestIntMult(val):
			return fractions.Fraction(val).limit_denominator(31).numerator
		for instanceNo in range(2):
			valid=True
			if self.systemParams.ddcFactorRx[instanceNo]==1 or self.systemParams.ddcFactorFb[instanceNo]==1:
				if self.systemParams.Fs==3000:
					self.systemParams.LMFSHdRx[instanceNo]="41240"
					self.systemParams.LMFSHdFb[instanceNo]="41240"
				else:
					self.systemParams.LMFSHdRx[instanceNo]="81380"
					self.systemParams.LMFSHdFb[instanceNo]="81380"
				
				self.systemParams.systemMode[instanceNo]=0
				self.systemParams.dedicatedLaneMode[instanceNo]=0
			if self.systemParams.ducFactorTx[instanceNo]==1:
				self.systemParams.LMFSHdTx[instanceNo]="41240"
				self.systemParams.ducFactorTx[instanceNo]=1
				
			LMFSHdRx            =self.systemParams.LMFSHdRx[instanceNo]           
			LMFSHdFb            =self.systemParams.LMFSHdFb[instanceNo]           
			LMFSHdTx            =self.systemParams.LMFSHdTx[instanceNo]           
			systemMode          =self.systemParams.systemMode[instanceNo]
			dedicatedLaneMode   =self.systemParams.dedicatedLaneMode[instanceNo]
			sampDropByRx        =self.systemParams.sampDropByRx[instanceNo]       
			sampDropByFb        =self.systemParams.sampDropByFb[instanceNo]       
			jesdProtocol        =self.systemParams.jesdProtocol

			ddcFactorRx         =self.systemParams.ddcFactorRx[instanceNo]
			ddcFactorFb         =self.systemParams.ddcFactorFb[instanceNo]
			ducFactorTx         =self.systemParams.ducFactorTx[instanceNo]
			self.systemParams.lowIfNcoRx[instanceNo]=round(self.systemParams.lowIfNcoRx[instanceNo],3)
			if self.systemParams.lowIfNcoRx[instanceNo]==0:
				self.systemStatus.rxLowIfRate[instanceNo]=interfaceRateLowIfRx[instanceNo]
			else:
				found=False
				for rates in afeConstants.supportedRxLowIfInterfaceRates[interfaceRateLowIfRx[instanceNo]]:
					if (rates-interfaceRateLowIfRx[instanceNo])*X>=self.systemParams.lowIfNcoRx[instanceNo]:
						self.systemStatus.rxLowIfRate[instanceNo]=rates
						found=True
						break
				if found==False:
					error("Cannot Support this LOW IF NCO for this RX DDC Rate.")
					self.systemStatus.rxLowIfRate[instanceNo]=interfaceRateLowIfRx[instanceNo]
					valid=False
				
			self.systemParams.lowIfNcoFb[instanceNo]=round(self.systemParams.lowIfNcoFb[instanceNo],3)
			if self.systemParams.lowIfNcoFb[instanceNo]==0:
				self.systemStatus.fbLowIfRate[instanceNo]=interfaceRateLowIfFb[instanceNo]
			else:
				found=False
				for rates in afeConstants.supportedTxFbLowIfInterfaceRates[interfaceRateLowIfFb[instanceNo]]:
					if (rates-interfaceRateLowIfFb[instanceNo])*X>=self.systemParams.lowIfNcoFb[instanceNo]:
						self.systemStatus.fbLowIfRate[instanceNo]=rates
						found=True
						break
				if found==False:
					error("Cannot Support this LOW IF NCO for this FB DDC Rate.")
					self.systemStatus.fbLowIfRate[instanceNo]=interfaceRateLowIfFb[instanceNo]
					valid=False
				
			self.systemParams.lowIfNcoTx[instanceNo]=round(self.systemParams.lowIfNcoTx[instanceNo],3)
			if self.systemParams.lowIfNcoTx[instanceNo]==0:
				self.systemStatus.txLowIfRate[instanceNo]=interfaceRateLowIfTx[instanceNo]
			else:
				found=False
				for rates in afeConstants.supportedTxFbLowIfInterfaceRates[interfaceRateLowIfTx[instanceNo]]:
					if (rates-interfaceRateLowIfTx[instanceNo])*X>=self.systemParams.lowIfNcoTx[instanceNo]:
						self.systemStatus.txLowIfRate[instanceNo]=rates
						found=True
						break
				if found==False:
					error("Cannot Support this LOW IF NCO for this TX DUC Rate.")
					self.systemStatus.txLowIfRate[instanceNo]=interfaceRateLowIfTx[instanceNo]
					valid=False
			
				
			if halfRateModeRx==1:
				FadcRx              =FadcRx/2
			if halfRateModeFb==1:
				FadcFb              =FadcFb/2
			if halfRateModeTx==1:
				Fdac                =Fdac/2
			(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(LMFSHdRx)
			(L1,M1,F1,S1,Hd1,resolution1,NumBands1)=self.jesdModeFeatures(LMFSHdFb)
			(LRx,MRx,FRx,SRx,HdRx,resolutionRx,NumBandsRx)=self.jesdModeFeatures(LMFSHdTx)
			
			### Checking the DDC and DUC factors:
			if round((1.0*ddcFactorRx)/ddcFactorFb,4) not in (1,2,3,4):
				error("FB:RX Data rate of 1,2,3 or 4 is only supported. Got: "+str(round((1.0*ddcFactorRx)/ddcFactorFb,4)))
				valid=False
				
			if self.systemParams.ddcFactorRx[instanceNo]!=1 and self.checkValidityOfDigChain(0,ddcFactorRx,halfRateModeRx)[0]==False:
				error("RX Decimation factor, "+str(ddcFactorRx)+",Not Supported")
				valid=False
			if self.systemParams.ddcFactorFb[instanceNo]!=1 and self.checkValidityOfDigChain(1,ddcFactorFb,halfRateModeFb)[0]==False:
				error("FB Decimation factor, "+str(ddcFactorFb)+",Not Supported")
				valid=False
			if self.systemParams.ddcFactorFb[instanceNo]!=1 and self.checkValidityOfDigChain(2,ducFactorTx,halfRateModeTx)[0]==False:
				error("TX Decimation factor, "+str(ducFactorTx)+",Not Supported")
				valid=False
				
			
			if jesdProtocol in (0,3):
				packingRatio=10.0/8
			else:
				packingRatio=66.0/64
				
			laneRateByFadcRx=(resolution*M*packingRatio)/(L*ddcFactorRx*sampDropByRx)
			laneRateByFadcFb=(resolution1*M1*packingRatio)/(L1*ddcFactorFb*sampDropByFb)
			laneRateByFdacTx=(resolutionRx*MRx*packingRatio)/(LRx*ducFactorTx)
			
			if (dedicatedLaneMode==0 and systemMode!=1) and round(laneRateByFadcRx,4)!=round(laneRateByFadcFb,4):
				error("In shared lane mode of Rx and Fb, the lane rates of RX and FB should be same. Calculated: RX Lane Rate "+str(laneRateByFadcRx)+" FB Lane Rate "+str(laneRateByFadcFb))
				valid=False
			#elif (dedicatedLaneMode==0  or systemMode!=1) and round(max(laneRateByFadcRx,laneRateByFadcFb)*1.0/min(laneRateByFadcRx,laneRateByFadcFb),4) not in jesdConstants.serdesSupportedSubRateDivs:
			#	error("RX and FB Lane Rates can only be in ratios "+str(jesdConstants.serdesSupportedSubRateDivs))
			#	valid=False
			if (dedicatedLaneMode==0 and systemMode!=1) and F!=F1:
				error("In shared lane mode of Rx and Fb, the F in LMFSHd of RX and FB should be equal")
				valid=False
			if (dedicatedLaneMode==1 or systemMode==1) and (L>2 or L1>2):
				error("In dedicatedLaneMode lane mode of Rx and Fb, maximum L of 2 is supported")
				valid=False
			#if (dedicatedLaneMode==0  and systemMode!=1) and F!=F1:
			#	error("In Shared Lane Mode, F of RX and FB Modes should be same.")
			#	valid=False
			if (self.systemParams.ddcFactorRx[instanceNo]!=1 and self.systemParams.ddcFactorFb[instanceNo]!=1 and LMFSHdRx not in jesdConstants.jesdModesRx):
				error("LMFSHdRx: "+str(LMFSHdRx)+" not supported")
				valid=False
			if sampDropByFb not in jesdConstants.jesdSampleDropModes:
				error("Sample Drop For FB "+str(sampDropByFb) +" not supported")
			if sampDropByRx not in jesdConstants.jesdSampleDropModes:
				error("Sample Drop For RX "+str(sampDropByRx) +" not supported")
			if (self.systemParams.ddcFactorRx[instanceNo]!=1 and self.systemParams.ddcFactorFb[instanceNo]!=1):
				if sampDropByFb in (1,3) and LMFSHdFb not in jesdConstants.jesdModesFb:
					error("LMFSHdFb: "+str(LMFSHdFb)+" not supported for sample drop factor of "+str(sampDropByFb))
					valid=False
				if sampDropByFb not in (1,3) and LMFSHdFb not in jesdConstants.jesdModesRx:
					error("LMFSHdFb: "+str(LMFSHdFb)+" not supported for sample drop factor of "+str(sampDropByFb)+". For FB and sample drop factor not equal to 1 or 3 only RX modes are supported by JESD.")
					valid=False
			if LMFSHdTx not in jesdConstants.jesdModesTx:
				error("LMFSHdTx: "+str(LMFSHdTx)+" not supported")
				valid=False
			
			### ADC JESD TX Config
			ddcRdClkRateDivRx=ddcFactorRx
			ddcRdClkRateDivFb=ddcFactorFb*2		# Since FB comes in two streams
			
			#The multiplication with sample drop factor is because the jesd Clock Div Factor should be as if there is no sample drop
			jesdClkRateDivRx=64.0*packingRatio/(laneRateByFadcRx*sampDropByRx)	#(L*ddcFactorRx*64)/(resolution*M)
			jesdClkRateDivFb=64.0*packingRatio/(laneRateByFadcFb*sampDropByFb)	#(L1*ddcFactorFb*64)/(resolution1*M1)
			if sampDropByFb%2==0:
				jesdClkRateDivFb=2*jesdClkRateDivFb
			
			if self.systemParams.ddcFactorRx[instanceNo]==1 or self.systemParams.ddcFactorFb[instanceNo]==1:
				if self.systemParams.Fs==3000:
					LMFSHdRx="48410"
					self.systemParams.LMFSHdRx[instanceNo]=LMFSHdRx
					LMFSHdFb="44420"
					self.systemParams.LMFSHdFb[instanceNo]=LMFSHdFb
				else:
					LMFSHdRx="44310"
					self.systemParams.LMFSHdRx[instanceNo]=LMFSHdRx
					LMFSHdFb="42320"
					self.systemParams.LMFSHdFb[instanceNo]=LMFSHdFb
					
			if LMFSHdTx=="41240":
				LMFSHdTx="44210"
			jesdConfigParams=self.systemStatus.jesdConfigParams[instanceNo]
			jesdConfigParams['LMFSHdRx']=LMFSHdRx
			jesdConfigParams['LMFSHdFb']=LMFSHdFb
			jesdConfigParams['LMFSHdTx']=LMFSHdTx
			jesdConfigParams['sampDropByRx']=sampDropByRx
			jesdConfigParams['sampDropByFb']=sampDropByFb
			if jesdProtocol in (2,3):
				jesdConfigParams['TX_K']=0
				jesdConfigParams['RX_K']=0
			else:
				jesdConfigParams['TX_K']=self.systemParams.jesdK[instanceNo]-1#15
				jesdConfigParams['RX_K']=self.systemParams.jesdK[instanceNo]-1#15
			jesdConfigParams['dedicated_rx_fb_lane_mode']=dedicatedLaneMode
			jesdConfigParams['dedicated_tx_lane_mode']=0
			jesdConfigParams['jesdProtocol']=jesdProtocol
			jesdConfigParams['scr']=self.systemParams.jesdScr[instanceNo]
			jesdConfigParams['RX_RBD']=self.systemParams.jesdRxRbd[instanceNo]

			if ddcFactorRx==1:
				jesdConfigParams['systemMode']=0
				self.systemParams.systemMode[instanceNo]=0
			else:
				jesdConfigParams['systemMode']=systemMode
			
			### DAC JESD RX Config
			ducWrClkRateDivTx=ducFactorTx*2		# Since TX streams are in pairs of two
			jesdClkRateDivTx=64.0*packingRatio/laneRateByFdacTx#(LRx*ducFactorTx*64)/(resolutionRx*MRx)
			found=False
			
			
			if ddcFactorRx==1:
				if self.systemParams.Fs==3000:
					jesdConfigParams['rootClkDivRxFb']		=1
					jesdConfigParams['ddcRdClkDivFactorRx']	=1
					jesdConfigParams['ddcRdClkDivFactorFb']	=1
					jesdConfigParams['jesdClkDivFactorRx']	=2
					jesdConfigParams['jesdClkDivFactorFb']	=2
				else:
					jesdConfigParams['rootClkDivRxFb']		=1
					jesdConfigParams['ddcRdClkDivFactorRx']	=1
					jesdConfigParams['ddcRdClkDivFactorFb']	=1
					jesdConfigParams['jesdClkDivFactorRx']	=round(8./3,4)
					jesdConfigParams['jesdClkDivFactorFb']	=round(8./3,4)
					
					
				# Root Clock Div Giving Priority to the lowest division factor of the derived clocks
				reorderedMainClockDivFactors=jesdConstants.rootClockDivFactors[:]
				minimumClockDivRootClock=min(ducWrClkRateDivTx,jesdClkRateDivTx)/8.0
				if minimumClockDivRootClock in [round(x,4) for x in reorderedMainClockDivFactors]:
					reorderedMainClockDivFactors.pop(reorderedMainClockDivFactors.index(minimumClockDivRootClock))
					reorderedMainClockDivFactors=[minimumClockDivRootClock,]+reorderedMainClockDivFactors
				
							# Finding the suitable clock division factors
				for rootClkDiv in reorderedMainClockDivFactors:
					if rootClkDiv==0 or isinstance(rootClkDiv, str)==True:
						continue
					if round(ducWrClkRateDivTx/(8.0*rootClkDiv),4) in jesdConstants.ducWrClockDivFactors and \
						round(jesdClkRateDivTx/(8.0*rootClkDiv),4) in jesdConstants.jesdClockDivFactors:
						found=True
						jesdConfigParams['rootClkDivTx']=rootClkDiv
						jesdConfigParams['ducWrClkDivFactorTx']=round(ducWrClkRateDivTx/(8.0*rootClkDiv),4)
						jesdConfigParams['jesdClkDivFactorTx']=round(jesdClkRateDivTx/(8.0*rootClkDiv),4)
						break
						
				if found==False:
					valid=False
					error("No Possible Jesd RX Clock Dividers Supported")
					jesdConfigParams['rootClkDivTx']=rootClkDiv
					jesdConfigParams['ducWrClkDivFactorTx']=1
					jesdConfigParams['jesdClkDivFactorTx']=1
					
			else:
				found=False
				# Root Clock Div Giving Priority to the lowest division factor of the derived clocks
				reorderedMainClockDivFactors=jesdConstants.rootClockDivFactors[:]
				minimumClockDivRootClock=min(ddcRdClkRateDivRx,ddcRdClkRateDivFb,jesdClkRateDivRx,jesdClkRateDivFb,ducWrClkRateDivTx,jesdClkRateDivTx)/8.0
				if minimumClockDivRootClock in reorderedMainClockDivFactors:
					reorderedMainClockDivFactors.pop(reorderedMainClockDivFactors.index(minimumClockDivRootClock))
					reorderedMainClockDivFactors=[minimumClockDivRootClock,]+reorderedMainClockDivFactors
				
				# Finding the suitable clock division factors
				for rootClkDiv in reorderedMainClockDivFactors:
					if rootClkDiv==0 or isinstance(rootClkDiv, str)==True:
						continue
					if round(ddcRdClkRateDivRx/(8.0*rootClkDiv),4) in [round(x,4) for x in jesdConstants.ddcRdClockDivFactors] and \
						round(ddcRdClkRateDivFb/(8.0*rootClkDiv),4) in [round(x,4) for x in jesdConstants.ddcRdClockDivFactors] and \
						round(jesdClkRateDivRx/(8.0*rootClkDiv),4) in [round(x,4) for x in jesdConstants.jesdClockDivFactors] and \
						round(jesdClkRateDivFb/(8.0*rootClkDiv),4) in [round(x,4) for x in jesdConstants.jesdClockDivFactors] and \
						round(ducWrClkRateDivTx/(8.0*rootClkDiv),4) in jesdConstants.ducWrClockDivFactors and \
						round(jesdClkRateDivTx/(8.0*rootClkDiv),4) in jesdConstants.jesdClockDivFactors:
						found=True
						jesdConfigParams['rootClkDivRxFb']=rootClkDiv
						jesdConfigParams['ddcRdClkDivFactorRx']=round(ddcRdClkRateDivRx/(8.0*rootClkDiv),4)
						jesdConfigParams['ddcRdClkDivFactorFb']=round(ddcRdClkRateDivFb/(8.0*rootClkDiv),4)
						jesdConfigParams['jesdClkDivFactorRx']=round(jesdClkRateDivRx/(8.0*rootClkDiv),4)
						jesdConfigParams['jesdClkDivFactorFb']=round(jesdClkRateDivFb/(8.0*rootClkDiv),4)
						jesdConfigParams['rootClkDivTx']=rootClkDiv
						jesdConfigParams['ducWrClkDivFactorTx']=round(ducWrClkRateDivTx/(8.0*rootClkDiv),4)
						jesdConfigParams['jesdClkDivFactorTx']=round(jesdClkRateDivTx/(8.0*rootClkDiv),4)
						break
						
				if found==False:
					valid=False
					error("No Possible Jesd Clock Dividers Supported")
					jesdConfigParams['rootClkDivRxFb']=rootClkDiv
					jesdConfigParams['ddcRdClkDivFactorRx']=1
					jesdConfigParams['ddcRdClkDivFactorFb']=1
					jesdConfigParams['jesdClkDivFactorRx']=1
					jesdConfigParams['jesdClkDivFactorFb']=1
					jesdConfigParams['rootClkDivTx']=rootClkDiv
					jesdConfigParams['ducWrClkDivFactorTx']=1
					jesdConfigParams['jesdClkDivFactorTx']=1
			digValid[instanceNo]=valid
			self.systemStatus.jesdConfigParams[instanceNo]=jesdConfigParams.copy()
			#self.systemStatus.serdesConfig[instanceNo]=serdesConfig.copy()
			
			self.systemStatus.laneRateRx[instanceNo]=round(laneRateByFadcRx*self.systemParams.Fs,6)
			self.systemStatus.laneRateFb[instanceNo]=round(laneRateByFadcFb*self.systemParams.Fs,6)
			self.systemStatus.laneRateTx[instanceNo]=round(laneRateByFdacTx*self.systemParams.Fs,6)
			
			if self.systemParams.systemMode[instanceNo]==1 or self.systemParams.dedicatedLaneMode[instanceNo]==1:
				for i in range(2):
					self.systemStatus.serdesTxLaneRatePreReorder[i+(instanceNo*4)]=self.systemStatus.laneRateRx[instanceNo]
					self.systemStatus.serdesTxLaneRatePreReorder[i+(instanceNo*4)+2]=self.systemStatus.laneRateFb[instanceNo]
			else:
				for i in range(4):
					self.systemStatus.serdesTxLaneRatePreReorder[i+(instanceNo*4)]=self.systemStatus.laneRateRx[instanceNo]
					
			for i in range(4):
				self.systemStatus.serdesRxLaneRatePreReorder[i+(instanceNo*4)]=self.systemStatus.laneRateTx[instanceNo]
			
		
			if self.systemParams.jesdProtocol==0:
				frameClockDivRx=getNearestIntMult(lcmGenClk/(self.systemStatus.laneRateRx[instanceNo]/self.lcm([(self.systemParams.jesdK[instanceNo]*F*10),80])))
				frameClockDivFb=getNearestIntMult(lcmGenClk/(self.systemStatus.laneRateFb[instanceNo]/self.lcm([(self.systemParams.jesdK[instanceNo]*F1*10),80])))
				frameClockDivTx=getNearestIntMult(lcmGenClk/(self.systemStatus.laneRateTx[instanceNo]/self.lcm([(self.systemParams.jesdK[instanceNo]*FRx*10),80])))
			else:                                                                                 
				frameClockDivRx=getNearestIntMult(lcmGenClk/(self.systemStatus.laneRateRx[instanceNo]/self.lcm([(self.systemParams.jesdK[instanceNo]*66*32),80])))
				frameClockDivFb=getNearestIntMult(lcmGenClk/(self.systemStatus.laneRateFb[instanceNo]/self.lcm([(self.systemParams.jesdK[instanceNo]*66*32),80])))
				frameClockDivTx=getNearestIntMult(lcmGenClk/(self.systemStatus.laneRateTx[instanceNo]/self.lcm([(self.systemParams.jesdK[instanceNo]*66*32),80])))
			
			lcmGenDiv=self.lcm([frameClockDivRx,frameClockDivTx,frameClockDivFb,lcmGenDiv])
			if round(ddcFactorRx,5)%1==0:
				lcmGenDiv=self.lcm([lcmGenDiv,ddcFactorRx])
			else:
				lcmGenDiv=self.lcm([lcmGenDiv,fractions.Fraction(ddcFactorRx).limit_denominator(31).numerator])
			if round(ddcFactorFb*2,5)%1==0:
				lcmGenDiv=self.lcm([lcmGenDiv,ddcFactorFb*2])
			else:
				lcmGenDiv=self.lcm([lcmGenDiv,fractions.Fraction(ddcFactorFb*2).limit_denominator(31).numerator])
			if round(ducFactorTx*2,5)%1==0:
				lcmGenDiv=self.lcm([lcmGenDiv,ducFactorTx*2])
			else:
				lcmGenDiv=self.lcm([lcmGenDiv,fractions.Fraction(ducFactorTx*2).limit_denominator(31).numerator])
			
		if True:#self.systemParams.sysrefFreqDiv==1:
			self.systemParams.sysrefFreqDiv=lcmGenDiv
		
		calibValid=True
		if self.systemParams.enableTxIqmcLolTrackingCorr==True:
			if self.systemParams.txIqMcCalibMode==0:
				if self.systemStatus.txLowIfRate[0]!=self.systemStatus.fbLowIfRate[0] and self.systemStatus.txLowIfRate[1]!=self.systemStatus.fbLowIfRate[0]:
						error("For TX IQMC correction to work, the post low-IF rates for FB and TX should be equal. Either put FB lowIfNcoFb close to lowIfNcoTx or use the FB rate of "+str(round(X*self.systemStatus.txLowIfRate[instanceNo],6))+" with lowIfNcoFb as 0. That is ddcFactorFb as "+str(round(self.systemParams.Fs/(X*self.systemStatus.txLowIfRate[instanceNo]),6)))
						calibValid=False
			elif self.systemParams.txIqMcCalibMode==1:
				if self.systemStatus.txLowIfRate[0]!=self.systemStatus.fbLowIfRate[1] and self.systemStatus.txLowIfRate[1]!=self.systemStatus.fbLowIfRate[1]:
						error("For TX IQMC correction to work, the post low-IF rates for FB and TX should be equal. Either put FB lowIfNcoFb close to lowIfNcoTx or use the FB rate of "+str(round(X*self.systemStatus.txLowIfRate[instanceNo],6))+" with lowIfNcoFb as 0. That is ddcFactorFb as "+str(round(self.systemParams.Fs/(X*self.systemStatus.txLowIfRate[instanceNo]),6)))
						calibValid=False
			elif self.systemParams.txIqMcCalibMode==2:
				if self.systemStatus.txLowIfRate[0]!=self.systemStatus.fbLowIfRate[0] and self.systemStatus.txLowIfRate[1]!=self.systemStatus.fbLowIfRate[1]:
						error("For TX IQMC correction to work, the post low-IF rates for FB and TX should be equal. Either put FB lowIfNcoFb close to lowIfNcoTx or use the FB rate of "+str(round(X*self.systemStatus.txLowIfRate[instanceNo],6))+" with lowIfNcoFb as 0. That is ddcFactorFb as "+str(round(self.systemParams.Fs/(X*self.systemStatus.txLowIfRate[instanceNo]),6)))
						calibValid=False

		serdesValid=self.initializeSerdesConfig()
		if self.systemParams.agcRegConfigParams[0]['enableIa']==True or self.systemParams.agcRegConfigParams[1]['enableIa']==True:
				self.systemParams.agcRegConfigParams[0]['gainControl']=2
				self.systemParams.agcRegConfigParams[1]['gainControl']=2
		if self.systemParams.agcRegConfigParams[2]['enableIa']==True or self.systemParams.agcRegConfigParams[3]['enableIa']==True:
				self.systemParams.agcRegConfigParams[2]['gainControl']=2
				self.systemParams.agcRegConfigParams[3]['gainControl']=2
				
		for instanceNo in range(2):
			self.systemStatus.validConfig[instanceNo]=serdesValid[instanceNo] & digValid[instanceNo] & calibValid
			valid=self.systemStatus.validConfig[instanceNo]
			info("2T2R1F Number: "+str(instanceNo))
			if self.systemStatus.validConfig[instanceNo]:
				info("Valid Configuration: "+str(self.systemStatus.validConfig[instanceNo]))
			else:
				error("Valid Configuration: "+str(self.systemStatus.validConfig[instanceNo]))
			info("laneRateRx: "+str(self.systemStatus.laneRateRx[instanceNo]))
			info("laneRateFb: "+str(self.systemStatus.laneRateFb[instanceNo]))
			info("laneRateTx: "+str(self.systemStatus.laneRateTx[instanceNo]))
			
		return valid,jesdConfigParams,self.systemStatus.serdesConfig,laneRateByFadcRx,laneRateByFadcFb,laneRateByFdacTx		
	#initializeConfig


	def lcm(self,list):
		lcm = 1
		for i in list:
		  lcm = lcm*i/gcd(lcm, i)
		return lcm
		
	@funcDecorator
	def initializeSerdesConfig(self):
		serdesValid=[False,False]
		
		reorderedSerdesTxLaneRate=self.systemStatus.serdesTxLaneRatePreReorder[:]
		reorderedSerdesRxLaneRate=self.systemStatus.serdesRxLaneRatePreReorder[:]
		if True:#self.systemParams.externalClockRx==True and self.systemParams.externalClockTx==True:
			FRef=self.systemParams.FRef
		else:
			FRef=self.systemStatus.pllConfigParams['vcoFreq']
			
		for i in range(8):
			reorderedSerdesTxLaneRate[i]=self.systemStatus.serdesTxLaneRatePreReorder[self.systemParams.jesdTxLaneMux[i]]
			reorderedSerdesRxLaneRate[i]=self.systemStatus.serdesRxLaneRatePreReorder[self.systemParams.jesdRxLaneMux.index(i)]
			
		self.systemStatus.serdesTxLaneRate=reorderedSerdesTxLaneRate[:]
		self.systemStatus.serdesRxLaneRate=reorderedSerdesRxLaneRate[:]
		
		for instanceNo in range(2):
			valid=True
			serdesConfig=self.systemStatus.serdesConfig[instanceNo]
			serdesConfig['subRateDivSerdesTx']=[1]*4
			found=False
			for minMax in jesdConstants.serdesSupportedVcoRatesMinMax:
				validLanes=0
				for laneNo in range(4):
					for subRateDiv in jesdConstants.serdesSupportedSubRateDivs:
						if (reorderedSerdesTxLaneRate[(instanceNo*4)+laneNo]*1.0e-3*subRateDiv) > minMax[0] and (reorderedSerdesTxLaneRate[(instanceNo*4)+laneNo]*1.0e-3*subRateDiv) < minMax[1]:
							validLanes+=1
							serdesConfig['subRateDivSerdesTx'][laneNo]=subRateDiv
							break
				if validLanes==4:
					found=True
					serdesConfig['serdesTxVcoRange']=minMax
					serdesConfig['serdesTxVco']=reorderedSerdesTxLaneRate[(instanceNo*4)]*serdesConfig['subRateDivSerdesTx'][0]
					break
			if found==False:
				error("Serdes TX Lane Rate for Rx Not in Serdes Range. Lane Rate: "+str(self.systemStatus.laneRateRx[instanceNo]))
				valid=False
				serdesConfig['serdesTxVcoRange']=(27,32)
				serdesConfig['serdesTxVco']=14745.6
			
			
			serdesConfig['subRateDivSerdesRx']=[1]*4
			found=False
			for minMax in jesdConstants.serdesSupportedVcoRatesMinMax:
				validLanes=0
				for laneNo in range(4):
					for subRateDiv in jesdConstants.serdesSupportedSubRateDivs:
						if (reorderedSerdesRxLaneRate[(instanceNo*4)+laneNo]*1.0e-3*subRateDiv) > minMax[0] and (reorderedSerdesRxLaneRate[(instanceNo*4)+laneNo]*1.0e-3*subRateDiv) < minMax[1]:
							validLanes+=1
							serdesConfig['subRateDivSerdesRx'][laneNo]=subRateDiv
							break
				if validLanes==4:
					found=True
					serdesConfig['serdesRxVcoRange']=minMax
					serdesConfig['serdesRxVco']=reorderedSerdesRxLaneRate[(instanceNo*4)]*serdesConfig['subRateDivSerdesRx'][0]
					break
			if found==False:
				error("Serdes RX Lane Rate for Rx Not in Serdes Range. Lane Rate: "+str(self.systemStatus.laneRateRx[instanceNo]))
				valid=False
				serdesConfig['serdesRxVcoRange']=(27,32)
				serdesConfig['serdesRxVco']=14745.6
			serdesValid[instanceNo]=valid
		
		refClkIpDivFinal=[1,1]
		found=False
		for refClkIpDiv in jesdConstants.serdesIpDivFactors:
			validInstances=0
			for instanceNo in range(2):
				if round(self.systemStatus.serdesConfig[instanceNo]['serdesTxVco']/(FRef*4.0/refClkIpDiv),5) in jesdConstants.serdesSupportedPllMulFactors and (FRef/refClkIpDiv)<500:
					if round(self.systemStatus.serdesConfig[instanceNo]['serdesRxVco']/(FRef*4.0/refClkIpDiv),5) in jesdConstants.serdesSupportedPllMulFactors:
						validInstances+=1
						refClkIpDivFinal[instanceNo]=refClkIpDiv

			if validInstances==2:
				self.systemStatus.serdesConfig[0]['refClkIpDiv']=refClkIpDivFinal[0]
				self.systemStatus.serdesConfig[1]['refClkIpDiv']=refClkIpDivFinal[1]
				found=True
				break
		if found==False:
			error("Could not find proper divider for SERDES input from reference clock.")
			self.systemStatus.serdesConfig[0]['refClkIpDiv']=1
			self.systemStatus.serdesConfig[1]['refClkIpDiv']=1
			serdesValid[0]=False
			serdesValid[1]=False
			
		for instanceNo in range(2):
			self.systemStatus.serdesConfig[instanceNo]['serdesTxPllN']=int(round(self.systemStatus.serdesConfig[instanceNo]['serdesTxVco']/(FRef*4.0/refClkIpDivFinal[instanceNo]),5))	
			self.systemStatus.serdesConfig[instanceNo]['serdesRxPllN']=int(round(self.systemStatus.serdesConfig[instanceNo]['serdesRxVco']/(FRef*4.0/refClkIpDivFinal[instanceNo]),5))

		return serdesValid
	#initializeSerdesConfig
	
	@funcDecorator
	def getRatesForMcu(self):
		if round(48./self.systemParams.ddcFactorRx[0],5) in (0.5,1.0,1.5,2.0,3.0,4.0,6.0):
			X=self.systemParams.Fs/48.
			self.systemStatus.mcuParams['Fs']=48
		elif round(54./self.systemParams.ddcFactorRx[0],5) in (0.5,1.0,1.5,2.0,3.0,4.0,6.0):
			X=self.systemParams.Fs/54.
			self.systemStatus.mcuParams['Fs']=54
		elif round(56./self.systemParams.ddcFactorRx[0],5) in (0.5,1.0,1.5,2.0,3.0,4.0,6.0):
			X=self.systemParams.Fs/56.
			self.systemStatus.mcuParams['Fs']=56
		else:
			error("Unsupported Decimation factor")
			X=62.5
			self.systemStatus.mcuParams['Fs']=48
		self.systemParams.X=X
	#getRatesForMcu
	
#projectBaseClass