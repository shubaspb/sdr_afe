from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *

import common.mMACROConst
reload(common.mMACROConst)
from common.mMACROConst import MACROConst
from common.mMACROConst import rxCalibInit

import mCalibTopHw
reload(mCalibTopHw)
from mCalibTopHw import CalibTopHw
import mCalibTopFw
reload(mCalibTopFw)
from mCalibTopFw import CalibTopFw

import mCalibTopConst
reload(mCalibTopConst)
from mCalibTopConst import *

import rxIqMc.mRxIqmcMailboxMessage
reload(rxIqMc.mRxIqmcMailboxMessage)

import random
import math
class CalibTop(projectBaseClass):
	"""Contains Calib top FW specific functions self.regs=device.TOP """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.CALIBTOP_HW=CalibTopHw(regs)
		self.CALIBTOP_FW=CalibTopFw(regs)
		self.rx_mailbox=rxIqMc.mRxIqmcMailboxMessage.RxIqmcMailboxMessage(regs,deviceRefs)
		self.errorList=['','']
		self.byteList=[0]*80;
		self.NBytesPerWord=4
		self.updateDeviceRefsInBaseClass(deviceRefs)
	#__init__

	@funcDecorator
	def reset(self,rst):
		""" "Resetting Top MC" "Done resetting Top MC" """
		self.regs.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg=rst
	#resetCm4
	
	@funcDecorator
	def writeOperandList(self, operandList):
		for i in range(0, len(operandList)):
			debug('OperandList='+str(hex(operandList[i])))
			#exec('self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf'+str(i)' = operandList[i]')
			command='self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf'+str(i)+'='+str(hex(operandList[i]))
			debug("Command="+command)
			exec(command)
	
	@funcDecorator
	def packBytesintoOperandsAndWrite(self, NBytesToWrite):
		operandList=[];
		NOperandsTowrite=NBytesToWrite//4;
		NExtraBytesToWrite=NBytesToWrite%4;
	
		if NExtraBytesToWrite!=0:
			NOperandsTowrite = NOperandsTowrite+1;
			
		for i in range(0, NOperandsTowrite):
			operandNum = 0;
	
			for j in range(0, self.NBytesPerWord):
				operandNum += self.byteList[i*self.NBytesPerWord+j]<<(j*8);
	
			operandList.append(operandNum);
	
		self.writeOperandList(operandList);

	
	@funcDecorator
	def wait_for_macro_ready(self):
		#self.regs.MACRO.FW_REGS.CM4_WR_SPI_REFLECT._cm4_wr_spi_rf0.getValue()
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.customer_macro=1
		logTemp=self.deviceRefs.device.rawWriteLogEn
		self.deviceRefs.device.rawWriteLogEn=0
		self.deviceRefs.device.printCommentToLog("SPIPoll 00f0,0,0,1")#"Poll for the bit 0 of the above read value to become 1.")
		if self.systemParams.simulationMode==False:
			count=0
			# while (self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_READY == 0 and count<=5000):
			while ((self.regs.MACRO.FW_REGS.CM4_WR_SPI_REFLECT.cm4_wr_spi_rf0)&0x1 == 0 and count<=20):
				count=count+1
				self.delay(0.002)
				info("Waiting for MACRO_READY bit to go high, count: " + str(count))
				if(count>100):
					error("Waiting for MACRO_READY bit to go high failed")
					break
		self.deviceRefs.device.rawWriteLogEn=logTemp
	#wait_for_macro_ready

####################################################################################
	@funcDecorator
	def wait_for_macro_done(self):
		#self.regs.MACRO.FW_REGS.CM4_WR_SPI_REFLECT._cm4_wr_spi_rf0.getValue()
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.customer_macro=1
		logTemp=self.deviceRefs.device.rawWriteLogEn
		self.deviceRefs.device.rawWriteLogEn=0
		#self.delay(0.002)
		self.deviceRefs.device.printCommentToLog("SPIPoll 00f0,0,7,7")#"Poll for the bit 2 of the above read value to become 1.")
		if self.systemParams.simulationMode==False:
			count=0
			# while (self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_DONE == 0 and count<=5000):
			while (((self.regs.MACRO.FW_REGS.CM4_WR_SPI_REFLECT.cm4_wr_spi_rf0)&0x4)>>2 == 0 and count<=20):
				self.delay(0.002)
				count=count+1
				info("Waiting for MACRO_DONE bit to go high, count: " + str(count))
				if(count>100):
					error("Waiting for MACRO_DONE bit to go high failed")
					break
		self.deviceRefs.device.rawWriteLogEn=logTemp
	#wait_for_macro_done

####################################################################################
	@funcDecorator
	def wait_for_macro_ack(self):
		#self.regs.MACRO.FW_REGS.CM4_WR_SPI_REFLECT._cm4_wr_spi_rf0.getValue()
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.customer_macro=1
		logTemp=self.deviceRefs.device.rawWriteLogEn
		self.deviceRefs.device.rawWriteLogEn=0

		self.deviceRefs.device.printCommentToLog("SPIPoll 00f0,1,1,1")#"Poll for the bit 1 of the above read value to become 1.")
		if self.systemParams.simulationMode==False:
			# while self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ACK == 0:
			count=0
			while (((self.regs.MACRO.FW_REGS.CM4_WR_SPI_REFLECT.cm4_wr_spi_rf0)&0x2)>>1 == 0):
				self.delay(0.002)
				count=count+1
				info('Waiting for MACRO_ACK bit to go high')
				if(count>100):
					error("Waiting for MACRO_ACK bit to go high failed")
					break
		self.deviceRefs.device.rawWriteLogEn=logTemp
	#wait_for_macro_ack

####################################################################################
	@funcDecorator
	def enable_macro_page(self):
		self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.customer_macro=1;
	# enable_macro_page

	@funcDecorator
	def get_macro_status(self,EXPECTED_ERROR=-1):
		return_param={}
		info('MACRO_READY: '+ str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_READY))
		info('MACRO_ACK: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ACK))
		info('MACRO_DONE: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_DONE))
		self.deviceRefs.device.expectedReadValue=0x0
		MACRO_ERROR=self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR
		info('MACRO_ERROR: '+str(MACRO_ERROR))
		if MACRO_ERROR==True:
			self.deviceRefs.device.expectedReadValue=0x0
			MACRO_ERROR_EXTENDED_CODE=self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_EXTENDED_CODE
			self.deviceRefs.device.expectedReadValue=0x0
			error('MACRO_ERROR_IN_OPCODE: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_OPCODE))
			self.deviceRefs.device.expectedReadValue=0x0
			error('MACRO_ERROR_OPCODE_NOT_ALLOWED: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_OPCODE_NOT_ALLOWED))
			self.deviceRefs.device.expectedReadValue=0x0
			error('MACRO_ERROR_IN_OPERAND: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_OPERAND))
			self.deviceRefs.device.expectedReadValue=0x0
			error('MACRO_ERROR_IN_EXECUTION: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_EXECUTION))
			self.deviceRefs.device.expectedReadValue=0x0
			error('MACRO_ERROR_OPCODE: '+str(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_OPCODE))
			self.deviceRefs.device.expectedReadValue=0x0
			error('MACRO_ERROR_EXTENDED: '+str(MACRO_ERROR_EXTENDED_CODE))
			if MACRO_ERROR_EXTENDED_CODE!=0:
				self.interpret_macro_error_extended_code(MACRO_ERROR_EXTENDED_CODE)
		else:
			MACRO_ERROR_EXTENDED_CODE=0
		return_param['MACRO_ERROR_EXTENDED_CODE']=MACRO_ERROR_EXTENDED_CODE
		if (MACRO_ERROR_EXTENDED_CODE!=EXPECTED_ERROR) and EXPECTED_ERROR!=-1:
			return_param['err_cnt']=1
		else:
			return_param['err_cnt']=0
		return(return_param)
	#get_macro_status():
	
	
####################################################################################
	@funcDecorator
	def check_for_macro_error(self,get_macro_error_extended_code=0):
		self.deviceRefs.device.expectedReadValue=0
		self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF._MACRO_ERROR.getValue()
		if self.systemParams.simulationMode==True:
			if (get_macro_error_extended_code==1):
				return(0,0,0,0,0,0)
			else:
				return(0,0,0,0,0)
		if (get_macro_error_extended_code==1):
			return(
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_OPCODE,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_OPCODE_NOT_ALLOWED,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_OPERAND,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_EXECUTION,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_EXTENDED_CODE);
		else:
			return(
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_OPCODE,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_OPCODE_NOT_ALLOWED,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_OPERAND,
				self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_ERROR_IN_EXECUTION);
	# check_for_macro_error

####################################################################################
	@funcDecorator
	def trigger_macro(self, opcode):
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = opcode<<24
		debug('Triggering MACRO by writing the opcode : '+str(hex(self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand)))
	#trigger_macro

####################################################################################
	@funcDecorator
	def set_32b_read(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__READ_32B; 
	#set_32b_read

####################################################################################
	@funcDecorator
	def set_16b_read(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__READ_16B; 

	#set_16b_read

####################################################################################
	@funcDecorator
	def set_8b_read(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__READ_8B; 

	#set_8b_read
	
####################################################################################
	@funcDecorator
	def set_multiword_read(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__READ_BURST;

	#set_multiword_read

####################################################################################
	@funcDecorator
	def set_32b_write(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__WRITE_32B;

	#set_32b_write

####################################################################################
	@funcDecorator
	def set_16b_write(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__WRITE_16B;

	#set_16b_write

####################################################################################
	@funcDecorator
	def set_8b_write(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__WRITE_8B;

	#set_8b_write
	
####################################################################################
	@funcDecorator
	def set_multiword_write(self):
		self.byteList[0]=MACROConst.MACRO_RDWR__WRITE_BURST;

	#set_multiword_write

####################################################################################
	@funcDecorator
	def set_length_for_multiword_write(self, length):
		self.byteList[1]=(length)%256; 
		self.byteList[2]=(length//256)%256; 

	#set_length_for_multiword_write

####################################################################################
	@funcDecorator
	def set_length_for_multiword_read(self, length):
		self.byteList[5]=(length)%256; 
		self.byteList[6]=(length//256)%256; 

	#set_length_for_multiword_read

####################################################################################
	@funcDecorator
	def set_8b_word_for_write(self, word8b_to_write):
		self.byteList[5]=word8b_to_write;
		self.byteList[6]=0;
		self.byteList[7]=0;
		self.byteList[8]=0;

	#set_8b_word_for_write

####################################################################################
	@funcDecorator
	def set_16b_word_for_write(self, word16b_to_write):
		self.byteList[5]=word16b_to_write%256;
		self.byteList[6]=word16b_to_write//256;
		self.byteList[7]=0;
		self.byteList[8]=0;

	#set_16b_word_for_write

####################################################################################
	@funcDecorator
	def set_32b_word_for_write(self, word32b_to_write):
		self.byteList[5]=(word32b_to_write)%256;
		self.byteList[6]=(word32b_to_write//256)%256;
		self.byteList[7]=(word32b_to_write//256//256)%256;
		self.byteList[8]=(word32b_to_write//256//256//256)%256;

	#set_32b_word_for_write

####################################################################################
	@funcDecorator
	def set_address_for_rdwr(self, address):
		local_address=address;

		for i in range(0,4):
			self.byteList[i+1]=local_address%256; 
			local_address = local_address//256;

	#set_address_for_rdwr

####################################################################################
	@funcDecorator
	def read_8b_result(self):
		return(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_STATUS_RESULT_0%256)
	#read_8b_result

####################################################################################
	@funcDecorator
	def read_16b_result(self):
		return(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_STATUS_RESULT_0%65536)
	#read_16b_result
	
####################################################################################
	@funcDecorator
	def read_32b_result(self):
		return(self.regs.INTERNAL_MACRO.FW_REGS.CM4_WR_SPI_RF.MACRO_STATUS_RESULT_0)
	#read_32b_result

####################################################################################
	@funcDecorator
	def set_rx_iqmc_start(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__START_CALIB;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_start

####################################################################################
	@funcDecorator
	def set_rx_iqmc_reset_states(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__RESET_STATES;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_reset_states

####################################################################################
	@funcDecorator
	def set_rx_iqmc_freeze_estimation(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__FREEZE_ESTIMATION;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_freeze_estimation

####################################################################################
	@funcDecorator
	def set_rx_iqmc_unfreeze_estimation(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__UNFREEZE_ESTIMATION;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_unfreeze_estimation

####################################################################################
	@funcDecorator
	def set_rx_iqmc_freeze_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__FREEZE_CORRECTION;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_freeze_correction

####################################################################################
	@funcDecorator
	def set_rx_iqmc_unfreeze_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__UNFREEZE_CORRECTION;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_unfreeze_correction

####################################################################################
	@funcDecorator
	def set_rx_iqmc_bypass_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__BYPASS_CORRECTION;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_bypass_correction

####################################################################################
	@funcDecorator
	def set_rx_iqmc_unbypass_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_RX_IQMC_SS_CALIB__UNBYPASS_CORRECTION;
		self.byteList[1] = channel_selected
	# set_rx_iqmc_unbypass_correction

####################################################################################
	@funcDecorator
	def set_tx_iqmc_start(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_IQMC_SS_CALIB__START_CALIB;
		self.byteList[1] = channel_selected
	# set_tx_iqmc_start

####################################################################################
	@funcDecorator
	def set_tx_iqmc_reset_states(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_IQMC_SS_CALIB__RESET_STATES;
		self.byteList[1] = channel_selected
	# set_tx_iqmc_reset_states

####################################################################################
	@funcDecorator
	def set_tx_iqmc_freeze_estimation(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_IQMC_SS_CALIB__FREEZE_ESTIMATION;
		self.byteList[1] = channel_selected
	# set_tx_iqmc_freeze_estimation

####################################################################################
	@funcDecorator
	def set_tx_iqmc_freeze_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_IQMC_SS_CALIB__FREEZE_CORRECTION;
		self.byteList[1] = channel_selected
	# set_tx_iqmc_freeze_correction

####################################################################################
	@funcDecorator
	def set_tx_iqmc_bypass_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_IQMC_SS_CALIB__BYPASS_CORRECTION;
		self.byteList[1] = channel_selected
	# set_tx_iqmc_bypass_correction

####################################################################################
	@funcDecorator
	def set_dc_offset_start(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_DC_OFFSET_SS_CALIB__START_CALIB;
		self.byteList[1] = channel_selected
	# set_dc_offset_start

####################################################################################
	@funcDecorator
	def set_dc_offset_reset_states(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_DC_OFFSET_SS_CALIB__RESET_STATES;
		self.byteList[1] = channel_selected
	# set_dc_offset_reset_states

####################################################################################
	@funcDecorator
	def set_dc_offset_freeze_estimation(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_DC_OFFSET_SS_CALIB__FREEZE_ESTIMATION;
		self.byteList[1] = channel_selected
	# set_dc_offset_freeze_estimation

####################################################################################
	@funcDecorator
	def set_dc_offset_freeze_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_DC_OFFSET_SS_CALIB__FREEZE_CORRECTION;
		self.byteList[1] = channel_selected
	# set_dc_offset_freeze_correction

####################################################################################
	@funcDecorator
	def set_dc_offset_bypass_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_DC_OFFSET_SS_CALIB__BYPASS_CORRECTION;
		self.byteList[1] = channel_selected
	# set_dc_offset_bypass_correction

####################################################################################
	@funcDecorator
	def set_tx_lo_start(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_LO_SS_CALIB__START_CALIB;
		self.byteList[1] = channel_selected
	# set_tx_lo_start

####################################################################################
	@funcDecorator
	def set_tx_lo_reset_states(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_LO_SS_CALIB__RESET_STATES;
		self.byteList[1] = channel_selected
	# set_tx_lo_reset_states

####################################################################################
	@funcDecorator
	def set_tx_lo_freeze_estimation(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_LO_SS_CALIB__FREEZE_ESTIMATION;
		self.byteList[1] = channel_selected
	# set_tx_lo_freeze_estimation

####################################################################################
	@funcDecorator
	def set_tx_lo_freeze_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_LO_SS_CALIB__FREEZE_CORRECTION;
		self.byteList[1] = channel_selected
	# set_tx_lo_freeze_correction

####################################################################################
	@funcDecorator
	def set_tx_lo_bypass_correction(self, channel_selected):
		self.byteList[0] = MACROConst.MACRO_TX_LO_SS_CALIB__BYPASS_CORRECTION;
		self.byteList[1] = channel_selected
	# set_tx_lo_bypass_correction

####################################################################################
	@funcDecorator
	def set_dc_offset_only_powerup_calib(self, channel_selected):
		bytesLen = 3;
		self.byteList[0] = MACROConst.MACRO_POWERUP_CALIB__START;
		dataOut = self.splitHexNumToBytes(MACROConst.MACRO_POWERUP_CALIB__CONTROL_DCOFFSET_ONLY,bytesLen);
		self.byteList[1] = dataOut[2];
		self.byteList[2] = dataOut[1];
		self.byteList[3] = dataOut[0];
		self.byteList[4] = channel_selected
	# set_dc_offset_only_powerup_calib

####################################################################################
	@funcDecorator
	def set_rx_iqmc_only_powerup_calib(self, channel_selected,ana_init_ctrl,dig_init_ctrl):
		bytesLen = 3;
		self.byteList[0] = MACROConst.MACRO_POWERUP_CALIB__START;
		dataOut = self.splitHexNumToBytes(MACROConst.MACRO_POWERUP_CALIB__CONTROL_RX_IQMC_ONLY,bytesLen);
		self.byteList[1] = dataOut[2];
		self.byteList[2] = dataOut[1];
		self.byteList[3] = dataOut[0];
		self.byteList[4] = channel_selected
		self.byteList[5] = ana_init_ctrl
		self.byteList[6] = dig_init_ctrl
	# set_rx_iqmc_only_powerup_calib

####################################################################################
	@funcDecorator
	def splitHexNumToBytes(self,dataIn, numBytes):
		"""splits the dataIn in hex into numBytes representation"""
		# numDec = int(dataIn,16)
		numShifts = range(numBytes,0,-1)
		dataInTemp = dataIn;
		dataOut = [];

		for i in range(len(numShifts)):
			dataByteDec = dataInTemp//(2**(8*(numShifts[i]-1)));
			hexData = (dataByteDec);
			dataOut.append(hexData);
			dataInTemp = dataInTemp%(2**(8*(numShifts[i]-1)));

		return(dataOut)
	
####################################################################################
	@funcDecorator
	def boot_top_cm4_from_ram(self, ram_filename):
		mainWindow.runFile(ram_filename)			

		self.regs.MACRO.FW_REGS.CM4_CONTROL.spi_sel = 0;
		self.regs.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel = 1
		self.regs.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 1
		#Commented by Sarma on 06/12/2017 to debug the SPI write issue after FW download
		self.regs.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 0

	# boot_top_cm4_from_ram

####################################################################################
	@funcDecorator
	def set_tx_mode(self, mode):
		self.byteList[0] = mode
	# set_tx_mode()

####################################################################################
	@funcDecorator
	def set_rx_mode(self, mode):
		self.byteList[1] = mode
	# set_rx_mode()

####################################################################################
	@funcDecorator
	def set_fb_mode(self, mode):
		self.byteList[2] = mode
	# set_fb_mode()

####################################################################################
	@funcDecorator
	def set_tdd_fdd_mode(self, mode):
		self.byteList[0] = mode
	# set_tdd_fdd_mode()

####################################################################################
	@funcDecorator
	def set_fref(self, rate):
		self.byteList[0] = rate
	# set_fref()

####################################################################################
	@funcDecorator
	def set_tx_lo_freq(self, freq_word, offset):
		bytesLen = 4
		dataOut = self.splitHexNumToBytes(freq_word, bytesLen);

		for i in range(0,bytesLen):
			self.byteList[i+offset]=dataOut[bytesLen-1-i]
	# set_tx_lo_freq()

####################################################################################
	@funcDecorator
	def set_rx_lo_freq(self, freq_word, offset):
		bytesLen = 4
		dataOut = self.splitHexNumToBytes(freq_word, bytesLen);

		for i in range(0,bytesLen):
			self.byteList[i+offset]=dataOut[bytesLen-1-i]
	# set_rx_lo_freq()

####################################################################################
	@funcDecorator
	def set_ddc_lo_freq(self, freq_word, offset):
		bytesLen = 4
		# dataOut = self.splitHexNumToBytes(freq_word, bytesLen);
		for i in range(0,bytesLen):
			self.byteList[i+offset]=(int(freq_word)>>int(8*i))&(0xFF)
	# set_ddc_lo_freq()

####################################################################################
	@funcDecorator
	def set_enable_low_if_mode_rx(self, mode):
		self.byteList[0] = mode
	# set_enable_low_if_mode_rx()

####################################################################################
	@funcDecorator
	def set_enable_low_if_mode_tx(self, mode):
		self.byteList[0] = mode
	#set_enable_low_if_mode_tx

####################################################################################
	@funcDecorator
	def set_enable_low_if_mode_fb(self, mode):
		self.byteList[0] = mode
	#set_enable_low_if_mode_fb

####################################################################################
	@funcDecorator
	def set_rx_mixer_nco_word(self, freq_word):
		bytesLen = 4
		dataOut = self.splitHexNumToBytes(freq_word, bytesLen);

		for i in range(0,bytesLen):
			self.byteList[i+0x19]=dataOut[bytesLen-1-i]
	#set_rx_mixer_nco_word

####################################################################################
	@funcDecorator
	def set_tx_mixer_nco_word(self, freq_word):
		bytesLen = 4
		dataOut = self.splitHexNumToBytes(freq_word, bytesLen);

		for i in range(0,bytesLen):
			self.byteList[i+0x22]=dataOut[bytesLen-1-i]
	#set_tx_mixer_nco_word

####################################################################################
	@funcDecorator
	def set_fb_mixer_nco_word(self, freq_word):
		""""""
	#set_fb_mixer_nco_word

####################################################################################
	@funcDecorator
	def set_adc_rate(self, rate):
		self.byteList[0] = rate	
	# set_adc_rate

####################################################################################
	@funcDecorator
	def set_adc_rate_updated(self, rate):
		if(rate==48 or rate==24):
			self.byteList[0] = MACROConst.MACRO_ADC_CONFIGURATION__RATE_48X	
		elif(rate==54 or rate==27):
			self.byteList[0] = MACROConst.MACRO_ADC_CONFIGURATION__RATE_54X	
		elif(rate==56 or rate==28):
			self.byteList[0] = MACROConst.MACRO_ADC_CONFIGURATION__RATE_56X
		else:
			error("//Invalid fs")
	# set_adc_rate

####################################################################################
	@funcDecorator
	def set_half_rate_mode_for_rx(self, rx_half_rate_mode):
		self.byteList[1] = rx_half_rate_mode
	# set_half_rate_mode_for_rx
	
####################################################################################
	@funcDecorator
	def set_half_rate_mode_for_tx(self, tx_half_rate_mode):
		self.byteList[2] = tx_half_rate_mode
	# set_half_rate_mode_for_tx

####################################################################################
	@funcDecorator
	def set_half_rate_mode_for_fb(self, fb_half_rate_mode):
		self.byteList[3] = fb_half_rate_mode
	# set_half_rate_mode_for_fb

####################################################################################
	@funcDecorator
	def set_tx_ab_if_rate(self, rate):
		self.byteList[0] = rate
	# set_tx_ab_if_rate()

####################################################################################
	@funcDecorator
	def set_tx_cd_if_rate(self, rate):
		self.byteList[2] = rate

	# set_tx_cd_if_rate()	

####################################################################################
	@funcDecorator
	def set_rx_ab_if_rate(self, rate):
		self.byteList[1] = rate

	# set_rx_ab_if_rate()

####################################################################################
	@funcDecorator
	def set_rx_cd_if_rate(self, rate):
		self.byteList[3] = rate

	# set_rx_cd_if_rate()

####################################################################################
	@funcDecorator
	def set_fb_ab_if_rate(self, rate):
		self.byteList[4] = rate

	# set_fb_ab_if_rate()

####################################################################################
	@funcDecorator
	def set_fb_cd_if_rate(self, rate):
		self.byteList[5] = rate
	
	# set_fb_cd_if_rate()
	
####################################################################################
	@funcDecorator
	def set_fb_if_rate(self, rate, ch,start_addr=4):
		if(rate==2):
			fb_rate_macro	=	0;
		elif(rate==3):
			fb_rate_macro	=	1;
		elif(rate==4):
			fb_rate_macro	=	2;
		elif(rate==6):
			fb_rate_macro	=	3;
		elif(rate==8):
			fb_rate_macro	=	4;
		elif(rate==12):
			fb_rate_macro	=	5;
		else:
			fb_rate_macro	=	0;		##Error
		self.byteList[start_addr+ch] = fb_rate_macro
		
	# set_fb_if_rate()
	
####################################################################################
	@funcDecorator
	def set_tune_rx_chain(self, selected_chains):
		self.byteList[0] = selected_chains

	# set_tune_rx_chain()

####################################################################################
	@funcDecorator
	def set_tune_tx_chain(self, selected_chains):
		self.byteList[1] = selected_chains
	
	# set_tune_tx_chain()

####################################################################################
	@funcDecorator
	def set_tune_fb_chain(self, selected_chains):
		self.byteList[2] = selected_chains

	# set_tune_fb_chain()

####################################################################################
	@funcDecorator
	def set_tune_analog_chain(self, selected_chains):
		self.byteList[3] = selected_chains

	# set_tune_fb_chain()

####################################################################################
	@funcDecorator
	def set_tune_CM4_related(self, selected_chains):
		debug("CM4 related operand is "+str(selected_chains))
		bytesLen = 4;
		dataOut = self.splitHexNumToBytes(selected_chains,bytesLen);
		debug("data for 4 to 8 bytes in tune and enable "+str(dataOut))
		self.byteList[4] = dataOut[3];
		self.byteList[5] = dataOut[2];
		self.byteList[6] = dataOut[1];
		self.byteList[7] = dataOut[0];

	# set_tune_fb_chain()

####################################################################################	
	@funcDecorator
	def changeTopClkToPll(self):
		""" Spi writes to switch to pll clock. """
		self.regs.INTERNAL_MACRO.CLOCK_CONTROL.Register21918_80h.Property22231_6_6=0
		self.regs.INTERNAL_MACRO.CLOCK_CONTROL.Register21918_80h.Property22231_6_6=1
		self.regs.INTERNAL_MACRO.CLOCK_CONTROL.Register21918_80h.Property22231_6_6=0
		self.regs.INTERNAL_MACRO.CLOCK_CONTROL.Register21918_80h.Property21923_4_4=0
		self.regs.INTERNAL_MACRO.CLOCK_CONTROL.Register21918_80h.Property21924_5_5=0
		self.regs.INTERNAL_MACRO.CLOCK_CONTROL.Register21925_88h.Property21925_0_0=1
	#changeTopClkToPll	

####################################################################################
	@funcDecorator
	def start_dsa_calibration(self,type,ch,dsa_start,dsa_stop,cal,fb_conn):
		"""
		To start factory calibration: 
		type = txdsa or rxdsa
		ch = AB or CD or ABCD
		"""
		self.byteList[0] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__START;
		if(type == "txdsa"):
			self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__TX_DSA;
		elif(type == "rxdsa"):
			self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__RX_DSA;
		
		if(ch=="AB"):
			self.byteList[2] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__APPLY_TO_AB;
		elif(ch=="CD"):
			self.byteList[2] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__APPLY_TO_CD;
		elif(ch=="ABCD"):
			self.byteList[2] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__APPLY_TO_ABCD;
		self.byteList[3] = dsa_start;
		self.byteList[4] = dsa_stop;
		self.byteList[5] = cal;
		self.byteList[6] = fb_conn;
			
			
	# start_dsa_calibration()

####################################################################################
	@funcDecorator
	def start_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
	internal_loopback_en,tone_chain,tone_scale,ref_tracking_en):
		"""
		To start factory calibration: 
		start_vga_calibration
		"""
		self.byteList[0] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__START;
		self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__VGA_CAL;
		self.byteList[2] = vga_to_cal;
		self.byteList[3] = dsa_start;
		self.byteList[4] = vga_start;
		self.byteList[5] = vga_stop;
		self.byteList[6] = vga_to_cal;
		self.byteList[7] = not_vga_or_lna;
		self.byteList[8] = internal_loopback_en;
		self.byteList[9] = tone_chain;
		self.byteList[10] = tone_scale;
		self.byteList[11] = ref_tracking_en;
		
	# start_dsa_calibration()

####################################################################################
	@funcDecorator
	def continue_dsa_calibration(self,type,ch,start_index,stop_index,toneABCD,tranABCD,refTrack,freqdepd=0,loopback=0):
		"""
		To start factory calibration: 
		type = txdsa or rxdsa
		ch = AB or CD or ABCD
		start_index : stop_index is 0 to 39
		toneABCD of Tx or RX to be calibrated 4bit value
		tranABCD of Tx or Rx to be connecte
		"""
		self.byteList[0] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__CONTINUE;
		if(type == "txdsa"):
			self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__TX_DSA;
		elif(type == "rxdsa"):
			self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__RX_DSA;
		
		if(ch=="AB"):
			self.byteList[2] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__APPLY_TO_AB;
		elif(ch=="CD"):
			self.byteList[2] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__APPLY_TO_CD;
		elif(ch=="ABCD"):
			self.byteList[2] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__APPLY_TO_ABCD;
			
		self.byteList[3] = start_index;
		self.byteList[4] = stop_index;
		self.byteList[5] = toneABCD&0xF;
		self.byteList[6] = tranABCD&0xF;
		if(type=="txdsa"):
			self.byteList[7] = refTrack&0xF;
		elif(type=="rxdsa"):
			self.byteList[7] = freqdepd&0x3;
			self.byteList[8] = refTrack&0xF;
			self.byteList[9] = loopback&0x3;		
	#continue_dsa_calibration	
		
####################################################################################
	@funcDecorator
	def continue_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
	internal_loopback_en,tone_chain,tone_scale,ref_tracking_en):
		"""
		To start factory calibration: 
		continue_vga_calibration
		"""
		self.byteList[0] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__CONTINUE;
		self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__VGA_CAL;
		self.byteList[2] = vga_to_cal;
		self.byteList[3] = dsa_start;
		self.byteList[4] = vga_start;
		self.byteList[5] = vga_stop;
		self.byteList[6] = vga_to_cal;
		self.byteList[7] = not_vga_or_lna;
		self.byteList[8] = internal_loopback_en;
		self.byteList[9] = tone_chain;
		self.byteList[10] = tone_scale;
		self.byteList[11] = ref_tracking_en;
		
	# continue_vga_calibration()

####################################################################################
	@funcDecorator
	def completed_dsa_calibration(self,type):
		"""
		To start factory calibration: 
		type = txdsa or rxdsa
		"""
		self.byteList[0] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__COMPLETED;
		if(type == "txdsa"):
			self.byteList[1] = MACROConst.MACRO_SET_FACTORY_CALIB__TX_DSA_GP;
		elif(type == "rxdsa"):
			self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__RX_DSA;
	#completed_dsa_calibration	
		
####################################################################################
	@funcDecorator
	def completed_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
	internal_loopback_en,tone_chain,tone_scale,ref_tracking_en):
		"""
		To start factory calibration: 
		completed_vga_calibration
		"""
		self.byteList[0] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__COMPLETED;
		self.byteList[1] = MACROConst.MACRO_FACTORY_CALIB_CONTROL__VGA_CAL;
		self.byteList[2] = vga_to_cal;
		self.byteList[3] = dsa_start;
		self.byteList[4] = vga_start;
		self.byteList[5] = vga_stop;
		self.byteList[6] = vga_to_cal;
		self.byteList[7] = not_vga_or_lna;
		self.byteList[8] = internal_loopback_en;
		self.byteList[9] = tone_chain;
		self.byteList[10] = tone_scale;
		self.byteList[11] = ref_tracking_en;
		
	# continue_vga_calibration()	
		
####################################################################################
	@funcDecorator
	def apply_dsa_packet(self,type,txa,txb,txc,txd):
		"""
		To start factory calibration: 
		type = txdsa or rxdsa
		"""
		if(type == "txdsa"):
			self.byteList[0] = MACROConst.MACRO_SET_FACTORY_CALIB__TX_DSA_GP;
		elif(type == "rxdsa"):
			self.byteList[0] = MACROConst.MACRO_SET_FACTORY_CALIB__RX_DSA_GP;
		self.byteList[1] = txa;
		self.byteList[2] = txb;
		self.byteList[3] = txc;
		self.byteList[4] = txd;
			
	#apply_dsa_packet	
	
####################################################################################	
	@funcDecorator
	def set_die_id_read(self) :
		self.byteList[0] = MACROConst.MACRO_SYSTEM_COMMAND_GET_DIE_ID
		
	# set_die_id

####################################################################################	
	@funcDecorator
	def set_fw_version_read(self) :
		self.byteList[0] = MACROConst.MACRO_SYSTEM_COMMAND_GET_FW_VERSION
		
	# set_die_id	
		
####################################################################################
	@funcDecorator
	def set_tx_iqmc_only_powerup_calib(self, channel_selected, ana_init_ctrl, dig_init_ctrl):
		bytesLen = 3;
		self.byteList[0] = MACROConst.MACRO_POWERUP_CALIB__START;
		dataOut = self.splitHexNumToBytes(MACROConst.MACRO_POWERUP_CALIB__CONTROL_TX_IQMC_ONLY,bytesLen);
		self.byteList[1] = dataOut[2];
		self.byteList[2] = dataOut[1];
		self.byteList[3] = dataOut[0];
		self.byteList[4] = channel_selected
		self.byteList[5] = ana_init_ctrl
		self.byteList[6] = dig_init_ctrl
	# set_dc_offset_only_powerup_calib

####################################################################################
	@funcDecorator
	def set_tx_lo_leakage_only_powerup_calib(self, channel_selected, ana_init_ctrl, dig_init_ctrl):
		bytesLen = 3;
		self.byteList[0] = MACROConst.MACRO_POWERUP_CALIB__START;
		dataOut = self.splitHexNumToBytes(MACROConst.MACRO_POWERUP_CALIB__CONTROL_TX_LOLeakage_ONLY,bytesLen);
		self.byteList[1] = dataOut[2];
		self.byteList[2] = dataOut[1];
		self.byteList[3] = dataOut[0];
		self.byteList[4] = channel_selected
		self.byteList[5] = ana_init_ctrl
		self.byteList[6] = dig_init_ctrl
	# set_dc_offset_only_powerup_calib

####################################################################################
	@funcDecorator
	def set_mission_mode_init(self, calib_mask, apply_to_channel):

		bytesLen = 4;
		dataOut = self.splitHexNumToBytes(calib_mask, bytesLen);
		
		self.byteList[0] = dataOut[3]	
		self.byteList[1] = dataOut[2]	
		self.byteList[2] = dataOut[1]	
		self.byteList[3] = dataOut[0]	
		self.byteList[4] = apply_to_channel
	# set_mission_mode_init(self, calib_mask, apply_to_channel):
####################################################################################
	def read_8b(self, address):
		self.set_8b_read();
		self.set_address_for_rdwr(address)
		err=self.execute_macro(5, MACROConst.MACRO_OPCODE_RDWR)

		data=self.read_8b_result()
		
		#info('error='+str(hex(err)))
		#info('Result='+str(hex((self.read_8b_result()))))
		return(data, err)
	# read_8b

####################################################################################
	def write_8b(self, address, data):
		self.set_8b_write();
		self.set_address_for_rdwr(address)
		self.set_8b_word_for_write(data & 0x000000FF)
		return(self.execute_macro(6, MACROConst.MACRO_OPCODE_RDWR))

	# write_8b
		
####################################################################################
	def read_16b(self, address):
		self.set_16b_read();
		self.set_address_for_rdwr(address)
		err=self.execute_macro(5, MACROConst.MACRO_OPCODE_RDWR)
		data=self.read_16b_result()
		
		#info('error='+str(hex(err)))
		#info('Result='+str(hex((self.read_8b_result()))))
		return(data, err)
	# read_16b

####################################################################################
	def write_16b(self, address, data):
		self.set_16b_write();
		self.set_address_for_rdwr(address)
		self.set_16b_word_for_write(data)
		return(self.execute_macro(7, MACROConst.MACRO_OPCODE_RDWR))

	# write_16b

####################################################################################
	def read_32b(self, address):
		self.set_32b_read();
		self.set_address_for_rdwr(address)
		err=self.execute_macro(5, MACROConst.MACRO_OPCODE_RDWR)
		data=self.read_32b_result()
		
		#info('error='+str(hex(err)))
		#info('Result='+str(hex((self.read_32b_result()))))
		return(data, err)
	# read_32b

####################################################################################
	def write_32b(self, address, data):
		self.set_32b_write();
		self.set_address_for_rdwr(address)
		self.set_32b_word_for_write(data)
		return(self.execute_macro(9, MACROConst.MACRO_OPCODE_RDWR))

	# write_32b
#
#
####################################################################################
#	def read_nbytes(self, address, nbytes):
#	# read_nbytes
#
####################################################################################
####################################################################################
#	def write_nbytes(self, address, data, nbytes):
#	# write_nbytes
####################################################################################
#
#	def reset_rx_iqmc_ss_calib(self):
#	# reset_rx_iqmc_ss_calib
#

####################################################################################
	def do_mission_mode_init(self, calib_mask = 0, apply_to_channel = 0xF):
		self.set_mission_mode_init(calib_mask, apply_to_channel);
		return(self.execute_macro(5, MACROConst.MACRO_OPCODE_MISSION_MODE_INIT))

	# start_rx_iqmc_ss_calib

####################################################################################
	def start_rx_iqmc_ss_calib(self, apply_to_channel):
		self.set_rx_iqmc_start(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))

	# start_rx_iqmc_ss_calib

####################################################################################
	def reset_rx_iqmc_states(self, apply_to_channel):
		self.set_rx_iqmc_reset_states(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# reset_rx_iqmc_states

####################################################################################
	def freeze_rx_iqmc_estimation(self, apply_to_channel):
		self.set_rx_iqmc_freeze_estimation(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_rx_iqmc_estimation

####################################################################################
	def freeze_rx_iqmc_correction(self, apply_to_channel):
		self.set_rx_iqmc_freeze_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_rx_iqmc_correction

####################################################################################
	def bypass_rx_iqmc_correction(self, apply_to_channel):
		self.set_rx_iqmc_bypass_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# bypass_rx_iqmc_correction

####################################################################################
	def start_tx_iqmc_ss_calib(self, apply_to_channel):
		self.set_tx_iqmc_start(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# start_tx_iqmc_ss_calib

####################################################################################
	def reset_tx_iqmc_states(self, apply_to_channel):
		self.set_tx_iqmc_reset_states(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# reset_tx_iqmc_states

####################################################################################
	def freeze_tx_iqmc_estimation(self, apply_to_channel):
		self.set_tx_iqmc_freeze_estimation(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_tx_iqmc_estimation

####################################################################################
	def freeze_tx_iqmc_correction(self, apply_to_channel):
		self.set_tx_iqmc_freeze_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_tx_iqmc_correction

####################################################################################
	def bypass_tx_iqmc_correction(self, apply_to_channel):
		self.set_tx_iqmc_bypass_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# bypass_tx_iqmc_correction

####################################################################################
	def start_dc_offset_ss_calib(self, apply_to_channel):
		self.set_dc_offset_start(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# start_dc_offset_ss_calib

####################################################################################
	def reset_dc_offset_states(self, apply_to_channel):
		self.set_dc_offset_reset_states(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# reset_dc_offset_states

####################################################################################
	def freeze_dc_offset_estimation(self, apply_to_channel):
		self.set_dc_offset_freeze_estimation(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_dc_offset_estimation

####################################################################################
	def freeze_dc_offset_correction(self, apply_to_channel):
		self.set_dc_offset_freeze_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_dc_offset_correction

####################################################################################
	def bypass_dc_offset_correction(self, apply_to_channel):
		self.set_dc_offset_bypass_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# bypass_dc_offset_correction

####################################################################################
	def start_tx_lo_ss_calib(self, apply_to_channel):
		self.set_tx_lo_start(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# start_tx_lo_ss_calib

####################################################################################
	def reset_tx_lo_states(self, apply_to_channel):
		self.set_tx_lo_reset_states(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# reset_tx_lo_states

####################################################################################
	def freeze_tx_lo_estimation(self, apply_to_channel):
		self.set_tx_lo_freeze_estimation(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_tx_lo_estimation

####################################################################################
	def freeze_tx_lo_correction(self, apply_to_channel):
		self.set_tx_lo_freeze_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# freeze_tx_lo_correction

####################################################################################
	def bypass_tx_lo_correction(self, apply_to_channel):
		self.set_tx_lo_bypass_correction(apply_to_channel);
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB))
	# bypass_tx_lo_correction

####################################################################################
	def start_dc_offset_only_powerup_calib(self,apply_to_channel):
		self.set_dc_offset_only_powerup_calib(apply_to_channel);
		return(self.execute_macro(5, MACROConst.MACRO_OPCODE_POWERUP_CALIB_CONTROL))
	# start_dc_offset_only_powerup_calib	

####################################################################################
	def do_rx_iqmc_puc(self, apply_to_channel,analog_init_ctrl, digital_init_ctrl):
		self.set_rx_iqmc_only_powerup_calib(apply_to_channel,analog_init_ctrl, digital_init_ctrl);
		return(self.execute_macro(7, MACROConst.MACRO_OPCODE_POWERUP_CALIB_CONTROL))
	# do_rx_iqmc_puc()

####################################################################################
	def do_txrxfb_configuration(self, tx_mode, rx_mode, fb_mode):
		self.set_tx_mode(tx_mode)
		self.set_rx_mode(rx_mode)
		self.set_fb_mode(fb_mode)
		return(self.execute_macro(3, MACROConst.MACRO_OPCODE_TXRXFB_CONFIG))
	# do_txrxfb_configuration()

####################################################################################
	def do_tdd_fdd_configuration(self, tdd_fdd_mode):
		self.set_tdd_fdd_mode(tdd_fdd_mode)
		return(self.execute_macro(1, MACROConst.MACRO_OPCODE_TDD_FDD_SET))
	# do_tdd_fdd_configuration()

####################################################################################
	def do_set_fref(self, rate):
		self.set_fref(rate)
		return(self.execute_macro(1, MACROConst.MACRO_OPCODE_SET_FREF))
	# do_set_fref()

####################################################################################
	def do_channel_freq_set(self, tx_lo_freq_AB=0, rx_lo_freq_AB=0, tx_lo_freq_CD=0, rx_lo_freq_CD=0, LO_0_FB_AB=0, LO_1_FB_AB=0, LO_0_FB_CD=0, LO_1_FB_CD=0, tx_low_if_mode=0, fb_low_if_mode=0, rx_mixer_nco_word=0, tx_mixer_nco_word=0, fb_mixer_nco_word=0):
		self.set_tx_lo_freq(tx_lo_freq_AB, 0x00)
		self.set_rx_lo_freq(rx_lo_freq_AB, 0x04)
		self.set_tx_lo_freq(tx_lo_freq_CD, 0x08)
		self.set_rx_lo_freq(rx_lo_freq_CD, 0x0C)
		
		LO_0_FB_AB=LO_0_FB_AB/125*122.88
		LO_1_FB_AB=LO_1_FB_AB/125*122.88
		LO_0_FB_CD=LO_0_FB_CD/125*122.88
		LO_1_FB_CD=LO_1_FB_CD/125*122.88

		
		info(' LO_0_FB_AB=' + str(LO_0_FB_AB) + ' LO_1_FB_AB='  + str(LO_1_FB_AB) + ' LO_0_FB_CD=' + str(LO_0_FB_CD) + ' LO_1_FB_CD='  + str(LO_1_FB_CD) )

		
		self.set_ddc_lo_freq(LO_0_FB_AB, 0x10)
		self.set_ddc_lo_freq(LO_1_FB_AB, 0x14)
		self.set_ddc_lo_freq(LO_0_FB_CD, 0x18)
		self.set_ddc_lo_freq(LO_1_FB_CD, 0x1C)
		
#		self.set_enable_low_if_mode_rx(rx_low_if_mode)
		# self.set_rx_mixer_nco_word(rx_mixer_nco_word)
#		self.set_enable_low_if_mode_tx(tx_low_if_mode)
		# self.set_tx_mixer_nco_word(tx_mixer_nco_word)
#		self.set_enable_low_if_mode_fb(fb_low_if_mode)
		# self.set_fb_mixer_nco_word(fb_mixer_nco_word)
		#return(self.execute_macro(55, MACROConst.MACRO_OPCODE_CHANNEL_FREQ_SET))
		return(self.execute_macro(32, MACROConst.MACRO_OPCODE_CHANNEL_FREQ_SET))
	# do_channel_freq_set

####################################################################################
	def do_adc_configuration(self, adc_rate, rx_half_rate, tx_half_rate, fb_half_rate):
		self.set_adc_rate(adc_rate)
		self.set_half_rate_mode_for_rx(rx_half_rate)
		self.set_half_rate_mode_for_tx(tx_half_rate)
		self.set_half_rate_mode_for_fb(fb_half_rate)
		return(self.execute_macro(4, MACROConst.MACRO_OPCODE_ADC_CONFIGURATION))
	
	# do_adc_configuration
	
####################################################################################
	def do_tx_rx_fb_adc_dac_configuration(self, rx_ab_adc_rate, rx_cd_adc_rate, tx_ab_dac_rate, tx_cd_dac_rate, fb_ab_adc_rate, fb_cd_adc_rate):
		
		rxHalfRate = 0
		txHalfRate = 0
		fbHalfRate = 0
		
		if (rx_ab_adc_rate == 48.0) and (rx_cd_adc_rate == 48.0):
			adcRate = 0;
			rxHalfRate = 0;
		
		elif (rx_ab_adc_rate == 24.0) and (rx_cd_adc_rate == 48.0) :
			adcRate = 0;
			rxHalfRate = 0x3;
			
		elif (rx_ab_adc_rate == 48.0) and (rx_cd_adc_rate == 24.0) :
			adcRate = 0;
			rxHalfRate = 0xC;
			
		elif (rx_ab_adc_rate == 24.0) and (rx_cd_adc_rate == 24.0) :
			adcRate = 0;
			rxHalfRate = 0xF;
			
		elif (rx_ab_adc_rate == 54.0) and (rx_cd_adc_rate == 54.0):
			adcRate = 1;
			rxHalfRate = 0;
		
		elif (rx_ab_adc_rate == 27.0) and (rx_cd_adc_rate == 54.0) :
			adcRate = 1;
			rxHalfRate = 0x3;
			
		elif (rx_ab_adc_rate == 54.0) and (rx_cd_adc_rate == 27.0) :
			adcRate = 1;
			rxHalfRate = 0xC;
			
		elif (rx_ab_adc_rate == 27.0) and (rx_cd_adc_rate == 27.0) :
			adcRate = 1;
			rxHalfRate = 0xF;
			
		elif (rx_ab_adc_rate == 56.0) and (rx_cd_adc_rate == 56.0):
			adcRate = 2;
			rxHalfRate = 0;
		
		elif (rx_ab_adc_rate == 28.0) and (rx_cd_adc_rate == 56.0) :
			adcRate = 2;
			rxHalfRate = 0x3;
			
		elif (rx_ab_adc_rate == 56.0) and (rx_cd_adc_rate == 28.0) :
			adcRate = 2;
			rxHalfRate = 0xC;
			
		elif (rx_ab_adc_rate == 28.0) and (rx_cd_adc_rate == 28.0) :
			adcRate = 2;
			rxHalfRate = 0xF;

		else :
			rxHalfRate = 0x0;
			
		
		if (tx_ab_dac_rate == 48.0) and (tx_cd_dac_rate == 48.0):
			adcRate = 0;
			txHalfRate = 0;
		
		elif (tx_ab_dac_rate == 24.0) and (tx_cd_dac_rate == 48.0) :
			adcRate = 0;
			txHalfRate = 0x3;
			
		elif (tx_ab_dac_rate == 48.0) and (tx_cd_dac_rate == 24.0) :
			adcRate = 0;
			txHalfRate = 0xC;
			
		elif (tx_ab_dac_rate == 24.0) and (tx_cd_dac_rate == 24.0) :
			adcRate = 0;
			txHalfRate = 0xF;
			
		elif (tx_ab_dac_rate == 54.0) and (tx_cd_dac_rate == 54.0):
			adcRate = 1;
			txHalfRate = 0;
		
		elif (tx_ab_dac_rate == 27.0) and (tx_cd_dac_rate == 54.0) :
			adcRate = 1;
			txHalfRate = 0x3;
			
		elif (tx_ab_dac_rate == 54.0) and (tx_cd_dac_rate == 27.0) :
			adcRate = 1;
			txHalfRate = 0xC;
			
		elif (tx_ab_dac_rate == 27.0) and (tx_cd_dac_rate == 27.0) :
			adcRate = 1;
			txHalfRate = 0xF;
			
		elif (tx_ab_dac_rate == 56.0) and (tx_cd_dac_rate == 56.0):
			adcRate = 2;
			txHalfRate = 0;
		
		elif (tx_ab_dac_rate == 28.0) and (tx_cd_dac_rate == 56.0) :
			adcRate = 2;
			txHalfRate = 0x3;
			
		elif (tx_ab_dac_rate == 56.0) and (tx_cd_dac_rate == 28.0) :
			adcRate = 2;
			txHalfRate = 0xC;
			
		elif (tx_ab_dac_rate == 28.0) and (tx_cd_dac_rate == 28.0) :
			adcRate = 2;
			txHalfRate = 0xF;

		else :
			txHalfRate = 0x0
			
		if 	(fb_ab_adc_rate == 48.0) and (fb_cd_adc_rate == 48.0) :
			adcRate = 0
			fbHalfRate = 0;
		elif (fb_ab_adc_rate == 48.0) and (fb_cd_adc_rate == 24.0) :
			adcRate = 0
			fbHalfRate = 0x02
		
		elif (fb_ab_adc_rate == 24.0) and (fb_cd_adc_rate == 48.0) :
			adcRate = 0
			fbHalfRate = 0x01
		
		elif (fb_ab_adc_rate == 24.0) and (fb_cd_adc_rate == 24.0) :
			adcRate = 0
			fbHalfRate = 0x03
			
		elif (fb_ab_adc_rate == 54.0) and (fb_cd_adc_rate == 54.0) :
			adcRate = 1
			fbHalfRate = 0;
		elif (fb_ab_adc_rate == 54.0) and (fb_cd_adc_rate == 27.0) :
			adcRate = 1
			fbHalfRate = 0x02
		
		elif (fb_ab_adc_rate == 27.0) and (fb_cd_adc_rate == 54.0) :
			adcRate = 1
			fbHalfRate = 0x01
		
		elif (fb_ab_adc_rate == 27.0) and (fb_cd_adc_rate == 27.0) :
			adcRate = 1
			fbHalfRate = 0x03
			
		elif (fb_ab_adc_rate == 56.0) and (fb_cd_adc_rate == 56.0) :
			adcRate = 2
			fbHalfRate = 0;
		elif (fb_ab_adc_rate == 56.0) and (fb_cd_adc_rate == 28.0) :	
			adcRate = 2
			fbHalfRate = 0x02
		
		elif (fb_ab_adc_rate == 28.0) and (fb_cd_adc_rate == 56.0) :
			adcRate = 2
			fbHalfRate = 0x01
		
		elif (fb_ab_adc_rate == 28.0) and (fb_cd_adc_rate == 28.0) :
			adcRate = 2
			fbHalfRate = 0x03
			
		else :
			fbHalfRate = 0x0
			
		
		self.do_adc_configuration(adcRate, rxHalfRate, txHalfRate, fbHalfRate)
		
		return rxHalfRate
####################################################################################
	def do_adc_configuration_updated(self, adc_rate, rx_half_rate, tx_half_rate, fb_half_rate):
		self.set_adc_rate_updated(adc_rate)
		self.set_half_rate_mode_for_rx(rx_half_rate)
		self.set_half_rate_mode_for_tx(tx_half_rate)
		self.set_half_rate_mode_for_fb(fb_half_rate)
		return(self.execute_macro(4, MACROConst.MACRO_OPCODE_ADC_CONFIGURATION))
	
	# do_adc_configuration_updated

####################################################################################
	def do_interface_rate_configuration(self, tx_ab_if_rate, tx_cd_if_rate, rx_ab_if_rate, rx_cd_if_rate, fb_ab_if_rate, fb_cd_if_rate):
		self.set_tx_ab_if_rate(tx_ab_if_rate)
		self.set_tx_cd_if_rate(tx_cd_if_rate)
		self.set_rx_ab_if_rate(rx_ab_if_rate)
		self.set_rx_cd_if_rate(rx_cd_if_rate)
		self.set_fb_ab_if_rate(fb_ab_if_rate)
		self.set_fb_cd_if_rate(fb_cd_if_rate)

		return(self.execute_macro(6, MACROConst.MACRO_OPCODE_INTERFACE_RATE_CONFIG))

	# do_interface_rate_configuration
	
####################################################################################
	def do_tx_rx_fb_interface_rate_configuration(self, tx_ab_if_rate, tx_cd_if_rate, rx_ab_if_rate, rx_cd_if_rate, fb_ab_if_rate, fb_cd_if_rate):
		
		#assign default values if corresponding inputs are not passed
		
		#Rx interface rate configuration
		rxABInterfaceRate = 0
		rxCDInterfaceRate = 0
		txABInterfaceRate = 0
		txCDInterfaceRate = 0
		rxABInterfaceRate=(0.5,1.0,1.5,2.0,3.0,4.0,6.0).index(round(rx_ab_if_rate,4))
		#if rx_ab_if_rate == 0.5 :
		#	rxABInterfaceRate = 0
		#elif rx_ab_if_rate == 1.0 :
		#	rxABInterfaceRate = 1
		#elif rx_ab_if_rate == 1.5 :
		#	rxABInterfaceRate = 2
		#elif rx_ab_if_rate == 2.0 :
		#	rxABInterfaceRate = 3
		#elif rx_ab_if_rate == 3.0 :
		#	rxABInterfaceRate = 4
		#elif rx_ab_if_rate == 4.0 :
		#	rxABInterfaceRate = 5
		#elif rx_ab_if_rate == 6.0 :
		#	rxABInterfaceRate = 6
		rxCDInterfaceRate=(0.5,1.0,1.5,2.0,3.0,4.0,6.0).index(round(rx_cd_if_rate,4))
			
		#if rx_cd_if_rate == 0.5 :
		#	rxCDInterfaceRate = 0
		#elif rx_cd_if_rate == 1.0 :
		#	rxCDInterfaceRate = 1
		#elif rx_cd_if_rate == 1.5 :
		#	rxCDInterfaceRate = 2
		#elif rx_cd_if_rate == 2.0 :
		#	rxCDInterfaceRate = 3
		#elif rx_cd_if_rate == 3.0 :
		#	rxCDInterfaceRate = 4
		#elif rx_cd_if_rate == 4.0 :
		#	rxCDInterfaceRate = 5
		#elif rx_cd_if_rate == 6.0 :
		#	rxCDInterfaceRate = 6
			
		# Tx interface rate configuration
		txABInterfaceRate=(2.0,3.0,4.0,6.0,8.0,12.0).index(round(tx_ab_if_rate,4))
		#if tx_ab_if_rate == 1.0 :
		#	txABInterfaceRate = 0 #this interface rate is not supported inside Tx config though
		#	#top level MACRO has it
		#	error("mode not supported")
		#elif tx_ab_if_rate == 2.0 :
		#	txABInterfaceRate = 0
		#elif tx_ab_if_rate == 3.0 :
		#	txABInterfaceRate = 1
		#elif tx_ab_if_rate == 4.0 :
		#	txABInterfaceRate = 2
		#elif tx_ab_if_rate == 6.0 :
		#	txABInterfaceRate = 3
		#elif tx_ab_if_rate == 8.0 :
		#	txABInterfaceRate = 4
		#elif tx_ab_if_rate == 12.0 :
		#	txABInterfaceRate = 5
		txCDInterfaceRate=(2.0,3.0,4.0,6.0,8.0,12.0).index(round(tx_cd_if_rate,4))
			
		#if tx_cd_if_rate == 1.0 :
		#	txCDInterfaceRate = 0 #this interface rate is not supported inside Tx config though
		#	#top level MACRO has it
		#	error("mode not supported")
		#elif tx_cd_if_rate == 2.0 :
		#	txCDInterfaceRate = 0
		#elif tx_cd_if_rate == 3.0 :
		#	txCDInterfaceRate = 1
		#elif tx_cd_if_rate == 4.0 :
		#	txCDInterfaceRate = 2
		#elif tx_cd_if_rate == 6.0 :
		#	txCDInterfaceRate = 3
		#elif tx_cd_if_rate == 8.0 :
		#	txCDInterfaceRate = 4
		#elif tx_cd_if_rate == 12.0 :
		#	txCDInterfaceRate = 5	
		self.do_interface_rate_configuration_updated(txABInterfaceRate, txCDInterfaceRate, rxABInterfaceRate, rxCDInterfaceRate, fb_ab_if_rate, fb_cd_if_rate)
		
####################################################################################
	def do_interface_rate_configuration_updated(self, tx_ab_if_rate, tx_cd_if_rate, rx_ab_if_rate, rx_cd_if_rate, fb_ab_if_rate, fb_cd_if_rate):
		self.set_tx_ab_if_rate(tx_ab_if_rate)
		self.set_tx_cd_if_rate(tx_cd_if_rate)
		self.set_rx_ab_if_rate(rx_ab_if_rate)
		self.set_rx_cd_if_rate(rx_cd_if_rate)
		self.set_fb_if_rate(fb_ab_if_rate,0)
		self.set_fb_if_rate(fb_cd_if_rate,1)

		return(self.execute_macro(6, MACROConst.MACRO_OPCODE_INTERFACE_RATE_CONFIG))

	# do_interface_rate_configuration_updated

####################################################################################
	def do_tune_and_enable(self, tx_selected_chains, rx_selected_chains, fb_selected_chains, analog_chain=0, cm4_related=0):			#Added in 0.6, default to support 0.5 version
		self.set_tune_tx_chain(tx_selected_chains)
		self.set_tune_rx_chain(rx_selected_chains)
		self.set_tune_fb_chain(fb_selected_chains)
		self.set_tune_analog_chain(analog_chain)
		self.set_tune_CM4_related(cm4_related)
		return(self.execute_macro(8, MACROConst.MACRO_OPCODE_TUNE_AND_ENABLE_CHAINS))
	
	# do_tune_and_enable

####################################################################################
	def do_tune_and_enable_pass_only_sys_config(self):
		self.byteList[0] = 0x00
		self.byteList[1] = 0x00
		self.byteList[2] = 0x00
		self.byteList[3] = 0x00
		self.byteList[4] = 0x00
		
		return(self.execute_macro(5, MACROConst.MACRO_OPCODE_TUNE_AND_ENABLE_CHAINS))
	
	# do_tune_and_enable_pass_only_sys_config

####################################################################################
	def execute_macro(self, nBytes, opcode,get_macro_error_extended_code=0):
		self.wait_for_macro_ready();
		self.packBytesintoOperandsAndWrite(nBytes);
		self.trigger_macro(opcode)
		self.wait_for_macro_done()
		return(self.check_for_macro_error(get_macro_error_extended_code))

	# execute_macro
	
	
####################################################################################
	def switch_topCM4_clock(self):
		self.switch_to_pll_clock();
		

####################################################################################
	def do_start_dsa_calibration(self,type,ch,dsa_start,dsa_stop,cal,fb_conn):
		self.start_dsa_calibration(type,ch,dsa_start,dsa_stop,cal,fb_conn)
		return(self.execute_macro(7, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_start_dsa_calibration
	
####################################################################################
	def do_start_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en):
		self.start_vga_calibration(dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en)
		return(self.execute_macro(13, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_start_vga_calibration
	
####################################################################################
	def do_continue_dsa_calibration(self,type,ch,start_index,stop_index,toneABCD,tranABCD,refTrack,freqdepd=0,loopback=0):
		self.continue_dsa_calibration(type,ch,start_index,stop_index,toneABCD,tranABCD,refTrack,freqdepd,loopback)
		if(type=="txdsa"):
			return(self.execute_macro(9, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
		elif(type=="rxdsa"):
			return(self.execute_macro(9, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_continue_dsa_calibration
	
####################################################################################
	def do_continue_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en):
		self.continue_vga_calibration(dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en)
		return(self.execute_macro(12, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_continue_dsa_calibration
	
####################################################################################
	def do_completed_dsa_calibration(self,type):
		self.completed_dsa_calibration(type)
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_completed_dsa_calibration
	
####################################################################################
	def do_completed_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en):
		self.completed_vga_calibration(dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en)
		return(self.execute_macro(12, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_completed_dsa_calibration
	
####################################################################################
	def do_apply_dsa_packet(self,type,txa,txb,txc,txd):
		self.apply_dsa_packet(type,txa,txb,txc,txd)
		return(self.execute_macro(5, MACROConst.MACRO_OPCODE_SET_FACTORY_CALIB_DATA))
	# do_apply_dsa_packet
	
####################################################################################
	def get_die_id(self):
		self.set_die_id_read()
		err = self.execute_macro(1,MACROConst.MACRO_OPCODE_SYSTEM_COMMAND)
		data=self.read_32b_result()
		return(data,err)
		
	# get_die_id	
		
####################################################################################
	def fb_capture(self,ch_a,ch_c):
		self.byteList[0]=ch_a
		self.byteList[1]=ch_c
		return(self.execute_macro(2, 0x42))
	# fb_capture		
		
####################################################################################
	def get_fw_version(self):
		self.set_fw_version_read()
		err = self.execute_macro(1,MACROConst.MACRO_OPCODE_SYSTEM_COMMAND)
		data=self.read_32b_result()
		info("FW_VERSION="+str(hex(data)))
		return(data,err)
		
	# get_die_id		

####################################################################################
	def system_init_post_sysref(self,operand):
		self.byteList[0]=operand
		return(self.execute_macro(1, MACROConst.MACRO_OPCODE_SYSTEM_INIT))		
	# get_die_id		

####################################################################################
	def start_tx_iqmc_only_powerup_calib(self,apply_to_channel, analog_init_ctrl, digital_init_ctrl):
		self.set_tx_iqmc_only_powerup_calib(apply_to_channel,analog_init_ctrl, digital_init_ctrl);
		return(self.execute_macro(7, MACROConst.MACRO_OPCODE_POWERUP_CALIB_CONTROL))
	# start_tx_iqmc_only_powerup_calib	

####################################################################################
	def start_tx_LO_leakage_only_powerup_calib(self,apply_to_channel, analog_init_ctrl, digital_init_ctrl):
		self.set_tx_lo_leakage_only_powerup_calib(apply_to_channel,analog_init_ctrl, digital_init_ctrl);
		return(self.execute_macro(7, MACROConst.MACRO_OPCODE_POWERUP_CALIB_CONTROL))
	# start_tx_iqmc_only_powerup_calib		
	
	
###################################################################
	def write_read_rxcm4_macro(self,wr=1,access_size=1,num_bytes=12,address=0x20017C00,value=0,num_burst=0):
		
		rx_rw_opcode = 25
		
		rf0 =  (num_bytes << 16)	+ ((access_size + (wr << 2))<<8) + (rx_rw_opcode)	
		# Fill the operands
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = rf0
		
		# Populating MACRO Memory
		self.memWrite32('macroMem', 0, address)
		self.memWrite32('macroMem', 4, value)
		self.memWrite32('macroMem', 8, num_burst)
		
		# Issue MACRO			
		err = self.execute_macro(nBytes=0,opcode=MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB)
		return (err)
	# write_read_rxcm4_macro

	@funcDecorator
	def packet_read_silicon(self,fileName,Number_of_bytes_in_burstread=1500):
		""" "Reading packet from silicon" "Done reading packet from silicon" """
		err_cnt=0
		packet_param={}
		info("//--------------------------------packet_read----------------------------------------------------------")
		burstread_enable=1
		file = open(fileName,'w')
		if (burstread_enable==1):
			self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Do the below reads and save the values into memory.")
			x=self.deviceRefs.device.logClassInst.enableReads
			self.deviceRefs.device.logClassInst.enableReads=True
			MACRO_MEM_DATA=self.burstRead(0x20+0x8000,Number_of_bytes_in_burstread)
			self.deviceRefs.device.logClassInst.enableReads=x
			self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: End of the reads.")
		info(MACRO_MEM_DATA)
		if self.systemParams.simulationMode==True:
			MACRO_MEM_DATA=[0]*Number_of_bytes_in_burstread
		file.write(str(MACRO_MEM_DATA))
		file.close()
		return MACRO_MEM_DATA
		
	@funcDecorator
	def set_factory_calibration_data(self,EXPECTED_ERROR):
		""" "Applying the Packet to the DSA Codes" "Done applying the Packet to the DSA Codes" """
		return_param={}
		"""set_factory_calibration_data"""
		err_cnt=0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0x02
		##opcode for factory calib
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x12)<<24)
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status(EXPECTED_ERROR);
		return_param['err_cnt']=err_cnt+macro_error_param['err_cnt']
		return_param['MACRO_ERROR_EXTENDED_CODE']=macro_error_param['MACRO_ERROR_EXTENDED_CODE']
		return(return_param)
	
	@funcDecorator
	def loadDsaPacket(self,rxTx,packetFile):
		""" rxTx=0 means RX. else it is TX. packetFile is the file loaded. """
		packetFile=open(packetFile,'r')
		lines=packetFile.readlines()[0]
		lines=lines.replace("[","")
		lines=lines.replace("]","")
		lines=lines.split(',')
		lines=[int(i.strip()) for i in lines]
		packetFile.close()
		self.wait_for_macro_ready();
		self.memRead8('macroMem', 0x00);
		self.burstWrite(0x20,lines)
		if rxTx==0:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0x02
		else:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0x01
		##opcode for factory calib
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x12)<<24)
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
	#loadDsaPacket
	
	@funcDecorator
	def interpret_macro_error_extended_code(self,MACRO_ERROR_EXTENDED_CODE):
		"""interpret_macro_error_extended_code"""
		if (MACRO_ERROR_EXTENDED_CODE==0):
			info("DSA Calibration Done");
		elif (MACRO_ERROR_EXTENDED_CODE==1):
			info("Command Error");
		elif (MACRO_ERROR_EXTENDED_CODE==2):
			info("DSA_RELIABILITY_HIT");
		elif (MACRO_ERROR_EXTENDED_CODE==3):
			info("DSA_FREQ_WRONG: Calibration Frequency is out of band");
		elif (MACRO_ERROR_EXTENDED_CODE==4):
			info("DSA_PWR_ERROR: Input signal power is too low");
		elif (MACRO_ERROR_EXTENDED_CODE==5):
			info("DSA_SNR_ERROR: SNR requirement not met for calibration. Also possible that input is not coherent to 256 Point FFT.");
		elif (MACRO_ERROR_EXTENDED_CODE==7):
			info("SIG_INVALID: Signal is invalid set by syscalib");
		elif (MACRO_ERROR_EXTENDED_CODE==8):
			info("DSA_MULTITONE_ERROR: Either tone is not on bin or spur level is too high");
		elif (MACRO_ERROR_EXTENDED_CODE==9):
			info("GAIN_STEP_ERROR: In DSA calibration power observed is outside the DSA correction range");
		elif (MACRO_ERROR_EXTENDED_CODE==10):
			info("DSA_PHASE_ERROR: Phase change between dsa/vga steps is more than (40deg)");
		elif (MACRO_ERROR_EXTENDED_CODE==13):
			info("PKT_ERROR: DSA packet loaded is corrupted");
		elif (MACRO_ERROR_EXTENDED_CODE==6):
			info("SYSCALIB_TIMEOUT: Syscalib didn't set capture done or fft done flag");


	#interpret_macro_error_extended_code
	
	@funcDecorator
	def macro_factory_calibration_control(self,OP0,OP1,OP2,OP3,OP4,OP5,OP6,OP7,OP8,OP9,OP10,OP11,EXPECTED_ERROR=0):
		""" "Initializing the System for factory Calibration" "Done initializing the System for factory Calibration" """
		"""MACRO	Factory calibration control
		Opcode	0x41
		Operand	Offset	Length	Value	Functionality	Results
		0		0x00	1		0x00	Terminate factory calibration	
								0x01	Start factory calibration	On completion of the calibration, a data packet with the calibration data is written to the MACRO Memory. 
								0x02	Continue factory calibration	
								0x0F	Completed	
		1		0x01	1		[1 3]	
										1 : Tx Dsa
										2:  Rx Dsa
										3:  VGA cal	
		2		0x02	1		0x0F	Applies to ABCD chains	This will be neglected for DSA calibration
								0x0C	Applies to CD chains	
								0x03	Applies the command to AB	
		Tx DSA gain phase power up Calibration
		3		0x03	1		[0 39]	Dsa start Index	
		4		0x04	1		[0 39]	Dsa Stop Index (always > Dsa Start Index)	
		5		0x05	1		LSB 4bits	0 -> No cal
											1 -> Do cal

											Bit 0: tx A
											Bit 1: tx B
											Bit 2: tx C
											Bit 3: tx D	
		6		0x06	1		LSB 4 bits	0-> FbAB connected 
											1-> FbCD connected

											Bit 0:  Tx A
											Bit 1:  Tx B
											Bit 2: Tx C
											Bit 3: Tx D	
		7		0x07	1				0 -> Reference tracking disabled
										1 -> Reference tracking enable	
		Rx DSA gain phase power up Calibration
		3		0x03	1		[0 36]		Dsa start Index	
		4		0x04	1		[0 36]		Dsa Stop Index (always > Dsa Start Index)	
		5		0x05	1		LSB 4bits	0 -> No cal
											1 -> Do cal

											Bit 0: rx A
											Bit 1: rx B
											Bit 2: rx C
											Bit 3: rx D	
		6		0x06	1		LSB 4 bits	0 -> No tone transmission
											1 -> Tone transmission nth chain

											Bit 0: tx A
											Bit 1: tx B
											Bit 2: tx C
											Bit 3: tx D	
		7		0x07	1					0 -> Frequency depedent cal Disabled
											1 -> Frequency depedent cal Enable	
		8		0x08	1					0 -> Reference tracking disabled
											1 -> Reference tracking enable	
		9		0x09	1					0->Internal Loop Back dis
											1->Internal Loop Back En
			
		VGA gain phase power up Calibration
		3		0x03	1		[0 36]		Dsa Index to be used	
		4		0x04	1		[0 31]		Vga start step index	
		5		0x05	1		[0 31]		Vga last step index	
		6		0x06	1		[3:0]		Vga to be caliberated.
		[3:0] maps to [D C B A] respectively	
		7		0x07	1		[0 31]		Current Vga step in external caliberation mode	
		8		0x08	1					VGA Step	
		9		0x09	1		4 Bits LSB	0 -> No tone transmission
											1 -> Tone transmission nth chain

											Bit 0: tx A
											Bit 1: tx B
											Bit 2: tx C
											Bit 3: tx D	
		10		0x0A	1					0-	VGA
											1-	LNA	
		11		0x0B	1						0 Vga Externally controlled
												1 Vga Internally controlled
		12		0x0C	1					0->Internal Loop Back dis
											1->Internal Loop Back En
			
		13		0x0D	1					0 -> Reference tracking disabled
											1 -> Reference tracking enable """ 

		OP0_MUXED=rxCalibInit.OP0_START_FACTORY_CALIBRATION
		OP1_MUXED=OP1
		OP2_MUXED=OP2
		OP3_MUXED=OP3
		OP4_MUXED=OP4
		OP5_MUXED=OP5
		OP6_MUXED=OP7
		OP7_MUXED=OP10
		OP8_MUXED=OP8
		OP9_MUXED=OP9
		OP10_MUXED=OP6
		OP11_MUXED=OP11
		return_param={}
		err_cnt=0
		#info("//--------------------------------macro_factory_calibration_control---------------------------------")
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(OP0_MUXED)+(OP1_MUXED<<8)+(OP2_MUXED<<16)+(OP3_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(OP4_MUXED)+(OP5_MUXED<<8)+(OP6_MUXED<<16)+(OP7_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2=(OP8_MUXED)+(OP9_MUXED<<8)+(OP10_MUXED<<16)+(OP11_MUXED<<24)
		##opcode for factory calib
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x41)<<24)
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status(EXPECTED_ERROR);
		return_param['MACRO_ERROR_EXTENDED_CODE']=macro_error_param['MACRO_ERROR_EXTENDED_CODE']
		return_param['err_cnt']=err_cnt+macro_error_param['err_cnt']
		return(return_param)
		
	@funcDecorator
	def macro_factory_calibration_control_continue(self,OP0,OP1,OP2,OP3,OP4,OP5,OP6,OP7,OP8,OP9,OP10,OP11,OP12,OP13,OP14,OP15,OP16,OP17,calib_param,EXPECTED_ERROR=0,ASIC_ENABLE=0):
		""" "Setting the parameters for factory Calibration"  "Done Setting the parameters for factory Calibration" """
		return_param={}
		err_cnt=0
		NUMBER_OF_DSA_CODES=112
		OP0_MUXED=rxCalibInit.OP0_CONTINUE_FACTORY_CALIBRATION
		OP1_MUXED=OP1
		OP2_MUXED=OP2
		OP3_MUXED=OP3
		OP4_MUXED=OP4
		OP5_MUXED=OP5
		OP6_MUXED=OP6
		OP7_MUXED=OP7
		OP8_MUXED=OP8
		OP9_MUXED=OP9
		OP10_MUXED=OP10
		OP11_MUXED=OP11
		OP12_MUXED=OP12
		OP13_MUXED=OP13
		OP14_MUXED=OP14
		OP15_MUXED=OP15
		OP16_MUXED=OP16
		OP17_MUXED=OP17
		
		i=0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(OP0_MUXED)+(OP1_MUXED<<8)+(OP2_MUXED<<16)+(OP3_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(OP4_MUXED)+(OP5_MUXED<<8)+(OP6_MUXED<<16)+(OP7_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2=(OP8_MUXED)+(OP9_MUXED<<8)+(OP10_MUXED<<16)+(OP11_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf3=(OP12_MUXED)+(OP13_MUXED<<8)+(OP14_MUXED<<16)+(OP15_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf4=(OP16_MUXED)+(OP17_MUXED<<8)
		##opcode for factory calib
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x41)<<24)
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status(EXPECTED_ERROR);
		return_param['MACRO_ERROR_EXTENDED_CODE']=macro_error_param['MACRO_ERROR_EXTENDED_CODE']
		return_param['err_cnt']=err_cnt+macro_error_param['err_cnt']
		return(return_param)
		
	@funcDecorator
	def macro_factory_calibration_control_done(self,OP0,OP1,OP2,OP3,OP4,OP5,OP6,OP7,OP8,OP9,OP10,OP11,EXPECTED_ERROR=0):
		""" "Completing Calibration and loading the packet into memory" "Completed Calibration and loading the packet into memory" """
		macro_calib_done_param={}
		err_cnt=0
		OP0_MUXED=rxCalibInit.OP0_COMPLETED_FACTORY_CALIBRATION
		OP1_MUXED=OP1
		OP2_MUXED=OP2
		OP3_MUXED=OP3
		OP4_MUXED=OP4
		OP5_MUXED=OP5
		OP6_MUXED=OP7
		OP7_MUXED=OP10
		OP8_MUXED=OP8
		OP9_MUXED=OP9
		OP10_MUXED=OP6
		OP11_MUXED=OP11
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(OP0_MUXED)+(OP1_MUXED<<8)+(OP2_MUXED<<16)+(OP3_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(OP4_MUXED)+(OP5_MUXED<<8)+(OP6_MUXED<<16)+(OP7_MUXED<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2=(OP8_MUXED)+(OP9_MUXED<<8)+(OP10_MUXED<<16)+(OP11_MUXED<<24)
		##opcode for factory calib
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x41)<<24)
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status(EXPECTED_ERROR);
		err_cnt=err_cnt+macro_error_param['err_cnt']
		macro_calib_done_param['err_cnt']=err_cnt;
		macro_calib_done_param['ERROR_CODE_DONE']=macro_error_param['MACRO_ERROR_EXTENDED_CODE']
		return(macro_calib_done_param)
		
	@funcDecorator
	def macro_factory_calibration_control_terminate(self,OP0,OP1,OP2,OP3,OP4,OP5,OP6,OP7,OP8,OP9):
		""" "Stopping calibration" "Stopped calibration" """
		macro_calib_done_param={}
		err_cnt=0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(OP0_TERMINATE_FACTORY_CALIBRATION)+(OP1<<8)+(OP2<<16)+(OP3<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(OP4)+(OP5<<8)+(OP6<<16)+(OP7<<24)
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2=(OP8)+(OP9<<8)
		##opcode for factory calib
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x41)<<24)
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status();
		err_cnt+=macro_error_param['err_cnt'];
		return(err_cnt)
	#macro_factory_calibration_control_terminate
	
	@funcDecorator
	def patch_top_fw_download(self,PATCH_DOWNLOAD,PATCH_OPCODE,address=0):
		"""patch_top_fw_download"""
		err_cnt=0
		# Number_of_patch_files=0x00
		# Current_patch_packet_length=0x00
		# crc_of_current_patch=0x00
		# patch_file_offset=0x00
		pkt_len=2**12
		# address=0x0
		PATCH_TOP_FW=0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_DOWNLOAD)+(PATCH_TOP_FW<<8)+(pkt_len<<16)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0="+str((PATCH_DOWNLOAD)+(PATCH_TOP_FW<<8)+(pkt_len<<16)))
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1="+str((address)))
		##opcode for patching
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((PATCH_OPCODE)<<24)
		debug("//self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand="+str(((PATCH_OPCODE)<<24)))
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status();
		err_cnt=err_cnt+macro_error_param['err_cnt']
		return(err_cnt)
	
	@funcDecorator
	def patch_top_fw_apply(self,PATCH_APPLY,PATCH_TOP_FW,PATCH_OPCODE):
		"""patch_top_fw_apply"""
		err_cnt=0
		# Number_of_patch_files=0x00
		# Current_patch_packet_length=0x00
		# crc_of_current_patch=0x00
		# patch_file_offset=0x00
		pkt_len=2**12
		address=0x0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_APPLY)+(PATCH_TOP_FW<<8)+(pkt_len<<16)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0="+str((PATCH_APPLY)+(PATCH_TOP_FW<<8)+(pkt_len<<16)))
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1="+str((address)))
		##opcode for patching
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((PATCH_OPCODE)<<24)
		debug("//self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand="+str(((PATCH_OPCODE)<<24)))
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status();
		err_cnt=err_cnt+macro_error_param['err_cnt']
		return(err_cnt)
		
	@funcDecorator
	def patch_rxiqmc_fw_download(self,PATCH_DOWNLOAD,PATCH_RX_FW,PATCH_OPCODE,address=0):
		"""patch_rxiqmc_fw_download"""
		err_cnt=0
		# Number_of_patch_files=0x00
		# Current_patch_packet_length=0x00
		# crc_of_current_patch=0x00
		# patch_file_offset=0x00
		pkt_len=2**12
		# address=0x0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_DOWNLOAD)+(PATCH_RX_FW<<8)+(pkt_len<<16)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0="+str((PATCH_DOWNLOAD)+(PATCH_RX_FW<<8)+(pkt_len<<16)))
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1="+str((address)))
		##opcode for patching
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((PATCH_OPCODE)<<24)
		debug("//self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand="+str(((PATCH_OPCODE)<<24)))
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status();
		err_cnt=err_cnt+macro_error_param['err_cnt']
		return(err_cnt)
	
	
	@funcDecorator
	def set_tx_fw_tx_fb_loopback_delay(self, channel_selected,ext_dly):
		
		self.byteList[0] = MACROConst.MACRO_TX_FW_RELAY__SPECIFY_TX_FB_DELAY_OPCODE
		self.byteList[1] = (2**4)*ext_dly + channel_selected
		self.byteList[2] = 8	# 8 bytes of information
		self.byteList[3] = 0            
	# set_tx_fw_tx_fb_loopback_delay
	
	@funcDecorator
	def convert_interface_rate_sample_delay_to_tx_fw_value(self,interface_rate,delay_interface_samples):
		# 1 LSB = 1 Clk at 48x = 0.3391 ns
		actual_delay = abs (delay_interface_samples * 1.0 / (interface_rate * self.systemParams.X * 1e6))
		clk_period_48x = 1/(48*self.systemParams.X*1e6)
		reg_val = int(round(actual_delay/clk_period_48x))                        

		if(delay_interface_samples >= 0):
			return(reg_val)           
		else:     
			return(65536-reg_val)
		  
	# convert_interface_rate_sample_delay_to_tx_fw_value
			  
	@funcDecorator
	def specify_tx_fw_tx_fb_loopback_delay(self,channel_selected,ext_dly ,tx_a_dly,tx_b_dly,tx_c_dly,tx_d_dly):	
		
		self.set_tx_fw_tx_fb_loopback_delay(channel_selected,ext_dly)
	
		self.memWrite16('macroMem', 0, tx_a_dly)
		self.memWrite16('macroMem', 2, tx_b_dly)
		self.memWrite16('macroMem', 4, tx_c_dly)
		self.memWrite16('macroMem', 6, tx_d_dly)
		
		return(self.execute_macro(4, MACROConst.MACRO_OPCODE_TX_FW_RELAY))
	# specify_tx_fw_tx_fb_loopback_delay
	
	@funcDecorator
	def patch_rxiqmc_fw_apply(self,PATCH_APPLY,PATCH_RX_FW,PATCH_OPCODE):
		"""patch_rxiqmc_fw_apply"""
		err_cnt=0
		# Number_of_patch_files=0x00
		# Current_patch_packet_length=0x00
		# crc_of_current_patch=0x00
		# patch_file_offset=0x00
		pkt_len=2**12
		address=0x0
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_APPLY)+(PATCH_RX_FW<<8)+(pkt_len<<16)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0="+str((PATCH_APPLY)+(PATCH_RX_FW<<8)+(pkt_len<<16)))
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
		debug("//self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1="+str((address)))
		##opcode for patching
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((PATCH_OPCODE)<<24)
		debug("//self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand="+str(((PATCH_OPCODE)<<24)))
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
		macro_error_param=self.get_macro_status();
		err_cnt=err_cnt+macro_error_param['err_cnt']
		return(err_cnt)
		
	@funcDecorator
	def start_tx_fw_steady_state(self,tx_iq_lo_channel_mask):	
		self.set_tx_fw_steady_state(tx_iq_lo_channel_mask)		
		return(self.execute_macro(4, MACROConst.MACRO_OPCODE_TX_FW_RELAY))
	# start_tx_fw_steady_state

	@funcDecorator
	def set_tx_fw_steady_state(self, tx_ss_iq_lo_channel_mask):
		self.byteList[0] = MACROConst.MACRO_TX_FW_RELAY__START_SS_OPCODE
		self.byteList[1] = tx_ss_iq_lo_channel_mask
		self.byteList[2] = 0
		self.byteList[3] = 0
	# set_tx_fw_steady_state
	
	
	@funcDecorator
	def compute_tx_steady_sate_tx_fb_map(self,dual_fbmode=0,singlefb_chc=0,dual_fbmap=[0,1,2,3]):
		tx_fb_map = [0,0,1,1]
		if(dual_fbmode == 0):           # If Single Fb Mode
			if(singlefb_chc == 0):      # Single Fb - Fb A 
				tx_fb_map = [0,0,0,0]
			else :                      # Single Fb - Fb C
				tx_fb_map = [1,1,1,1]
		else :                          # If Dual Fb Mode	
			tx_fb_map[dual_fbmap[0]] = 0
			tx_fb_map[dual_fbmap[1]] = 0
			tx_fb_map[dual_fbmap[2]] = 1
			tx_fb_map[dual_fbmap[3]] = 1
		tx_fb_map_val = 8*tx_fb_map[3] + 4*tx_fb_map[2] + 2*tx_fb_map[1] + tx_fb_map[0]
		return(tx_fb_map_val)		
	#	compute_tx_steady_sate_tx_fb_map

	@funcDecorator
	def do_tx_rx_algo_config(self,txrx,estimation_mode,tx_fb_map):	
		self.set_algo_config(txrx, estimation_mode , tx_fb_map)	
		return(self.execute_macro(3, MACROConst.MACRO_OPCODE_ALGO_CONFIG))
	# do_tx_rx_algo_config
	
	@funcDecorator
	def set_algo_config(self, tx_rx, estim_mode , tx_fb_cfg):
		self.byteList[0] = tx_rx
		self.byteList[1] = estim_mode
		self.byteList[2] = tx_fb_cfg
	# set_algo_config	
	
	
	@funcDecorator
	def serdesFirmwareLoadMacro(self,serdesIp):
		"""  """
		self.wait_for_macro_ready()
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(0)+(serdesIp<<8)+(1<<16)
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=130<<24
		self.wait_for_macro_done()
		self.wait_for_macro_ready()
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(1)+(serdesIp<<8)+(1<<16)
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=130<<24
		self.wait_for_macro_done()
		self.check_for_macro_error()
	#downloadSerdesFirmware
	
	@funcDecorator
	def sleepMacro(self,rx_chain=0xF,tx_chain=0xF,fb_chain=0x3,pll=0x1F,txcm4=1,rxcm4=1,serdes=1):
		""" "Putting the System to Sleep/Waking it up" "Done putting the System to Sleep/Waking it up" """
		temp=self.deviceRefs.device.hardReadAlways
		self.deviceRefs.device.hardReadAlways=True
		command=0
		tdd=1
		pll=0
		for i in len(self.systemStatus.pllValid):
			pll+=self.systemStatus.pllValid[i]<<i
		
		self.wait_for_macro_ready();
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 =(rx_chain)+(tx_chain<<4)+(fb_chain<<8)+(pll<<10)+(txcm4<<15)+(rxcm4<<16)+(serdes<<17)+(command<<18)+(tdd<<19)
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (57)<<24
		self.wait_for_macro_done();
		
		self.wait_for_macro_ready();
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (58)<<24
		self.wait_for_macro_done();
		critical(self.check_for_macro_error());
		self.deviceRefs.device.hardReadAlways=temp
	#sleepMacro
	
	
	####################################################################################
	@funcDecorator
	def set_low_if_nco_rx_ab(self,freq_word,start_addr=0xA):
		bytesLen = 4
		dataOut = self.splitHexNumToBytes(freq_word, bytesLen);

		for i in range(0,bytesLen):
			self.byteList[i+start_addr]=dataOut[bytesLen-1-i]
	# set_low_if_nco_rx_ab(self,freq_word):
	
	@funcDecorator
	def do_low_if_mode_configuration(self, low_if_mode_rx,low_if_mode_tx,low_if_mode_fb,low_if_nco_rx_ab,low_if_nco_rx_cd,low_if_nco_tx_ab,low_if_nco_tx_cd,low_if_nco_fb_ab,low_if_nco_fb_cd):
		self.set_low_if_nco_rx_ab(low_if_nco_rx_ab,8)
		self.set_low_if_nco_rx_ab(low_if_nco_rx_cd,12)
		self.set_low_if_nco_rx_ab(low_if_nco_tx_ab,0)
		self.set_low_if_nco_rx_ab(low_if_nco_tx_cd,4)
		self.set_low_if_nco_rx_ab(low_if_nco_fb_ab,16)
		self.set_low_if_nco_rx_ab(low_if_nco_fb_cd,20)
		return(self.execute_macro(24, MACROConst.MACRO_OPCODE_LOW_IF_MODE))
	# do_low_if_mode_configuration
	
	@funcDecorator
	def do_tx_rx_fb_low_if_interface_rate_configuration(self, tx_ab_if_rate, tx_cd_if_rate, rx_ab_if_rate, rx_cd_if_rate, fb_ab_if_rate, fb_cd_if_rate, low_if_mode_tx=0x1F, low_if_mode_rx=0x1F, low_if_mode_fb=0x3):
		
		#assign default values if corresponding inputs are not passed
		
		#Rx interface rate configuration
		rxABInterfaceRate = 0
		rxCDInterfaceRate = 0
		txABInterfaceRate = 0
		txCDInterfaceRate = 0
		
		rxABInterfaceRate=(0.5,1,1.5,2,3,4,6).index(round(rx_ab_if_rate))
		rxCDInterfaceRate=(0.5,1,1.5,2,3,4,6).index(round(rx_cd_if_rate))
		
		# Tx interface rate configuration
		if tx_ab_if_rate==1:
			error("Unsupported TXAB Interface Rate given.")
		txABInterfaceRate=(2,3,4,6,8,12).index(round(tx_ab_if_rate))
		
		if tx_cd_if_rate==1:
			error("Unsupported TX CD Interface Rate given.")
		txCDInterfaceRate=(2,3,4,6,8,12).index(round(tx_cd_if_rate))
		
		self.do_low_if_interface_rate_configuration_updated(txABInterfaceRate, txCDInterfaceRate, rxABInterfaceRate, rxCDInterfaceRate, fb_ab_if_rate, fb_cd_if_rate, low_if_mode_tx, low_if_mode_rx, low_if_mode_fb)
	#do_tx_rx_fb_low_if_interface_rate_configuration
	
	@funcDecorator
	def do_low_if_interface_rate_configuration_updated(self, tx_ab_if_rate, tx_cd_if_rate, rx_ab_if_rate, rx_cd_if_rate, fb_ab_if_rate, fb_cd_if_rate, low_if_mode_tx=0x1F, low_if_mode_rx=0x1F, low_if_mode_fb=0x3):
		self.set_fb_if_rate(fb_ab_if_rate,0,7)
		self.set_fb_if_rate(fb_cd_if_rate,1,7)
		
		self.byteList[0] = low_if_mode_tx
		self.byteList[1] = tx_ab_if_rate
		self.byteList[2] = tx_cd_if_rate
		self.byteList[3] = low_if_mode_rx
		self.byteList[4] = rx_ab_if_rate
		self.byteList[5] = rx_cd_if_rate
		self.byteList[6] = low_if_mode_fb
		return(self.execute_macro(9, MACROConst.MACRO_OPCODE_LOW_IF_RATE_CONFIGURATION))		
	# do_low_if_interface_rate_configuration_updated
	
	@funcDecorator
	def configureLowIf(self):	
		x=self.systemParams.X/61.44
		low_if_nco_rx=[0,0]
		if (self.systemParams.lowIfNcoRx[0]>=0):
			low_if_nco_rx[0]=int(round(self.systemParams.lowIfNcoRx[0]*1000*x))#1MHz
		else:
			low_if_nco_rx[0]=int(round(61440*self.systemStatus.rxLowIfRate[0]+self.systemParams.lowIfNcoRx[0]*1000*x))#1MHz
		if (self.systemParams.lowIfNcoRx[1]>=0):
			low_if_nco_rx[1]=int(round(self.systemParams.lowIfNcoRx[1]*1000*x))#1MHz
		else:
			low_if_nco_rx[1]=int(round(61440*self.systemStatus.rxLowIfRate[1]+self.systemParams.lowIfNcoRx[1]*1000*x))#1MHz
		low_if_nco_tx=[0,0]
		if (self.systemParams.lowIfNcoTx[0]>=0):
			low_if_nco_tx[0]=int(2**32-61440*self.systemStatus.txLowIfRate[0]+(self.systemParams.lowIfNcoTx[0]*1000*x))#1Mhz
		else:
			low_if_nco_tx[0]=int(2**32+self.systemParams.lowIfNcoTx[0]*1000*x)#1Mhz
		if (self.systemParams.lowIfNcoTx[1]>=0):
			low_if_nco_tx[1]=int(2**32-61440*self.systemStatus.txLowIfRate[1]+(self.systemParams.lowIfNcoTx[1]*1000*x))#1Mhz
		else:
			low_if_nco_tx[1]=int(2**32+self.systemParams.lowIfNcoTx[1]*1000*x)#1Mhz
		low_if_nco_fb=[0,0]
		if (self.systemParams.lowIfNcoFb[0]>=0):
			low_if_nco_fb[0]=int(2**32-61440*self.systemStatus.fbLowIfRate[0]+(self.systemParams.lowIfNcoFb[0]*1000*x))#1Mhz
		else:
			low_if_nco_fb[0]=int(2**32+self.systemParams.lowIfNcoFb[0]*1000*x)#1Mhz
		if (self.systemParams.lowIfNcoFb[1]>=0):
			low_if_nco_fb[1]=int(2**32-61440*self.systemStatus.fbLowIfRate[1]+(self.systemParams.lowIfNcoFb[1]*1000*x))#1Mhz
		else:
			low_if_nco_fb[1]=int(2**32+self.systemParams.lowIfNcoFb[1]*1000*x)#1Mhz

		if self.systemParams.lowIfNcoRx==[0,0]:
			low_if_mode_rx=0
		elif self.systemParams.lowIfNcoRx[0]==0:
			low_if_mode_rx=0xc
		elif self.systemParams.lowIfNcoRx[1]==0:
			low_if_mode_rx=0x3
		else:
			low_if_mode_rx=0x1f
		
		if((round(self.systemParams.Fs/self.systemParams.ddcFactorRx[0],2)==round(self.systemParams.X/2.,2))and(round(self.systemParams.Fs/self.systemParams.ddcFactorRx[1],2)==round(self.systemParams.X/2.,2))):
			low_if_mode_rx=0x1f
		elif(round(self.systemParams.Fs/self.systemParams.ddcFactorRx[0],2)==round(self.systemParams.X/2.,2)):
			low_if_mode_rx=(low_if_mode_rx&0x1c)+0x3
		elif(round(self.systemParams.Fs/self.systemParams.ddcFactorRx[1],2)==round(self.systemParams.X/2.,2)):
			low_if_mode_rx=(low_if_mode_rx&0x13)+0xc
		
		
		if self.systemParams.lowIfNcoTx==[0,0]:
			low_if_mode_tx=0
		elif self.systemParams.lowIfNcoTx[0]==0:
			low_if_mode_tx=0xc
		elif self.systemParams.lowIfNcoTx[1]==0:
			low_if_mode_tx=0x3
		else:
			low_if_mode_tx=0x1f
			#info("low_if_mode_tx=0x1f")
		low_if_mode_fb=0
		#if self.systemParams.lowIfNcoFb==[0,0]:
		#	low_if_mode_fb=0
		#elif self.systemParams.lowIfNcoFb[0]==0:
		#	low_if_mode_fb=0x2
		#elif self.systemParams.lowIfNcoFb[1]==0:
		#	low_if_mode_fb=0x1
		#else:
		#	low_if_mode_fb=0x3
		self.systemStatus.lowIfParams['low_if_mode_rx']=low_if_mode_rx
		self.systemStatus.lowIfParams['low_if_mode_tx']=low_if_mode_tx
		self.systemStatus.lowIfParams['low_if_mode_fb']=low_if_mode_fb
		self.systemStatus.lowIfParams['low_if_nco_rx0']=low_if_nco_rx[0]
		self.systemStatus.lowIfParams['low_if_nco_rx1']=low_if_nco_rx[1]
		self.systemStatus.lowIfParams['low_if_nco_tx0']=low_if_nco_tx[0]
		self.systemStatus.lowIfParams['low_if_nco_tx1']=low_if_nco_tx[1]
		
		self.do_tx_rx_fb_low_if_interface_rate_configuration(self.systemStatus.txLowIfRate[0], self.systemStatus.txLowIfRate[1], \
																self.systemStatus.rxLowIfRate[0], self.systemStatus.rxLowIfRate[1], \
																self.systemStatus.fbLowIfRate[0], self.systemStatus.fbLowIfRate[1], low_if_mode_tx, low_if_mode_rx, low_if_mode_fb);
		self.do_low_if_mode_configuration(low_if_mode_rx,low_if_mode_tx,low_if_mode_fb,low_if_nco_rx[0],\
																low_if_nco_rx[1],low_if_nco_tx[0],low_if_nco_tx[1],low_if_nco_fb[0],low_if_nco_fb[1]);
	#configureLowIf

####################################################################################
	def do_start_dsa_calibration(self,type,ch,dsa_start,dsa_stop,cal,fb_conn):
		self.start_dsa_calibration(type,ch,dsa_start,dsa_stop,cal,fb_conn)
		return(self.execute_macro(7, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_start_dsa_calibration
	
####################################################################################
	def do_start_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en,get_macro_error_extended_code=0):
		self.start_vga_calibration(dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en)
		return(self.execute_macro(13, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL,get_macro_error_extended_code))
	# do_start_vga_calibration
	
####################################################################################
	def do_continue_dsa_calibration(self,type,ch,start_index,stop_index,toneABCD,tranABCD,refTrack,freqdepd=0,loopback=0,tonescale = 15):
		self.continue_dsa_calibration(type,ch,start_index,stop_index,toneABCD,tranABCD,refTrack,freqdepd,loopback,tonescale)
		if(type=="txdsa"):
			return(self.execute_macro(10, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
		elif(type=="rxdsa"):
			return(self.execute_macro(9, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_continue_dsa_calibration
	
####################################################################################
	def do_continue_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en,dsa_stop,f_depend_cal_en,ext_loopback_en,\
		dsa_nd_vga_cal,dsa_idx_for_vga_cal,vga_idx_for_dsa_cal,tone_id,FW_VERSION,get_macro_error_extended_code=0):
		self.continue_vga_calibration(dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en,dsa_stop,f_depend_cal_en,ext_loopback_en, \
		dsa_nd_vga_cal,dsa_idx_for_vga_cal,vga_idx_for_dsa_cal,tone_id,FW_VERSION)
		return(self.execute_macro(18, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL,get_macro_error_extended_code))
	# do_continue_dsa_calibration
	
####################################################################################
	def do_completed_dsa_calibration(self,type):
		self.completed_dsa_calibration(type)
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL))
	# do_completed_dsa_calibration
	
####################################################################################
	def do_completed_vga_calibration(self,dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en,get_macro_error_extended_code=0):
		self.completed_vga_calibration(dsa_start,vga_start,vga_stop,vga_to_cal,not_vga_or_lna,\
		internal_loopback_en,tone_chain,tone_scale,ref_tracking_en)
		return(self.execute_macro(12, MACROConst.MACRO_OPCODE_FACTORY_CALIB_CONTROL,get_macro_error_extended_code))
	# do_completed_dsa_calibration
	
####################################################################################
	def do_apply_dsa_packet(self,type,txa,txb,txc,txd):
		self.apply_dsa_packet(type,txa,txb,txc,txd)
		return(self.execute_macro(5, MACROConst.MACRO_OPCODE_SET_FACTORY_CALIB_DATA))
	# do_apply_dsa_packet
	
	
	@funcDecorator
	def loadTopPatch(self):
		self.deviceRefs.device.hardReadAlways=True
		wrDataList=MACROConst.topPatch
		reversed_arr = wrDataList[::-1]
		Number_of_memory_blocks_to_write=2
		size_of_fw=Number_of_memory_blocks_to_write*32768+1
		for i in range (0,len(reversed_arr)):
			if (reversed_arr[i]!=0):
				size_of_fw=len(reversed_arr)-i
				break;
		size_count=0
		for i in range(0,1+int(size_of_fw/4096.0)):
			self.memWrite('macroMem', 32, 0);
			CHUNK_NUMBER=i
			self.burstWrite(0x20,wrDataList[4096*CHUNK_NUMBER:4096*CHUNK_NUMBER+2048]);
			size_count=size_count+2048
			delay(0.5)
			#self.burstRead(rdDataList,2048);
			#self.delay(0.5)
			if (size_count<size_of_fw):
				self.burstWrite(0x20+2048,wrDataList[4096*CHUNK_NUMBER+2048:4096*CHUNK_NUMBER+4096]);
				size_count=size_count+2048
				self.delay(0.5)
			
			delay(0.05)
			
			self.patch_top_fw_download(0x0,0x81,4096*i);
		##############################################################
		delay(0.05)
		self.patch_top_fw_apply(1,0,0x81);
		self.deviceRefs.device.hardReadAlways=False
	#loadTopPatch
	
	@funcDecorator
	def freezeTxIqmcEstim(self,freeze=True):
		if freeze:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0xff13
		else:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0xff14
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = 0x35000000
		self.wait_for_macro_done()
	#freezeTxIqmcEstim
	
	@funcDecorator
	def freezeTxLoEstim(self,freeze=True):
		if freeze:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0xff15
		else:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0xff16
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = 0x35000000
		self.wait_for_macro_done()
	#freezeTxLoEstim
	
	@funcDecorator
	def resetTxIqmcLo(self):
		self.memWrite32("macroMem",0,0x2001138A)
		self.memWrite32("macroMem",4,0x01010101)
		self.memWrite32("macroMem",8,0x2)
		
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0x000A0610
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = 0x35000000
		self.wait_for_macro_done()
	#resetTxIqmcLo
	
	@funcDecorator
	def txDsaGainSmoothConfig(self,mode,delay,max_ana_attn):
		""" Updating the TX DSA update mode"""
		if(mode=="TddToggle"):
			self.byteList[0]= 0x00
		elif(mode=="GainSmooth"):
			self.byteList[0]=0x01		
		self.byteList[1]= delay
		self.byteList[2]= max_ana_attn
		return(self.execute_macro(3, MACROConst.MACRO_OPCODE_TX_DSA_GAIN_SMOOTH_CONFIG))
	# tx_dsa_gain_smooth_config	

	@funcDecorator
	def txDsaGainSmooth(self,gain,ch):
		if(gain<=0):
			val = int(round(-gain * 8))
		else:
			val = int(round(2**16 - gain * 8))
		
		self.byteList[0]=val%256   # 5.3
		self.byteList[1]=val/256
		self.byteList[2]=ch
		return(self.execute_macro(3, MACROConst.MACRO_OPCODE_TX_DSA_GAIN_SMOOTH))
	# tx_dsa_gain_smooth	

	####################################################################################
	@funcDecorator
	def fbDsaSwitchConfig(self,enable):
		self.byteList[0]= enable
		return(self.execute_macro(1, MACROConst.MACRO_OPCODE_FB_DSA_SWITCH_CONFIG))
	# fb_dsa_switch_config	

	####################################################################################
	@funcDecorator
	def fbDsaGainConfig(self,dsa,ch):
		self.byteList[0]=dsa
		self.byteList[1]=ch
		return(self.execute_macro(2, MACROConst.MACRO_OPCODE_FB_DSA_GAIN_SMOOTH))
	# fb_dsa_gain_config		
	
	@funcDecorator
	def txIqmcLolHostUpdateMode(self,enable):
		self.wait_for_macro_ready()
		if enable==True:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0xff11
			self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=0x35000000
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_RD.spi_wr0=0xff
		else:
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0x0011
			self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=0x35000000
		self.wait_for_macro_ack();
		self.wait_for_macro_done();	
	#enableTxIqmcHostUpdateMode
	
	@funcDecorator
	def giveTxIqmcLolUpdateTrigger(self):
		self.wait_for_macro_ready()
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0x000C
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=0x35000000
		self.wait_for_macro_ack();
		self.wait_for_macro_done();
	#giveTxIqmcLolUpdateTrigger
	
	@funcDecorator
	def readTxIqmcLo(self,addr=0x20000000,num_bytes=1):
		self.byteList[0]=0x10
		self.byteList[1]=num_bytes
		self.byteList[2]=0x04
		self.byteList[3]=0x00
		self.memWrite32("macroMem",0,addr)
		return(self.execute_macro(3, MACROConst.MACRO_OPCODE_TX_FW_RELAY))
	# readTxIqmcLo	
	
	
#CalibTop