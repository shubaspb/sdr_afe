from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *
import random
import math
import cmath
import mCalibTopConst
reload(mCalibTopConst)
from mCalibTopConst import *
class CalibTopHw(projectBaseClass):
	"""Contains Calib Top Control HW specific functions self.regs=device.TOP"""
	@initDecorator
	def __init__(self,regs):
		self.regs=regs
		self.errorList=['','']
	#__init__

	@funcDecorator
	def txCaptureInRxMem(self,enable):
		"""capture tx data in the rx memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22019_0_0 = enable;
	#txCaptureInRxMem
	
	@funcDecorator
	def txCaptureInFbMem(self,enable):
		"""capture tx data in the fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22020_1_1 = enable;
	#txCaptureInFbMem
	
	@funcDecorator
	def spiAccessEn(self,enable):
		"""enable SPI access to calib memories"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.MISC_MODES.spi_access_en = enable;
	#spiAccessEn
	
	@funcDecorator
	def clearFftStat(self):
		"""clear all fft statistics"""
		errCnt = 0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property22044_24_24 = 0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property22044_24_24 = 1;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property22044_24_24 = 0;
		
		first_max_i = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22007_23_0.getValue();
		if(first_max_i != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected first_max_i: 0");
			info("read first_max_i: "+str(first_max_i));
		
		first_max_q = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22008_23_0.getValue();
		if(first_max_q != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected first_max_q: 0");
			info("read first_max_q: "+str(first_max_q));
			
		first_max_index = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22009_9_0.getValue();
		if(first_max_index != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected first_max_index: 0");
			info("read first_max_index: "+str(first_max_index));
			
		second_max_i = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22010_23_0.getValue();
		if(second_max_i != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected second_max_i: 0");
			info("read second_max_i: "+str(second_max_i));
			
		second_max_q = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22011_23_0.getValue();
		if(second_max_q != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected second_max_q: 0");
			info("read second_max_q: "+str(second_max_q));
			
		second_max_index = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22012_9_0.getValue();
		if(second_max_index != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected second_max_index: 0");
			info("read second_max_index: "+str(second_max_index));
			
		fft_sum_out = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22013_31_0.getValue();
		if(fft_sum_out != 0):
			errCnt = errCnt+1;
			error("clear fft statistics not working");
			info("expected fft_sum_out: 0");
			info("read fft_sum_out: "+str(fft_sum_out));
		return(errCnt);
	#clearFftStat
		
	
	@funcDecorator
	def clearFlags(self):
		"""Clear call the status flags"""
		errCnt=0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21938_8_8 = 	0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21938_8_8 = 	1;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21938_8_8 = 	0;
		
		capture_done_rxAB = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch._Property22041_0_0.getValue();
		if(capture_done_rxAB != 0):
			errCnt = errCnt+1;
			error("clear flags not working");
			info("expected capture_done_rxAB: 0");
			info("read capture_done_rxAB: "+str(capture_done_rxAB));
			
		capture_done_rxCD = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch._Property22046_1_1.getValue();
		if(capture_done_rxCD != 0):
			errCnt = errCnt+1;
			error("clear flags not working");
			info("expected capture_done_rxCD: 0");
			info("read capture_done_rxCD: "+str(capture_done_rxCD));
			
		capture_done_fbAB = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch._Property22047_2_2.getValue();
		if(capture_done_fbAB != 0):
			errCnt = errCnt+1;	
			error("clear flags not working");
			info("expected capture_done_fbAB: 0");
			info("read capture_done_fbAB: "+str(capture_done_fbAB));
			
		capture_done_fbCD = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch._Property22048_3_3.getValue();
		if(capture_done_fbCD != 0):
			errCnt = errCnt+1;
			error("clear flags not working");
			info("expected capture_done_fbCD: 0");
			info("read capture_done_fbCD: "+str(capture_done_fbCD));
			
		fft_read_done_rx = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22045_15_15.getValue();
		if(fft_read_done_rx != 0):
			errCnt = errCnt+1;
			error("clear flags not working");
			info("expected fft_read_done_rx: 0");
			info("read fft_read_done_rx: "+str(fft_read_done_rx));
			
		fft_read_done_fb = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22050_17_17.getValue();
		if(fft_read_done_fb != 0):
			errCnt = errCnt+1;
			error("clear flags not working");
			info("expected fft_read_done_fb: 0");
			info("read fft_read_done_fb: "+str(fft_read_done_fb));
			
		fft_done = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22051_19_19.getValue();
		if(fft_done != 0):
			errCnt = errCnt+1;
			error("clear flags not working");
			info("expected fft_done: 0");
			info("read fft_done: "+str(fft_done));
		return(errCnt);
	#clearFlags
	
	@funcDecorator
	def setCaptureModeRx(self,captureModeRx):
		"""capture Mode for the Rx memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21977_13_10 = 	captureModeRx;
		if(captureModeRx==0 or captureModeRx==1):
			self.regs.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22021_2_2 = 1;
	#setCaptureModeRx
	
	@funcDecorator
	def setCaptureModeFb(self,captureModeFb):
		"""capture Mode for the Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property22034_22_19 = 	captureModeFb;
		if(captureModeFb==0 or captureModeFb==1):
			self.regs.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22022_3_3 = 1;
	#setCaptureModeFb
	
	@funcDecorator
	def captureOrFftRx(self,captureOrFft):
		"""Select between Capture and FFT for the Rx memory"""		
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21974_16_16 = 	captureOrFft;	
	#captureOrFftRx
	
	@funcDecorator
	def captureOrFftFb(self,captureOrFft):
		"""Select between Capture and FFT for the Fb memory"""		
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property22033_24_24 = 	captureOrFft;	
	#captureOrFftFb
	
	@funcDecorator
	def captureTrigger(self):
		"""Trigger new Capture for both RX and FB Memories"""
		capture = 0;
		self.captureOrFftRx(capture);
		self.captureOrFftFb(capture);
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21930_0_0 = 	0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21930_0_0 = 	1;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21930_0_0 = 	0;		
	#captureTrigger
	
	@funcDecorator
	def setFftMode(self,fftMode):
		"""Fft Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21989_9_8 = 	fftMode;
	#setFftMode
	
	@funcDecorator
	def setSyncMode(self,syncMode):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21932_0_0 = 	syncMode;
	#setSyncMode
	
	@funcDecorator
	def configSyncSel(self,configSync):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21933_3_0 = 	configSync;
	#configSyncSel
	
	@funcDecorator
	def syncConfigSel(self,syncConfig):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21934_9_8 = 	syncConfig;
	#syncConfigSel
	
	@funcDecorator
	def setStatMode(self,statMode):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21937_0_0 = 	statMode;
	#setStatMode
	
	@funcDecorator
	def setAccessMode(self,accessMode):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21975_5_4 = 	accessMode;
	#setAccessMode
	
	@funcDecorator
	def configRandom(self,randomConf):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21976_1_0 = 	randomConf;
	#configRandomMode
	
	@funcDecorator
	def chConfig(self,rxOrFb,config):
		"""sync Mode for the Rx/Fb memory"""
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.channel_config_"+str(rxOrFb)+" = config");
	#chConfig
	
	@funcDecorator
	def chCountMaxConfig(self,rxOrFb,ch,countMax):
		"""sync Mode for the Rx/Fb memory"""
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.channel"+str(ch)+"_count_max_"+str(rxOrFb)+" = countMax");
	#chCountMaxConfig
	
	@funcDecorator
	def setMemStartBurstAddr(self,rxOrFb,ch,memStartBurstAddr):
		"""sync Mode for the Rx/Fb memory"""
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.mem_start_burst_chx"+str(ch)+"_"+str(rxOrFb)+" = memStartBurstAddr");
	#setMemStartBurstAddr
	
	@funcDecorator
	def setBurstDepth(self,rxOrFb,burstDepth):
		"""sync Mode for the Rx/Fb memory"""
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.mem_depth_burst_"+str(rxOrFb)+" = burstDepth");
	#setBurstDepth
	
	@funcDecorator
	def setBurstLen(self,burstLen):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.mem_num_burst = burstLen;
	#setBurstLen
	
	@funcDecorator
	def setPreAvgCnt(self,preAvgCnt):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.pre_average_cnt = preAvgCnt;
	#setPreAvgCnt
	
	@funcDecorator
	def dsaSelRx(self,rx):
		"""sync Mode for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21987_27_26 = rx;
	#dsaSelRx
	
	@funcDecorator
	def pollCaptureDone(self,rxOrFb,abOrCd):
		"""Polling for Capture done from the HW"""
		exec("capDone = self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4._capture_done_"+str(rxOrFb)+""+str(abOrCd)+".getValue()");
		cnt=0;
		errCnt=0;
		while(capDone!=1 | cnt<10):
			exec("capDone = self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4._capture_done_"+str(rxOrFb)+""+str(abOrCd)+".getValue()");
			cnt=cnt+1;
		if(cnt>=10):
			errCnt = errCnt+1;
			error("capture done for "+str(rxOrFb)+""+str(abOrCd)+" is not set");
		return(errCnt);
	#pollCaptureDone
	
	@funcDecorator
	def pollFftReadDoneRxMem(self):
		"""Polling for fft read done from the RX Mem"""
		fftReadDoneRx = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22045_15_15.getValue();
		cnt=0;
		errCnt=0;
		while(fftReadDoneRx!=1 | cnt<10):
			fftReadDoneRx = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22045_15_15.getValue();
			cnt=cnt+1;
		if(cnt>=10):
			errCnt = errCnt+1;
			error("fft read done rx is not set");
		return(errCnt);
	#pollFftReadDoneRxMem
	
	@funcDecorator
	def pollFftReadDoneFbMem(self):
		"""Polling for fft read done from the FB Mem"""
		fftReadDoneFb = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22050_17_17.getValue();
		cnt=0;
		errCnt=0;
		while(fftReadDoneFb!=1 | cnt<10):
			fftReadDoneFb = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22050_17_17.getValue();
			cnt=cnt+1;
		if(cnt>=10):
			errCnt = errCnt+1;
			error("fft read done fb is not set");
		return(errCnt);
	#pollFftReadDoneFbMem
	
	@funcDecorator
	def pollFftDone(self):
		"""Polling for fft done from the HW"""
		fftDone = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22051_19_19.getValue();
		cnt=0;
		errCnt=0;
		while(fftDone!=1 | cnt<10):
			fftDone = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22051_19_19.getValue();
			cnt=cnt+1;
		if(cnt>=10):
			errCnt = errCnt+1;
			error("fft done is not set");
		return(errCnt);
	#pollFftDone
	
	@funcDecorator
	def allFft(self,set):
		"""All Fft for the Rx/Fb memory"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property22014_16_16 = 	set;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21956_8_8 =  set;
	#allFft
	
	@funcDecorator
	def fftTriggerRxMem(self):
		"""Trigger new fft for RX Memory"""
		fft = 1;
		self.captureOrFftRx(fft);
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21997_24_24 = 	1;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21993_16_16 	= 	0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21993_16_16 	= 	1;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21993_16_16 	= 	0;		
	#fftTriggerRxMem
	
	@funcDecorator
	def fftTriggerFbMem(self):
		"""Trigger new fft for FB Memory"""
		fft = 1;
		self.captureOrFftFb(fft);
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21997_24_24 = 	0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21993_16_16 = 	0;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21993_16_16 = 	1;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21993_16_16 = 	0;		
	#fftTriggerFbMem
	
	@funcDecorator
	def readFftPower(self):
		"""returns the fft power"""
		fftPower = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_power.getValue();
		return(fftPower);
	#readFftPower
	
	@funcDecorator
	def fftPowerExcludeConfig(self, index, startBin, endBin):
		"""exclude range for the fft power"""
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL.fft_power_exclude_start_"+str(index)+" =  "+str(startBin));
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL.fft_power_exclude_end_"+str(index)+" =  "+str(endBin));
	#FftPowerExcludeConfig
	
	@funcDecorator
	def fftResultBinConfig(self, index, bin):
		"""bin index for the fft results"""
		exec("self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL.fft_result_index_"+str(index)+" =  "+str(bin));
	#FftResultBinConfig
	
	@funcDecorator
	def ddcOrRawCapture(self,ddcOrRaw):
		"""Select between DDC or Raw Capture for the Rx/Fb memory"""		
		self.regs.INTERNAL_MACRO.CALIB_TOP.CTRL_CM4.ddc_or_raw = 	ddcOrRaw;	
	#ddcOrRawCapture
	
	@funcDecorator
	def setFftSize(self,fftSize):
		"""Select between DDC or Raw Capture for the Rx/Fb memory"""		
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21963_3_0 = 	fftSize;	
	#setFftSize	
	
	@funcDecorator
	def setFftBlockLen(self,fftBlockLen):
		"""Select between DDC or Raw Capture for the Rx/Fb memory"""		
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21992_11_8 = 	fftBlockLen;	
	#setFftBlockLen
	
	@funcDecorator
	def readFftResults(self,bin):
		"""read the fft results"""	
		errCnt=0;
		first_max_i = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22007_23_0.getValue();
		info("first_max_i is: "+str(first_max_i));
		
		first_max_q = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22008_23_0.getValue();
		info("first_max_q is: "+str(first_max_q));
		
		first_max_index = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22009_9_0.getValue();
		info("first_max_index is: "+str(first_max_index));
		if(first_max_index!=bin):
			if(first_max_index!=(1024-bin)):
				errCnt += 1;
				error("bin index not matching");
				info("bin calculated: "+str(first_max_index));
				info("Bin Expected: "+str(bin));
		
		second_max_i = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22010_23_0.getValue();
		info("second_max_i is: "+str(second_max_i));
		
		second_max_q = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22011_23_0.getValue();
		info("second_max_q is: "+str(second_max_q));
		
		second_max_index = self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch._Property22012_9_0.getValue();
		info("second_max_index is: "+str(second_max_index));
		
		if(first_max_i>=2**23):
			first_max_i = first_max_i - 2**24;
		if(first_max_q>=2**23):
			first_max_q = first_max_q - 2**24;
		gain = abs(complex(first_max_i, first_max_q));
		gainRef = abs(complex(2**23, 0));
		if(gain>0):
			gainDb = 20*cmath.log10(gain/gainRef);
		else:
			gainDb = -200;
		fMaxCom = first_max_i+1j*first_max_q;
		npPhase = np.angle(fMaxCom)*180/cmath.pi;
		phase = np.arctan2(first_max_q,first_max_i);
		
		info( "gain is: "+str(gain));
		info( "gainDb is: "+str(gainDb));
		info( "phase is: "+str(phase)+" radians");
		info( "npPhase is: "+str(npPhase)+" degrees");
		return(errCnt, npPhase)
	#readFftResults
	
	@funcDecorator
	def fftPostAvg(self, set):
		"""fft config to select the ch for doing fft"""	
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21955_0_0 = set;	
	#fftConfig
	
	@funcDecorator
	def fftLoadZeroes(self, set):
		"""fft config to select the ch for doing fft"""	
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21961_6_6 = set;	
	#fftLoadZeroes
	
	@funcDecorator
	def readFftResultsAllFft(self, rxOrFb, ch, bin):
		"""read the fft results when allFft is done"""	
		errCnt=0;
		exec("first_max_i = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_"+str(rxOrFb)+"_"+str(ch)+"_max_i.getValue()");
		info("fft_"+str(rxOrFb)+"_"+str(ch)+"_first_max_i is: "+str(first_max_i));
		exec("first_max_q = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_"+str(rxOrFb)+"_"+str(ch)+"_max_q.getValue()");
		info("fft_"+str(rxOrFb)+"_"+str(ch)+"_first_max_q is: "+str(first_max_q));
		exec("first_max_index = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_"+str(rxOrFb)+"_"+str(ch)+"_max_index.getValue()");
		if(first_max_index!=bin):
			errCnt += 1;
			error("bin index not matching");
			info("bin calculated: "+str(first_max_index));
			info("Bin Expected: "+str(bin));
		info("fft_"+str(rxOrFb)+"_"+str(ch)+"_first_max_index is: "+str(first_max_index));
		exec("second_max_i = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_"+str(rxOrFb)+"_"+str(ch)+"_smax_i.getValue()");
		info("fft_"+str(rxOrFb)+"_"+str(ch)+"_second_max_i is: "+str(second_max_i));
		exec("second_max_q = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_"+str(rxOrFb)+"_"+str(ch)+"_smax_q.getValue()");
		info("fft_"+str(rxOrFb)+"_"+str(ch)+"_second_max_q is: "+str(second_max_q));
		exec("second_max_index = self.regs.INTERNAL_MACRO.CALIB_TOP.FFT_CTRL._fft_"+str(rxOrFb)+"_"+str(ch)+"_smax_index.getValue()");
		info("fft_"+str(rxOrFb)+"_"+str(ch)+"_second_max_index is: "+str(second_max_index));
		return(errCnt)
	#readFftResultsAllFft
	
	@funcDecorator
	def fftConfig(self, config):
		"""fft config to select the ch for doing fft"""	
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21972_15_0 = config;	
	#fftConfig	
		
	@funcDecorator
	def calibTopSettings(self):
		"""calibTopSettings"""
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21962_16_16 					=	1; 
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21964_9_0 				= 	0x3ff; # Some IP config
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property21973_31_16 			=	0x7FFF;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21930_8Ch.Property22006_31_16 			=	0x7FFF;
		self.regs.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21970_6_6 		= 	1;
	#calibTopSettings
	
#CalibTopHw