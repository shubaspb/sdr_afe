from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mAfeConstants import jesdConstants

import math 

import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *

import mClkAB
reload(mClkAB)
from mClkAB import clkABLib

import mClkCD
reload(mClkCD)
from mClkCD import clkCDLib

import mTimingControl
reload(mTimingControl)
from mTimingControl import timingControlLib

import mPll
reload(mPll)
from mPll import pllLib

import mTopAnaControl
reload(mTopAnaControl)
from mTopAnaControl import topAnaControlLib

import common.mMACROConst
reload(common.mMACROConst)
from common.mMACROConst import MACROConst

import mGpio
reload(mGpio)
from mGpio import gpioLib

import mDsaController
reload(mDsaController)
from mDsaController import dsaController

import calibTop.mCalibTop
reload(calibTop.mCalibTop)
from calibTop.mCalibTop import CalibTop

import datetime
import os
import errno


class topLib(projectBaseClass):
	"""Contains TOP specific functions. self.regs=device.TOP """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.CLKAB=clkABLib(0,regs.CLK_AB,deviceRefs)
		self.CLKCD=clkCDLib(1,regs.CLK_CD,deviceRefs)
		self.TIMINGCTRL=timingControlLib(regs.TIMING_CTRL,deviceRefs)
		self.PLL=[]
		self.DSA=[]
		for i in xrange(2):
			self.DSA.append(dsaController(i,regs.DSA_CNTRL[i],deviceRefs))
		for i in xrange(5):
			self.PLL.append(pllLib(i,regs.PLL[i].pll1,deviceRefs))
		self.TOPANA=topAnaControlLib(regs.TOP_ANA_CTRL.TOP_ANA_CTRL,deviceRefs)
		self.GPIO=gpioLib(regs.TC_GPIO,deviceRefs)
		
		self.SYSCALIB=CalibTop(regs,deviceRefs)
		
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
		self.broadcastSysref=False
		self.continuousPinSysref=False
		

	#__init__

	
	@funcDecorator	
	def enableSigGen(self,en=True):
		""" "Enabling internal SigGen for calibration" "Done enabling internal SigGen for calibration" """
		# Siggen Initialization - To be done before Sysref
		self.regs.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22208_28_28 = en
		self.regs.INTERNAL_MACRO.STREAMING.Register22210_13Fh.Property22210_30_30 = en
		self.regs.INTERNAL_MACRO.STREAMING.Register22210_13Fh.Property22211_29_29 = en
	#enableSigGen
	
	@funcDecorator
	def enableJtagAccessTop(self):
		################################################################################
		# Do async reset of full setup
		#fpga_pin_reset(testSettings_inst.setup_id);
		#TOP.topReset(rxIqmcTopSimSettings)
		##Remove the topCm4 reset
		self.SYSCALIB.reset(1)
		self.SYSCALIB.reset(0)
		##2. Check topCm4 alone
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0 = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_txiqmc = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_rxiqmc = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_top = 1;
		self.regs.MACRO.FW_REGS.CM4_CONTROL.spi_sel=0;
		self.regs.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel=1
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_ram_sel=1
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41728_1_0=1
		self.regs.MACRO.SYS_CONTROL.PATCH_CONTROL.patch_enable_txiqmc=1
		self.SYSCALIB.reset(1)
		self.SYSCALIB.reset(0)
	#enableJtagAccessTop
	
	@funcDecorator
	def enableJtagAccessTx(self):
			##Remove the txCm4 reset
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0 = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0 = 1;

		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_inclk_gate_en=0
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_outclk_gate_en=0
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_reset=0

		##2. Check txCm4 alone
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_txiqmc = 1;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_rxiqmc = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_top = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_ram_sel=1
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41728_1_0=0
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0 = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0 = 1;
	#enableJtagAccessTx
	
	@funcDecorator
	def enableJtagAccessRx(self):
		##Remove the rxCm4 reset
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z = 1;
		##extra settings for p85
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_inclk_en=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_outclk_en=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_reset=0

		##2. Check rxCm4 alone
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_txiqmc = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_rxiqmc = 1;
		self.regs.TC_GPIO.digtop.Register41632_600h.spi_ctrl_jtag_only_top = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_ram_sel=1;
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_spi_sel=0;
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z = 0;
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z = 1;
	#enableJtagAccessRx
	
	@funcDecorator
	def remove_reset_rxiqmc(self):
		"""remove_reset_rxiqmc"""
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z=1
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z=1
	#remove_reset_rxiqmc
	
	@funcDecorator
	def requestPllSpiAccess(self,en=1):
		""" "Requesting/releasing SPI Access to PLL Pages" "Done requesting/releasing SPI Access to PLL Pages" """
		
		if(en == 1):
			
			self.regs.TC_GPIO.digtop.Register41632_600h.pll_reg_spi_req_a=1
			self.regs.TC_GPIO.digtop.Register41632_600h.pll_reg_spi_req_b1=0
			count=0
			self.deviceRefs.device.printCommentToLog("SPIPoll 01d5,0,0,1")#("Poll for the bit 0 of the below read value to become 1.")
			if self.systemParams.simulationMode==False:
				while ((not self.regs.TC_GPIO.digtop.Register41632_600h._pll_reg_spi_a_ack.getValue()) and count<10): 
					
					count+=1
					self.delay(0.01)
				if(count == 10):
					error("SPIA has got control of PLL pages")
				else:		
					info("SPIA has got control of PLL pages")	
			else:
				self.regs.TC_GPIO.digtop.Register41632_600h._pll_reg_spi_a_ack.getValue()
		elif(en == 2)	:
			self.regs.TC_GPIO.digtop.Register41632_600h.pll_reg_spi_req_a=0
			self.regs.TC_GPIO.digtop.Register41632_600h.pll_reg_spi_req_b1=1
			count=0
			self.deviceRefs.device.printCommentToLog("SPIPoll 0375,0,0,1")#("Poll for the bit 0 of the below read value to become 1.")
			if self.systemParams.simulationMode==False:
				while ((not self.regs.TC_GPIO.digtop.Register41632_600h._pll_reg_spi_b1_ack.getValue()) and count<10): 
					count+=1
					self.delay(0.01)
				if(count == 10):
					error("SPIB has NOT got control of PLL pages")
				else:		
					info("SPIB has got control of PLL pages")
			else:
				self.regs.TC_GPIO.digtop.Register41632_600h._pll_reg_spi_b1_ack.getValue()
		else:	
			self.regs.TC_GPIO.digtop.Register41632_600h.pll_reg_spi_req_a=0
			self.regs.TC_GPIO.digtop.Register41632_600h.pll_reg_spi_req_b1=0
			self.delay(0.01)
			info("PLL Pages SPI control relinquished.")
	#requestPllSpiAccess

	
	@funcDecorator
	def leakSysrefRxTxDig(self,Rx=1,Tx=1,Dig=1):
		""" "Leaking sysref from internal sysref counter" "Done leaking sysref from internal sysref counter" """
		self.requestPllSpiAccess(1)
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44412_3_0=0x0
		if Rx==1:
			self.regs.PLL[1].pll1.pll1.bypass_leak_sysref_rx=1
		if Tx==1:
			self.regs.PLL[1].pll1.pll1.bypass_leak_sysref_tx=1
		if Dig==1:
			self.regs.PLL[1].pll1.pll1.bypass_leak_sysref_dig=1
		self.delay(0.1)
		self.regs.PLL[1].pll1.pll1.bypass_leak_sysref_rx=0
		self.regs.PLL[1].pll1.pll1.bypass_leak_sysref_tx=0
		self.regs.PLL[1].pll1.pll1.bypass_leak_sysref_dig=0
		self.requestPllSpiAccess(0)
	#leakSysrefRxTxDig
	
	@funcDecorator
	def disableOverrideTdd(self):
		""" "Disabling TDD overrides" "Done disabling TDD overrides" """
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44708_0_0=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44709_16_16=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44710_0_0=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44711_16_16=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44712_0_0=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44713_16_16=0
	#disableOverrideTdd
	
	@funcDecorator
	def overrideTdd(self,rx,fb,tx):
		""" "Overriding TDD Pins internally" "Done overriding TDD Pins internally" """
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44708_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44709_16_16=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44710_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44711_16_16=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44712_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44713_16_16=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44714_8_8=tx
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44715_24_24=rx
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44716_8_8=fb
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44717_24_24=tx
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44718_8_8=rx
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44719_24_24=fb
	#overrideTdd
	
	@funcDecorator
	def staggeredTddToggle(self):
		""" "Staggered TDD Toggle" "Done Staggered TDD Toggle" """
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44708_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44709_16_16=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44710_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44711_16_16=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44712_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44713_16_16=1
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44715_24_24=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44718_8_8=0
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44715_24_24=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44718_8_8=1
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44715_24_24=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44718_8_8=0
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44714_8_8=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44717_24_24=0
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44716_8_8=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44719_24_24=0
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44714_8_8=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44717_24_24=1
		
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44716_8_8=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44719_24_24=1
		
	#overrideTdd
	
	@funcDecorator
	def getTddStatus(self):
		self.deviceRefs.device.currentPageSelected.setValue(0)
		logTemp=self.deviceRefs.device.rawWriteLogEn
		self.deviceRefs.device.rawWriteLogEn=0
		tddStatus=[]
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44708_0_0.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44709_16_16.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44710_0_0.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44711_16_16.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44712_0_0.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44713_16_16.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44714_8_8.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44715_24_24.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44716_8_8.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44717_24_24.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44718_8_8.getValue())
		tddStatus.append(self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h._Property44719_24_24.getValue())
		self.deviceRefs.device.currentPageSelected.setValue(0)
		self.deviceRefs.device.rawWriteLogEn=logTemp
		return tddStatus
	#getTddStatus

	@funcDecorator
	def setTddStatus(self,tddStatus):
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44708_0_0=tddStatus[0]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44709_16_16=tddStatus[1]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44710_0_0=tddStatus[2]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44711_16_16=tddStatus[3]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44712_0_0=tddStatus[4]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44713_16_16=tddStatus[5]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44714_8_8=tddStatus[6]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44715_24_24=tddStatus[7]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44716_8_8=tddStatus[8]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44717_24_24=tddStatus[9]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44718_8_8=tddStatus[10]
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44719_24_24=tddStatus[11]
	#setTddStatus
	
	@funcDecorator
	def tddConfig(self):
		""" "Doing Internal TDD settings" "Completed Internal TDD settings"" """
		self.TIMINGCTRL.timingCntrlTddConfig()
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2172_5Ch.Property2175_4_4 = 1
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2172_5Ch.Property2176_3_3 = 1
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2172_5Ch.Property2177_2_2 = 1
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2172_5Ch.Property2178_1_1 = 1
	#tddConfig
	
	@funcDecorator
	def powerDownConfigFb(self,en=0):
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_1f_fbab_spare_0.PDN_GBL_FBAB=(en>>0)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_1f_fbcd_spare_0.PDN_GBL_FBCD=(en>>1)&1
	#powerDownConfigFb
	
	@funcDecorator
	def powerDownConfigRx(self,en=0):
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2r_rxab_spare_0.PDN_GBL_RXA=(en>>0)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2r_rxab_spare_0.PDN_GBL_RXB=(en>>1)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2r_rxcd_spare_0.PDN_GBL_RXC=(en>>2)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2r_rxcd_spare_0.PDN_GBL_RXD=(en>>3)&1
	#powerDownConfigRx
	
	@funcDecorator
	def powerDownConfigTx(self,en=0):
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2t_txab_spare_0.PDN_GBL_TXA=(en>>0)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2t_txab_spare_0.PDN_GBL_TXB=(en>>1)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2t_txcd_spare_0.PDN_GBL_TXC=(en>>2)&1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_2t_txcd_spare_0.PDN_GBL_TXD=(en>>3)&1
	#powerDownConfigTx
	
	@funcDecorator
	def gateRefClkToDig(self,en=1):
		self.regs.TC_GPIO.digtop.CLOCK_GATING.gate_refclk_for_dig=en
	#gateRefClkToDig
		
	def top_txCM4ClkEn_ROM(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_outclk_gate_en=1
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_reset=1
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_dither_mode_en=1
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41718_1_0=2
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_reset=0
		self.regs.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_divider_outclk_gate_en=0
	#top_txCM4ClkEn_ROM	
		
	def top_rxCM4ClkEn_ROM(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_outclk_en=1
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_reset=1
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_dither_mode_en=1
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41723_1_0=2
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_reset=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_outclk_en=0
	#top_rxCM4ClkEn_ROM
	
################################################################################
	
	def top_txCM4Reset_ROM(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0=0
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0=1
	#top_txCM4Reset_ROM
	
################################################################################
		
	def top_rxCM4Reset_ROM(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z=1
	#top_rxCM4Reset_ROM
	
	@funcDecorator
	def sendSysref(self,spiSysref):
		""" "Sending Sysref to device from Pin/SPI" "Done sending Sysref to device from Pin/SPI" """
		#self.sendSysrefSpi(spiSysref)
		#return
		#if spiSysref==1:
		#	self.sendSysrefSpi(1)
		#	return
		#if self.systemParams.useMacros==True:
		self.requestPllSpiAccess(1)
		##Sysref Sequence Start
		for TRIM_100N_INT_TXCMLLDOVREF1 in range(1):
			if spiSysref==1 and TRIM_100N_INT_TXCMLLDOVREF1==1:
				continue
			# checkLoSysref(1)
			#Lowering LDO voltage(3: lowest, 4: highest) Sets LDO to 975mV by def
			#self.regs.CLK_AB.ctl_2t_clktop_config.Register2195_5Fh.Property2196_30_28=3  
			#self.regs.CLK_AB.ctl_2t_clktop_config.Register2181_5Dh.Property2182_14_12=3
			
			#Lowering LDO with a coarse step of 100mV
			self.regs.CLK_AB.ctl_2t_clktop_refsys_config.Register2075_2Ch.Property2075_7_5=TRIM_100N_INT_TXCMLLDOVREF1
			self.delay(0.001)
			
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44708_0_0=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44709_16_16=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44710_0_0=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44711_16_16=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44712_0_0=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44713_16_16=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44714_8_8=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44715_24_24=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44716_8_8=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44717_24_24=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44718_8_8=1
			#self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44719_24_24=1
			
			self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44386_15_0=self.systemParams.sysrefFreqDiv-1#sysrefDiv#191
			self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x0
			self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x101
			self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x0
			pll_no=1
			
			for pll_no in range(5):
				self.regs.PLL[pll_no].pll1.pll1.lcmgen_sync_ena=0
				self.regs.PLL[pll_no].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=1
				self.regs.PLL[pll_no].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=1
				if spiSysref==1:
					self.regs.PLL[1].pll1.pll1.lcmgen_usespisysref=1
				else:
					self.regs.PLL[1].pll1.pll1.lcmgen_usespisysref=0	
					
				self.regs.PLL[pll_no].pll1.pll1.lcmgen_div=self.systemParams.sysrefFreqDiv-1#sysrefDiv#192-1
				#device.TOP.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44386_15_0=191
				
				#configuring lcmgen
				self.regs.PLL[pll_no].pll1.pll1.lcmgen_sync_ena=0
				self.regs.PLL[pll_no].pll1.pll1.lcmgen_sync_ena=1
			if spiSysref==0:
				self.deviceRefs.device.printCommentToLog("Give Sysref Here.")
			self.delay(0.001)
			if spiSysref==1:
				for i in range(1):
					self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=0
					self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=1
				self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=0
			### Give Sysref Here
			
			for pll_no in range(5):
				self.regs.PLL[pll_no].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=0
				self.regs.PLL[pll_no].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
		self.regs.CLK_AB.ctl_2t_clktop_refsys_config.Register2075_2Ch.Property2075_7_5=0			
			
		#if self.systemParams.useMacros==True:
		self.requestPllSpiAccess(0)
			
	
	@funcDecorator
	def txIqmcFbLoopbackControl(self,pinControl=0,txFbLpbk=0x0a):
		if(pinControl==0):
			if self.systemParams.txIqMcCalibMode == 2:
				self.regs.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 1
				self.regs.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= txFbLpbk
			else:
				self.regs.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 1
				if (txFbLpbk&0x8)==0x8:
					self.regs.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= 4
				else:
					self.regs.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= txFbLpbk
		else:
			self.regs.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 0

	
	@funcDecorator
	def sendSysrefInternalWorking(self,spiSysref):
		""" "Sending Sysref to device from Pin/SPI" "Done sending Sysref to device from Pin/SPI" """
		#self.sendSysrefSpi(spiSysref)
		#return
		#if spiSysref==1:
		#	self.sendSysrefSpi(1)
		#	return
		#if self.systemParams.useMacros==True:
		#	self.requestPllSpiAccess(1)
		#Lowering LDO voltage(3: lowest, 4: highest) Sets LDO to 975mV by def
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2195_5Fh.Property2196_30_28=3  
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2181_5Dh.Property2182_14_12=3

		#Lowering LDO with a coarse step of 100mV
		self.regs.CLK_AB.ctl_2t_clktop_refsys_config.Register2075_2Ch.Property2075_7_5=1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44386_15_0=self.systemParams.sysrefFreqDiv-1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x101
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x0

		pll_no=1
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=31 #Broadcast
		self.regs.PLL[pll_no].pll1.pll1.lcmgen_sync_ena=0
		self.regs.PLL[pll_no].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=1
		self.regs.PLL[pll_no].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=1
		self.regs.PLL[pll_no].pll1.pll1.lcmgen_div=self.systemParams.sysrefFreqDiv-1
		#self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44386_15_0=191
		#configuring lcmgen
		self.regs.PLL[pll_no].pll1.pll1.lcmgen_sync_ena=0
		self.regs.PLL[pll_no].pll1.pll1.lcmgen_sync_ena=1
		self.delay(0.1)
		self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Give Sysref Here.")
		self.regs.PLL[pll_no].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=0
		self.regs.PLL[pll_no].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0

		#restoring coarse LDO step
		self.regs.CLK_AB.ctl_2t_clktop_refsys_config.Register2075_2Ch.Property2075_7_5=0
		#if self.systemParams.useMacros==True:
		#	self.requestPllSpiAccess(0)
	#sendSysref
	
	@funcDecorator
	def sendSysrefSpi(self,spiSysref=1):
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44386_15_0=self.systemParams.sysrefFreqDiv-1
		##Program internal states of Timing controller ( timing_controller.spare_reg_port(0) and (8)) to 1 and '0' to reset it.
		spare_reg_port_tg = self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h._Property44689_31_0.getValue()
		spare_reg_port_tg_updated = spare_reg_port_tg | 0x101;
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0 = spare_reg_port_tg_updated
		spare_reg_port_tg_updated = spare_reg_port_tg_updated & 0xFFFFFEFE;
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0 = spare_reg_port_tg_updated
		
		#if self.systemParams.useMacros==True:
		self.requestPllSpiAccess(1)

		if self.continuousPinSysref==False:
			self.regs.PLL[1].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			self.regs.PLL[1].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=1
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1d
			self.regs.PLL[0].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			self.regs.PLL[0].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=1

			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1f
			if spiSysref==1:
				self.regs.PLL[1].pll1.pll1.lcmgen_usespisysref=1
			else:
				self.regs.PLL[1].pll1.pll1.lcmgen_usespisysref=0	

			if spiSysref==0:
				self.regs.PLL[1].pll1.pll1.EN_SYNC_DIV=1
				
			self.regs.PLL[1].pll1.pll1.lcmgen_div=self.systemParams.sysrefFreqDiv-1
			self.regs.PLL[1].pll1.pll1.lcmgen_sync_ena=0
			self.regs.PLL[1].pll1.pll1.lcmgen_sync_ena=1
			self.delay(0.1)
			#### Give Sysref Here
			self.deviceRefs.device.printCommentToLog("Give Sysref Here.")
			if spiSysref==1:
				for i in range(1):
					self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=0
					self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=1
				self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=0
			if spiSysref==0:
				self.regs.PLL[1].pll1.pll1.EN_SYNC_DIV=0
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x00
			
			self.regs.PLL[1].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=0
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1d
			self.regs.PLL[0].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=0
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x00
		else:
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x02
			self.regs.PLL[1].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			self.regs.PLL[1].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=1
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1d
			self.regs.PLL[0].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			self.regs.PLL[0].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=1

			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1f
			self.regs.PLL[1].pll1.pll1.lcmgen_div=self.systemParams.sysrefFreqDiv-1
			if spiSysref==1:
				self.regs.PLL[1].pll1.pll1.lcmgen_usespisysref=1
			else:
				self.regs.PLL[1].pll1.pll1.lcmgen_usespisysref=0	

			if spiSysref==0:
				self.regs.PLL[1].pll1.pll1.EN_SYNC_DIV=1
			self.deviceRefs.device.printCommentToLog("Wait for Sysref to come.")
			self.delay(0.1)
			if spiSysref==0:
				self.regs.PLL[1].pll1.pll1.EN_SYNC_DIV=0
			
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x02
			self.regs.PLL[1].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=1
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1d
			self.regs.PLL[0].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=1
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1f
			
			self.regs.PLL[1].pll1.pll1.lcmgen_sync_ena=0
			self.regs.PLL[1].pll1.pll1.lcmgen_sync_ena=1
			self.deviceRefs.device.printCommentToLog("Wait for Sysref to come.")
			if spiSysref==1:
				for i in range(1):
					self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=0
					self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=1
				self.regs.PLL[1].pll1.pll1.lcmgen_spisysref=0
			else:
				self.delay(0.1)
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x00
			
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x02
			self.regs.PLL[1].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			self.regs.PLL[1].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=0
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x1d
			self.regs.PLL[0].pll1.pll1.EN_SYNC_TO_PLLDIG_DIV=0
			self.regs.PLL[0].pll1.pll1.SYS_REF_FROM_PIN_BYPAS=0
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=0x00
			
		#if self.systemParams.useMacros==True:
		#	self.requestPllSpiAccess(0)
	#sendSysref
			
	
	@funcDecorator
	def initialTopConfig(self):
		""" "Doing Top & DSA initialization" "Done Top & DSA initialization" """
		if self.systemStatus.chipVersion>0x10:
			self.regs.TC_GPIO.digtop.Register41632_600h.dsa_abcd_addr_range=1
		
		if self.systemParams.enableFbCd==False:
			self.deviceRefs.device.printCommentToLog("Disabling FB CD")
			self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_1f_fbcd_spare_0.PDN_GBL_FBCD=True
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2291_3_3=1
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2290_4_4=1
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2292_2_2=1
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2293_1_1=1
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=0
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.PDN_GBL_PLL5_CLKTOP=0
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.SERDES_L_IP_REF_CLK_DIV_0=jesdConstants.serdesIpDivFactors.index(self.systemStatus.serdesConfig[0]['refClkIpDiv'])
		self.regs.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.SERDES_R_IP_REF_CLK_DIV_1=jesdConstants.serdesIpDivFactors.index(self.systemStatus.serdesConfig[1]['refClkIpDiv'])
		if 1 in self.systemParams.systemMode:
			self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44661_9_8=2
		
		if self.systemParams.jesdABLvdsSync==True:
			self.regs.TC_GPIO.digtop.Register41632_600h.sync_lvds_mode_ab=True
		else:
			self.regs.TC_GPIO.digtop.Register41632_600h.sync_lvds_mode_ab=False
		
		if self.systemParams.jesdCDLvdsSync==True:
			self.regs.TC_GPIO.digtop.Register41632_600h.sync_lvds_mode_cd=True
		else:
			self.regs.TC_GPIO.digtop.Register41632_600h.sync_lvds_mode_cd=False
		
		self.regs.TC_GPIO.digtop.CFG_GPIO_76.pull_ctrl_gpio_76=0
		self.regs.TC_GPIO.digtop.CFG_GPIO_57.pull_ctrl_gpio_57=0
		self.regs.TC_GPIO.digtop.CFG_GPIO_61.pull_ctrl_gpio_61=0
		self.regs.TC_GPIO.digtop.CFG_GPIO_48.pull_ctrl_gpio_48=0
		self.deviceRefs.broadcastEn=0xf
		self.DSA[0].rxDsaRegDefaults()
		self.DSA[0].rxDsaCodesPopulate()
		self.DSA[0].txDsaCodesPopulate()
		self.DSA[0].fbDsaCodesPopulate()
		self.deviceRefs.broadcastEn=0x0
		
		if self.systemParams.fbDsaPerTxEn==True:
			for chNo in range(4):
				self.SYSCALIB.fbDsaGainConfig(self.systemParams.fbDsaPerTx[chNo],chNo)
			self.SYSCALIB.fbDsaSwitchConfig(1)
	#initialTopConfig
	
	@funcDecorator
	def leakSysrefToJesd(self):
		""" "Leaks Sysref to JESD" """
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44437_24_24=0
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44720_10_0=1		# to leak only to JESD
		self.leakSysrefRxTxDig(0,0,1)
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44720_10_0=(2**10-2)
	#leakSysrefToJesd
	

	@funcDecorator
	def leakSysrefToAnalog(self):
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44393_0_0=1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44401_1_1=1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44402_2_2=1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44403_3_3=1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44404_4_4=1
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44405_5_5=1
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44400_9_0=0x3ff
		self.regs.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44400_9_0=0x0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44393_0_0=0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44401_1_1=0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44402_2_2=0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44403_3_3=0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44404_4_4=0
		self.regs.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44405_5_5=0
	#leakSysrefToAnalog
	
	@funcDecorator
	def getPllControlVoltageOnTp(self,pll,en):
		self.requestPllSpiAccess(1)
		self.regs.CLK_AB.ctl_2t_clktop_config.Register2351_74h.Property2353_5_5=1
		self.regs.TC_GPIO.digtop.CFG_GPIO_0.analog_tp_en_gpio_0=1
		self.regs.TC_GPIO.digtop.CFG_GPIO_1.analog_tp_en_gpio_1=1
		self.regs.TC_GPIO.digtop.CFG_GPIO_0.pull_ctrl_gpio_0=0
		self.regs.TC_GPIO.digtop.CFG_GPIO_1.pull_ctrl_gpio_1=0
		
		######### Next set of lines to enable PLL test points
		self.regs.PLL[pll].pll1.pll1.EN_LDO_ANA_TEST=en
		self.regs.PLL[pll].pll1.pll1.EN_LDO_RF_TEST=en
		self.regs.PLL[pll].pll1.pll1.EN_BIAS_TEST=en
		self.regs.PLL[pll].pll1.pll1.EN_CP_TEST=en
		self.regs.PLL[pll].pll1.pll1.EN_LPF_TEST=en
		self.regs.PLL[pll].pll1.pll1.EN_VCO_TEST=en
		self.regs.PLL[pll].pll1.pll1.CTL_TP_LPF=1
		 
		########## To bring VCO control voltage
		 
		self.regs.PLL[pll].pll1.pll1.CTL_TP_ANA_MUX = 4 #(to read VCO control voltage)            #####1 (LDO_ANA), 2(LDO_RF), 3(CP_BIAS), 4(VCO control voltage)
		if pll in (0,1,2):
			info("PLL 0 to 2 comes on pin RXFBNCO1, Ball U17")
		elif pll ==3:
			info("PLL 3 comes on pin RXBPD2H, Ball U7")
		else:
			info("PLL 4 comes on pin syncbinm1, Ball D5")
		self.requestPllSpiAccess(0)
	#getPllControlVoltageOnTp
	
	
	@funcDecorator
	def boot_rx_cm4_from_ram(self, ram_filename, explicit_load=1):
		self.enable_rx_cm4_clk()
		if(explicit_load==1):
			self.load_rx_cm4_pram(ram_filename)
		else:
			self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_ram_sel=1
	# boot_rx_cm4_from_ram

	@funcDecorator
	def enable_rx_cm4_clk(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_inclk_en=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_outclk_en=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_divider_reset=0
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_spi_sel=0
		
	@funcDecorator
	def boot_top_cm4_from_ram(self, ram_filename):
		execfile(ram_filename)			

		self.regs.MACRO.FW_REGS.CM4_CONTROL.spi_sel = 0;
		self.regs.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel = 1

	# boot_top_cm4_from_ram

	@funcDecorator
	def spi_prom_loader(self, wrDataList, Number_of_trials=5): 
		increment_val=32768-32
		start_val_dummy=32
		for i in range(Number_of_trials):
			trial_number=0
			self.memWrite('topCm4Prom', start_val_dummy+increment_val*i , 0);
			while (trial_number<Number_of_trials):
				###MRV### info("//trial_number="+str(trial_number))
				self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(200000)
				self.burstWrite(0x20,wrDataList[increment_val*i:increment_val*(i+1)]);
				self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(40000)
				readDataList_0=self.burstRead(0x20+0x8000,(increment_val)/2);
				readDataList_1=self.burstRead(0x20+0x8000+(increment_val)/2,(increment_val)/2);
				readDataList=readDataList_0+readDataList_1;
				if (readDataList==wrDataList[increment_val*i:increment_val*(i+1)]):
					break;
				trial_number=trial_number+1
		self.memWrite('topCm4Prom', start_val_dummy+increment_val*5 , 0);
		trial_number=0
		while (trial_number<Number_of_trials):
			###MRV### info("//trial_number="+str(trial_number))
			self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(200000)
			self.burstWrite(0x20,wrDataList[increment_val*5:increment_val*5+32*5]);
			self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(40000)
			readDataList=self.burstRead(0x20+0x8000,32*5);
			if (readDataList==wrDataList[increment_val*5:increment_val*5+32*5]):
				break;
			trial_number=trial_number+1
		self.regs.MACRO.FW_REGS.CM4_CONTROL.spi_sel=0;

	####################################################################################
	@funcDecorator
	def boot_top_cm4_from_prom(self, ram_filename, self_PROJECT_ROOT):
	#	execfile(ram_filename)			
		#mainWindow.runFile(self_PROJECT_ROOT+"\\temp_hex_fw\\topCm4Pram_"+str(FW_VERSION)+"_spi_download.py");
		#execfile(self_PROJECT_ROOT+"\\temp_hex_fw\\spi_prom_160.py")
		print (ram_filename)

		from ram_filename import wrDataList
		self.spi_prom_loader(wrDataList)

		self.regs.MACRO.FW_REGS.CM4_CONTROL.spi_sel = 0
		self.regs.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel = 0

	# boot_top_cm4_from_ram

	###################################################################################
	@funcDecorator
	def remove_reset_for_topcm4(self):
		self.regs.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 1
		self.regs.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 0

	# remove_reset_for_topcm4()

	@funcDecorator
	def keep_top_cm4_under_reset(self):
		self.regs.MACRO.FW_REGS.CM4_CONTROL.core_reset_reg = 1
		self.regs.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 1
	# keep_top_cm4_under_reset(self):

	###################################################################################
	@funcDecorator
	def keep_rm_cm4_under_reset(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_reset_z = 0

	# keep_rxcm4_under_reset(self):

	###################################################################################
	@funcDecorator
	def keep_tx_cm4_under_reset(self):
		self.regs.TC_GPIO.digtop.Register41632_600h.Property41703_0_0 = 0

	# keep_tx_cm4_under_reset

	###################################################################################
	@funcDecorator
	def get_timestamp_str(self):
		year_str	= str(datetime.datetime.now().year)
		month_str	= str(datetime.datetime.now().month)
		day_str		= str(datetime.datetime.now().day)
		hour_str	= str(datetime.datetime.now().hour)
		minute_str	= str(datetime.datetime.now().minute)
		second_str	= str(datetime.datetime.now().second)

		timestamp_str = year_str+month_str+day_str+hour_str+minute_str+second_str
			
		return(timestamp_str)
		# get_stimestamp_str(self):
		
	@funcDecorator
	def append_log_to_file(ordered_dict, filename, is_first_time=False):
	#	os.makedirs(os.path.dirname(filename), exist_ok=True)

		try:
			os.makedirs(os.path.dirname(filename))
		except OSError as exception:
			if exception.errno != errno.EEXIST:
				raise

		with open(filename, 'a') as fp:
			headline=''
			content=''

			for key, value in ordered_dict.items(self):
				headline 	= headline + key + ','
				content 	= content + str(value) + ','
				
			headline 	= headline + '\n'
			content 	= content + '\n'

			if is_first_time is True:
				fp.writelines(headline)

			fp.writelines(content)
			
	# append_log_to_file
		
	###################################################################################
	@funcDecorator
	def load_rx_cm4_pram(self, ram_filename):
		local_dict=locals()
		execfile(ram_filename, globals(), local_dict)			
		wrDataList = local_dict['wrDataList']

		increment_val=32768-32
		start_val_dummy=32
		Number_of_trials=5
		reversed_arr = wrDataList[::-1]
		Number_of_memory_blocks_to_write=2
		size_of_fw=Number_of_memory_blocks_to_write*32768+1
		for i in range (0,len(reversed_arr)):
			if (reversed_arr[i]!=0):
				size_of_fw=len(reversed_arr)-i
				break;
		print("size_of_fw="+str(size_of_fw))
		if (size_of_fw>Number_of_memory_blocks_to_write*32768):
			print("Cannot load the fw through ram since it is crossing the range")
		for i in range(0,Number_of_memory_blocks_to_write):
			trial_number=0
			self.memWrite('rxiqmcPram', start_val_dummy+increment_val*i , 0);
			while (trial_number<Number_of_trials):
				print("//trial_number="+str(trial_number))
				self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(200000)
				self.burstWrite(0x20,wrDataList[increment_val*i:increment_val*(i+1)]);
				self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(40000)
				readDataList_0=self.burstRead(0x20+0x8000,(increment_val)/2);
				readDataList_1=self.burstRead(0x20+0x8000+(increment_val)/2,(increment_val)/2);
				readDataList=readDataList_0+readDataList_1;
				if (readDataList==wrDataList[increment_val*i:increment_val*(i+1)]):
					break;
				trial_number=trial_number+1
		self.memWrite('rxiqmcPram', start_val_dummy+increment_val*Number_of_memory_blocks_to_write , 0);
		trial_number=0
		while (trial_number<Number_of_trials):
			print("//trial_number="+str(trial_number))
			self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(200000)
			self.burstWrite(0x20,wrDataList[increment_val*Number_of_memory_blocks_to_write:increment_val*Number_of_memory_blocks_to_write+32*Number_of_memory_blocks_to_write]);
			self.deviceRefs.device.regProgDevice._controller.instrument.setBaudRate(40000)
			readDataList=self.burstRead(0x20+0x8000,32*Number_of_memory_blocks_to_write);
			if (readDataList==wrDataList[increment_val*Number_of_memory_blocks_to_write:increment_val*Number_of_memory_blocks_to_write+32*Number_of_memory_blocks_to_write]):
				break;
			trial_number=trial_number+1
		self.regs.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_spi_sel=0;
	# def load_rx_cm4_pram(self):

	@funcDecorator
	def load_rx_cm4_pram_on_silicon(self, ram_filename):
		local_dict=locals()
		execfile(ram_filename, globals(), local_dict)			
		wrDataList = local_dict['wrDataList']

		increment_val=32768-32
		start_val_dummy=0x20
		for i in range(0,2):
			increment_addr=i*increment_val;
			self.memWrite('rxiqmcPram', increment_addr + start_val_dummy , 0);
			for loop in range(0,16):
				increment_loop_addr=2048*loop
				if	(loop<15): 
					self.burstWrite(0x20+increment_loop_addr,wrDataList[increment_addr+increment_loop_addr:increment_addr+increment_loop_addr+2048]);
				else:
					self.burstWrite(0x20+increment_loop_addr,wrDataList[increment_addr+increment_loop_addr:increment_addr+increment_loop_addr+2048-0x20]);
		increment_addr=2*increment_val
		self.memWrite('rxiqmcPram', increment_addr + start_val_dummy , 0);
		self.burstWrite(0x20,wrDataList[increment_addr:increment_addr+32*2]);
	# def load_rx_cm4_pram_on_silicon(self, ram_filename):
	
	@funcDecorator
	def loadTxIqMcPatch(self):
		""" "Downloading TX IQMC Steady State Patch" "Completed downloading TX IQMC Steady State Patch" """
		
		temp=self.deviceRefs.device.hardReadAlways
		self.deviceRefs.device.hardReadAlways=True
		## Patch Function Definition 
		PATCH_TOP_FW=0x0
		PATCH_TX_FW=0x1
		PATCH_RX_FW=0x2
		PATCH_DOWNLOAD=0x0
		PATCH_APPLY=0x1
		PATCH_OPCODE=0x81

		def patch_txiqmc_fw_download_macro(pkt_len=4096,address=0):
			# Write the Operands		
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_DOWNLOAD)+((PATCH_TX_FW)<<8)+(pkt_len<<16)
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
			# Issue MACRO			
			self.SYSCALIB.execute_macro(nBytes=0,opcode=PATCH_OPCODE)
			#  patch_txiqmc_fw_download_macro
			
		def patch_txiqmc_fw_apply_macro(pkt_len=4096,address=0):
			info("*TX IQMC Patch Apply*")
			# Write the Operands
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_APPLY)+(PATCH_TX_FW<<8)+(pkt_len<<16)
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
			# Issue MACRO			
			self.SYSCALIB.execute_macro(nBytes=0,opcode=PATCH_OPCODE)

		def patch_top_fw_download_macro(pkt_len=4096,address=0):
			info("*TOP Patch Download*")
			# Write the Operands		
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_DOWNLOAD)+((PATCH_TOP_FW)<<8)+(pkt_len<<16)
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
			# Issue MACRO			
			self.SYSCALIB.execute_macro(nBytes=0,opcode=PATCH_OPCODE)
			#  patch_top_fw_download_macro
			
		def patch_top_fw_apply_macro(pkt_len=4096,address=0):
			info("*TOP Patch Apply*")
			# Write the Operands
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=(PATCH_APPLY)+(PATCH_TOP_FW<<8)+(pkt_len<<16)
			self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=(address)
			# Issue MACRO			
			self.SYSCALIB.execute_macro(nBytes=0,opcode=PATCH_OPCODE)

		###################################################################################################################################

		#TX Patch RAM Download - 64 kB	
			
		#CLK Ungate for Tx CM4 Patch Download
		self.SYSCALIB.do_tune_and_enable(0,0,0,0,MACROConst.MACRO_TUNE_AND_ENABLE__CLK_CONFIG_AND_ENABLE_TXCM4)
		
		if self.systemStatus.chipVersion>0x10:
			if self.systemStatus.useTxIqmcPatchVersion==2:
				wrDataList=MACROConst.txPatchPg1p1
				# Patch Download
				pkt_size = [2048,2048,312] #Old Value 176
				for iteration in range (3):
					# Dummy Write for Page Select
					self.SYSCALIB.memWrite('macroMem', 32, 0);
					# Copy 2kB data to MacroMem
					self.burstWrite(0x20,wrDataList[iteration*2048:(iteration+1)*2048]);
					# Copy 2 kB data in MacroMem to desired location of Tx PRAM
					patch_txiqmc_fw_download_macro(pkt_len=pkt_size[iteration],address=2048*iteration);
					if self.systemParams.simulationMode==False:
						self.deviceRefs.device.regProgDevice._controller.instrument.purge()
				patch_txiqmc_fw_apply_macro(pkt_len=2048+2048+312,address=0)				
			elif self.systemStatus.useTxIqmcPatchVersion==1:
				wrDataList=MACROConst.txPatchPg1p1V0
				self.SYSCALIB.memWrite('macroMem', 32, 0);
				self.burstWrite(0x20,wrDataList);
				patch_txiqmc_fw_download_macro(pkt_len=600,address=0);
				patch_txiqmc_fw_apply_macro(pkt_len=600,address=0)
			else:
				wrDataList=MACROConst.txPatchPg1p1
				# Patch Download
				pkt_size = [2048,2048,176] 
				for iteration in range (3):
					# Dummy Write for Page Select
					self.SYSCALIB.memWrite('macroMem', 32, 0);
					# Copy 2kB data to MacroMem
					self.burstWrite(0x20,wrDataList[iteration*2048:(iteration+1)*2048]);
					# Copy 2 kB data in MacroMem to desired location of Tx PRAM
					patch_txiqmc_fw_download_macro(pkt_len=pkt_size[iteration],address=2048*iteration);
					if self.systemParams.simulationMode==False:
						self.deviceRefs.device.regProgDevice._controller.instrument.purge()
				patch_txiqmc_fw_apply_macro(pkt_len=2048+2048+176,address=0)
		else:
			wrDataList=MACROConst.txPatch

			# Patch Download
			# Iterate and Copy 2 kB at a time -  Need 32 iterations to copy 
			for iteration in range (32):
				info("Doing "+str(iteration)+" part out of 32")
				# Dummy Write for Page Select
				self.SYSCALIB.memWrite('macroMem', 32, 0);
				# Copy 2kB data to MacroMem
				self.burstWrite(0x20,wrDataList[iteration*2048:(iteration+1)*2048]);
				# Copy 2 kB data in MacroMem to desired location of Tx PRAM
				patch_txiqmc_fw_download_macro(pkt_len=2048,address=2048*iteration);
				if self.systemParams.simulationMode==False:
					self.deviceRefs.device.regProgDevice._controller.instrument.purge()
		self.deviceRefs.device.hardReadAlways=temp
	#loadTxIqMcPatch
	
	@funcDecorator
	def loadRxIqMcPatch(self):
		wrDataList=MACROConst.rxpatch

		PATCH_TOP_FW=0x0
		PATCH_TX_FW=0x1
		PATCH_RX_FW=0x2
		PATCH_DOWNLOAD=0x0
		PATCH_APPLY=0x1
		PATCH_OPCODE=0x81
		DSA_OK=0
		patch_rxiqmc_apply=1
		err_cnt=0
		##ennable clocks
		################################ENABLE CLOCKS FOR PATCHING#########################################################
		self.top_rxCM4ClkEn_ROM();##enable clocks before applying patch
		#############################LOOP should be run based on size of patch(PATCH_SIZE_IN_BYTES/4096)####################
		for i in range(1): #range(0,5):
			self.memWrite('macroMem', 32, 0);
			CHUNK_NUMBER=i
			#info("CHUNK_NUMBER="+str(CHUNK_NUMBER))
			self.burstWrite(0x20,wrDataList[4096*CHUNK_NUMBER:4096*CHUNK_NUMBER+2048]);
			temp=self.deviceRefs.device.rawWriteLogEn
			self.deviceRefs.device.rawWriteLogEn=0
			rdDataList=self.burstRead(0x20+0x8000,2048);
			self.deviceRefs.device.rawWriteLogEn=temp

			if (rdDataList!=wrDataList[4096*CHUNK_NUMBER:4096*CHUNK_NUMBER+2048]):
				error("Patch NOT loaded properly.CHECK")
			self.burstWrite(0x20+2048,wrDataList[4096*CHUNK_NUMBER+2048:4096*CHUNK_NUMBER+4096]);
			temp=self.deviceRefs.device.rawWriteLogEn
			self.deviceRefs.device.rawWriteLogEn=0
			rdDataList=self.burstRead(0x20+0x8000+2048,2048);
			if (rdDataList!=wrDataList[4096*CHUNK_NUMBER+2048:4096*CHUNK_NUMBER+4096]):
				error("Patch NOT loaded properly. CHECK")
			self.deviceRefs.device.rawWriteLogEn=temp
			self.SYSCALIB.patch_rxiqmc_fw_download(PATCH_DOWNLOAD,PATCH_RX_FW,PATCH_OPCODE,4096*i);

		###################################################PATCH APPLY######################################################
		err_cnt=self.SYSCALIB.patch_rxiqmc_fw_apply(PATCH_APPLY,PATCH_RX_FW,PATCH_OPCODE);###patch apply 	

		###############REMOVE RESET FOR THE PATCH TO TAKE EFFECT##############################################################
		#self.top_rxCM4Reset_ROM();#####Removing reset for rxcm4

		###############Check if Patch download Macro had any errors###############
		if err_cnt>0 :
			error("Macro for loading Patch Failing. CHECK")
		
	
	@funcDecorator
	def loadEfusePackets(self):
		""" "Loading EFuse Packets" "Done Loading Efuse packets" """
		"""	
			for fixed packets
			Bit number	Packet name
			Bit 0	FB NL packet
			Bit 1	RX ANA Freq Dependent packet
			Bit 2	RX ANA BB Dependent packet
			Bit 3	RX ANA ADCRate Dependent packet
			Bit 4	RX ANA ADCRate & BW Dependent packet
			Bit 5	RX ANA onlyADC Dependent packet
			Bit 6	RX ANA onlyRx channel Dependent packet
			Bit 7	CLKTOP TRIMS packet
			Bit 8	TX ANA Freq Independet packet
			Bit 9	TX ANA Freq Dependent packet
			Bit 10	FB ANA packet
			Bit 11	FB spur cancellation packet
			Bit 12	PLL TRIMS packet
			Bit <31:13>	Reserved
		"""
		
		
		nearestTrimFreq=3500
		minDiff=3500
		for freq in [2800,3500,4900]:
			if abs(freq-self.systemParams.pllLo[0])<minDiff:
				nearestTrimFreq=freq
				minDiff=abs(freq-self.systemParams.pllLo[0])
		
		if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(48*62.5, 6):
			if (self.systemParams.rxAdcBw == 100):
				if nearestTrimFreq==4900:
					#48X-4.9G
					fuseList=(2,4,7,14,15,17,20)
				elif nearestTrimFreq==3500:
					#48X-3.5G
					fuseList=(1,4,7,12,13,17,20)
				elif nearestTrimFreq==2800:
					#48X-2.6G and below ---
					fuseList=(0,4,7,10,11,17,20)
				else:
					debug("valid PLL LO value not found in loadEfusePackets..............")
					return
			elif (self.systemParams.rxAdcBw == 150):
				if nearestTrimFreq==4900:
					#48X-4.9G
					fuseList=(2,6,7,14,15,19,20)
				elif nearestTrimFreq==3500:
					#48X-3.5G
					fuseList=(1,6,7,12,13,19,20)
				elif nearestTrimFreq==2800:
					#48X-2.6G and below ---
					fuseList=(0,6,7,10,11,19,20)
				else:
					debug("valid PLL LO value not found in loadEfusePackets..............")
					return
			else:
				debug("valid RX ADC BW value not found in loadEfusePackets..............")
				return
		elif round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(54*62.5, 6):
			if nearestTrimFreq==4900:
				#54X-4.9G
				fuseList=(2,5,7,14,15,18,20)
			elif nearestTrimFreq==3500:
				#54X-3.5G
				fuseList=(1,5,7,12,13,18,20)
			elif nearestTrimFreq==2800:
				#54X-2.6G and below ---
				fuseList=(0,5,7,10,11,18,20)
			else:
				debug("valid PLL LO value not found in loadEfusePackets..............")
				return
		elif round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) in [round(24*62.5, 6), round(27*62.5, 6)]:
			if nearestTrimFreq==4900:
				#24X/27X-4.9G
				fuseList=(2,3,7,14,15,16,20)
			elif nearestTrimFreq==3500:
				#24X/27X-3.5G
				fuseList=(1,3,7,12,13,16,20)
			elif nearestTrimFreq==2800:
				#24X/27X-2.6G and below ---
				fuseList=(0,3,7,10,11,16,20)
			else:
				debug("valid PLL LO value not found in loadEfusePackets..............")
				return
		else:
			debug("valid Mode not found in loadEfusePackets..............")
			return
		  
		self.SYSCALIB.wait_for_macro_ready() 
		packet_cnt_2load=len(fuseList) 
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0 #Load No fixed packets 
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1 = (fuseList[1]<<24)+(fuseList[0]<<16) + (packet_cnt_2load <<8) + 0x00 
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2 = (fuseList[5]<<24)+(fuseList[4]<<16) + (fuseList[3]<<8)+(fuseList[2]) 
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf3 = (fuseList[6]) 
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (0x12)<<24 
		self.SYSCALIB.wait_for_macro_done() 

		#loadEfusePackets
	
	def findFbNyquist(self,freq):
		nyq=int(math.ceil(freq*2.0*(1+self.systemParams.halfRateModeFb)/self.systemParams.Fs))
		if nyq>4:
			nyq=4
		return nyq-1
	#findFbNyquist
	
	@funcDecorator
	def loadNyquistAndTempSenseInfo(self):
		self.regs.MACRO.FW_REGS.CM4_CONTROL.all_local_page = 0
		self.regs.MACRO.FW_REGS.CM4_CONTROL.all_addr_high = 0
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=1
		self.writeReg(0x3F10,0x20)
		self.writeReg(0x3F12,0xCE)
		self.writeReg(0x3F13,0xFF)
		self.writeReg(0x3F14,0x7F)
		self.writeReg(0x3F15,0x00)
		self.writeReg(0x3EE6,0x01)
		self.writeReg(0x3F64,self.findFbNyquist(self.systemParams.fbNco[0]))
		self.writeReg(0x3F65,self.findFbNyquist(self.systemParams.fbNcoBand1[0]))
		self.writeReg(0x3F66,self.findFbNyquist(self.systemParams.fbNco[1]))
		self.writeReg(0x3F67,self.findFbNyquist(self.systemParams.fbNcoBand1[1]))
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=0
	#loadNyquistInfo
	


	@funcDecorator
	def loadFbImdEfusePackets(self):
		""" "Loading PLL EFuse trims" "Done Loading PLL EFuse trims" """
		self.loadNyquistAndTempSenseInfo()
		#fuseList=(8,9)
		# packet_cnt_2load=len(fuseList)
		fbNco=self.systemParams.fbNco[0]
		
		"""	LO	LO condition	Dummy 	Actual data rate	
			b1	1.2	LO<1.5G		48		48/54
			b2	2.6	1.5<LO<2.9G	54		48/54
			b3	3.5	2.9<LO<4.5G	48		48/54
			b4	4.9	LO>4.5G		48		48/54"""
		if(fbNco<1474.56):
			fbBand=1
		elif((fbNco>=1474.56) & (fbNco<2949.12)):
			fbBand=2
		elif((fbNco>=2949.12) & (fbNco<4423.68)):
			fbBand=3
		elif(fbNco>=4423.68):	
			fbBand=4
		else:
			fbBand=3
			
		fbRateMap = {1:  48, 2:  54, 3:  48, 4:  48}
		X=self.systemParams.X
		
		self.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(round(fbRateMap[fbBand]*62.5, 6)/(X*(1+self.systemParams.halfRateModeRx)),6),\
			round(round(fbRateMap[fbBand]*62.5, 6)/(X*(1+self.systemParams.halfRateModeRx)),6), round(round(fbRateMap[fbBand]*62.5, 6)/(X*(1+self.systemParams.halfRateModeTx)),6), \
			round(round(fbRateMap[fbBand]*62.5, 6)/(X*(1+self.systemParams.halfRateModeTx)),6), round(round(fbRateMap[fbBand]*62.5, 6)/(X*(1+self.systemParams.halfRateModeFb)),6),\
			round(round(fbRateMap[fbBand]*62.5, 6)/(X*(1+self.systemParams.halfRateModeFb)),6))
		
		self.SYSCALIB.wait_for_macro_ready()
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = (0x1)<<8 #Load only FB IMD
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1 = 0  #(fuseList[1]<<24)+(fuseList[0]<<16) + (packet_cnt_2load <<8) + 0x00
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (0x12)<<24
		self.SYSCALIB.wait_for_macro_done()
		
		
		# if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(27*62.5, 6): 
			# self.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6),\
				# round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), \
				# round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6),\
				# round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6))
		
		#self.requestPllSpiAccess(0)
		
	#loadPllEfusePackets

	@funcDecorator
	def loadPllEfusePackets(self):
		""" "Loading PLL EFuse trims" "Done Loading PLL EFuse trims" """
		# self.loadNyquistAndTempSenseInfo()
		fuseList=(8,9)
		packet_cnt_2load=len(fuseList)
		X=self.systemParams.X
		if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(27*62.5, 6): 
			self.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeRx)),6),\
				round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeRx)),6), round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeTx)),6), \
				round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeTx)),6), round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeFb)),6),\
				round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeFb)),6))
		
		self.SYSCALIB.wait_for_macro_ready()
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = (0x1f7c)<<8 #Load all fixed packets except FB IMD
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1 = (fuseList[1]<<24)+(fuseList[0]<<16) + (packet_cnt_2load <<8) + 0x00
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (0x12)<<24
		self.SYSCALIB.wait_for_macro_done()
		
		if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(27*62.5, 6): 
			self.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6),\
				round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), \
				round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6),\
				round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6))
		
		#self.requestPllSpiAccess(0)
		
	#loadPllEfusePackets
	
	@funcDecorator
	def loadEfusePacketsPostAnaWrites(self):
		X=self.systemParams.X
		if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(27*62.5, 6): 
			self.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeRx)),6),\
				round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeRx)),6), round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeTx)),6), \
				round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeTx)),6), round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeFb)),6),\
				round(round(48*62.5, 6)/(X*(1+self.systemParams.halfRateModeFb)),6))
		self.SYSCALIB.wait_for_macro_ready()
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = (0x18)<<8 #Load all fixed packets except FB IMD
		if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(48*62.5, 6):
			if (self.systemParams.rxAdcBw == 100):
				fuseVal=0x07040200
			elif (self.systemParams.rxAdcBw == 150):
				fuseVal=0x07060200
		elif round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(54*62.5, 6):
			fuseVal=0x07050200
		elif round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) in [round(24*62.5, 6), round(27*62.5, 6)]:
			fuseVal=0x07030200
		else:
			fuseVal=0x07040200
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1 = fuseVal
		self.regs.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2 = 0
		self.regs.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (0x12)<<24
		self.SYSCALIB.wait_for_macro_done()
		if round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx),6) == round(27*62.5, 6): 
			self.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6),\
				round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), \
				round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6),\
				round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6))
	#loadEfusePacketsPostAnaWrites


#topLib	