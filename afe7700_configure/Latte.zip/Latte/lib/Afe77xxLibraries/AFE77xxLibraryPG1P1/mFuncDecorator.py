import random
import re
from collections import defaultdict
from functools import wraps
from globalDefs import *
from mSetupParams import setupParams

class deviceRefs():
	#lmkRegs='Dummy'
	#fpgaRegs='Dummy'
	#fpgaBypass='Dummy'
	device='Dummy'
	#fpgaWriter='Dummy'
	systemParams='Dummy'
	systemStatus='Dummy'
	#lmkParams='Dummy'
	broadcastEn=0
	
	engine='Dummy'
	process='Dummy'
	
	previousClassCalled='Dummy'
	previousBroadcastEn=0

	skipFpga=0
	skipLmk=0
	useMacros=False
	macroFunctionsDict={}
	openFunctions=0
#deviceRefs


def funcDecorator(func):
	
	@wraps(func)
	def inDecorator(*args):
		desc=func.__doc__
		className=args[0].__class__.__name__
		print "Entered: "+ str(func.__name__)+ " of class "+str(className)
		if desc!=None and className in ('fpgaLib','fpgaLib_J58','lmkLib'):
			if desc.count('"')>=2:
				desc=desc[desc.find('"')+1:]
				startComment=desc[:desc.find('"')]
				desc=desc[desc.find('"')+1:]
				if className == 'lmkLib':
					setupParams.dutInstances[setupParams.selectedDut].deviceRefs.device.printCommentToLog(startComment)			
				else:
					setupParams.dutInstances[setupParams.selectedDut].deviceRefs.device.printCommentToLog(startComment)			
		else:
			deviceRefsInstance=args[0].deviceRefs
			if desc!=None and deviceRefsInstance.device!="Dummy":
				if desc.count('"')>=2:
					desc=desc[desc.find('"')+1:]
					startComment=desc[:desc.find('"')]
					desc=desc[desc.find('"')+1:]
					deviceRefsInstance.device.printCommentToLog("START: "+startComment)
					#info(startComment)
		if className not in ('fpgaLib','fpgaLib_J58','lmkLib'):
			if func.__name__!="deviceBringup":
				deviceRefsInstance.openFunctions+=1
			alternateBroadcastEn=(deviceRefsInstance.broadcastEn&1)+((deviceRefsInstance.broadcastEn>>1)&2)
			if deviceRefsInstance.device == 'Dummy':
				error("Pass device reference using deviceRefsInstance.deviceref = device")
			elif deviceRefsInstance.broadcastEn!=0:# or (deviceRefsInstance.previousClassCalled==className and deviceRefsInstance.previousBroadcastEn!=deviceRefsInstance.broadcastEn):
				if className == 'pllLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.PLL_CTRL.pll=deviceRefsInstance.broadcastEn
				elif className == 'fbDigLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.DATAPATH_DIGITAL.fb_top=alternateBroadcastEn
				elif className == 'rxAgcDgcLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.DATAPATH_DIGITAL.rx_top=alternateBroadcastEn
				elif className == 'rxDigLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.DATAPATH_DIGITAL.rx_top=alternateBroadcastEn
				elif className == 'jesdTxLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.rx_jesd=alternateBroadcastEn
				elif className == 'jesdRxLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.tx_jesd=alternateBroadcastEn
				elif className == 'dacDigLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.DATAPATH_DIGITAL.tx_top=alternateBroadcastEn
				elif className == 'dsaController':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.Miscenallous.dsa=alternateBroadcastEn
				elif className == 'serdesLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=alternateBroadcastEn
				elif className == 'rxAnaILib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i=deviceRefsInstance.broadcastEn
				elif className == 'rxAnaQLib':
					deviceRefsInstance.device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i=deviceRefsInstance.broadcastEn
				
			deviceRefsInstance.previousClassCalled=className
			deviceRefsInstance.previousBroadcastEn=deviceRefsInstance.broadcastEn
		#info(func)
		#info(deviceRefsInstance.macroFunctionsDict.keys())
		#info(func in deviceRefsInstance.macroFunctionsDict.keys())
		if className in ('fpgaLib','fpgaLib_J58'):
			setupParams.engine.stop=1
			
		if setupParams.skipFpga==True and className in ('fpgaLib','fpgaLib_J58'):# and func.__name__!="fpgaTxSendK":
			a=None
		elif setupParams.skipLmk==True and className=="lmkLib":
			a=None
		else:
			a=func(*args)
		if desc!=None and className in ('fpgaLib','fpgaLib_J58','lmkLib'):
			pass
		else:
			if className not in ('fpgaLib','fpgaLib_J58','lmkLib'):
				deviceRefsInstance.openFunctions-=1
				#print deviceRefsInstance.openFunctions
			#if (deviceRefsInstance.openFunctions==0 or deviceRefsInstance.broadcastEn==0)  and  func.__name__ not in ('delay','writeReg','readReg','serdesFirmwareWrite','serdesFirmwareRead','serdesWrite','serdesRead','writeMem32','writeMem8','readMem32','readMem16','readMem8','memPageSel','memAddrGen','memWrite','memWrite8','memWrite16','memWrite32','memRead','memRead8','memRead16','memRead32','burstRead','burstWrite','jesdModeFeatures','checkValidityOfDigChain','findLoNcoPossibleFrequency','updateDeviceRefsInBaseClass', 'timerWaitForMilliSec', 'timerWaitForSec', 'errorinDb', 'jesdModeFeatures', 'checkValidityOfDigChain', 'findLoNcoPossibleFrequency', 'largestPowerOfTwoThatIsAFactorOf', 'initializeConfig', 'initializeConfigOld'):
			#	if deviceRefsInstance.device.currentPageSelected!=None:
			#		deviceRefsInstance.device.currentPageSelected.setValue(0)	
		desc=func.__doc__
		if desc!=None and className in ('fpgaLib','fpgaLib_J58','lmkLib'):
			if desc.count('"')>=2:
				desc=desc[desc.find('"')+1:]
				startComment=desc[:desc.find('"')]
				desc=desc[desc.find('"')+1:]
				if className == 'lmkLib':
					setupParams.dutInstances[setupParams.selectedDut].deviceRefs.device.printCommentToLog(startComment)			
				else:
					setupParams.dutInstances[setupParams.selectedDut].deviceRefs.device.printCommentToLog(startComment)			
		else:
			if desc!=None and deviceRefsInstance.device!="Dummy":
				if desc.count('"')>=4:
					desc=desc[desc.find('"')+1:]
					desc=desc[desc.find('"')+1:]
					desc=desc[desc.find('"')+1:]
					endComment=desc[:desc.find('"')]
					deviceRefsInstance.device.printCommentToLog("END: "+endComment)
				#info(endComment)
		return a
	#inDecorator
	return inDecorator
#funcDecorator

def errorLogDecorator(func):
	def inDecorator(*args):
		ret=func(*args);
		nopreverrors=len(errorLog.errorlist)+1
		if type(ret[0]) is list:
			errors=ret[0]
		else:
			errors=ret
		if args[0] in errorLog.errorlistmonitor.keys():
			prevno=errorLog.errorlistmonitor[args[0]]
		else:
			errorLog.errorlistmonitor[args[0]]=2
			prevno=2
				
		if len(errors)>prevno:
			errorLog.errorlist[nopreverrors]['className']=args[0].__class__.__name__			
			errorLog.errorlist[nopreverrors]['funcName']=func.__name__
			
			if errors[2] is not None:
				Error=''
				#info("Prev %d and New %d" %(prevno,len(errors)))
				for i in range(prevno,len(errors)):
					Error=Error+errors[i]+"; "
				errorLog.errorlist[nopreverrors]['Error']=Error
			if errors[1] is not None:
				errorLog.errorlist[nopreverrors]['chno']=errors[1]
			if errors[0] is not None:
				errorLog.errorlist[nopreverrors]['topno']=errors[0]
			errorLog.errorlistmonitor[args[0]]=len(errors)
		if type(ret[0]) is list:
			return ret[1:]
		else:
			return
	return inDecorator

def errorLevelLogDecorator(func):
	def inDecorator(*args):
		ret=func(*args);
		if type(ret[0]) is list:
			errors=ret[0]
		else:
			errors=ret
		if errors[2] is not None:
			Error=['','','']
			for i in range(2,len(errors)):
				if re.match("[0-9]:",errors[i]):
					errorlevel=int(errors[i][0])
					if errorlevel not in (0,1,2):
						errorlevel=0
					nopreverrors=len(errorLog.errorlevellist[errorlevel])+1
					errorLog.errorlevellist[errorlevel][nopreverrors]['className']=args[0].__class__.__name__			
					errorLog.errorlevellist[errorlevel][nopreverrors]['funcName']=func.__name__
					Error[errorlevel]=Error[errorlevel]+errors[i]+"; "
					errorLog.errorlevellist[errorlevel][nopreverrors]['Error']=Error[errorlevel]
					if errors[1] is not None:
						errorLog.errorlevellist[errorlevel][nopreverrors]['chno']=errors[1]
					if errors[0] is not None:
						errorLog.errorlevellist[errorlevel][nopreverrors]['topno']=errors[0]
					if errorlevel>=errorLog.printerrorlevel:
						if errorlevel==0:
							warning(str(errorlevel)+": Error In Function: " + func.__name__ + ":\t" + errors[i][2:])
						elif errorlevel==1:
							error(str(errorlevel)+": Error In Function: " + func.__name__ + ":\t" + errors[i][2:])
						else:
							critical(str(errorlevel)+": Error In Function: " + func.__name__ + ":\t" + errors[i][2:])
		else:
			error("Error! Wrong level Entered")
		if type(ret[0]) is list:
			return ret[1:]
		else:
			return
	return inDecorator

def initDecorator(func):
	@wraps(func)
	def inDecorator(*args):
		className=args[0].__class__.__name__
		print "Instantiated: Class "+ str(className)
		return func(*args)
	#inDecorator
	return inDecorator
#initDecorator



class errorLog(object):
	errorlist=defaultdict(dict);
	errorlevellist=[defaultdict(dict),defaultdict(dict),defaultdict(dict)];
	errorlistmonitor=defaultdict(dict);
	printerrorlevel=2	
#errorLog

def printError():
	"""print Errors"""
	for errcnt in errorLog.errorlist:
		error(str(errcnt) +":")
		for err in errorLog.errorlist[errcnt]:
			error('\t'+str(err)+': '+str(errorLog.errorlist[errcnt][err]))
#printError

def printLevelError(errorlevel):
	"""print Errors of level errorlevel"""
	print "\nPrinting Errors of Level: " + str(errorlevel)
	for errcnt in errorLog.errorlevellist[errorlevel]:
		error(str(errcnt) +":")
		for err in errorLog.errorlevellist[errorlevel][errcnt]:
			if errorlevel==0:
				warning('\t'+str(err)+': '+str(errorLog.errorlevellist[errorlevel][errcnt][err]))
			elif errorlevel==1:
				error('\t'+str(err)+': '+str(errorLog.errorlevellist[errorlevel][errcnt][err]))
			else:
				critical('\t'+str(err)+': '+str(errorLog.errorlevellist[errorlevel][errcnt][err]))
#printLevelError
