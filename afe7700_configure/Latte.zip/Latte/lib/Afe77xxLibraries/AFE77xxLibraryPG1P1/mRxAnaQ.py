from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class rxAnaQLib(projectBaseClass):
	"""Contains RX EC DIG Q specific functions. self.regs=device.RX_ANA_Q """
	@initDecorator
	def __init__(self,topno,chno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
		self.chno=chno
		self.errorList=[topno,chno]
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
	
	#__init__

	@funcDecorator
	def pdnFrontEnd(self,pdn):
		self.regs.PDN_MATRIX.PDN_MATRIX_FE.Register2647_C74h.Property2649_1_1 = pdn
		self.regs.BB_FILTER_Q.BB_FILTER_MODES.Register2888_103h.Property2891_31_31 = pdn
	#pdnFrontEnd
#rxAnaQLib