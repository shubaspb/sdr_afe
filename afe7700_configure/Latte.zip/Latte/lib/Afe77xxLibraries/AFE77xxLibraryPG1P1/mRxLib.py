from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

import mRxAnaAB
reload(mRxAnaAB)
from mRxAnaAB import rxAnaABLib

import mRxDig
reload(mRxDig)
from mRxDig import rxDigLib

import mRxAnaCD
reload(mRxAnaCD)
from mRxAnaCD import rxAnaCDLib

import mRxAnaIQ
reload(mRxAnaIQ)
from mRxAnaIQ import rxAnaIQLib

import mRxAnaI
reload(mRxAnaI)
from mRxAnaI import rxAnaILib

import mRxAnaQ
reload(mRxAnaQ)
from mRxAnaQ import rxAnaQLib

import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *

import rxIqMc.mRxIqmc
reload(rxIqMc.mRxIqmc)

import rxIqMc.mRxIqmcFw
reload(rxIqMc.mRxIqmcFw)

import rxIqMc.mRxIqmcFwGetStatus
reload(rxIqMc.mRxIqmcFwGetStatus)

class rxLib(projectBaseClass):
	"""Contains RX specific functions. self.regs=device """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.RXDIG=[]
		for i in xrange(2):
			self.RXDIG.append(rxDigLib(i,regs.RX.DIG_AB[i].RxDecSet,deviceRefs))
		self.RXANAAB=rxAnaABLib(0,regs.RX.ANA_AB,deviceRefs)
		self.RXANACD=rxAnaCDLib(1,regs.RX.ANA_CD,deviceRefs)

		self.RXANAIQ=[]
		self.RXANAI=[]
		self.RXANAQ=[]
		for i in xrange(4):
			self.RXANAIQ.append(rxAnaIQLib(i/2,i%2,regs.RX_ANA_IQ[i],deviceRefs))
			self.RXANAI.append(rxAnaILib(i/2,i%2,regs.RX_ANA_I[i],deviceRefs))
			self.RXANAQ.append(rxAnaQLib(i/2,i%2,regs.RX_ANA_Q[i],deviceRefs))
		
		self.RXIQMC=rxIqMc.mRxIqmc.RxIqmc(self.regs.RX.RXIQMC.rx_iqmc,deviceRefs)
		self.RXIQMCFW = rxIqMc.mRxIqmcFw.RxIqmcFw(self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h,deviceRefs)
		self.RXIQMCFWGETSTATUS = rxIqMc.mRxIqmcFwGetStatus.RxIqmcFwGetStatus(self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h,deviceRefs)
		
	#__init__

	@funcDecorator
	def pdnFrontEnd(self,chNo=0,pdn=1):
		self.RXANAI[chNo].pdnFrontEnd(pdn)
		self.RXANAQ[chNo].pdnFrontEnd(pdn)
	#pdnFrontEnd
	
	def freezeRxIqmc(self,freeze):
		""" freeze=True will freeze the RX IQMC and =False will unfreeze it. """
		self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50551_1_1=1
		self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50138_0_0=freeze
		self.delay(0.001)
		if freeze==True:
			self.deviceRefs.device.expectedReadValue=0x1
		else:
			self.deviceRefs.device.expectedReadValue=0x0
		self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h._Property50630_11_8.getValue()
	#freezeRxIqmc
	
	
	def freezeRxLol(self,freeze=0):
		""" freeze=True will freeze the RX LOL Coreection and =False will unfreeze it. """
		for i in range (0,2):
			self.regs.RX.DIG_AB[i].RxDecSet.Register28150_C94h.dc_freeze_reg=freeze
			self.regs.RX.DIG_AB[i].RxDecSet.Register28282_E94h.dc_freeze_reg=freeze
			self.regs.RX.DIG_AB[i].RxDecSet.Register28216_CC0h.dc_freeze_reg=freeze
			self.regs.RX.DIG_AB[i].RxDecSet.Register28348_EC0h.dc_freeze_reg=freeze
	#freezeRxLol
	
	
#rxLib