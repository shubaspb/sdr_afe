from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class jesdSubchipLib(projectBaseClass):
	"""Contains JESD SUBCHIP specific functions. self.regs=device.JESD.SUBCHIP.SUBCHIP """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
		self.selectedFbNyquist=1
	#__init__

	@funcDecorator
	def jesdSubchipInitConfig(self):
		if 1 in self.systemParams.ddcFactorRx+self.systemParams.ddcFactorFb:
			self.configJesdTxLaneMux(1)
			self.configJesdRxLaneMux(1)
		else:
			if len(self.systemParams.jesdTxLaneMux)==8:
				self.configJesdTxLaneMux(self.systemParams.jesdTxLaneMux)
				self.configJesdRxLaneMux(self.systemParams.jesdRxLaneMux)
			else:
				self.configJesdTxLaneMux(0)
				self.configJesdRxLaneMux(0)
		self.configureDataMux(0,0)
		self.configJesdTxSyncMux()
		self.configJesdRxSyncMux()
		
		self.deviceRefs.device.printCommentToLog("START: Setting FIFO and dither in JESD")
		self.regs.JESD_SUBCHIP_REG50.ext_read_start_delay_fbab=8
		self.regs.JESD_SUBCHIP_REG53.ext_read_start_delay_fbcd=8
		self.regs.JESD_SUBCHIP_REG48.ext_read_start_delay_rxa=8
		self.regs.JESD_SUBCHIP_REG49.ext_read_start_delay_rxb=8
		self.regs.JESD_SUBCHIP_REG51.ext_read_start_delay_rxc=8
		self.regs.JESD_SUBCHIP_REG52.ext_read_start_delay_rxd=8
		#if self.systemStatus.chipVersion>0x10 and 1 not in [self.systemParams.ddcFactorRx+self.systemParams.ddcFactorFb]:
		#	self.regs.JESD_SUBCHIP_REG91.root_clk_dithered_mode_en=1
		#	div_factor = [1,1.3333,1.5,2,3,4,6,1.6667,1.75,2.3333,7,3.5]
		#	if round(self.systemStatus.jesdConfigParams[0]['rootClkDivRxFb'],4) in div_factor:
		#		div_factorIndex=div_factor.index(round(self.systemStatus.jesdConfigParams[0]['rootClkDivRxFb'],4))
		#		clk_shift_reg_len = [0b00000001 ,0b00001000 ,0b00000100,0b00000010,0b00000100,0b00001000,0b00100000,0b01000000,0b01000000,0b01000000,0b01000000,0b01000000][div_factorIndex]
		#		clk_shift_reg_val = [0b00000001 ,0b00000111 ,0b00000011 ,0b00000001 ,0b00000001 ,0b00000001 ,0b00000001 ,0b00111111 ,0b00110011 ,0b00101010 ,0b00000001 ,0b00001001][div_factorIndex]
		#		lsfr_max = [0b001 ,0b100 ,0b011 ,0b010 ,0b011 ,0b100 ,0b110 ,0b111 ,0b111 ,0b111 ,0b111 ,0b111][div_factorIndex]
		#		self.regs.JESD_SUBCHIP_REG132.spare_out=(clk_shift_reg_len<<23)+(clk_shift_reg_val<<15)+(lsfr_max<<12)+0xfff#0x201bfff
		#	else:
		#		self.regs.JESD_SUBCHIP_REG132.spare_out=0
		#else:
		#	self.regs.JESD_SUBCHIP_REG91.root_clk_dithered_mode_en=0
		self.deviceRefs.device.printCommentToLog("END: Done Setting FIFO and dither in JESD")
		
	#jesdSubchipInitConfig
	
	@funcDecorator
	def configureDataMux(self,rx_ch=0,fb_ch=0):
		""" "Configuring the Data Muxes" "Done configuring the Data Muxes" """  
		
		if(fb_ch==0):
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_is0=0
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_qs0=0
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_is1=1
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_qs1=1

			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_is0=2
			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_qs0=2
			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_is1=3
			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_qs1=3
			if(self.systemParams.ddcFactorFb[0]==1):
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is0=0#2
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs0=0#2
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is1=1#3
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs1=1#3
			else:
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is0=2
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs0=2
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is1=3
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs1=3

			if(self.systemParams.ddcFactorFb[1]==1):
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is0=2#0
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs0=2#0
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is1=3#1
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs1=3#1
			else:
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is0=0
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs0=0
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is1=1
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs1=1
			
		else:
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_is0=2
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_qs0=2
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_is1=3
			self.regs.JESD_SUBCHIP_REG68.mux_sel_for_2r1f0_fbab_qs1=3

			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_is0=0
			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_qs0=0
			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_is1=1
			self.regs.JESD_SUBCHIP_REG69.mux_sel_for_2r1f0_fbcd_qs1=1
			if(self.systemParams.ddcFactorFb[0]==1):
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is0=2#0
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs0=2#0
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is1=3#1
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs1=3#1
			else:
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is0=0
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs0=0
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_is1=1
				self.regs.JESD_SUBCHIP_REG70.mux_sel_for_2r1f1_fbab_qs1=1

			if(self.systemParams.ddcFactorFb[1]==1):
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is0=0#2
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs0=0#2
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is1=1#3
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs1=1#3
			else:
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is0=2
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs0=2
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_is1=3
				self.regs.JESD_SUBCHIP_REG71.mux_sel_for_2r1f1_fbcd_qs1=3
			
		if(self.systemParams.ddcFactorFb[0]==1):
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p0=0
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p1=2
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p2=1
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p3=3
		else:
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p0=0
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p1=1
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p2=2
			self.regs.JESD_SUBCHIP_REG58.mux_sel_for_fbab_p3=3
		
		if(self.systemParams.ddcFactorFb[1]==1):
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p0=0
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p1=2
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p2=1
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p3=3
		else:
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p0=0
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p1=1
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p2=2
			self.regs.JESD_SUBCHIP_REG59.mux_sel_for_fbcd_p3=3

		# To get AB Out in Decimation on top 4 lanes
		self.regs.JESD_SUBCHIP_REG60.mux_sel_for_rxa_i0 = 0+(2*rx_ch)
		self.regs.JESD_SUBCHIP_REG60.mux_sel_for_rxa_q0 = 0+(2*rx_ch)
		self.regs.JESD_SUBCHIP_REG61.mux_sel_for_rxa_i1 = 1+(2*rx_ch)
		self.regs.JESD_SUBCHIP_REG61.mux_sel_for_rxa_q1 = 1+(2*rx_ch)
		
		# To get CD Out in Decimation for M=8 Modes on top 4 lanes
		self.regs.JESD_SUBCHIP_REG62.mux_sel_for_rxb_i0 = 4+(2*rx_ch)
		self.regs.JESD_SUBCHIP_REG62.mux_sel_for_rxb_q0 = 4+(2*rx_ch)
		self.regs.JESD_SUBCHIP_REG63.mux_sel_for_rxb_i1 = 5+(2*rx_ch)
		self.regs.JESD_SUBCHIP_REG63.mux_sel_for_rxb_q1 = 5+(2*rx_ch)
			
			
		if(self.systemParams.ddcFactorRx[0]==1):
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p3 = 3
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p2 = 2
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p1 = 1
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p0 = 0
			
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p3 = 3
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p2 = 2
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p1 = 1
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p0 = 0
			
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_i0=0+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_q0=0+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_i1=1+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_q1=1+(2*rx_ch)
			
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_i0=4+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_q0=4+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_i1=5+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_q1=5+(2*rx_ch)
		else:
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p3 = 3
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p2 = 1
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p1 = 2
			self.regs.JESD_SUBCHIP_REG54.mux_sel_for_rxa_p0 = 0

			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p3 = 3
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p2 = 1
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p1 = 2
			self.regs.JESD_SUBCHIP_REG55.mux_sel_for_rxb_p0 = 0
			
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_i0=4
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_q0=4
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_i1=5
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_q1=5
			
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_i0=0
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_q0=0
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_i1=1
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_q1=1
			
		if(self.systemParams.ddcFactorRx[1]==1):
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p3 = 3
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p2 = 2
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p1 = 1
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p0 = 0
			
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p3 = 3
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p2 = 2
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p1 = 1
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p0 = 0
			
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_i0=0+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_q0=0+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_i1=1+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_q1=1+(2*rx_ch)
			
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_i0=4+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_q0=4+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_i1=5+(2*rx_ch)
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_q1=5+(2*rx_ch)
		else:
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p3 = 3
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p2 = 1
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p1 = 2
			self.regs.JESD_SUBCHIP_REG56.mux_sel_for_rxc_p0 = 0
			
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p3 = 3
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p2 = 1
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p1 = 2
			self.regs.JESD_SUBCHIP_REG57.mux_sel_for_rxd_p0 = 0

			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_i0=4
			self.regs.JESD_SUBCHIP_REG64.mux_sel_for_rxc_q0=4
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_i1=5
			self.regs.JESD_SUBCHIP_REG65.mux_sel_for_rxc_q1=5
			
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_i0=0
			self.regs.JESD_SUBCHIP_REG66.mux_sel_for_rxd_q0=0
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_i1=1
			self.regs.JESD_SUBCHIP_REG67.mux_sel_for_rxd_q1=1
		
		if self.systemParams.LMFSHdTx[0][1]=='8':
			self.regs.JESD_SUBCHIP_REG102.mux_sel_for_txc_i=2
			self.regs.JESD_SUBCHIP_REG102.mux_sel_for_txc_q=2
			self.regs.JESD_SUBCHIP_REG103.mux_sel_for_txd_i=3
			self.regs.JESD_SUBCHIP_REG103.mux_sel_for_txd_q=3
		
		if self.systemParams.jesdLoopbackEn==1:
			self.regs.JESD_SUBCHIP_REG72.loop_back_mode_tx0=1
			self.regs.JESD_SUBCHIP_REG72.loop_back_mode_tx1=1
			self.regs.JESD_SUBCHIP_REG73.loop_back_fifo_init_state=0
			self.regs.JESD_SUBCHIP_REG72.loopback_rx_tx_clk_div_override_ena=1		
	#configureDataMux

	@funcDecorator
	def configJesdTxLaneMux(self,laneMap):
		""" "Configuring JESD TX Lane Mux" "Done configuring JESD TX Lane Mux" """
		if laneMap==0:
			laneMap=range(8)
		elif laneMap==1:
			laneMap=(0,1,4,5,2,3,6,7)
		self.regs.JESD_SUBCHIP_REG74.txoctetpath0_sel=laneMap[0]
		self.regs.JESD_SUBCHIP_REG74.txoctetpath1_sel=laneMap[1]
		self.regs.JESD_SUBCHIP_REG75.txoctetpath2_sel=laneMap[2]
		self.regs.JESD_SUBCHIP_REG75.txoctetpath3_sel=laneMap[3]
		self.regs.JESD_SUBCHIP_REG76.txoctetpath4_sel=laneMap[4]
		self.regs.JESD_SUBCHIP_REG76.txoctetpath5_sel=laneMap[5]
		self.regs.JESD_SUBCHIP_REG77.txoctetpath6_sel=laneMap[6]
		self.regs.JESD_SUBCHIP_REG77.txoctetpath7_sel=laneMap[7]
		
		self.regs.JESD_SUBCHIP_REG78.txoctetpath0_clk_sel=laneMap.index(0) if 0 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG78.txoctetpath1_clk_sel=laneMap.index(1) if 1 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG79.txoctetpath2_clk_sel=laneMap.index(2) if 2 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG79.txoctetpath3_clk_sel=laneMap.index(3) if 3 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG80.txoctetpath4_clk_sel=laneMap.index(4) if 4 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG80.txoctetpath5_clk_sel=laneMap.index(5) if 5 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG81.txoctetpath6_clk_sel=laneMap.index(6) if 6 in laneMap else 0
		self.regs.JESD_SUBCHIP_REG81.txoctetpath7_clk_sel=laneMap.index(7) if 7 in laneMap else 0
	#configJesdTxLaneMux
	
	@funcDecorator
	def configJesdRxLaneMux(self,laneMap):
		""" "Configuring JESD RX Lane Mux" "Done configuring JESD RX Lane Mux" """
		if laneMap==0:
			laneMap=range(8)
		elif laneMap==1:
			laneMap=(0,1,4,5,2,3,6,7)
		self.regs.JESD_SUBCHIP_REG104.rxoctetpath0_sel=laneMap[0]
		self.regs.JESD_SUBCHIP_REG104.rxoctetpath1_sel=laneMap[1]
		self.regs.JESD_SUBCHIP_REG105.rxoctetpath2_sel=laneMap[2]
		self.regs.JESD_SUBCHIP_REG105.rxoctetpath3_sel=laneMap[3]
		self.regs.JESD_SUBCHIP_REG106.rxoctetpath4_sel=laneMap[4]
		self.regs.JESD_SUBCHIP_REG106.rxoctetpath5_sel=laneMap[5]
		self.regs.JESD_SUBCHIP_REG107.rxoctetpath6_sel=laneMap[6]
		self.regs.JESD_SUBCHIP_REG107.rxoctetpath7_sel=laneMap[7]

		self.regs.JESD_SUBCHIP_REG108.rxoctetpath0_clk_sel=laneMap[0]
		self.regs.JESD_SUBCHIP_REG108.rxoctetpath1_clk_sel=laneMap[1]
		self.regs.JESD_SUBCHIP_REG109.rxoctetpath2_clk_sel=laneMap[2]
		self.regs.JESD_SUBCHIP_REG109.rxoctetpath3_clk_sel=laneMap[3]
		self.regs.JESD_SUBCHIP_REG110.rxoctetpath4_clk_sel=laneMap[4]
		self.regs.JESD_SUBCHIP_REG110.rxoctetpath5_clk_sel=laneMap[5]
		self.regs.JESD_SUBCHIP_REG111.rxoctetpath6_clk_sel=laneMap[6]
		self.regs.JESD_SUBCHIP_REG111.rxoctetpath7_clk_sel=laneMap[7]
	#configJesdRxLaneMux


	@funcDecorator
	def configJesdTxSyncMux(self):
		""" "Configuring JESDTX Sync Mux" "Done configuring JESDTX Sync Mux" """
		self.regs.JESD_SUBCHIP_REG84.adc_jesd_sync_n_sel3=self.systemParams.jesdTxFBCDSyncMux
		self.regs.JESD_SUBCHIP_REG84.adc_jesd_sync_n_sel2=self.systemParams.jesdTxRxCDSyncMux
		self.regs.JESD_SUBCHIP_REG84.adc_jesd_sync_n_sel1=self.systemParams.jesdTxFBABSyncMux
		self.regs.JESD_SUBCHIP_REG84.adc_jesd_sync_n_sel0=self.systemParams.jesdTxRxABSyncMux
	#configJesdTxSyncMux
	
	@funcDecorator
	def configJesdRxSyncMux(self):
		""" "Configuring JESDRX Sync Mux" "Done configuring JESDRX Sync Mux" """
		# to get sync-out0 CMOS (ball Y5) and also on all pins
		
		if self.systemParams.jesdRxABSyncMux==self.systemParams.jesdRxCDSyncMux:
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n0=1
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n1=1
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n2=1
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n3=1
		else:
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n0=0
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n1=0
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n2=0
			self.regs.JESD_SUBCHIP_REG97.dac_jesd_sync_n_combine_on_n3=0
		self.regs.JESD_SUBCHIP_REG85.dac_jesd_sync_n_sel0=self.systemParams.jesdRxABSyncMux
		self.regs.JESD_SUBCHIP_REG85.dac_jesd_sync_n_sel1=self.systemParams.jesdRxABSyncMux
		self.regs.JESD_SUBCHIP_REG85.dac_jesd_sync_n_sel2=self.systemParams.jesdRxCDSyncMux
		self.regs.JESD_SUBCHIP_REG85.dac_jesd_sync_n_sel3=self.systemParams.jesdRxCDSyncMux
	#configJesdRxSyncMux
	
#jesdSubchipLib