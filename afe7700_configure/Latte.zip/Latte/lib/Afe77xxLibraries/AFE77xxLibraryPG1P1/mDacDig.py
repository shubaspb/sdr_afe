from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import random
import math

class dacDigLib(projectBaseClass):
	"""Contains DAC Digital specific functions. self.regs=device.TX.DAC_DIG_AB.tx_top """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs.tx_top
		self.topno=topno
	#__init__
	
	@funcDecorator
	def clockGate(self,clk_dis):
		"""clockGate"""
		self.regs.Register50781_604h.TxClkDiv2P0Gate	=	clk_dis
		self.regs.Register50781_604h.TxClkDiv2P1Gate	=	clk_dis
		self.regs.Register50781_604h.TxClkDiv4P0Gate	=	clk_dis
		self.regs.Register50781_604h.TxClkDiv4P1Gate	=	clk_dis
		self.regs.Register50781_604h.TxClkDiv4P2Gate	=	clk_dis
		self.regs.Register50781_604h.TxClkDiv4P3Gate	=	clk_dis
	#clockGate
	
	@funcDecorator
	def configTxDig(self):
		""" 'Configuring the TX Digital' 'Done configuring the TX Digital' """  
		self.clockGate(0)
		interpMode=self.systemParams.ducFactorTx[self.topno]
		InterpStg0Mode=self.systemParams.halfRateModeTx
	
		(found,(stage1Setting,stage1p5Setting,stage2Setting,stage3Setting,stage4Setting))=self.checkValidityOfDigChain(2,interpMode,self.systemParams.halfRateModeTx)
		if found==False:
			error(r"Didnt find the Correct Setting for TX Interpolation chain: "+str(interpMode))
		
		self.regs.Register51043_104h.InterpStg0Mode=InterpStg0Mode
		self.regs.Register51043_104h.InterpStg1p5Bypass=(2,1).index(stage1p5Setting)
		self.regs.Register51043_104h.InterpStg2Mode=(1,1,round(7.0/6,4),round(9.0/8,4)).index(round(stage2Setting,4))
		self.regs.Register51043_104h.InterpStg3Val=(1,2,3,1.5).index(stage3Setting)
		self.regs.Register51043_104h.InterpStg4Mode=(1,2).index(stage4Setting)
		if round(interpMode,3) in (4, 4.5, 4.667, 2, 2.25, 2.333):
			self.regs.Register51043_104h.InterpStg3ClkCfg=0
		elif round(interpMode,3) in (6, 6.75, 7, 3, 3.375, 3.5):
			self.regs.Register51043_104h.InterpStg3ClkCfg=1
		elif round(interpMode,3) in (8, 9, 9.333, 16, 18, 18.667):
			self.regs.Register51043_104h.InterpStg3ClkCfg=2
		else:#(12, 13.5, 14, 24, 27, 28)
			self.regs.Register51043_104h.InterpStg3ClkCfg=3

		if round(interpMode,3) in (4, 4.5, 4.667, 6, 6.75, 7):
			self.regs.Register51043_104h.InterpStg3OutFIFONumRead=1
		else:
			self.regs.Register51043_104h.InterpStg3OutFIFONumRead=0
		
		self.regs.RegTxInterpCfg5.RdPtrOffDigInpAsyncFIFO=8
		self.regs.RegTxInterpCfg5.RdPtrOffstg1p5InFIFO=8
		self.regs.RegTxInterpCfg5.RdPtrOffstg2InFIFO=8
		self.regs.RegTxInterpCfg5.RdPtrOffStg4OutFIFO=64
		if self.systemStatus.chipVersion>0x10:
			self.regs.RegTxInterpCfg5.RdPtrOffDigOutAsyncFIFO=3
		else:
			self.regs.RegTxInterpCfg5.RdPtrOffDigOutAsyncFIFO=2
			
		if round(interpMode,3) in (3, 3.375, 3.5, 8, 9, 9.333, 16, 18, 18.667):
			self.regs.RegTxInterpCfg5.RdPtrOffStg3OutFIFO=20
		elif round(interpMode,3) in (4, 4.5, 4.667):
			self.regs.RegTxInterpCfg5.RdPtrOffStg3OutFIFO=24
		else:
			self.regs.RegTxInterpCfg5.RdPtrOffStg3OutFIFO=12
		
		self.regs.Tx1DigGainCtrl.BlockEnable=1 ###To enable dig gain
		self.regs.Tx1DigGainCtrl.LutUpdateMode=1
		self.regs.Tx2DigGainCtrl.BlockEnable=1 ###To enable dig gain
		self.regs.Tx2DigGainCtrl.LutUpdateMode=1
		#self.regs.RegTxInterpCfg5.RdPtrOffStg0FIFO
		
	#configTxDig

	@funcDecorator
	def ditherEn(self,en=1,DitherMultSel=4):
		if en==1:
			self.regs.Register50805_610h.Property50805_25_0=67108863
			self.regs.Register50806_615h.Property50806_8_8=1
			self.regs.Register50806_615h.Property50806_8_8=0
			self.regs.Register50806_615h.Property50812_0_0=1
			self.regs.Register50806_615h.Property50811_6_4=DitherMultSel
		else:
			self.regs.Register50806_615h.Property50806_8_8=1
			self.regs.Register50806_615h.Property50806_8_8=0
			self.regs.Register50806_615h.Property50812_0_0=0
	#ditherEn
	
	
	@funcDecorator
	def configureSrBlock(self):
		""" "Configuring SR Block" "Done Configuring SR Block" """
		
		self.regs.Register51278_210h.alarmMask              = 0x0F80 
		if self.systemParams.srConfigParams[(self.topno*2)+0]['mode']==10:
			self.regs.Register51278_210h.Property51287_0_0           = 1
		self.regs.Register51278_210h.AmplMode               = 1      ##  Linear
		self.regs.Register51278_210h.GainStepSize           = self.systemParams.srConfigParams[(self.topno*2)+0]['GainStepSize']      ##  5 value jump step
		self.regs.Register51278_210h.AttnStepSize           = self.systemParams.srConfigParams[(self.topno*2)+0]['AttnStepSize']      ##  5 value jump step
		self.regs.Register51278_210h.AmplUpdateCycles       = math.ceil(self.systemParams.srConfigParams[(self.topno*2)+0]['AmplUpdateCycles']/(self.systemParams.Fs*0.5/self.systemParams.ducFactorTx[self.topno]))
		self.regs.Register51278_210h.MultDataMode           = 1      ##  1 LGS mode, default value
		if self.systemParams.srConfigParams[(self.topno*2)+0]['mode']==10:
			self.regs.Register51278_210h.Property51298_30_16 = self.systemParams.srConfigParams[(self.topno*2)+0]['threshold']*655.36  ##  Threshold
		self.regs.Register51278_210h.fsmWaitCntr            = 19     ##  50ns for 2.7ns clock counter
		self.regs.Register51278_210h.BlkEnable              = self.systemParams.srConfigParams[(self.topno*2)+0]['enable']      ##  Block enable
		
		self.regs.Register52409_410h.alarmMask              = 0x0F80 
		if self.systemParams.srConfigParams[(self.topno*2)+0]['mode']==10:
			self.regs.Register52409_410h.Property52445_0_0           = 1
		self.regs.Register52409_410h.AmplMode               = 1      ##  Linear
		self.regs.Register52409_410h.GainStepSize           = self.systemParams.srConfigParams[(self.topno*2)+1]['GainStepSize']      ##  5 value jump step
		self.regs.Register52409_410h.AttnStepSize           = self.systemParams.srConfigParams[(self.topno*2)+1]['AttnStepSize']      ##  5 value jump step
		self.regs.Register52409_410h.AmplUpdateCycles       = math.ceil(self.systemParams.srConfigParams[(self.topno*2)+1]['AmplUpdateCycles']/(self.systemParams.Fs/self.systemParams.ducFactorTx[self.topno]))
		self.regs.Register52409_410h.MultDataMode           = 1      ##  1 LGS mode, default value
		if self.systemParams.srConfigParams[(self.topno*2)+0]['mode']==10:
			self.regs.Register52409_410h.Property52446_30_16 = self.systemParams.srConfigParams[(self.topno*2)+1]['threshold']*655.36  ##  Threshold
		self.regs.Register52409_410h.fsmWaitCntr            = 19     ##  50ns for 2.7ns clock counter
		self.regs.Register52409_410h.BlkEnable              = self.systemParams.srConfigParams[(self.topno*2)+1]['enable']      ##  Block enable
	#configureSrBlock
	
#dacDigLib