from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import random
import math

class fbDigLib(projectBaseClass):
	"""Contains FB DIG specific functions. self.regs=device.FB.FB_DIG.FB_DIG """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
	#__init__


	@funcDecorator
	def setNcoWord(self,ncoFreq):
		""" "Set FB NCO Word" """
		ncoFreqWord=int(round(ncoFreq*2**32/self.systemParams.Fs))
		ncoFreq=ncoFreqWord*self.systemParams.Fs*1.0/(2**32)
		info("Set FB "+str(self.topno)+" to Freq(MHz): "+str(ncoFreq))
		self.systemParams.fbNco[self.topno]=ncoFreq
		self.regs.FBDigCfg2.FBDigMixerFreqWord=ncoFreqWord&(2**32-1)
	#setNcoWord
		
	@funcDecorator
	def configFbDig(self):
		""" "Configuring the FB Digital" "Done configuring the FB Digital" """  
		decimMode      =self.systemParams.ddcFactorFb[self.topno]
		halfRateMode   =self.systemParams.halfRateModeFb
		
		self.regs.FBDigCfg6.FBDigClkDiv2P0Gate=0
		self.regs.FBDigCfg6.FBDigClkDiv2P1Gate=0
		self.regs.FBDigCfg6.FBDigClkDiv4P0Gate=0
		self.regs.FBDigCfg6.FBDigClkDiv4P1Gate=0
		self.regs.FBDigCfg6.FBDigClkDiv4P2Gate=0
		self.regs.FBDigCfg6.FBDigClkDiv4P3Gate=0
		
		if self.systemParams.ddcFactorFb[self.topno]!=1:
			self.regs.FBDigCfg3.FBDigJESDDataSel=0
		else:
			self.regs.FBDigCfg3.FBDigJESDDataSel=2
		
		(found,(stage1Setting,stage2Setting,stage3Setting,stage3p5Setting))=self.checkValidityOfDigChain(1,decimMode,halfRateMode)
		if found==False and self.systemParams.ddcFactorFb[self.topno]!=1:
			error(r"Didnt find the Correct Setting for Fb Decim chain: "+str(decimMode))
			
		self.regs.FBDigCfg3.FBDecStg1Byp=(2,1).index(stage1Setting)
		self.regs.FBDigCfg3.FBDecStg2Mode=(2.0,3.0).index(stage2Setting)
		self.regs.FBDigCfg3.FBDecStg3Mode=(1.0,1.0,round(7.0/6,4),round(9.0/8,4)).index(round(stage3Setting,4))		
		self.regs.FBDigCfg3.FBStg3pt5Bypass=(2,1).index(stage3p5Setting)
		
		self.regs.FBDigCfg3.FBDecADCRate=halfRateMode
		self.setNcoWord(self.systemParams.fbNco[self.topno])
		
		self.regs.FBDigCfg4.FBDecStg1OutFIFORdPtrVal=0
		self.regs.FBDigCfg4.FBDecStg3OutFIFORdPtrVal=7
		if self.systemStatus.chipVersion>0x10:
			self.regs.FBDigCfg4.FBAsyncFIFORdPtrVal=3
		else:
			self.regs.FBDigCfg4.FBAsyncFIFORdPtrVal=2
			
		self.regs.FBDigCfg5.FBDigClkLFSRSeed=527284091
		self.regs.FBDigCfg5.FBDigClkLFSRLoad=0
		self.regs.FBDigCfg5.FBDigClkLFSRLoad=1
		self.regs.FBDigCfg5.FBDigClkLFSRLoad=0
		#self.regs.Register618_1BCh.Property619_24_24=0
		self.regs.FBDigCfg7.FBDigMixerInteger=0
		self.regs.FBDigCfg7.FBDigMixerFrac=0
		self.regs.FBDigCfg7.FBDigMixerDelta=0
		self.regs.FBDigCfg7.FBDigMixerCorrEn=0
		self.regs.FBDigCfg1.FBDigMixerPhaseVal=0
	#configFbDig
	
	@funcDecorator
	def setFbDigGain(self,enable,digGain):
		device.FB[0].FB_DIG.FB_DIG.FBDgcRegisters.FBDgcEnable=enable
		device.FB[0].FB_DIG.FB_DIG.FBDgcRegisters.FBDgcHWEn=enable
		if digGain<-3:
			device.FB[0].FB_DIG.FB_DIG.FBDgcRegisters.FBDgcLUTSel=(2*digGain)+17
			device.FB[0].FB_DIG.FB_DIG.Register618_1BCh.Property619_24_24=1
		else:
			device.FB[0].FB_DIG.FB_DIG.FBDgcRegisters.FBDgcLUTSel=(2*digGain)+5
			device.FB[0].FB_DIG.FB_DIG.Register618_1BCh.Property619_24_24=0
	#setFbDigGain
	
#fbDigLib