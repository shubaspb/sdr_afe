from globalDefs import *
from tswDecode import lteDecode
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mSetupParams import setupJesdParams
from mSetupParams import setupParams
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import numpy as np
import random,math
import os

class fpgaLib_J58(projectBaseClass):
	"""Contains FPGA specific functions. self.regs=myfpga """
	@initDecorator
	def __init__(self,regs,fpgaParams):
		self.fpgaParams=fpgaParams
		self.regs=regs
		self.selectedDacLanes=[]
		self.selectedAdcLanes=[]
		self.dacLaneOffset=0
		self.sendDataMode=2
		self.dacTones={}
		self.dacTones['TXA_B0_SIG']=10
		self.dacTones['TXA_B1_SIG']=10
		self.dacTones['TXB_B0_SIG']=10
		self.dacTones['TXB_B1_SIG']=10
		self.dacTones['TXC_B0_SIG']=10
		self.dacTones['TXC_B1_SIG']=10
		self.dacTones['TXD_B0_SIG']=10
		self.dacTones['TXD_B1_SIG']=10
		self.dacTones['TXA_B0_AMP']=-10
		self.dacTones['TXA_B1_AMP']=-10
		self.dacTones['TXB_B0_AMP']=-10
		self.dacTones['TXB_B1_AMP']=-10
		self.dacTones['TXC_B0_AMP']=-10
		self.dacTones['TXC_B1_AMP']=-10
		self.dacTones['TXD_B0_AMP']=-10
		self.dacTones['TXD_B1_AMP']=-10
		
	#__init__

	@funcDecorator
	def reset(self):
		info("Resetting FPGA.")
		r = self.regs.Reconnect()
		self.regs.interfaceHandle.LaneRate=0
		self.regs.interfaceHandle.setLaneRate(LaneRate=setupParams.dutInstances[0].systemStatus.laneRateRx[0],ref_clk = setupParams.fpgaRefClk)
		self.powerDownUnusedLanes()
		self.setLanePolarities()
		self.regs.interfaceHandle.Set_PHY_TX_Driver_Settings(self.getUsedLanes(),0x1F,0xF,0x0)
		self.rxSyncCapture(61.44,2**20)
		return 1
	#reset
	
	@funcDecorator
	def checkVersion(self,instanceNo=0):
		bitFileVersion=self.regs.interfaceHandle.bitFileVersion
		if setupParams.dutInstances[0].systemParams.jesdProtocol==0 and bitFileVersion&0xffff!=0x204b:
			error("Mismatch in the FPGA bit file version. AFE JESD Protocol is 204B but the FPGA bit file is "+hex(bitFileVersion&0xffff))
			return -1
		elif setupParams.dutInstances[0].systemParams.jesdProtocol==2 and bitFileVersion&0xffff!=0x204c:
			error("Mismatch in the FPGA bit file version. AFE JESD Protocol is 204C but the FPGA bit file is "+hex(bitFileVersion&0xffff))
			return -1
		return 1
		
	
	@funcDecorator
	def fpgaTxSendK(self,en=[True]*2):	
		#self.deviceRefs.device.printCommentToLog("FPGA Sending K characters to all the 8 lanes")	
		if True in en:
			self.regs.interfaceHandle.WriteControlRegister(self.regs.interfaceHandle.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000000F]) 
		else:
			self.regs.interfaceHandle.WriteControlRegister(self.regs.interfaceHandle.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000010F]) 
	
	#fpgaTxSendK
	
	@funcDecorator
	def selectCapture(self,LMFSHd,lanes,converterOrder,dutNo=0):
		""" Assumes that lanes are consecutive. Looks at the first element of the list and number of lanes only. """
		myfpga=self.regs
		laneSettings=setupJesdParams.boardLaneSettings[setupParams.boardType][dutNo]['tx_lanes']
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		
		lanes=[laneSettings[i] for i in lanes]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if S%2==0 or '_DUP' in LMFSHd :
			myfpga.sampleConverterOrderReverse=1
		#self.regs.interfaceHandle.fpgaRxConfig(convertersPerLane=(M*1.0/L),F=F)
		#self.fpgaRxConfig()
		self.regs.interfaceHandle.selectRxLanes(lanes)
		if resolution==48 or "_DUP" in LMFSHd:
			myfpga.LMFSHd=str(L)+str(M)+str(F)+str(S*2)+str(Hd)
			myfpga.dropAlternateSamplesPerConverter=1
		else:
			myfpga.LMFSHd=LMFSHd
			myfpga.dropAlternateSamplesPerConverter=0
		myfpga.converterOrder=converterOrder
		self.selectedAdcLanes=lanes[:]
	#selectCapture
	
	@funcDecorator
	def selectDrive(self,LMFSHd,lanes,converterOrder,dutNo=0):	
		laneSettings=setupJesdParams.boardLaneSettings[setupParams.boardType][dutNo]['rx_lanes']
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		
		lanes=[laneSettings[i] for i in lanes]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		self.regs.interfaceHandle.fpgaTxConfig(convertersPerLane=(M*1.0/L),F=F)
		self.regs.interfaceHandle.selectTxLanes(lanes)
		self.selectedDacLanes=lanes[:]
	#selectDrive	
	
	@funcDecorator
	def selectDriveLanes(self,lanes,jesdProtocol,dutNo=0):	
		laneSettings=setupJesdParams.boardLaneSettings[setupParams.boardType][dutNo]['rx_lanes']
		systemParams=setupParams.dutInstances[dutNo].systemParams		
		lanes=[laneSettings[i] for i in lanes]
		if jesdProtocol==2:
			self.regs.interfaceHandle.SetupStreamSwitches_TX('204C',lanes,self.regs.interfaceHandle.LaneRate)
		else:
			self.regs.interfaceHandle.SetupStreamSwitches_TX('204B',lanes,self.regs.interfaceHandle.LaneRate)
		self.selectedDacLanes=lanes[:]
	#selectDriveLanes
		
	@funcDecorator
	def fpgaRxConfig(self,rxOrFb=0,instanceNo=0,dutNo=0):
		""" Configuring FPGA JESD RX
		rxOrFb if it is RX or FB. instanceNois 0 or 1. """
		instanceNo=instanceNo/2
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		if rxOrFb==0:
			LMFSHd=systemParams.LMFSHdRx[instanceNo]
			laneRate=systemStatus.laneRateRx[instanceNo]
		else:
			LMFSHd=systemParams.LMFSHdFb[instanceNo]
			laneRate=systemStatus.laneRateFb[instanceNo]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if self.regs.interfaceHandle.LaneRate!=laneRate:
			self.regs.interfaceHandle.setLaneRate(LaneRate=laneRate,ref_clk = setupParams.fpgaRefClk)
		self.regs.interfaceHandle.fpgaRxConfig(convertersPerLane=(M*1.0/L),F=F,K=systemParams.jesdK[instanceNo],scrambler=systemParams.jesdScr[instanceNo],jesdProtocol=systemParams.jesdProtocol)
	#fpgaRxConfig

	@funcDecorator
	def fpgaTxConfig(self,instanceNo=0,dutNo=0):
		""" Configuring FPGA JESD TX """
		instanceNo=instanceNo/2
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		LMFSHd=systemParams.LMFSHdTx[2*instanceNo]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if self.regs.interfaceHandle.LaneRate!=systemStatus.laneRateTx[instanceNo]:
			self.regs.interfaceHandle.setLaneRate(LaneRate=systemStatus.laneRateTx[instanceNo],ref_clk = setupParams.fpgaRefClk)
		self.regs.interfaceHandle.fpgaTxConfig(convertersPerLane=(M*1.0/L),F=F,K=systemParams.jesdK[instanceNo],scrambler=systemParams.jesdScr[instanceNo],jesdProtocol=systemParams.jesdProtocol)
	#fpgaTxConfig
	
	@funcDecorator
	def compareFpgaTxConfig(self,instanceNo=0,dutNo=0):
		instanceNo=instanceNo/2
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		LMFSHd=systemParams.LMFSHdTx[2*instanceNo]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		jesdTxSettings=self.regs.interfaceHandle.jesdTxSettings
		if self.regs.interfaceHandle.LaneRate==systemStatus.laneRateTx[instanceNo] and jesdTxSettings['convertersPerLane']==(M*1.0/L) and jesdTxSettings['scr']==systemParams.jesdScr[instanceNo] and jesdTxSettings['F']==F and jesdTxSettings['K']==systemParams.jesdK[instanceNo] and jesdTxSettings['protocol']==systemParams.jesdProtocol:
			return True
		else:
			return False
	#compareFpgaTxConfig
	
	@funcDecorator
	def compareFpgaRxConfig(self,rxFb,instanceNo=0,dutNo=0):
		instanceNo=instanceNo/2
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		LMFSHd=systemParams.LMFSHdRx[instanceNo]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		jesdRxSettings=self.regs.interfaceHandle.jesdRxSettings
		if self.regs.interfaceHandle.LaneRate==systemStatus.laneRateRx[instanceNo] and jesdRxSettings['convertersPerLane']==(M*1.0/L) and jesdRxSettings['scr']==systemParams.jesdScr[instanceNo*2] and jesdRxSettings['F']==F and jesdRxSettings['K']==systemParams.jesdK[instanceNo] and jesdRxSettings['protocol']==systemParams.jesdProtocol:
			return True
		else:
			return False
	#compareFpgaRxConfig

	@funcDecorator
	def jesdConvertersToLanes(self,LMFSHd,converterWiseData):
		""" This function packs the converterwise data into lanes as per the LMFSHd provided. It returns an array of lane wise data. The lane wise data is an array of 16-bit data. """
		
		inputDataResolution=16
		jesdModeIn=LMFSHd.lower()
		if "_" in jesdModeIn:
			jesdMode=jesdModeIn[:jesdModeIn.find("_")]
		else:
			jesdMode=jesdModeIn
		L=int(jesdMode[0])
		M=int(jesdMode[1])
		if len(jesdMode)==5:
			F=int(jesdMode[2])
			S=int(jesdMode[3])
			Hd=int(jesdMode[4])
		elif len(jesdMode)==6:
			F=int(jesdMode[2:4])
			S=int(jesdMode[4])
			Hd=int(jesdMode[5])
		
		if M!=len(converterWiseData):
			error("The number of arrays passed and M given doesn't match. Please send an array consisting of converter wise data. No values written to FPGA.")
			#return
		bits=16
		resolution=int(round(16*(F*L)/(M*S*2.0)))
		totalSampleNumber=len(converterWiseData)*len(converterWiseData[0])
		
		if resolution==16 and M==L:
			laneWiseData=converterWiseData
		elif resolution==16 and M==2*L:
			laneWiseData=[]
			for i in range(L):
				laneData=[0]*(2*len(converterWiseData[0]))
				laneData[::2]=converterWiseData[2*i]
				laneData[1::2]=converterWiseData[(2*i)+1]
				laneWiseData.append(laneData)
		elif resolution==16 and M==4*L:
			laneWiseData=[]
			for i in range(L):
				laneData=[0]*(4*len(converterWiseData[0]))
				laneData[::4]=converterWiseData[4*i]
				laneData[1::4]=converterWiseData[(4*i)+1]
				laneData[2::4]=converterWiseData[(4*i)+2]
				laneData[3::4]=converterWiseData[(4*i)+3]
				laneWiseData.append(laneData)
		else:
			converterInterleavedData=np.zeros(totalSampleNumber,dtype=int)
			for i in range(M):
				if (len(converterWiseData[i])*resolution/8.0)%1!=0:
					converterWiseData[i]=converterWiseData[i][:1-(len(converterWiseData[i])*resolution%8)]
				if S == 2:
					converterInterleavedData[2*i::2*M]=converterWiseData[i][0::2]
					converterInterleavedData[2*i+1::2*M]=converterWiseData[i][1::2]
				elif S ==4:
					converterInterleavedData[4*i::4*M]=converterWiseData[i][0::4]
					converterInterleavedData[4*i+1::4*M]=converterWiseData[i][1::4]
					converterInterleavedData[4*i+2::4*M]=converterWiseData[i][2::4]
					converterInterleavedData[4*i+3::4*M]=converterWiseData[i][3::4]
				else:
					converterInterleavedData[i::M]=converterWiseData[i]
			
			laneInterleavedDataBits=[]
			for sample in converterInterleavedData:
				if resolution<inputDataResolution and self.sendDataMode!=0:
					if self.sendDataMode==1:
						sample=int(round(sample*1.0/(2**(inputDataResolution-resolution))))<<(inputDataResolution-resolution)
					else:
						sample=sample+random.randint(0,15)
				#exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(sample&(2**inputDataResolution-1))")
				exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(int((sample)+(2**(bits-1)))^(1<<(bits-1))&(2**inputDataResolution-1))")
				if resolution<inputDataResolution:
					resolutionEff=resolution
				else:
					resolutionEff=inputDataResolution
				for i in range(resolutionEff):
					laneInterleavedDataBits.append(sampleBits[i])
				if inputDataResolution<resolution:
					for i in range(resolution-inputDataResolution):
						laneInterleavedDataBits.append('0')
					
			if len(laneInterleavedDataBits)%(8*F*L)!=0:
				for i in range(len(laneInterleavedDataBits)%(8*F*L)):
					laneInterleavedDataBits.append('0')

			laneInterleavedDataOctets=[]
			laneInterleavedDataBits=np.array(laneInterleavedDataBits)
			laneInterleavedDataBits=laneInterleavedDataBits.reshape(len(laneInterleavedDataBits)/8,8)
			for octet in laneInterleavedDataBits:
				octetStr=""
				for i in range(8):
					octetStr+=str(octet[i])
				laneInterleavedDataOctets.append(int(octetStr,2))

			laneWiseDataOctets=[]
			for lane in range(L):
				laneData=[0]*(len(laneInterleavedDataOctets)/L)
				for octet in range(F):
					laneData[octet::F]=laneInterleavedDataOctets[((lane*F)+octet)::(L*F)]
				laneWiseDataOctets.append(laneData)
			
			
			laneWiseData=[]
			for lane in range(L):
				laneData=[]
				for sample in range(0,len(laneWiseDataOctets[0])/2):
					laneData.append((laneWiseDataOctets[lane][sample*2]<<8)+laneWiseDataOctets[lane][(2*sample)+1])
				laneWiseData.append(laneData)
		return laneWiseData
			
	# # laneDataRet=jesdConvertersToLanes(LMFSHd,converterWiseData)

	# def SwapByteOrder(self,y):
		# dt = np.dtype('uint16')	
		# dt = dt.newbyteorder(self.regs.interfaceHandle.byteorder)	
		# y=np.frombuffer(y.tobytes(),dt)
		# return y
		
	# def ConcatenateChannels(self,Channels):	
		# z = np.concatenate(Channels)
		# z = np.frombuffer(z.reshape([len(Channels),len(Channels[0])]).transpose().tobytes(),'uint32')
		# return z

	# def LoadToneFromFile(self,filename):	
		# y = np.genfromtxt(filename)
		# return np.around(y).astype('int16')
		
	@funcDecorator
	def toneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=4096,fsBaseBand=491.52):
		bits=16
		n = int(NumberOfSamples/2)
		m = int((fInBaseBand/fsBaseBand)*n)	
		fInBaseBand=(m/float(n)*fsBaseBand)
	
		ampl=10**(ampl_dBFs/20.0)
		
		signal = np.zeros(NumberOfSamples,dtype=complex)
		for x in range(NumberOfSamples):
			signal[x] = np.round((2**(bits-1))*ampl*np.e**(1j*2*np.pi*(fInBaseBand/fsBaseBand)*x))
		realSignal=signal.real
		imagSignal=signal.imag
		log("loaded")
		return([realSignal,imagSignal])
	
	# @funcDecorator
	# def multiToneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=24*192,fsBaseBand=491.52):
		# bits=16
		# n = int(NumberOfSamples/2)
		# ampl=[]
		# for i in range(len(fInBaseBand)):
			# m = int((fInBaseBand[i]/fsBaseBand)*n)	
			# fInBaseBand[i]=(m/float(n)*fsBaseBand)
			# if i>=len(ampl_dBFs):
				# ampl_dBFs.append(-20.0)
			# ampl.append(10**(ampl_dBFs[i]/20.0))
		# ### Max samples 32k for I and 32k for Q for 12410 mode. 64k per lane for 0th and 1st lanes. Same data on 2nd and 3rd lanes as on 0th and 1st lanes respectively
		# signal = np.zeros(NumberOfSamples,dtype=complex)
		# for x in range(NumberOfSamples):
			# signal[x]=0
			# for i in range(len(fInBaseBand)):
				# signal[x] += np.round((2**(bits-1))*ampl[i]*np.e**(1j*2*np.pi*(fInBaseBand[i]/fsBaseBand)*x))
		# realSignal=signal.real
		# imagSignal=signal.imag
		# return([realSignal,imagSignal])
	
	# @funcDecorator
	# def loadSignalToFpgaBackup(self,laneWiseData,M,nC):
			
		# laneWiseData = np.asarray(laneWiseData)		
		# a = []
		# for l in laneWiseData:
			# b = [l[0::2],l[1::2]]
			# a= a + b
		# laneWiseData = np.asarray(a)
		

		# laneWiseData8Bit=[]
		# for laneData in laneWiseData:
			# laneData8Bit=[0]*(2*len(laneData))
			# laneData8BitPreOrder=list(np.frombuffer(np.asarray(laneData,'uint16'),dtype='uint8'))
			# if self.regs.interfaceHandle.jesdRxSettings['protocol']==2:	
				# laneData8Bit[0::4]=laneData8BitPreOrder[3::4]
				# laneData8Bit[1::4]=laneData8BitPreOrder[2::4]
				# laneData8Bit[2::4]=laneData8BitPreOrder[1::4]
				# laneData8Bit[3::4]=laneData8BitPreOrder[0::4]	
			# else:
				# laneData8Bit=laneData8BitPreOrder
			# laneWiseData8Bit.append(laneData8Bit)

		# laneWiseData8BitPreOrder = np.asarray(laneWiseData8Bit)
		# if self.regs.interfaceHandle.jesdRxSettings['protocol']==2:
			# laneWiseData8Bit[0::2]=laneWiseData8BitPreOrder[1::2]
			# laneWiseData8Bit[1::2]=laneWiseData8BitPreOrder[0::2]
			
		# laneWiseData16Bit =[]
		# for laneData in laneWiseData8Bit:
			# laneData16Bit=[0]*(len(laneData)/2)
			# for sample in range(0,len(laneData),2):
				# laneData16Bit[sample/2] = laneData[sample+1]+(laneData[sample]<<8)
			# laneWiseData16Bit.append(laneData16Bit)
		# laneWiseData16Bit = np.asarray(laneWiseData16Bit)
		
		# y   = self.ConcatenateChannels(laneWiseData16Bit.astype('uint16'))
		
		# yFinal =  np.zeros(np.shape(y))
		# if M>nC:
			# for i in range(1,M/2-1):
				# if i%2==0:
					# yFinal[i::M/2] = y[i/2::M/2]
				# else:
					# yFinal[i::M/2] = y[i/2+M/4::M/2]
			# yFinal[0::M/2]=y[0::M/2]
			# yFinal[M/2-1::M/2]=y[M/2-1::M/2]
		# else:
			# yFinal = y
			
		# self.regs.interfaceHandle.StopDACSamples()
		# log("DAC Start")
		# self.regs.interfaceHandle.StartDAC(yFinal,force=1)
	# #loadSignalToFpgaBackup
	
	@funcDecorator
	def loadSignalToFpga(self,laneWiseData):
		if (len(laneWiseData)%2 == 1) and self.regs.interfaceHandle.jesdRxSettings['protocol']==0:
			laneWiseData += [[0]*len(laneWiseData[0])]

		for i in range(len(laneWiseData)):
			laneWiseData[i]=list(laneWiseData[i][self.dacLaneOffset:])+list(laneWiseData[i][:self.dacLaneOffset])
		laneInterleavedData=[0]*(len(laneWiseData)*len(laneWiseData[0])/2)	#Will be in 32 bit
		laneNo=0
		if self.regs.interfaceHandle.jesdRxSettings['protocol']==0:	
			for laneData in laneWiseData:
				laneData8BitPreOrder=list(np.frombuffer(np.asarray(laneData,'uint16'),dtype='uint8'))
				laneData8Bit=[0]*len(laneData8BitPreOrder)
				laneData8Bit[::2]=laneData8BitPreOrder[1::2]
				laneData8Bit[1::2]=laneData8BitPreOrder[0::2]
				laneInterleavedData[laneNo::len(laneWiseData)]=list(np.frombuffer(np.asarray(laneData8Bit,'uint8'),dtype='uint32'))
				laneNo+=1
		else:
			laneInterleavedData=[0]*(len(laneWiseData)*len(laneWiseData[0])/2)	#Will be in 32 bit
			laneNo=0
			for laneData in laneWiseData:
				laneData16BitPostOrder=[0]*len(laneData)
				laneData16BitPostOrder[0::2]=laneData[1::2]
				laneData16BitPostOrder[1::2]=laneData[0::2]
				laneData32Bit=list(np.frombuffer(np.asarray(laneData16BitPostOrder,'uint16'),dtype='uint32'))
				laneInterleavedData[laneNo*2::len(laneWiseData)*2]=laneData32Bit[1::2]
				laneInterleavedData[laneNo*2+1::len(laneWiseData)*2]=laneData32Bit[0::2]
				laneNo+=1
		
		self.regs.interfaceHandle.StopDACSamples()
		log("DAC Start")
		self.regs.interfaceHandle.StartDAC(np.asarray(laneInterleavedData),force=1)
	# #loadSignalToFpga
	# @funcDecorator
	# def loadSignalToFpgaOld(self,laneWiseData):
		# laneWiseData = np.asarray(laneWiseData)		
		# a = []
		# for l in laneWiseData:
			# b = [l[0::2],l[1::2]]
			# a= a + b
		# laneWiseData = np.asarray(a)
		# for i in range(len(laneWiseData)):
			# laneWiseData[i] = self.SwapByteOrder(laneWiseData[i].astype('uint16'))	
		
		# y   = self.ConcatenateChannels(laneWiseData.astype('uint16'))
		# self.regs.interfaceHandle.StopDACSamples()
		# log("DAC Start")
		# self.regs.interfaceHandle.StartDAC(y,force=1)
	# #loadSignalToFpgaOld
	
	def SendConvertorData(self,LMFSHd,ConvertorData):
	
		M        = int(LMFSHd[1])
		nC       = len(ConvertorData)
		
		converterWiseData=[]
		for i in range(M):
			converterWiseData.append(ConvertorData[i%len(ConvertorData)])
			
		laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData)
		self.loadSignalToFpga(laneWiseData)
		
	@funcDecorator
	def sendSingleTone(self,twoTNo,fin1,amp1,fin2,amp2,fin3="NC",amp3="NC",fin4="NC",amp4="NC",Samples=24*192):	
		LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,Samples)				
		tone1=self.toneGen(fin1,amp1,nSamples,fBand1)
		tone2=self.toneGen(fin2,amp2,nSamples,fBand2)
		twoTones=[tone1[0],tone1[1],tone2[0],tone2[1]]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if "NC" not in [fin3,amp3,fin4,amp4] and len(self.selectedDacLanes)==(2*L):
			tone3=self.toneGen(fin3,amp3,nSamples,fBand1)
			tone4=self.toneGen(fin4,amp4,nSamples,fBand2)
			twoTones=[tone3[0],tone3[1],tone4[0],tone4[1]]+twoTones
			LMFSHd=str(L*2)+str(M*2)+str(F)+str(S)+str(Hd)
		self.SendConvertorData(LMFSHd,twoTones)
		log("loadedSing")
		return tone1
	#sendSingleTone
	
	# @funcDecorator
	# def getTone(self,toneToSend,backoff,fBand,nSamples):
		# if isinstance(toneToSend,str):
			# filePath=toneToSend
			# if backoff==True:
				# LTE_file=open(filePath,'r')
				# LTE_data_encoded = LTE_file.read()
				# noConvertersInFile=len(LTE_data_encoded[:LTE_data_encoded.find('\n')].strip().split())
				# LTE_file.close()
				# LTE_data_encoded = LTE_data_encoded.split()
				# LTE_data_encoded = np.vectorize(int)(LTE_data_encoded)
				# toneToSend=[LTE_data_encoded.tolist()[::noConvertersInFile],LTE_data_encoded.tolist()[1::noConvertersInFile]]
			# else:
				# if filePath.strip()=="":
					# toneToSend=[[0]*8192,[0]*8192]
				# elif (not (os.path.exists(filePath) and  os.path.isfile(filePath))) or (filePath[-4:].lower()!=".tsw"):
					# error("LTE file Doesn't Exist or invalid. Please give path for a TSW file.")
					# toneToSend=[[0]*8192,[0]*8192]
				# else:
					# toneToSend=lteDecode.decodeTswData(filePath)
		# elif isinstance(toneToSend,int) or isinstance(toneToSend,float):
			# toneToSend=self.toneGen(toneToSend,backoff,nSamples,fBand)
		# elif isinstance(toneToSend,list) or isinstance(toneToSend,tuple):
			# actualBackoff=[]
			# if isinstance(backoff,list):
				# for i in range(len(toneToSend)):
					# actualBackoff.append(backoff[i%len(backoff)])
			# else:
				# for i in range(len(toneToSend)):
					# actualBackoff.append(backoff)
			# toneToSend=self.multiToneGen(toneToSend,actualBackoff,nSamples,fBand)
		# else:
			# toneToSend=[[0]*nSamples,[0]*nSamples]
		
		# return toneToSend
			
	@funcDecorator
	
	
	# def jesdConvertersToLanes(self,LMFSHd,converterWiseData):
		# """ This function packs the converterwise data into lanes as per the LMFSHd provided. It returns an array of lane wise data. The lane wise data is an array of 16-bit data. """
		
		# inputDataResolution=16
		# jesdModeIn=LMFSHd.lower()
		# if "_" in jesdModeIn:
			# jesdMode=jesdModeIn[:jesdModeIn.find("_")]
		# else:
			# jesdMode=jesdModeIn
		# L=int(jesdMode[0])
		# M=int(jesdMode[1])
		# if len(jesdMode)==5:
			# F=int(jesdMode[2])
			# S=int(jesdMode[3])
			# Hd=int(jesdMode[4])
		# elif len(jesdMode)==6:
			# F=int(jesdMode[2:4])
			# S=int(jesdMode[4])
			# Hd=int(jesdMode[5])
			
		# if M!=len(converterWiseData):
			# error("The number of arrays passed and M given doesn't match. Please send an array consisting of converter wise data. No values written to FPGA.")
			# #return
		# bits=16
		# resolution=int(round(16*(F*L)/(M*S*2.0)))
		# totalSampleNumber=len(converterWiseData)*len(converterWiseData[0])
		
		# converterInterleavedData=np.zeros(totalSampleNumber,dtype=int)
		# for i in range(M):
			# if (len(converterWiseData[i])*resolution/8.0)%1!=0:
				# converterWiseData[i]=converterWiseData[i][:1-(len(converterWiseData[i])*resolution%8)]
			# converterInterleavedData[i::M]=converterWiseData[i]
			
		# laneInterleavedDataBits=[]
		# for sample in converterInterleavedData:
			# #exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(sample&(2**inputDataResolution-1))")
			# exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(int((sample)+(2**(bits-1)))^(1<<(bits-1))&(2**inputDataResolution-1))")
			# if resolution<inputDataResolution:
				# resolutionEff=resolution
			# else:
				# resolutionEff=inputDataResolution
			# for i in range(resolutionEff):
				# laneInterleavedDataBits.append(sampleBits[i])
			# if inputDataResolution<resolution:
				# for i in range(resolution-inputDataResolution):
					# laneInterleavedDataBits.append('0')
					
		# if len(laneInterleavedDataBits)%(8*F*L)!=0:
			# for i in range(len(laneInterleavedDataBits)%(8*F*L)):
				# laneInterleavedDataBits.append('0')
				
		# laneInterleavedDataOctets=[]
		# laneInterleavedDataBits=np.array(laneInterleavedDataBits)
		# laneInterleavedDataBits=laneInterleavedDataBits.reshape(len(laneInterleavedDataBits)/8,8)
		# for octet in laneInterleavedDataBits:
			# octetStr=""
			# for i in range(8):
				# octetStr+=str(octet[i])
			# laneInterleavedDataOctets.append(int(octetStr,2))
			
		# laneWiseDataOctets=[]
		# for lane in range(L):
			# laneData=[0]*(len(laneInterleavedDataOctets)/L)
			# for octet in range(F):
				# laneData[octet::F]=laneInterleavedDataOctets[((lane*F)+octet)::(L*F)]
			# laneWiseDataOctets.append(laneData)
			
			
		# laneWiseData=[]
		# for lane in range(L):
			# laneData=[]
			# for sample in range(0,len(laneWiseDataOctets[0])/2):
				# laneData.append((laneWiseDataOctets[lane][sample*2]<<8)+laneWiseDataOctets[lane][(2*sample)+1])
			# laneWiseData.append(laneData)
		# return laneWiseData
		
		# laneDataRet=jesdConvertersToLanes(LMFSHd,converterWiseData)
		
	def SwapByteOrder(self,y):
		dt = np.dtype('uint16')	
		dt = dt.newbyteorder(self.regs.interfaceHandle.byteorder)	
		y=np.frombuffer(y.tobytes(),dt)
		return y
	def ConcatenateChannels(self,Channels):	
		z = np.concatenate(Channels)
		z = np.frombuffer(z.reshape([len(Channels),len(Channels[0])]).transpose().tobytes(),'uint32')
		return z
		
	def LoadToneFromFile(self,filename):	
		y = np.genfromtxt(filename)
		return np.around(y).astype('int16')
		
	@funcDecorator
	# def toneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=4096,fsBaseBand=491.52):
		# bits=16
		# n = int(NumberOfSamples/2)
		# m = int((fInBaseBand/fsBaseBand)*n)	
		# if (m%2) == 0 :
			# m = m+1
		# fInBaseBand=(m/float(n)*fsBaseBand)
		
		# ampl=10**(ampl_dBFs/20.0)
		
		# signal = np.zeros(NumberOfSamples,dtype=complex)
		# for x in range(NumberOfSamples):
			# signal[x] = np.round((2**(bits-1))*ampl*np.e**(1j*2*np.pi*(fInBaseBand/fsBaseBand)*x))
		# realSignal=signal.real
		# imagSignal=signal.imag
		# return([realSignal,imagSignal])
		
	@funcDecorator
	def multiToneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=24*192,fsBaseBand=491.52):
		bits=16
		n = int(NumberOfSamples/2)
		ampl=[]
		for i in range(len(fInBaseBand)):
			m = int((fInBaseBand[i]/fsBaseBand)*n)	
			if (m%2) == 0 :
				m = m+1
			fInBaseBand[i]=(m/float(n)*fsBaseBand)
			if i>=len(ampl_dBFs):
				ampl_dBFs.append(-20.0)
			ampl.append(10**(ampl_dBFs[i]/20.0))
			### Max samples 32k for I and 32k for Q for 12410 mode. 64k per lane for 0th and 1st lanes. Same data on 2nd and 3rd lanes as on 0th and 1st lanes respectively
		signal = np.zeros(NumberOfSamples,dtype=complex)
		for x in range(NumberOfSamples):
			signal[x]=0
			for i in range(len(fInBaseBand)):
				signal[x] += np.round((2**(bits-1))*ampl[i]*np.e**(1j*2*np.pi*(fInBaseBand[i]/fsBaseBand)*x))
		realSignal=signal.real
		imagSignal=signal.imag
		return([realSignal,imagSignal])
		
	@funcDecorator
	# def loadSignalToFpga(self,laneWiseData):
		# laneWiseData = np.asarray(laneWiseData)		
		# a = []
		# for l in laneWiseData:
			# b = [l[0::2],l[1::2]]
			# a= a + b
		# laneWiseData = np.asarray(a)
		# for i in range(len(laneWiseData)):
			# laneWiseData[i] = self.SwapByteOrder(laneWiseData[i].astype('int16'))	
			
		# y   = self.ConcatenateChannels(laneWiseData.astype('uint16'))
		# self.regs.interfaceHandle.StopDACSamples()
		# log("DAC Start")
		# self.regs.interfaceHandle.StartDAC(y,force=1)
		# #loadSignalToFpga
		
	# def SendConvertorData(self,LMFSHd,ConvertorData):
		
		# M        = int(LMFSHd[1])
		# nC       = len(ConvertorData)
		
		# converterWiseData = []
		
		# for i in range(((M-1)/nC)+1):
			# ConvertersLeft = M - i*nC
			# if ConvertersLeft > nC:
				# ConvertersLeft = nC
			# converterWiseData  = converterWiseData + ConvertorData[:ConvertersLeft]
			
			
		# laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData)
		# self.loadSignalToFpga(laneWiseData)
		
	# @funcDecorator
	# def sendSingleTone(self,twoTNo,fin1,amp1,fin2,amp2,Samples=24*192):	
		# LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,Samples)				
		# tone1=self.toneGen(fin1,amp1,nSamples,fBand1)
		# tone2=self.toneGen(fin2,amp2,nSamples,fBand2)			
		# twoTones=[tone1[0],tone1[1],tone2[0],tone2[1]]
		# self.SendConvertorData(LMFSHd,twoTones)
		# #sendSingleTone
		
	def sendLteData(self,twoTNo,filePath):	
		LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,0)	
		if filePath.strip()=="":
			return
		elif (not (os.path.exists(filePath) and  os.path.isfile(filePath))) or (filePath[-4:].lower()!=".tsw"):
			error("LTE file Doesn't Exist or invalid. Please give path for a TSW file.")
			return
		
		tone1=lteDecode.decodeTswData(filePath)		
		M        = int(LMFSHd[1])
		twoTones=[tone1[0],tone1[1],tone1[0],tone1[1]]
		self.SendConvertorData(LMFSHd,twoTones)
	#sendLteData
	
	@funcDecorator
	def sendCustomData(self,twoTNo,filePath):
		if (not (os.path.exists(filePath) and  os.path.isfile(filePath))): 
			error("File Doesn't Exist. Please give path.") 
			return 
		systemParams=setupParams.dutInstances[setupParams.selectedDut].systemParams
		LMFSHd=systemParams.LMFSHdTx[2*twoTNo] 
		(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(LMFSHd)
		
		LTE_file=open(filePath,'r')
		LTE_data_encoded = LTE_file.read()
		noConvertersInFile=len(LTE_data_encoded[:LTE_data_encoded.find('\n')].strip().split())
		LTE_file.close()
		converterWiseData=[]
		LTE_data_encoded = LTE_data_encoded.split()
		LTE_data_encoded = np.vectorize(int)(LTE_data_encoded)
		
		for c in range(noConvertersInFile):
			converterWiseData.append(LTE_data_encoded[c::noConvertersInFile])
		while len(converterWiseData)<M:
			converterWiseData=converterWiseData+converterWiseData
		converterWiseData=converterWiseData[:M]
		self.SendConvertorData(LMFSHd,converterWiseData)
		#laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData) 
		#self.loadSignalToFpga(twoTNo,laneWiseData) 
	#sendCustomData
	
	@funcDecorator
	def sendCustomComplexData(self,twoTNo,filePath):
		if (not (os.path.exists(filePath) and  os.path.isfile(filePath))): 
			error("File Doesn't Exist. Please give path.") 
			return 
		systemParams=setupParams.dutInstances[setupParams.selectedDut].systemParams
		LMFSHd=systemParams.LMFSHdTx[2*twoTNo] 
		(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(LMFSHd)
		
		LTE_file=open(filePath,'r')
		LTE_data_encoded = LTE_file.read()
		noConvertersInFile=len(LTE_data_encoded[:LTE_data_encoded.find('\n')].strip().split())
		LTE_file.close()
		converterWiseData=[]
		LTE_data_encoded = LTE_data_encoded.split()
		LTE_data_encoded = np.vectorize(int)(LTE_data_encoded)
		
		for c in range(noConvertersInFile):
			converterWiseData.append(LTE_data_encoded[c::noConvertersInFile])
		while len(converterWiseData)<M:
			converterWiseData=converterWiseData+converterWiseData
		converterWiseData=converterWiseData[:M]
		self.SendConvertorData(LMFSHd,converterWiseData)
		#laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData) 
		#self.loadSignalToFpga(twoTNo,laneWiseData) 
	#sendCustomData
	
	@funcDecorator
	def getTXParams(self,twoTNo,Samples):	
		systemParams=setupParams.dutInstances[setupParams.selectedDut].systemParams
		systemStatus=setupParams.dutInstances[setupParams.selectedDut].systemStatus
		
		#LMFSHd=systemParams.LMFSHdTx[2*twoTNo]
		LMFSHd=systemParams.LMFSHdTx[twoTNo]
		#fBand1=systemParams.Fs*1.0/systemParams.ducFactorTx[(twoTNo*2)+0]
		#fBand2=systemParams.Fs*1.0/systemParams.ducFactorTx[(twoTNo*2)+1]
		fBand1=systemParams.Fs*1.0/systemParams.ducFactorTx[0]
		fBand2=systemParams.Fs*1.0/systemParams.ducFactorTx[1]
		nSamples  = int(math.ceil(math.ceil(Samples/24.0)))*24			
		return LMFSHd,fBand1,fBand2,nSamples
		
	@funcDecorator
	def sendMultiTone(self,twoTNo,fin1,amp1,fin2,amp2,Samples=24*192):	
		LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,Samples)			
		tone1 = self.multiToneGen(fin1,amp1,nSamples,fBand1)
		tone2 = self.multiToneGen(fin2,amp2,nSamples,fBand2)
		twoTones=[tone1[0],tone1[1],tone2[0],tone2[1]]
		self.SendConvertorData(LMFSHd,twoTones)

	@funcDecorator
	def setLanePolarities(self):
		self.regs.interfaceHandle.SetLanePolarities(setupJesdParams.boardLaneSettings[setupParams.boardType]['tx_polarity'],setupJesdParams.boardLaneSettings[setupParams.boardType]['rx_polarity'])
	#setLanePolarities
		
	@funcDecorator
	def powerDownUnusedLanes(self):
		fpgaLanesUsed=[]
		for i in range(len(setupJesdParams.boardLaneSettings[setupParams.boardType].keys())-2):
			[fpgaLanesUsed.append(x) for x in setupJesdParams.boardLaneSettings[setupParams.boardType][i]['rx_lanes']]
		 
		invalidLanes=[]
		for lane in range(16):
			if lane not in fpgaLanesUsed:
				invalidLanes.append(lane)
		self.regs.interfaceHandle.powerDownLanes(invalidLanes,True)
	#powerDownUnusedLanes
	
	@funcDecorator
	def getUsedLanes(self):
		fpgaLanesUsed=[]
		for i in range(len(setupJesdParams.boardLaneSettings[setupParams.boardType].keys())-2):
			[fpgaLanesUsed.append(x) for x in setupJesdParams.boardLaneSettings[setupParams.boardType][i]['rx_lanes']]
		return fpgaLanesUsed
	#getUsedLanes
	
	@funcDecorator
	def rxSyncCapture(self,dataRate,samples,onTime=-1,instanceNo=0):
		periodMs=samples*0.001/dataRate
		if onTime==-1:
			onTime=periodMs
		if setupParams.dutInstances[setupParams.selectedDut].systemParams.jesdProtocol in [0]:
			self.regs.interfaceHandle.ConfigurePulseGen(0,periodMs,[[1,1+onTime]])	
			self.regs.interfaceHandle.ConfigurePulseGen(1,periodMs,[[1,1+onTime]])	
			self.regs.interfaceHandle.StartPulseGen('free')
			self.regs.interfaceHandle.MaxWait = 1024
			self.regs.interfaceHandle.CaptureSyncMode=7
		else:
			self.regs.interfaceHandle.ConfigurePulseGen(0,periodMs,[[1,1+onTime]])	
			self.regs.interfaceHandle.ConfigurePulseGen(1,periodMs,[[1,1+onTime]])	
			self.regs.interfaceHandle.StartPulseGen('rx_sync')
			self.regs.interfaceHandle.MaxWait = 1024
			self.regs.interfaceHandle.CaptureSyncMode=0
			
	@funcDecorator
	def dataGen(self,fin1,amp1,Samples1,fin2=0,amp2=0,Samples2=0,twoTNo=0):
		LMFSHd,fBand1,fBand2,nSamples1=self.getTXParams(twoTNo,Samples1)				
		tone1=self.toneGen(fin1,amp1,nSamples1,fBand1)
		if(Samples2!=0):
			LMFSHd,fBand1,fBand2,nSamples2=self.getTXParams(twoTNo,Samples2)	
			tone2=self.toneGen(fin2,amp2,nSamples2,fBand1)
			tone = tone1+tone2
			tone = np.concatenate((tone1, tone2),axis = 1)	
		else:
			tone = tone1
		return tone
	#dataGen			
	
#fpgaLib

