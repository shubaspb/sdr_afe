from globalDefs import *
from tswDecode import lteDecode
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mSetupParams import setupJesdParams
from mSetupParams import setupParams
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import numpy as np
import random,math
import os

class fpgaLib_J58(projectBaseClass):
	"""Contains FPGA specific functions. self.regs=myfpga """
	@initDecorator
	def __init__(self,regs,fpgaParams):
		self.fpgaParams=fpgaParams
		self.regs=regs
		self.setJesdTxF=[0,0]
		self.setJesdRxF=[0,0]
	#__init__

	@funcDecorator
	def reset(self):
		info("Resetting FPGA.")
		r = self.regs.Reconnect()
		self.regs.interfaceHandle.LaneRate=0
		self.regs.interfaceHandle.setLaneRate(LaneRate=setupParams.dutInstances[0].systemStatus.laneRateRx[0])
		#self.resetQpllIpReset()
	#reset

	#@funcDecorator
	#def resetQpllIpReset(self):
	#	systemStatus		= setupParams.dutInstances[setupParams.selectedDut].systemStatus
	#	ref_clk  		    = 245.76
	#	pll_div             = int(systemStatus.laneRateRx[0]/ref_clk)
	#	self.regs.interfaceHandle.PLLReset()
	#	self.regs.interfaceHandle.JESD_Reset()
	#	self.regs.interfaceHandle.ChangePLLRate(pll_div)
	##resetQpll
		
	@funcDecorator
	def fpgaTxSendK(self,en=[True]*2):	
		#self.deviceRefs.device.printCommentToLog("FPGA Sending K characters to all the 8 lanes")	
		if True in en:
			self.regs.interfaceHandle.WriteControlRegister(self.regs.interfaceHandle.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000000F]) 
		else:
			self.regs.interfaceHandle.WriteControlRegister(self.regs.interfaceHandle.JESD_BASE_ADDR_CONFIG + 4*2  ,[0x0000010F]) 
	
	#fpgaTxSendK
	
	@funcDecorator
	def selectCapture(self,LMFSHd,lanes,converterOrder,dutNo=0):
		""" Assumes that lanes are consecutive. Looks at the first element of the list and number of lanes only. """
		myfpga=self.regs
		laneSettings=setupJesdParams.boardLaneSettings[setupParams.boardType][dutNo]['tx_lanes']
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		
		lanes=[laneSettings[i] for i in lanes]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		self.regs.interfaceHandle.fpgaRxConfig(convertersPerLane=(M*1.0/L),F=F)
		self.regs.interfaceHandle.selectRxLanes(lanes)
		if resolution==48 or "_DUP" in LMFSHd:
			myfpga.LMFSHd=str(L)+str(M)+str(F)+str(S*2)+str(Hd)
			myfpga.dropAlternateSamplesPerConverter=1
		else:
			myfpga.LMFSHd=LMFSHd
			myfpga.dropAlternateSamplesPerConverter=0
		myfpga.converterOrder=converterOrder
	#selectCapture

	@funcDecorator
	def selectDrive(self,LMFSHd,lanes,converterOrder,dutNo=0):	
	
		laneSettings=setupJesdParams.boardLaneSettings[setupParams.boardType][dutNo]['rx_lanes']
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		
		lanes=[laneSettings[i] for i in lanes]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if self.regs.interfaceHandle.LaneRate!=systemStatus.laneRateTx[0]:
			self.regs.interfaceHandle.setLaneRate(LaneRate=systemStatus.laneRateTx[0])
		
		self.regs.interfaceHandle.fpgaTxConfig(convertersPerLane=(M*1.0/L),F=F)
		self.regs.interfaceHandle.selectTxLanes(lanes)
	#selectDrive
		
	@funcDecorator
	def fpgaRxConfig(self,rxOrFb=0,instanceNo=0,dutNo=0):
		""" "Configuring FPGA JESD RX" "Done configuring FPGA JESD RX"
		rxOrFb if it is RX or FB. instanceNois 0 or 1. """
		
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		if rxOrFb==0:
			LMFSHd=systemParams.LMFSHdRx[instanceNo]
			laneRate=systemStatus.laneRateRx[instanceNo]
		else:
			LMFSHd=systemParams.LMFSHdFb[instanceNo]
			laneRate=systemStatus.laneRateFb[instanceNo]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if self.regs.interfaceHandle.LaneRate!=laneRate:
			self.regs.interfaceHandle.setLaneRate(LaneRate=laneRate)
		self.regs.interfaceHandle.fpgaRxConfig(convertersPerLane=(M*1.0/L),F=F,K=systemParams.jesdK[instanceNo],scrambler=systemParams.jesdScr[instanceNo],jesdProtocol=systemParams.jesdProtocol)
	#fpgaRxConfig

	@funcDecorator
	def fpgaTxConfig(self,instanceNo=0,dutNo=0):
		""" "Configuring FPGA JESD TX" "Done configuring FPGA JESD TX" """
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		LMFSHd=systemParams.LMFSHdTx[instanceNo]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if self.regs.interfaceHandle.LaneRate!=systemStatus.laneRateTx[instanceNo]:
			self.regs.interfaceHandle.setLaneRate(LaneRate=systemStatus.laneRateTx[instanceNo])
		self.regs.interfaceHandle.fpgaTxConfig(convertersPerLane=(M*1.0/L),F=F,K=systemParams.jesdK[instanceNo],scrambler=systemParams.jesdScr[instanceNo],jesdProtocol=systemParams.jesdProtocol)
	#fpgaTxConfig

	@funcDecorator
	def checkRxSync(self):
		info("###########Device ADC JESD-TX Link Status###########")
		return
	#checkRxSync

	@funcDecorator
	def jesdConvertersToLanes(self,LMFSHd,converterWiseData):
		""" This function packs the converterwise data into lanes as per the LMFSHd provided. It returns an array of lane wise data. The lane wise data is an array of 16-bit data. """
		
		inputDataResolution=16
		jesdModeIn=LMFSHd.lower()
		if "_" in jesdModeIn:
			jesdMode=jesdModeIn[:jesdModeIn.find("_")]
		else:
			jesdMode=jesdModeIn
		L=int(jesdMode[0])
		M=int(jesdMode[1])
		if len(jesdMode)==5:
			F=int(jesdMode[2])
			S=int(jesdMode[3])
			Hd=int(jesdMode[4])
		elif len(jesdMode)==6:
			F=int(jesdMode[2:4])
			S=int(jesdMode[4])
			Hd=int(jesdMode[5])
		
		if M!=len(converterWiseData):
			error("The number of arrays passed and M given doesn't match. Please send an array consisting of converter wise data. No values written to FPGA.")
			#return
		bits=16
		resolution=int(round(16*(F*L)/(M*S*2.0)))
		totalSampleNumber=len(converterWiseData)*len(converterWiseData[0])
		
		converterInterleavedData=np.zeros(totalSampleNumber,dtype=int)
		for i in range(M):
			if (len(converterWiseData[i])*resolution/8.0)%1!=0:
				converterWiseData[i]=converterWiseData[i][:1-(len(converterWiseData[i])*resolution%8)]
			converterInterleavedData[i::M]=converterWiseData[i]
		
		laneInterleavedDataBits=[]
		for sample in converterInterleavedData:
			#exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(sample&(2**inputDataResolution-1))")
			exec("sampleBits='{0:0"+str(inputDataResolution)+"b}'.format(int((sample)+(2**(bits-1)))^(1<<(bits-1))&(2**inputDataResolution-1))")
			if resolution<inputDataResolution:
				resolutionEff=resolution
			else:
				resolutionEff=inputDataResolution
			for i in range(resolutionEff):
				laneInterleavedDataBits.append(sampleBits[i])
			if inputDataResolution<resolution:
				for i in range(resolution-inputDataResolution):
					laneInterleavedDataBits.append('0')
				
		if len(laneInterleavedDataBits)%(8*F*L)!=0:
			for i in range(len(laneInterleavedDataBits)%(8*F*L)):
				laneInterleavedDataBits.append('0')

		laneInterleavedDataOctets=[]
		laneInterleavedDataBits=np.array(laneInterleavedDataBits)
		laneInterleavedDataBits=laneInterleavedDataBits.reshape(len(laneInterleavedDataBits)/8,8)
		for octet in laneInterleavedDataBits:
			octetStr=""
			for i in range(8):
				octetStr+=str(octet[i])
			laneInterleavedDataOctets.append(int(octetStr,2))

		laneWiseDataOctets=[]
		for lane in range(L):
			laneData=[0]*(len(laneInterleavedDataOctets)/L)
			for octet in range(F):
				laneData[octet::F]=laneInterleavedDataOctets[((lane*F)+octet)::(L*F)]
			laneWiseDataOctets.append(laneData)
		
		
		laneWiseData=[]
		for lane in range(L):
			laneData=[]
			for sample in range(0,len(laneWiseDataOctets[0])/2):
				laneData.append((laneWiseDataOctets[lane][sample*2]<<8)+laneWiseDataOctets[lane][(2*sample)+1])
			laneWiseData.append(laneData)
		return laneWiseData
			
	# laneDataRet=jesdConvertersToLanes(LMFSHd,converterWiseData)

	def SwapByteOrder(self,y):
		dt = np.dtype('uint16')	
		dt = dt.newbyteorder(self.regs.interfaceHandle.byteorder)	
		y=np.frombuffer(y.tobytes(),dt)
		return y
	def ConcatenateChannels(self,Channels):	
		z = np.concatenate(Channels)
		z = np.frombuffer(z.reshape([len(Channels),len(Channels[0])]).transpose().tobytes(),'uint32')
		return z

	def LoadToneFromFile(self,filename):	
		y = np.genfromtxt(filename)
		return np.around(y).astype('int16')
		
	@funcDecorator
	def toneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=4096,fsBaseBand=491.52):
		bits=16
		n = int(NumberOfSamples/2)
		m = int((fInBaseBand/fsBaseBand)*n)	
		if (m%2) == 0 :
			m = m+1
		fInBaseBand=(m/float(n)*fsBaseBand)
	
		ampl=10**(ampl_dBFs/20.0)
		
		signal = np.zeros(NumberOfSamples,dtype=complex)
		for x in range(NumberOfSamples):
			signal[x] = np.round((2**(bits-1))*ampl*np.e**(1j*2*np.pi*(fInBaseBand/fsBaseBand)*x))
		realSignal=signal.real
		imagSignal=signal.imag
		return([realSignal,imagSignal])
	
	@funcDecorator
	def multiToneGen(self,fInBaseBand,ampl_dBFs,NumberOfSamples=24*192,fsBaseBand=491.52):
		bits=16
		n = int(NumberOfSamples/2)
		ampl=[]
		for i in range(len(fInBaseBand)):
			m = int((fInBaseBand[i]/fsBaseBand)*n)	
			if (m%2) == 0 :
				m = m+1
			fInBaseBand[i]=(m/float(n)*fsBaseBand)
			if i>=len(ampl_dBFs):
				ampl_dBFs.append(-20.0)
			ampl.append(10**(ampl_dBFs[i]/20.0))
		### Max samples 32k for I and 32k for Q for 12410 mode. 64k per lane for 0th and 1st lanes. Same data on 2nd and 3rd lanes as on 0th and 1st lanes respectively
		signal = np.zeros(NumberOfSamples,dtype=complex)
		for x in range(NumberOfSamples):
			signal[x]=0
			for i in range(len(fInBaseBand)):
				signal[x] += np.round((2**(bits-1))*ampl[i]*np.e**(1j*2*np.pi*(fInBaseBand[i]/fsBaseBand)*x))
		realSignal=signal.real
		imagSignal=signal.imag
		return([realSignal,imagSignal])
	
	@funcDecorator
	def loadSignalToFpga(self,laneWiseData):
		laneWiseData = np.asarray(laneWiseData)		
		a = []
		for l in laneWiseData:
			b = [l[0::2],l[1::2]]
			a= a + b
		laneWiseData = np.asarray(a)
		for i in range(len(laneWiseData)):
			laneWiseData[i] = self.SwapByteOrder(laneWiseData[i].astype('int16'))	
		
		y   = self.ConcatenateChannels(laneWiseData.astype('uint16'))
		self.regs.interfaceHandle.StopDACSamples()
		log("DAC Start")
		self.regs.interfaceHandle.StartDAC(y,force=1)
	#loadSignalToFpga
	
	def SendConvertorData(self,LMFSHd,ConvertorData):
	
		M        = int(LMFSHd[1])
		nC       = len(ConvertorData)
		
		converterWiseData = []
		
		for i in range(((M-1)/nC)+1):
			ConvertersLeft = M - i*nC
			if ConvertersLeft > nC:
				ConvertersLeft = nC
			converterWiseData  = converterWiseData + ConvertorData[:ConvertersLeft]
			
		
		laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData)
		self.loadSignalToFpga(laneWiseData)
		
	@funcDecorator
	def sendSingleTone(self,twoTNo,fin1,amp1,fin2,amp2,Samples=24*192):	
		LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,Samples)				
		tone1=self.toneGen(fin1,amp1,nSamples,fBand1)
		tone2=self.toneGen(fin2,amp2,nSamples,fBand2)			
		twoTones=[tone1[0],tone1[1],tone2[0],tone2[1]]
		self.SendConvertorData(LMFSHd,twoTones)
	#sendSingleTone
	
	@funcDecorator
	def sendLteData(self,twoTNo,filePath):	
		LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,0)	
		if filePath.strip()=="":
			return
		elif (not (os.path.exists(filePath) and  os.path.isfile(filePath))) or (filePath[-4:].lower()!=".tsw"):
			error("LTE file Doesn't Exist or invalid. Please give path for a TSW file.")
			return
		
		tone1=lteDecode.decodeTswData(filePath)		
		M        = int(LMFSHd[1])
		twoTones=[tone1[0],tone1[1],tone1[0],tone1[1]]
		self.SendConvertorData(LMFSHd,twoTones)
	#sendLteData
	
	@funcDecorator
	def sendCustomData(self,twoTNo,filePath):
		if (not (os.path.exists(filePath) and  os.path.isfile(filePath))): 
			error("File Doesn't Exist. Please give path.") 
			return 
		LMFSHd=self.systemParams.LMFSHdTx[twoTNo] 
		(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(LMFSHd)
		
		LTE_file=open(filePath,'r')
		LTE_data_encoded = LTE_file.read()
		noConvertersInFile=len(LTE_data_encoded[:LTE_data_encoded.find('\n')].strip().split())
		LTE_file.close()
		converterWiseData=[]
		LTE_data_encoded = LTE_data_encoded.split()
		LTE_data_encoded = np.vectorize(int)(LTE_data_encoded)
		
		for c in range(noConvertersInFile):
			converterWiseData.append(LTE_data_encoded[c::noConvertersInFile])
		while len(converterWiseData)<M:
			converterWiseData=converterWiseData+converterWiseData
		converterWiseData=converterWiseData[:M]
		self.SendConvertorData(LMFSHd,converterWiseData)
		#laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData) 
		#self.loadSignalToFpga(twoTNo,laneWiseData) 
	#sendCustomData
	
	@funcDecorator
	def sendCustomComplexData(self,twoTNo,filePath):
		if (not (os.path.exists(filePath) and  os.path.isfile(filePath))): 
			error("File Doesn't Exist. Please give path.") 
			return 
		LMFSHd=self.systemParams.LMFSHdTx[twoTNo] 
		(L,M,F,S,Hd,resolution,NumBands)=self.jesdModeFeatures(LMFSHd)
		
		LTE_file=open(filePath,'r')
		LTE_data_encoded = LTE_file.read()
		noConvertersInFile=len(LTE_data_encoded[:LTE_data_encoded.find('\n')].strip().split())
		LTE_file.close()
		converterWiseData=[]
		LTE_data_encoded = LTE_data_encoded.split()
		LTE_data_encoded = np.vectorize(int)(LTE_data_encoded)
		
		for c in range(noConvertersInFile):
			converterWiseData.append(LTE_data_encoded[c::noConvertersInFile])
		while len(converterWiseData)<M:
			converterWiseData=converterWiseData+converterWiseData
		converterWiseData=converterWiseData[:M]
		self.SendConvertorData(LMFSHd,converterWiseData)
		#laneWiseData=self.jesdConvertersToLanes(LMFSHd,converterWiseData) 
		#self.loadSignalToFpga(twoTNo,laneWiseData) 
	#sendCustomData
	
	@funcDecorator
	def getTXParams(self,twoTNo,Samples):	
		systemParams=setupParams.dutInstances[setupParams.selectedDut].systemParams
		systemStatus=setupParams.dutInstances[setupParams.selectedDut].systemStatus
		LMFSHd=systemParams.LMFSHdTx[twoTNo]
		fBand1=systemParams.Fs*1.0/systemParams.ducFactorTx[0]
		fBand2=systemParams.Fs*1.0/systemParams.ducFactorTx[1]
		nSamples  = int(math.ceil(math.ceil(Samples/24.0)))*24			
		return LMFSHd,fBand1,fBand2,nSamples
		
	@funcDecorator
	def sendMultiTone(self,twoTNo,fInBaseBand,ampl_dBFs,Samples=24*192):	
		LMFSHd,fBand1,fBand2,nSamples=self.getTXParams(twoTNo,Samples)			
		tone1 = self.multiToneGen(self,fInBaseBand,ampl_dBFs,nSamples,fBand1)
		twoTones=[tone1[0],tone1[1],tone1[0],tone1[1]]
		self.SendConvertorData(LMFSHd,twoTones)
	#sendMultiTone
	
	@funcDecorator
	def setLanePolarities(self):
		self.regs.interfaceHandle.SetLanePolarities(setupJesdParams.boardLaneSettings[setupParams.boardType]['tx_polarity'],setupJesdParams.boardLaneSettings[setupParams.boardType]['rx_polarity'])
	#setLanePolarities
	
	@funcDecorator
	def selectChs(self,rxFbDut0_chNoDut0,rxFbDut1_chNoDut1=[]):
		""" rxFbDutx_chNoDutx is a list of (rxFb,chNo) pairs.
			Say you want to select RXA of DUT0, RXD of DUT1 and FBA of DUT0, it should be  """
		
		lanesToCaptureCombined=[]
		LMFSHdToCaptureCombined=""
		convertersPerLane=0
		FCommon=0
		for sel in range(len(rxFbDut0_chNoDut0)):
			(LMFSHd,lanesToCapture,converterOrder)=setupParams.dutInstances[0].getCaptureSettings(rxFbDut0_chNoDut0[sel][0],rxFbDut0_chNoDut0[sel][1])
			if LMFSHdToCaptureCombined=="":
				LMFSHdToCaptureCombined=LMFSHd
				(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
				convertersPerLane=(M*1.0/L)
				FCommon=F
			else:
				(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
				if (M*1.0/L)!=convertersPerLane or FCommon!=F:
					error("Channels with different configurations are being tried to capture.")
				
			for lane in lanesToCapture:
				lanesToCaptureCombined.append(lane)
		
		myfpga=self.regs
		laneSettings=setupJesdParams.boardLaneSettings[setupParams.boardType][dutNo]['tx_lanes']
		systemParams=setupParams.dutInstances[dutNo].systemParams
		systemStatus=setupParams.dutInstances[dutNo].systemStatus
		
		lanes=[laneSettings[i] for i in lanes]
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		self.regs.interfaceHandle.fpgaRxConfig(convertersPerLane=(M*1.0/L),F=F)
		self.regs.interfaceHandle.selectRxLanes(lanes)
		if resolution==48 or "_DUP" in LMFSHd:
			myfpga.LMFSHd=str(L)+str(M)+str(F)+str(S*2)+str(Hd)
			myfpga.dropAlternateSamplesPerConverter=1
		else:
			myfpga.LMFSHd=LMFSHd
			myfpga.dropAlternateSamplesPerConverter=0
		myfpga.converterOrder=converterOrder
	#selectChs
	
	def reloadFpga(self):
		if self.fpgaParams.fpgaResetFtdi==None:
			return
		self.fpgaParams.fpgaResetFtdi.pin4=3
		delay(0.5)
		self.fpgaParams.fpgaResetFtdi.pin4=4
		delay(0.2)


	def resetFpga(self):
		if self.fpgaParams.fpgaResetFtdi==None:
			return
		self.fpgaParams.fpgaResetFtdi.pin0=3
		delay(0.5)
		self.fpgaParams.fpgaResetFtdi.pin0=4
		delay(0.2)
		
		

#fpgaLib

