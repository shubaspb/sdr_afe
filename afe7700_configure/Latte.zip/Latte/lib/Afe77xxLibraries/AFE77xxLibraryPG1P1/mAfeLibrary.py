import math,os
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mRxLib
reload(mRxLib)
from mRxLib import rxLib

import mFbLib
reload(mFbLib)
from mFbLib import fbLib

import mJesd
reload(mJesd)
from mJesd import jesdLib

import mTop
reload(mTop)
from mTop import topLib

import mTx
reload(mTx)
from mTx import txLib

import mLmk
reload(mLmk)
from mLmk import lmkLib

import mFpga
reload(mFpga)
from mFpga import fpgaLib

import mFPGA_J58
reload(mFPGA_J58)
from mFPGA_J58 import fpgaLib_J58


import mFuncDecorator
reload(mFuncDecorator)
from mFuncDecorator import *
import globalDefs as Globals
from globalDefs import *

import common.mMACROConst
reload(common.mMACROConst)
from common.mMACROConst import MACROConst

from mSetupParams import setupParams,setupJesdParams
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus

class afeLibrary(projectBaseClass):
	"""Contains functions at AFE Device level. self.regs=device """
	@initDecorator
	def __init__(self,deviceRefs,dutNo=0):
		self.regs=deviceRefs.device
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		
		self.skipTxConfig=0
		self.skipRxConfig=0
		self.skipFbConfig=0
		
		#self.systemParams.enableRxIqmcLolPowerUpCorr==True=True
		self.skipAgc=False#True#
		
		self.systemStatus.dutNo=dutNo
		
		self.RX=rxLib(self.regs,deviceRefs)
		self.FB=[]
		for i in xrange(2):
			self.FB.append(fbLib(i,self.regs.FB[i],deviceRefs))
		self.TX=txLib(self.regs.TX,deviceRefs)
		self.TOP=topLib(self.regs.TOP,deviceRefs)
		self.JESD=jesdLib(self.regs.JESD,deviceRefs)
		
		if dutNo<len(setupParams.dutInstances):
			setupParams.dutInstances[dutNo]=self
		else:
			setupParams.dutInstances.append(self)
			dutNo=len(setupParams.dutInstances)-1
		self.LMK=setupParams.lmkLib
		if setupParams.fpgaLib!=None:
			self.FPGA=setupParams.fpgaLib
		else:
			self.FPGA=None
			setupParams.skipFpga=True
		if dutNo==0:
			self.LMK.deviceRefs=deviceRefs
			self.LMK.systemParams=deviceRefs.systemParams
			self.LMK.systemStatus=deviceRefs.systemStatus
			
			self.FPGA.deviceRefs=deviceRefs
			self.FPGA.systemParams=deviceRefs.systemParams
			self.FPGA.systemStatus=deviceRefs.systemStatus
		
		
		self.errorList=['','']
		# Below are psuedo links for ease of use
		self.PLL=[self.TOP.PLL[0],self.TOP.PLL[1],self.TOP.PLL[2],self.TOP.PLL[3],self.TOP.PLL[4]]
		self.JESDTX=[self.JESD.JESDTX[0],self.JESD.JESDTX[1]]
		self.JESDRX=[self.JESD.JESDRX[0],self.JESD.JESDRX[1]]
		self.SERDES=[self.JESD.SERDES[0],self.JESD.SERDES[1]]
		self.RXDIG=[self.RX.RXDIG[0],self.RX.RXDIG[1]]
		self.FBDIG=[self.FB[0].FBDIG,self.FB[1].FBDIG]
		self.TXDIG=[self.TX.DACDIG[0],self.TX.DACDIG[1]]
		info("Successfully Loaded the Libraries.")
		self.libVersion="Date: 02-02-2021."
	#__init__
	
	@funcDecorator
	def softReset(self):
		""" "Resetting the Device" "Done resetting the Device" """
		temp=self.regs.hardReadAlways
		self.regs.hardReadAlways=False
		tempRawWrites=self.deviceRefs.device.rawWriteLogEn
		self.deviceRefs.device.rawWriteLogEn=0
		self.regs.reset()
		self.deviceRefs.device.rawWriteLogEn=tempRawWrites
		self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG0.global_soft_reset=0
		self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG0.global_soft_reset=1
		self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG0.global_soft_reset=0		
		if False:#self.systemParams.customerConfig==True:
			self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG0.global_4pin=0
		else:
			self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG0.global_4pin=1
		self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG0.global_ascend=1
		self.regs.hardReadAlways=temp
		
		self.deviceRefs.device.expectedReadValue=0xa
		self.systemStatus.chipType=self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG3_CHIPTYPE._chip_type.getValue()
		self.deviceRefs.device.expectedReadValue=0x77
		self.systemStatus.chipId=self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG4_ID._chip_id.getValue()
		self.deviceRefs.device.expectedReadValue=self.systemParams.chipVersion
		self.systemStatus.chipVersion=self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG6_VERSION._chip_ver.getValue()
		self.systemStatus.vendorId=self.regs.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG7_VENDORID._vendor_id.getValue()
		
		if self.systemParams.simulationMode==True:
			self.systemStatus.chipType	=self.systemParams.chipType
			self.systemStatus.chipId		=self.systemParams.chipId
			self.systemStatus.chipVersion=self.systemParams.chipVersion

		info("chipType: "+str(hex(self.systemStatus.chipType)))
		info("chipId: "+str(hex(self.systemStatus.chipId)))
		info("chipVersion: "+str(hex(self.systemStatus.chipVersion)))
		if self.systemStatus.chipVersion!=0:
			self.deviceRefs.device.metalFix=1
	#softReset
	
	@funcDecorator
	def wakeupDevice(self):
		""" "Waking up device" "Done waking up device" """
		self.regs.TOP.TC_GPIO.digtop.Register41632_600h.Property41632_0_0=1
		self.regs.TOP.TC_GPIO.digtop.Register41632_600h.misc_spi_global_pdn_sig=0
	#wakeupDevice
	
	def closePageAndNewStep(self,stepName):
		if self.regs.currentPageSelected != None:
			self.regs.currentPageSelected.setValue(0)
		if self.regs.logClassInst != None:
			self.regs.logClassInst.logNewStep(stepName)
	#closePageAndNewStep
	
	@funcDecorator
	def deviceBringup(self):
		"""	"Doing AFE Config" "Device Config Complete" """
		if self.deviceRefs.device.logClassInst != None:
			self.deviceRefs.device.logClassInst.previousStepName=""
			self.deviceRefs.device.logClassInst.previousStepNo=-1
		self.deviceRefs.device.printCommentToLog("Library Version: %s"%(self.systemParams.latteLibVersion))
		
		if 'skipSteadyStateCalib' in dir(self):
			self.skipRxSteadyStateCalib=not self.systemParams.enableRxIqmcLolTrackingCorr
		#if 'skipPuc' in dir(self):
		#	self.powerUpCalib=(1,0,2)[self.skipPuc]
		if 'powerUpCalib' in dir(self):
			self.systemParams.enableRxDsaFactoryCal=(self.powerUpCalib>>1)&1
			self.systemParams.enableTxDsaFactoryCal=(self.powerUpCalib>>2)&1
			self.systemParams.enableTxIqmcLolPowerUpCorr=self.powerUpCalib&1
		
		if self.systemParams.customerConfig==True:
			self.systemParams.syncLoopBack=True
		self.deviceRefs.broadcastEn=0
		
		if self.deviceRefs.device.currentPageSelected!=None:
			logTemp=self.deviceRefs.device.rawWriteLogEn
			self.deviceRefs.device.rawWriteLogEn=0
			self.deviceRefs.device.currentPageSelected.setValue(0)
			self.deviceRefs.device.rawWriteLogEn=logTemp
		
		self.closePageAndNewStep('rstDevice')
		self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Toggle HW Reset")
		self.softReset()
		self.initializeConfig()
		if False in self.systemStatus.validConfig:
			if "pauseHereCustom" in dir(Globals):
				pauseHereCustom(title='Invalid Configuration.',msg='Invalid Configuration. Please select Valid configuration. Refer to Log for Errors.')
			return
		if self.systemStatus.chipId==0xffff:
			error("SPI not working.")
			return
		
		comment="The list of parameters. In the arrays of 2 elements, each value corresponds to one 2T2R1F.\n// "
		count=0
		for i in vars(self.systemParams):
			if "__" not in i:
				exec("comment+=i+"+"': '+str(self.systemParams."+i+")+';  '")
				count+=1
				if count%5==0:
					comment+="\n// "
		self.deviceRefs.device.printCommentToLog(comment)
		self.FPGA.reset()
		if setupParams.skipLmk==0:
			self.LMK.lmkConfig()
			if setupParams.lmkLib.lmkParams.pllEn==False:#self.systemParams.useSpiSysref==False:
				self.LMK.lmkSysrefEn(1)
		
		if setupParams.boardType not in ("BENCH","EVM-1Device"):
			self.FPGA.regs.Reconnect()
			
		if self.systemStatus.chipVersion==0x10:
			self.deviceBringupPG1p0()
			return
		
		self.closePageAndNewStep('wakeUp')
		self.wakeupDevice()
		self.TOP.GPIO.reloadEfuseChain()
		self.TOP.GPIO.checkEfuse()
		self.TOP.GPIO.enableEfuseClock(0)
		
		self.closePageAndNewStep('rstMCU')
		
		self.TOP.SYSCALIB.reset(1)
		self.TOP.SYSCALIB.reset(0)
		self.delay(0.1)
		self.closePageAndNewStep('rstMCU')
		self.TOP.SYSCALIB.loadTopPatch()
		if self.systemParams.useMacros==True and 1 not in self.systemParams.ddcFactorFb+self.systemParams.ddcFactorRx:
			self.closePageAndNewStep('rstMCU')
			self.TOP.loadFbImdEfusePackets()  #Loading FB IMD packets based on band of use
			self.setTopSystemParams()
		self.closePageAndNewStep('efusebyMCU')
		self.TOP.loadPllEfusePackets()
		#self.closePageAndNewStep('efusebyMCU')
		#self.deviceRefs.device.printCommentToLog("If you have a RX or TX DSA packet to be applied, apply it here.")
		self.regs.TOP.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x101
		# PLL efuse loads
		if self.systemStatus.pllValid[0]==True:
			self.closePageAndNewStep('pll0Config')
		else:
			self.closePageAndNewStep('pll0Config')
		self.TOP.requestPllSpiAccess(1)
		
		for i in range(5):
			if self.systemStatus.pllValid[i]==True:
				self.closePageAndNewStep('pll'+str(i)+'Config')
				self.TOP.PLL[i].configurePll()
			else:
				self.closePageAndNewStep('pll'+str(i)+'PowerDown')
				self.TOP.PLL[i].powerUpPll(0)
		if self.systemStatus.pllLockStatus[1]==False and self.systemParams.simulationMode==False:
			error("DC PLL Didn't lock")
			return
		if self.systemStatus.pllValid[4]==True:
			self.closePageAndNewStep('pll4Config')
		else:
			self.closePageAndNewStep('pll4PowerDown')
		self.TOP.requestPllSpiAccess(0)
		self.closePageAndNewStep('efuseToAnalog')
		self.TOP.SYSCALIB.changeTopClkToPll()
		self.closePageAndNewStep('efuseToAnalog')
		self.TOP.loadEfusePackets()
		self.closePageAndNewStep('topConfig')
		self.TOP.initialTopConfig()
		if self.systemParams.jesdABLvdsSync==True:
			self.regs.RX.ANA_AB.ANA_AB.Register8874_42h.Property8874_20_16=23
		if self.systemParams.jesdCDLvdsSync==True:
			self.regs.RX.ANA_CD.ANA_CD.Register46440_42h.Property46440_20_16=23

		self.closePageAndNewStep('clkMuxConfig')
		self.configPllMux()
		self.closePageAndNewStep('serdesConfig')
		self.JESD.enableSerdesApb(1)
		self.deviceRefs.device.printCommentToLog("Forcing the sync pins to high to ensure random data for SERDES adaptation.")
		self.TOP.GPIO.forceDacSyncPins(1,1,1)
		self.closePageAndNewStep('serdesConfig')

		(LMFSHd,lanesToCapture,converterOrder)=self.getCaptureSettings(2,0)
		if self.systemParams.jesdProtocol!=1 and setupParams.boardType not in ("EVM-1Device",):
			if self.skipTxConfig==0:
				self.FPGA.fpgaTxConfig(0,self.systemStatus.dutNo)
				if setupParams.boardType not in ("BENCH",):
					self.FPGA.selectDrive(LMFSHd,lanesToCapture,converterOrder,self.systemStatus.dutNo)
			self.FPGA.fpgaTxSendK([False,False])
					
		self.JESD.SERDES[0].serdesReset()
		self.JESD.SERDES[1].serdesReset()
		self.closePageAndNewStep('serdesConfig')
		temp=self.deviceRefs.device.hardReadAlways
		self.deviceRefs.device.hardReadAlways=0

		# if True in [(True if laneRate>20000 else False) for laneRate in self.systemStatus.laneRateRx+self.systemStatus.laneRateFb+self.systemStatus.laneRateTx]:
			# self.JESD.serdesConfigLoad(Globals.libFolderPath+r"\\resourceFiles\serdes25GConfigBaseScript.txt",3)
		# elif True in [(True if vco>32000 else False) for vco in [self.systemStatus.serdesConfig[0]['serdesTxVco'],self.systemStatus.serdesConfig[0]['serdesRxVco'],self.systemStatus.serdesConfig[1]['serdesTxVco'],self.systemStatus.serdesConfig[1]['serdesRxVco']]]:
			# self.JESD.serdesConfigLoad(Globals.libFolderPath+r"\\resourceFiles\serdes16GConfigBaseScript.txt",3)
		# else:
			# self.JESD.serdesConfigLoad(Globals.libFolderPath+r"\resourceFiles\serdesConfigBaseScript.txt",3)
		
		
		self.JESD.serdesConfigLoad()
		if self.systemParams.serdesFirmware==True:
			self.closePageAndNewStep('serdesConfig')
			self.deviceRefs.device.hardReadAlways=True
			self.deviceRefs.device.printCommentToLog("START: Loading Serdes Firmware.")
			self.TOP.SYSCALIB.serdesFirmwareLoadMacro(3)
			self.deviceRefs.device.hardReadAlways=False
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
			self.JESD.SERDES[0].postFwDownloadSerdesWrites()
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=0
			self.deviceRefs.device.printCommentToLog("END: Done loading Serdes Firmware.")

		self.deviceRefs.device.hardReadAlways=temp
		
		self.closePageAndNewStep('sigChainConfig')
		self.JESD.SUBCHIP.jesdSubchipInitConfig()

		self.deviceRefs.broadcastEn=0
		if self.systemParams.useMacros==True and 1 not in self.systemParams.ddcFactorFb+self.systemParams.ddcFactorRx:
			self.closePageAndNewStep('sigChainConfig')
			self.configDigChain()
		else:
			if self.skipFbConfig==0:
				if self.systemParams.ddcFactorFb[0]==self.systemParams.ddcFactorFb[1]:
					self.deviceRefs.broadcastEn=15
					self.FB[0].FBDIG.configFbDig()
					self.deviceRefs.broadcastEn=0
				else:
					self.FB[0].FBDIG.configFbDig()
					self.FB[1].FBDIG.configFbDig()
					
			self.deviceRefs.broadcastEn=0
			if self.skipRxConfig==0:
				if self.systemParams.ddcFactorRx[0]==self.systemParams.ddcFactorRx[1]:
					self.deviceRefs.broadcastEn=15
					self.RX.RXDIG[0].configRxDig()
					self.deviceRefs.broadcastEn=0
				else:
					self.RX.RXDIG[0].configRxDig()
					self.RX.RXDIG[1].configRxDig()
			self.deviceRefs.broadcastEn=0
			
			if self.skipTxConfig==0:
				if self.systemParams.ducFactorTx[0]==self.systemParams.ducFactorTx[1]:
					self.deviceRefs.broadcastEn=15
					self.TX.DACDIG[0].configTxDig()
					self.deviceRefs.broadcastEn=0
				else:
					self.TX.DACDIG[0].configTxDig()
					self.TX.DACDIG[1].configTxDig()
		
		self.closePageAndNewStep('sigChainConfig')
		if self.systemParams.srConfigParams[0]['enable']==True or self.systemParams.srConfigParams[1]['enable']==True or self.systemParams.srConfigParams[2]['enable']==True or self.systemParams.srConfigParams[3]['enable']==True:
			self.TX.DACDIG[0].configureSrBlock()
			self.TX.DACDIG[1].configureSrBlock()

		if self.systemParams.txDsaUpdateMode==1:
			self.TOP.SYSCALIB.txDsaGainSmoothConfig("GainSmooth",self.systemParams.txDsaGainStepDelay,30)
		elif self.systemParams.txDsaUpdateMode==2:
			self.TOP.SYSCALIB.txDsaGainSmoothConfig("TddToggle",self.systemParams.txDsaGainStepDelay,30)
		
		self.closePageAndNewStep('OvTDDpin')
		self.TOP.tddConfig()
		self.closePageAndNewStep('OvTDDpin')
		self.TOP.overrideTdd(0,0,0)
		self.closePageAndNewStep('OvTDDpin')
		self.TOP.overrideTdd(0,0,1)
		self.closePageAndNewStep('analogWrite')
		self.dacAnaWrites()
		self.closePageAndNewStep('analogWrite')
		self.TOP.overrideTdd(1,0,0)
		self.rxAnaWrites()
		self.jesdSwing(7)
		self.closePageAndNewStep('analogWrite')
		self.TOP.overrideTdd(0,1,0)
		self.fbAnaWrites()
		self.closePageAndNewStep('analogWrite')
		if self.systemParams.pllMuxModes in (0,1,2,4) and self.systemParams.mode2t2r!=0:
			self.anaWritesForTddMode2T2R()

		self.TOP.loadEfusePacketsPostAnaWrites()
		self.regs.hardReadAlways=True
		if self.systemParams.halfRateModeFb==1:
			self.regs.FB[0].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=4
			self.regs.FB[1].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=4
		for i in range(4):
			self.regs.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8168_281h.Property8172_15_15=1
			self.regs.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8156_284h.Property8162_6_6=1
			self.regs.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8156_284h.Property8163_7_7=1
			self.regs.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8178_334h.Property8180_7_6=0
			if self.systemParams.Fs==3000:
				self.regs.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8197_335h.Property8197_10_8=4
				self.regs.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13442_335h.Property13442_10_8=4
			self.regs.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13180_281h.Property13533_15_15=1
			self.regs.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13547_6_6=1
			self.regs.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7=1
			self.regs.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13440_334h.Property13594_7_6=0
			self.regs.RX_ANA_IQ[i].ADC_LP_TESTMODES.ADC_LP_COMMON_TESTMODES.Register19028_28Ah.Property19373_23_23=1
		self.regs.hardReadAlways=False

		#if self.systemParams.jesdProtocol!=1 and setupParams.boardType not in ("EVM-1Device",):
		#	if self.skipTxConfig==0:
		#		self.FPGA.fpgaTxConfig(0,self.systemStatus.dutNo)
		#	if self.systemParams.syncLoopBack==False and setupParams.boardType=="BENCH":
		#		self.FPGA.fpgaTxSendK([False]*2)
		if self.systemParams.syncLoopBack==False:
			self.FPGA.fpgaTxSendK([True,True])
			self.FPGA.fpgaTxSendK([False,False])

		if ((self.systemStatus.jesdConfigParams[0] == self.systemStatus.jesdConfigParams[1]) and (0 not in self.systemParams.enableRxFbJesdLinks) and (0 not in self.systemParams.enableTxJesdLinks)):
			self.deviceRefs.broadcastEn=15
			self.closePageAndNewStep('jesdConfig')
			self.JESD.JESDTX[0].jesdConfig()
			self.closePageAndNewStep('jesdConfig')
			self.JESD.JESDRX[0].jesdConfig()
			self.deviceRefs.broadcastEn=0
		else:
			for i in range(2):
				if self.skipRxConfig==0 or self.skipFbConfig==0:
					if self.systemParams.enableRxFbJesdLinks[i]==1:
						self.closePageAndNewStep('jesdConfig')
						self.JESD.JESDTX[i].jesdConfig()
					else:
						self.regs.JESD.ADC_TX[i].ADC_TX.JESD_TX_CONFIG6.lane_ena=0
				if self.skipTxConfig==0:
					if self.systemParams.enableTxJesdLinks[i]==1:
						self.closePageAndNewStep('jesdConfig')
						self.JESD.JESDRX[i].jesdConfig()
					else:
						self.regs.JESD.DAC_RX[i].DAC_RX.TXDUC_REG124.lane_ena=0
		
		#self.closePageAndNewStep('packetLoad')
		self.regs.currentPageSelected.setValue(0)
		self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: If you have a RX or TX DSA packet to be applied, apply it here.")
		if self.systemParams.rxDsaPacketFilePath!="" and self.systemParams.enableTxDsaFactoryCal==False:
			self.TOP.SYSCALIB.loadDsaPacket(0,self.systemParams.rxDsaPacketFilePath)
		if self.systemParams.txDsaPacketFilePath!="" and self.systemParams.enableRxDsaFactoryCal==False:
			self.TOP.SYSCALIB.loadDsaPacket(1,self.systemParams.txDsaPacketFilePath)
		
		if self.systemParams.enableTxIqmcLolTrackingCorr==True or self.systemParams.enableTxIqmcLolPowerUpCorr==True:
			self.closePageAndNewStep('calibration')
			self.txIqLoCalibInit()
			
		if self.systemParams.enableTxDsaFactoryCal==True or self.systemParams.enableTxSigGen==True:
			self.closePageAndNewStep('calibration')
			self.TOP.enableSigGen(1)
		self.closePageAndNewStep('calibration')
		self.TOP.sendSysref(1)
		self.TOP.staggeredTddToggle()
		if self.systemParams.enableTxIqmcLolPowerUpCorr==1:	# TX IQMC POWER Calib
			self.closePageAndNewStep('calibration')
			temp=self.deviceRefs.device.hardReadAlways
			self.deviceRefs.device.hardReadAlways=True
			self.TOP.enableSigGen(1)
			self.txIqMcPowerUpCalib()
			self.TOP.overrideTdd(0,1,1)
			if os.path.isfile(ASTERIX_DIR+DEVICES_DIR+"gainPhaseCalibPacket.txt"):
				packetFile=open(ASTERIX_DIR+DEVICES_DIR+"gainPhaseCalibPacket.txt",'r')
				MACRO_MEM_DATA=[int(i) for i in packetFile.read().replace('[','').replace(']','').split(',')]
				self.memRead32('macroMem', 0x00);
				self.burstWrite(0x20,MACRO_MEM_DATA)
				self.TOP.SYSCALIB.set_factory_calibration_data(0);
			#self.TOP.SYSCALIB.start_dc_offset_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_ABCD)	
			self.deviceRefs.device.hardReadAlways=temp
			self.rxAnaWrites()
			self.jesdSwing(7)
			
		self.closePageAndNewStep('calibration')
		self.deviceRefs.broadcastEn=0x0f
		self.RX.RXDIG[0].dcOffsetCorrection(1)
		self.deviceRefs.broadcastEn=0x00

		if self.systemParams.enableTxDsaFactoryCal==1:	# TX DSA Calib
			self.closePageAndNewStep('txDsaCalibration')
			self.txDsaCalibration(0xf)
		
		if self.systemParams.enableRxDsaFactoryCal==1:	# RX DSA Calib
			self.closePageAndNewStep('rxDsaCalibration')
			self.rxDsaCalibration(0xf)
			
		self.closePageAndNewStep('gpioConfig')
		self.deviceRefs.device.printCommentToLog("Removing the force on Sync Pin.")
		self.TOP.GPIO.forceDacSyncPins(0,0,0)
		if self.systemParams.gpioConfigMode==0:
			self.TOP.GPIO.gpioIntAgcMode()
		elif self.systemParams.gpioConfigMode==1:
			self.TOP.GPIO.gpioExtAgcMode()
		elif self.systemParams.gpioConfigMode==2:
			self.TOP.GPIO.gpioCustomMode()
		else:
			self.TOP.GPIO.configureAllGpio()
			if("fb_nco_sw" in self.systemParams.gpioMapping.values()):
				self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44514_0_0=1
				self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44517_8_8=1
				self.regs.FB[0].FB_DIG.FB_DIG.FBNCOSelections.FBNCOModeSel=3
				self.regs.FB[1].FB_DIG.FB_DIG.FBNCOSelections.FBNCOModeSel=3
		self.TOP.GPIO.intAlarms()
		############## RXIQMC
		if self.systemParams.enableRxIqmcLolTrackingCorr==True:
			self.closePageAndNewStep('rxIqMc')
			self.rxIqMcSteadyState()
		
		if self.systemParams.enableTxIqmcLolTrackingCorr==True and self.systemParams.enableTxIqmcDelayChar==False:
			self.closePageAndNewStep('txIqMc')
			if self.systemParams.txIqmcExternalDelayValue==[0,0,0,0]:
				self.txIqMcSteadyStateCalibPG1p1()
			else:
				self.txIqMcSteadyStateCalibPG1p1(1,self.systemParams.txIqmcExternalDelayValue)
			if self.systemParams.enableTxIqmcLolHostUpdateMode==True:
				self.TOP.SYSCALIB.txIqmcLolHostUpdateMode(1)

		if self.skipAgc==False:
			self.closePageAndNewStep('agcConfig')
			self.agcBasicConfig()
		
		self.closePageAndNewStep('attnSet')
		if self.systemParams.customerConfig==False:
			self.deviceRefs.broadcastEn=15
			self.TOP.DSA[0].setTxDsa(0,1)
			self.TOP.DSA[0].setTxDsa(1,1)
			self.TOP.DSA[0].setTxDsa(0,0)
			self.TOP.DSA[0].setTxDsa(1,0)
			self.deviceRefs.broadcastEn=0
		else:
			self.deviceRefs.broadcastEn=15
			self.TOP.DSA[0].setTxDsa(0,1)
			self.TOP.DSA[0].setTxDsa(1,1)
			self.deviceRefs.broadcastEn=0
			for i in range(2):			
				for j in range(2):
					self.TOP.DSA[i].setTxDsa(j,self.systemParams.defaultTxDsa[(2*i)+j])
					self.TOP.DSA[i].setRxDsa(j,self.systemParams.defaultRxDsa[(2*i)+j])
				self.TOP.DSA[i].setFbDsa(self.systemParams.defaultFbDsa[i])
		if self.systemParams.executeLinkUpSequenceSeparately==False:	
			self.deviceRefs.device.printCommentToLog("Start of Link up Sequence")
			
			self.closePageAndNewStep('jesdLinkUpInit')
			self.deviceRefs.broadcastEn=15
			self.JESD.JESDTX[0].clearInitStates()
			self.JESD.JESDRX[0].clearInitStates()
			self.deviceRefs.broadcastEn=0
			
			if (self.skipRxConfig==0 or self.skipFbConfig==0) and self.systemParams.jesdProtocol!=1 and setupParams.boardType not in ("EVM-1Device",):
				if setupParams.boardType=="BENCH":
					self.FPGA.fpgaRxConfig(0,0,0,self.systemStatus.dutNo)
				else:
					self.FPGA.fpgaRxConfig(0,0,self.systemStatus.dutNo)
	
			if self.systemParams.jesdProtocol==1 and 0 in [self.skipRxConfig, self.skipFbConfig, self.skipTxConfig] and setupParams.boardType=="BENCH":
				self.FPGA.fpgaHConfig()
				if self.systemParams.syncLoopBack==False:
					self.FPGA.fpgaTxSendK([False]*2)
			
			if setupParams.boardType not in ("BENCH","EVM-1Device"):
				self.FPGA.setLanePolarities()
			
			self.closePageAndNewStep('jesdLinkUpInit')
			self.clearSysrefFlags()
			self.closePageAndNewStep('jesdLinkUpInit')
			self.TOP.sendSysref(self.systemParams.useSpiSysref)
			self.TOP.staggeredTddToggle()
			self.closePageAndNewStep('jesdLinkUpInit')
			self.sysrefCheck(0)
			self.closePageAndNewStep('jesdLinkUpInit')
			self.deviceRefs.broadcastEn=15 
			self.JESD.JESDTX[0].clearDataAlarms()
			self.JESD.JESDRX[0].clearDataAlarms()
			self.deviceRefs.broadcastEn=0
			
				
			if setupParams.skipFpga==0:
				if setupParams.boardType=="BENCH":
					if self.skipRxConfig==0 or self.skipFbConfig==0:
						if self.systemParams.syncLoopBack==False:
							self.deviceRefs.broadcastEn=15
							self.JESD.JESDTX[0].toggleSync()
							self.deviceRefs.broadcastEn=0
						#self.FPGA.checkRxSync()
					if self.skipTxConfig==0:
						if self.systemParams.syncLoopBack==False:
							self.FPGA.fpgaTxSendK([True]*2)
							self.FPGA.fpgaTxSendK([False]*2)
						#for i in range(2):
						#	self.JESD.JESDRX[i].getJesdAlarms(1)
				else:
					self.selectCh(2,0)
					self.selectCh(2,2)
					self.selectCh(0,0)
				try:
					self.FPGA.checkRxSync()
				except:
					pass
				
			self.closePageAndNewStep('dacJesdLinkUp')
			for i in range(2):
				if(self.systemParams.enableTxJesdLinks[i]==True or self.systemParams.customerConfig==False):
					self.JESD.JESDRX[i].getJesdAlarms(1)
			self.deviceRefs.broadcastEn=0
			
			self.closePageAndNewStep('dacJesdLinkUp')
			self.JESD.SERDES[0].postLinkupSerdesWrites()
			self.JESD.SERDES[1].postLinkupSerdesWrites()
			if setupParams.lmkLib.lmkParams.pllEn==False:#self.systemParams.useSpiSysref==False:
				self.LMK.lmkSysrefEn(0)
				
		self.fbAnaWritesPostLinkup()
		self.closePageAndNewStep('dacJesdLinkUp')
		self.clearAllAlarms()
		self.closePageAndNewStep('dacJesdLinkUp')

		if self.systemParams.enableRxIqmcLolTrackingCorr==True:
			self.deviceRefs.device.hardReadAlways=True
			patch=True
			self.TOP.SYSCALIB.do_tune_and_enable(0, \
								0,0, \
								0, \
								MACROConst.MACRO_TUNE_AND_ENABLE__SYSCONFIG_MSG_TO_RxCM4 | \
								MACROConst.MACRO_TUNE_AND_ENABLE__RxCM4_BRINGUP | \
								MACROConst.MACRO_TUNE_AND_ENABLE__CLK_CONFIG_AND_ENABLE_RXCM4)

			self.TOP.SYSCALIB.get_macro_status()
			if patch==True and self.systemStatus.chipVersion==0x10:
				if device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50452_3_0!=1 :
					error("Patch is not downloaded properly into Rx CM4")
				else:
					info("Patch is loaded into Rx CM4")
			self.deviceRefs.device.hardReadAlways=False
			self.rxIqMcSteadyStateEnable()
		
		if self.systemParams.enableTxIqmcLolTrackingCorr==True and self.systemParams.enableTxIqmcDelayChar==False:
			self.TOP.SYSCALIB.start_tx_fw_steady_state(0xFF)
			self.TOP.txIqmcFbLoopbackControl(0)
			info("TX IQMC: TX-FB loopback selection is in SPI mode. To change to pin, use \"AFE.TOP.txIqmcFbLoopbackControl(1)\"")

		self.TOP.disableOverrideTdd()
		if setupParams.skipFpga==False and self.systemParams.jesdProtocol==0 and setupParams.boardType=="BENCH":		# Protocol only because the bit file doesn't support it
			self.FPGA.defGpioConfig()			
			self.FPGA.rxTddEn(0,0)
			self.FPGA.rxTddEn(1,1)
			self.FPGA.fbTddEn(0,0)
			self.FPGA.fbTddEn(1,1)
			self.FPGA.txTddEn(0,0)
			self.FPGA.txTddEn(1,1)
		self.regs.currentPageSelected.setValue(0)		# Closing the last Page			
	#deviceBringup

	@funcDecorator
	def configDigChain(self):
		temp=self.deviceRefs.device.hardReadAlways
		self.deviceRefs.device.hardReadAlways=True
		self.deviceRefs.device.printCommentToLog("START: Doing RX, TX and FB Digital Chain Config.")
		
		if self.systemParams.lowIfNcoTx!=[0,0]:
			lowIfOperand=0x800
		else:
			lowIfOperand=0
			
		if self.systemParams.lowIfNcoFb[1]!=0:
			############# First configuring second FB config
			low_if_nco_fb=[0,0]
			if (self.systemParams.lowIfNcoFb[0]>=0):
				low_if_nco_fb[0]=int(2**32-61440*self.systemStatus.fbLowIfRate[0]+(self.systemParams.lowIfNcoFb[0]*1000))#1Mhz
			else:
				low_if_nco_fb[0]=int(2**32+self.systemParams.lowIfNcoFb[0]*1000)#1Mhz
			if (self.systemParams.lowIfNcoFb[1]>=0):
				low_if_nco_fb[1]=int(2**32-61440*self.systemStatus.fbLowIfRate[1]+(self.systemParams.lowIfNcoFb[1]*1000))#1Mhz
			else:
				low_if_nco_fb[1]=int(2**32+self.systemParams.lowIfNcoFb[1]*1000)#1Mhz
			
			self.TOP.SYSCALIB.do_tx_rx_fb_low_if_interface_rate_configuration(self.systemStatus.txLowIfRate[0], self.systemStatus.txLowIfRate[1], \
															self.systemStatus.rxLowIfRate[0], self.systemStatus.rxLowIfRate[1], \
													self.systemStatus.fbLowIfRate[0], self.systemStatus.fbLowIfRate[1], self.systemStatus.lowIfParams['low_if_mode_tx'], self.systemStatus.lowIfParams['low_if_mode_rx'], 2);
	
			self.TOP.SYSCALIB.do_low_if_mode_configuration(self.systemStatus.lowIfParams['low_if_mode_rx'],self.systemStatus.lowIfParams['low_if_mode_tx'],0x2,self.systemStatus.lowIfParams['low_if_nco_rx0'],\
			self.systemStatus.lowIfParams['low_if_nco_rx1'],self.systemStatus.lowIfParams['low_if_nco_tx0'],self.systemStatus.lowIfParams['low_if_nco_tx1'],low_if_nco_fb[0],low_if_nco_fb[1]); 
			
			#self.TOP.SYSCALIB.do_low_if_mode_configuration(0x0,0,0x2,0,\
			#0,0,0,low_if_nco_fb[0],low_if_nco_fb[1]);
			
			self.TOP.SYSCALIB.do_tune_and_enable(1-self.skipTxConfig, \
			1-self.skipRxConfig,1-self.skipFbConfig, \
			0, \
			0)
			
			cfg1=self.regs.FB[1].FB_DIG.FB_DIG.Register613_144h._Property614_9_8.getValue()
			FBIFMixerEn=self.regs.FB[1].FB_DIG.FB_DIG.FBIFMixerCfg1._FBIFMixerEn.getValue()
			FBIFMixerCorrEn=self.regs.FB[1].FB_DIG.FB_DIG.FBIFMixerCfg1._FBIFMixerCorrEn.getValue()

			
			####### Configuring FB0
			self.TOP.SYSCALIB.do_tx_rx_fb_low_if_interface_rate_configuration(self.systemStatus.txLowIfRate[0], self.systemStatus.txLowIfRate[1], \
															self.systemStatus.rxLowIfRate[0], self.systemStatus.rxLowIfRate[1], \
													self.systemStatus.fbLowIfRate[0], self.systemStatus.fbLowIfRate[1], self.systemStatus.lowIfParams['low_if_mode_tx'], self.systemStatus.lowIfParams['low_if_mode_rx'], 1);
			self.TOP.SYSCALIB.do_low_if_mode_configuration(self.systemStatus.lowIfParams['low_if_mode_rx'],self.systemStatus.lowIfParams['low_if_mode_tx'],1,self.systemStatus.lowIfParams['low_if_nco_rx0'],\
			self.systemStatus.lowIfParams['low_if_nco_rx1'],self.systemStatus.lowIfParams['low_if_nco_tx0'],self.systemStatus.lowIfParams['low_if_nco_tx1'],low_if_nco_fb[0],low_if_nco_fb[1]); 
			#self.TOP.SYSCALIB.do_low_if_mode_configuration(0x0,0,3,0,\
			#0,0,0,low_if_nco_fb[0],low_if_nco_fb[1]);
		
		
		##tune and enable for tx/rx/fb chains
		if True in [self.systemParams.halfRateModeTx,self.systemParams.halfRateModeRx,self.systemParams.halfRateModeFb]:
			self.TOP.SYSCALIB.do_tune_and_enable(1-self.skipTxConfig, \
					1-self.skipRxConfig,1-self.skipFbConfig, \
					MACROConst.MACRO_TUNE_AND_ENABLE__ENABLE_HALFRATE_ANALOG_PROGRAMMING, \
					lowIfOperand)
		else:
			self.TOP.SYSCALIB.do_tune_and_enable(1-self.skipTxConfig, \
					1-self.skipRxConfig,1-self.skipFbConfig, \
					0, \
					lowIfOperand)
	
		if self.systemParams.lowIfNcoFb[1]!=0:
			self.regs.FB[1].FB_DIG.FB_DIG.Register613_144h.Property614_9_8=cfg1
			self.regs.FB[1].FB_DIG.FB_DIG.FBIFMixerCfg1.FBIFMixerEn=FBIFMixerEn
			self.regs.FB[1].FB_DIG.FB_DIG.FBIFMixerCfg1.FBIFMixerCorrEn=FBIFMixerCorrEn
			
		self.regs.TOP.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((69)<<24)
		self.TOP.SYSCALIB.wait_for_macro_done()

		#self.FB[0].FBDIG.setNcoWord(self.systemParams.fbNco[0])
		#self.FB[1].FBDIG.setNcoWord(self.systemParams.fbNco[1])
		if(self.systemParams.halfRateModeFb==1):
			self.regs.FB[0].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=2
			self.regs.FB[1].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=2
		else:
			self.regs.FB[0].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=5
			self.regs.FB[1].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=5

		if(self.systemParams.halfRateModeRx==1):		
			self.regs.RX.DIG_AB[0].RxDecSet.Register27017_100h.Property27027_2_0 = 0
			self.regs.RX.DIG_AB[1].RxDecSet.Register27017_100h.Property27027_2_0 = 0
		else:
			self.regs.RX.DIG_AB[0].RxDecSet.Register27017_100h.Property27027_2_0 = 3
			self.regs.RX.DIG_AB[1].RxDecSet.Register27017_100h.Property27027_2_0 = 3
		self.regs.TX.DAC_DIG_AB[0].tx_top.RegTxInterpCfg5.RdPtrOffDigOutAsyncFIFO=3
		self.regs.TX.DAC_DIG_AB[1].tx_top.RegTxInterpCfg5.RdPtrOffDigOutAsyncFIFO=3
		
		
		
		for i in range(0,2):#The pointer was optimal for some interface rates in TX.
			self.regs.TX.DAC_DIG_AB[i].tx_top.RegTxInterpCfg5.RdPtrOffDigInpAsyncFIFO=13
			self.regs.TX.DAC_DIG_AB[i].tx_top.Tx1DigGainCtrl.BlockEnable=1 ###To enable dig gain
			self.regs.TX.DAC_DIG_AB[i].tx_top.Tx1DigGainCtrl.LutUpdateMode=1
			self.regs.TX.DAC_DIG_AB[i].tx_top.Tx2DigGainCtrl.BlockEnable=1 ###To enable dig gain
			self.regs.TX.DAC_DIG_AB[i].tx_top.Tx2DigGainCtrl.LutUpdateMode=1
			
		for instance in range(2):
			self.regs.RX.DIG_AB[instance].RxDecSet.RxOvrload0.pdn_in=1
			self.regs.RX.DIG_AB[instance].RxDecSet.RxOvrload1.pdn_in=1
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27242_A50h.Property27242_7_0 = 51#3
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27254_A51h.gain_component_n = 51#3
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27266_A52h.gain_component_n = 51#3
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27278_A53h.gain_component_n = 51#3
			
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27242_A50h.gain_corrector_bypass = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27254_A51h.gain_corrector_bypass = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27266_A52h.gain_corrector_bypass = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27278_A53h.gain_corrector_bypass = 0
			
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27290_A54h.Property27290_0_0 = 1
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27290_A54h.rx2_unit_gain_mode = 1
			
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27242_A50h.coef_update_signal = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27254_A51h.coef_update_signal = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27266_A52h.coef_update_signal = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27278_A53h.coef_update_signal = 0
			
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27242_A50h.coef_update_signal = 1
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27254_A51h.coef_update_signal = 1
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27266_A52h.coef_update_signal = 1
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27278_A53h.coef_update_signal = 1
			
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27242_A50h.coef_update_signal = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27254_A51h.coef_update_signal = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27266_A52h.coef_update_signal = 0
			self.regs.RX.DIG_AB[instance].RxDecSet.Register27278_A53h.coef_update_signal = 0
		
			
		self.deviceRefs.device.printCommentToLog("END: Completed RX, TX and FB Digital Chain Config.")
		self.deviceRefs.device.hardReadAlways=temp
	#configDigChain
	
	@funcDecorator
	def setTopSystemParams(self):
		""" "Configuring TOP parameters for MCU" "Done configuring TOP parameters for MCU" """
		device=self.regs
		temp=device.hardReadAlways
		device.hardReadAlways=True
		self.TOP.SYSCALIB.do_txrxfb_configuration(MACROConst.MACRO_TXRXFB_CONFIG__TWO_TWOR_MODE,\
						MACROConst.MACRO_TXRXFB_CONFIG__TWO_TWOT_MODE,\
						MACROConst.MACRO_TXRXFB_CONFIG__TWOF_MODE)
		X=self.systemParams.X
		# Informing Top CM4 about the ADC/DAC Rates
		self.TOP.SYSCALIB.do_tx_rx_fb_adc_dac_configuration(round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6),\
						round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeRx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), \
						round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeTx)),6), round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6),\
						round(self.systemParams.Fs/(X*(1+self.systemParams.halfRateModeFb)),6))
		
		# Informing Top CM4 about Interface Rates
		self.TOP.SYSCALIB.do_tx_rx_fb_interface_rate_configuration(\
					round(self.systemParams.Fs/self.systemParams.ducFactorTx[0]/X,6),\
					round(self.systemParams.Fs/self.systemParams.ducFactorTx[1]/X,6),\
					round(self.systemParams.Fs/self.systemParams.ddcFactorRx[0]/X,6),\
					round(self.systemParams.Fs/self.systemParams.ddcFactorRx[1]/X,6),\
					round(self.systemParams.Fs/self.systemParams.ddcFactorFb[0]/X,6),\
					round(self.systemParams.Fs/self.systemParams.ddcFactorFb[1]/X,6))
		if (self.systemParams.lowIfNcoRx+self.systemParams.lowIfNcoFb+self.systemParams.lowIfNcoTx)!=[0]*6 or(round(self.systemParams.Fs/self.systemParams.ddcFactorRx[0],2)==round(X/2.,2))or(round(self.systemParams.Fs/self.systemParams.ddcFactorRx[1],2)==round(X/2.,2)):
			self.TOP.SYSCALIB.configureLowIf()
		##for fb nco programmation
		self.TOP.SYSCALIB.do_channel_freq_set(0,0,0,0,self.systemParams.fbNco[0]*1000*X/62.5,\
				self.systemParams.fbNcoBand1[0]*1000*X/62.5,self.systemParams.fbNco[1]*1000*X/62.5,self.systemParams.fbNcoBand1[1]*1000*X/62.5)
		# self.systemParams.fbNcoBand1[0]
		device.hardReadAlways=temp
	#setTopSystemParams
	
	def txIqLoIntLpbkDlyChar(self):
		if self.systemStatus.useTxIqmcPatchVersion!=2:
			self.txIqLoIntLpbkDlyCharV2p4()
			return
			
		device=self.regs
		hardReadTemp = device.hardReadAlways
		device.hardReadAlways = True
						
		TxChanelsForCalib = [1,1,1,1] 
						
		############################## Tx IQMC PU Calibration Params ##################################
		Tx_IQMC_Calib_Siggen_Power 			= 8			  # 10-> -10 dBFS ;   20(log(Tone_Scale/16))  ; For -10 dBFS, Siggen Tone_Scale = 5  ; Min Val = 24 (-24dBFS)
		Tx_Freq_Dep_IQMC_Calib_Iterations   = 1			  # Firmware Default is 2
		
		############################### Tx-Fb Int Loopback Settings ###############################
		# Applicable Only if "Tx_Iqmc_Loopback" = 1  i.e, Int Loopback
		TX_STRENGTH  					= 255			 # 255-Max Strength; 0-Min Strength
		FB_STRENGTH 					= 7			  # 7-Max Strength; 0-Min Strength  
		Tx_Fb_Lpbk_Gain	  			= 1			  # 4 = -200mv; 16 = -400 mv; 1 = Highest
		###########################################################################################
		
		######################### Register Writes for TX IQMC Calib ##############################
		#Tx IQMC Calib - Siggen dBFS 
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x3630,Tx_IQMC_Calib_Siggen_Power)			
		# Tx Freq Dep IQMC Calib Iterations 
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x362F,Tx_Freq_Dep_IQMC_Calib_Iterations)
		##########################################################################################

		# Internal Lpbk Settings
		internalLoopbackConfig = 0x1B   # Top CM4 writes Tx,Fb Lpbk Strengths and Removes Loopback after PowerUp
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x3F1C,TX_STRENGTH)
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x3F1E,FB_STRENGTH)
		
		# Tx-Fb Map is 0xC for Internal Lpbk
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x362E,0xC)
		
		# Pass Sysconfig
		self.TOP.SYSCALIB.do_tune_and_enable(0,0,0,0,MACROConst.MACRO_TUNE_AND_ENABLE__SYSCONFIG_MSG_TO_TxCM4)
		
		#################################### Running the Tx IQMC Freq-Dep Calibration #####################################
		if  (TxChanelsForCalib[0] == 1):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 0
			device.RX.ANA_AB.ANA_AB.Register8878_46h.Property8878_16_16=1
			device.RX.ANA_AB.ANA_AB.Register8878_46h.Property8889_22_17 = Tx_Fb_Lpbk_Gain
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_A,internalLoopbackConfig, 0)
			
		if(TxChanelsForCalib[1] == 1):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 0
			device.RX.ANA_AB.ANA_AB.Register8878_46h.Property8878_16_16=1
			device.RX.ANA_AB.ANA_AB.Register8878_46h.Property8889_22_17 = Tx_Fb_Lpbk_Gain
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_B,internalLoopbackConfig, 0)
			
		if(TxChanelsForCalib[2] == 1):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 1
			device.RX.ANA_CD.ANA_CD.Register46448_46h.Property46449_16_16 =1
			device.RX.ANA_CD.ANA_CD.Register46448_46h.Property46462_22_17 = Tx_Fb_Lpbk_Gain	
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_C,internalLoopbackConfig, 0)
			
		if(TxChanelsForCalib[3] == 1):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 1
			device.RX.ANA_CD.ANA_CD.Register46448_46h.Property46449_16_16 =1
			device.RX.ANA_CD.ANA_CD.Register46448_46h.Property46462_22_17 = Tx_Fb_Lpbk_Gain
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_D,internalLoopbackConfig, 0)	
				
		#######################################################################################################	
		
		self.TOP.overrideTdd(1,1,1)		
		device.TOP.INTERNAL_MACRO.STREAMING.Register22233_110h.Property22233_3_0 = 0

		# Return the Tx-Fb Delay Estimates
		Tx_Fb_Dly = [0,0,0,0]		
		Tx_Fb_Dly[0] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48001_31_16
		Tx_Fb_Dly[1] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48002_15_0
		Tx_Fb_Dly[2] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48003_31_16
		Tx_Fb_Dly[3] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48004_15_0
			
		
		### !!! Start of Change - TxCM4_20_Apr_19_PATCH_1p1_V011 !!! ###
		delayValidity = [0,0,0,0]
		delayValidity[0] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48005_3_0.getValue()
		delayValidity[1] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48006_7_4.getValue()
		delayValidity[2] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48007_11_8.getValue()
		delayValidity[3] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property47655_15_12.getValue()

		for iter in range(4):
			if(delayValidity[iter] !=1):
				Tx_Fb_Dly[iter] = 0		
		### !!! End of Change !!! ###
		
		# Restore hardRead Status
		device.hardReadAlways = hardReadTemp
		return(Tx_Fb_Dly)
		
	#txIqLoIntLpbkDlyChar	
	
	@funcDecorator	
	def txIqLoDelayLutRead(self):		
		
		iqmc_rate_map = {2:  0, 3:  1, 4:  2, 6:  3, 8:  4, 12: 5}
		adc_rate_map  = {48: 0, 54: 1 ,56: 2, 24: 3, 27: 4, 28: 5}
		
		interface_rate = [int(round(self.systemParams.Fs/self.systemParams.ducFactorTx[0]/self.systemParams.X,6)),\
						  int(round(self.systemParams.Fs/self.systemParams.ducFactorTx[1]/self.systemParams.X,6))]
		iqmc_rate	 = [self.systemStatus.txLowIfRate[0], self.systemStatus.txLowIfRate[1]]		
		adc_rate	   = int(self.systemParams.Fs/self.systemParams.X/(1+self.systemParams.halfRateModeTx))		
				
						#			2X  		 3X  		 4X			 6X		 	 8X			 12X
		#'''48X''' TxFbDelayLUT = [[153.54,  	 163.56,	 167.08,	 187.125,	199.0,	  233.0   ],\ 	
		#'''54X'''				 [171.58,	  180.5,	  203.08,	 221.0,	  231.67,	 262.0   ],\
		#'''56X'''				 [170.25,	  178.875,	200.41,	 217.75,	 228.0,	  257.25  ],\
		#'''24X'''				 [157.25,	  169.125,	174.5,	  198.25,	 0,		  0	   ],\
		#'''27X'''				 [174.875,	 185.4375,   209.75,	 230.875,	0,		  0	   ],\
		#'''28X'''				 [173.375,	 183.625,	206.75,	 227.25,	 0,		  0	   ]]
		
		# This LUT Stores the Tx-Fb Delay in terms of Tx Interface Rate Samples
		#				 2X  		  3X  		  4X		  6X		  8X		  12X
		TxFbDelayLUT = [[162.5,	173.9,	178.0,	201.0,	214.6,	254.3],\
						[180.2,	190.1,	213.5,	233.9,	249.0,	282.7],\
						[170.25,	  178.875,	200.41,	 217.75,	 228.0,	  257.25  ],\
						[172.565,	  186.117,	193.252,	  212.523,	 0,		  0	   ],\
						[190.455,	 202.573,   228.219,	 252.573,	0,		  0	   ],\
						[173.375,	 183.625,	206.75,	 227.25,	 0,		  0	   ]] 	
							  
		Tx_Fb_Delay = [0,0,0,0]
		
		for channel in range(4):			
			Tx_Fb_Delay[channel] = TxFbDelayLUT[adc_rate_map.get(adc_rate)][iqmc_rate_map.get(iqmc_rate[channel/2])]
		
		return(Tx_Fb_Delay)
	#txIqLoDelayLutRead

	@funcDecorator
	def txIqLoExtLpbkDlyChar(self,txChannel=0):	
		if self.systemStatus.useTxIqmcPatchVersion!=2:
			self.txIqLoExtLpbkDlyCharV2p4()
			return
		device=self.regs
		hardReadTemp = device.hardReadAlways
		device.hardReadAlways = True
		self.regs.TOP.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44377_0_0=1
		# Fb_Mux_Mode in steady state
		dual_fb_mode = (self.systemParams.txIqMcCalibMode==2)   			# 0 -Single Fb Mode ; 1- Dual Fb_Mode
		dual_fb_map = [0,1,2,3]	 # [0,1,2,3] -> TxAB to FbA  and TxCD to FbC   # Has effect only in Dual_Fb Mode 
		single_fb_ch = self.systemParams.txIqMcCalibMode%2   			# 0 - Fb A for Single Fb Mode ; 1 -  Fb C for Single Fb Mode  Has effect only in Single_Fb Mode
		Tx_IQMC_Full_Band_Estimation = 0		
				
		# Steady State Tx-Fb Map Programming 
		tx_fb_map_val = self.TOP.SYSCALIB.compute_tx_steady_sate_tx_fb_map(dual_fb_mode,single_fb_ch,dual_fb_map)	
		
				
		############################## Tx IQMC PU Calibration Params ##################################
		Tx_IQMC_Calib_Siggen_Power 			= 8			  # 10-> -10 dBFS ;   20(log(Tone_Scale/16))  ; For -10 dBFS, Siggen Tone_Scale = 5  ; Min Val = 24 (-24dBFS)
		Tx_Freq_Dep_IQMC_Calib_Iterations   = 1			  # Firmware Default is 2
		
		############################### Tx-Fb Int Loopback Settings ###############################
		# Applicable Only if "Tx_Iqmc_Loopback" = 1  i.e, Int Loopback
		TX_STRENGTH  					= 255			 # 255-Max Strength; 0-Min Strength
		FB_STRENGTH 					= 7			  # 7-Max Strength; 0-Min Strength  
		Tx_Fb_Lpbk_Gain	  			= 1			  # 4 = -200mv; 16 = -400 mv; 1 = Highest
		###########################################################################################
		
		######################### Register Writes for TX IQMC Calib ##############################
		#Tx IQMC Calib - Siggen dBFS 
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x3630,Tx_IQMC_Calib_Siggen_Power)			
		# Tx Freq Dep IQMC Calib Iterations 
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x362F,Tx_Freq_Dep_IQMC_Calib_Iterations)
		##########################################################################################

				
		# For External Loopback based PowerUp Calib - The Steady State and PowerUp Tx-Fb Map are kept Same
		# Setting Tx-Fb Map for PU
		internalLoopbackConfig = 0x3F		
		self.TOP.SYSCALIB.memWrite8("topCm4Dram",0x362E,tx_fb_map_val)
		
		# Pass Sysconfig
		self.TOP.SYSCALIB.do_tune_and_enable(0,0,0,0,MACROConst.MACRO_TUNE_AND_ENABLE__SYSCONFIG_MSG_TO_TxCM4)
		
		#################################### Running the Tx IQMC Freq-Dep Calibration #####################################
		if  (txChannel == 0):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 0
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_A,internalLoopbackConfig, 0)			
		elif(txChannel == 1):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 0
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_B,internalLoopbackConfig, 0)			
		elif(txChannel == 2):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 1
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_C,internalLoopbackConfig, 0)			
		elif(txChannel == 3):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13 = 1
			self.TOP.SYSCALIB.start_tx_iqmc_only_powerup_calib(MACROConst.MACRO_POWERUP_CALIB__CHAIN_D,internalLoopbackConfig, 0)	
		
		#######################################################################################################	
		
		self.TOP.overrideTdd(1,1,1)
		
		device.TOP.INTERNAL_MACRO.STREAMING.Register22233_110h.Property22233_3_0 = 0
		
		# Return the Tx-Fb Delay Estimates
		Tx_Fb_Dly = [0,0,0,0]		
		self.deviceRefs.device.printCommentToLog("External-Action: Read and store this. TX IQMC External Loopback Delay Value for TXA")
		Tx_Fb_Dly[0] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48001_31_16
		self.deviceRefs.device.printCommentToLog("External-Action: Read and store this. TX IQMC External Loopback Delay Value for TXB")
		Tx_Fb_Dly[1] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48002_15_0
		self.deviceRefs.device.printCommentToLog("External-Action: Read and store this. TX IQMC External Loopback Delay Value for TXC")
		Tx_Fb_Dly[2] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48003_31_16
		self.deviceRefs.device.printCommentToLog("External-Action: Read and store this. TX IQMC External Loopback Delay Value for TXD")
		Tx_Fb_Dly[3] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48004_15_0
				
				
		if self.systemParams.mode2t2r==0:#self.systemParams.pllMuxModes in (0,1,2) or self.systemParams.mode2t2r==False:
			self.regs.TOP.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44377_0_0=0
		else:
			self.regs.TOP.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44377_0_0=1
		
		### !!! Start of Change - TxCM4_20_Apr_19_PATCH_1p1_V011 !!! ###		
		delayValidity = [0,0,0,0]
		self.deviceRefs.device.printCommentToLog("TX IQMC External Loopback Delay Validity for TXA.")
		delayValidity[0] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48005_3_0.getValue()
		self.deviceRefs.device.printCommentToLog("TX IQMC External Loopback Delay Validity for TXB.")
		delayValidity[1] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48006_7_4.getValue()
		self.deviceRefs.device.printCommentToLog("TX IQMC External Loopback Delay Validity for TXB.")
		delayValidity[2] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48007_11_8.getValue()
		self.deviceRefs.device.printCommentToLog("TX IQMC External Loopback Delay Validity for TXC.")
		delayValidity[3] = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property47655_15_12.getValue()

		if(delayValidity[txChannel] !=1):
			Tx_Fb_Dly[txChannel] = 0	
		### !!! End of Change !!! ###
		
		# Restore hardRead Status
		device.hardReadAlways = hardReadTemp
		return(Tx_Fb_Dly[txChannel])
		
	#txIqLoExtLpbkDlyChar	
	
	@funcDecorator
	def doTxIqmcExternalLoopback(self,txChannel=0):
		self.deviceRefs.broadcastEn=0
		
		if self.deviceRefs.device.currentPageSelected!=None:
			logTemp=self.deviceRefs.device.rawWriteLogEn
			self.deviceRefs.device.rawWriteLogEn=0
			self.deviceRefs.device.currentPageSelected.setValue(0)
			self.deviceRefs.device.rawWriteLogEn=logTemp
		
		self.closePageAndNewStep('rstDevice')
		self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Toggle HW Reset")
		self.softReset()
		self.initializeConfig()
		if False in self.systemStatus.validConfig:
			if "pauseHereCustom" in dir(Globals):
				pauseHereCustom(title='Invalid Configuration.',msg='Invalid Configuration. Please select Valid configuration. Refer to Log for Errors.')
			return
		if self.systemStatus.chipId==0xffff:
			error("SPI not working.")
			return	
		comment="The list of parameters. In the arrays of 2 elements, each value corresponds to one 2T2R1F.\n// "
		count=0
		for i in vars(self.systemParams):
			if "__" not in i:
				exec("comment+=i+"+"': '+str(self.systemParams."+i+")+';  '")
				count+=1
				if count%5==0:
					comment+="\n// "
		self.deviceRefs.device.printCommentToLog(comment)
		if setupParams.skipLmk==0:
			self.LMK.lmkConfig()
			if setupParams.lmkLib.lmkParams.pllEn==False:#self.systemParams.useSpiSysref==False:
				self.LMK.lmkSysrefEn(1)
		
		self.closePageAndNewStep('wakeUp')
		self.wakeupDevice()
		self.TOP.GPIO.reloadEfuseChain()
		self.TOP.GPIO.checkEfuse()
		self.TOP.GPIO.enableEfuseClock(0)
		
		self.closePageAndNewStep('rstMCU')
		
		self.TOP.SYSCALIB.reset(1)
		self.TOP.SYSCALIB.reset(0)
		self.delay(0.1)
		self.closePageAndNewStep('rstMCU')
		self.TOP.SYSCALIB.loadTopPatch()
		if self.systemParams.useMacros==True and 1 not in self.systemParams.ddcFactorFb+self.systemParams.ddcFactorRx:
			self.closePageAndNewStep('rstMCU')
			self.setTopSystemParams()
		self.closePageAndNewStep('efusebyMCU')
		self.TOP.loadPllEfusePackets()
		#self.closePageAndNewStep('efusebyMCU')
		#self.deviceRefs.device.printCommentToLog("If you have a RX or TX DSA packet to be applied, apply it here.")
		self.regs.TOP.TIMING_CTRL.TG_TOP.Register44386_4D0h.Property44689_31_0=0x101
		# PLL efuse loads
		if self.systemStatus.pllValid[0]==True:
			self.closePageAndNewStep('pll0Config')
		else:
			self.closePageAndNewStep('pll0Config')
		self.TOP.requestPllSpiAccess(1)
		
		for i in range(5):
			if self.systemStatus.pllValid[i]==True:
				self.closePageAndNewStep('pll'+str(i)+'Config')
				self.TOP.PLL[i].configurePll()
			else:
				self.closePageAndNewStep('pll'+str(i)+'PowerDown')
				self.TOP.PLL[i].powerUpPll(0)
		if self.systemStatus.pllLockStatus[1]==False and self.systemParams.simulationMode==False:
			error("DC PLL Didn't lock")
			return
		if self.systemStatus.pllValid[4]==True:
			self.closePageAndNewStep('pll4Config')
		else:
			self.closePageAndNewStep('pll4PowerDown')
		self.TOP.requestPllSpiAccess(0)
		self.closePageAndNewStep('efuseToAnalog')
		self.TOP.SYSCALIB.changeTopClkToPll()
		self.closePageAndNewStep('efuseToAnalog')
		self.TOP.loadEfusePackets()
		self.closePageAndNewStep('topConfig')
		self.TOP.initialTopConfig()
		if self.systemParams.jesdABLvdsSync==True:
			self.regs.RX.ANA_AB.ANA_AB.Register8874_42h.Property8874_20_16=23
		if self.systemParams.jesdCDLvdsSync==True:
			self.regs.RX.ANA_CD.ANA_CD.Register46440_42h.Property46440_20_16=23

		self.closePageAndNewStep('clkMuxConfig')
		self.configPllMux()
		
		self.closePageAndNewStep('sigChainConfig')
		self.JESD.SUBCHIP.jesdSubchipInitConfig()

		self.deviceRefs.broadcastEn=0
		if self.systemParams.useMacros==True and 1 not in self.systemParams.ddcFactorFb+self.systemParams.ddcFactorRx:
			self.closePageAndNewStep('sigChainConfig')
			self.configDigChain()
		else:
			if self.skipFbConfig==0:
				if self.systemParams.ddcFactorFb[0]==self.systemParams.ddcFactorFb[1]:
					self.deviceRefs.broadcastEn=15
					self.FB[0].FBDIG.configFbDig()
					self.deviceRefs.broadcastEn=0
				else:
					self.FB[0].FBDIG.configFbDig()
					self.FB[1].FBDIG.configFbDig()
					
			self.deviceRefs.broadcastEn=0
			if self.skipRxConfig==0:
				if self.systemParams.ddcFactorRx[0]==self.systemParams.ddcFactorRx[1]:
					self.deviceRefs.broadcastEn=15
					self.RX.RXDIG[0].configRxDig()
					self.deviceRefs.broadcastEn=0
				else:
					self.RX.RXDIG[0].configRxDig()
					self.RX.RXDIG[1].configRxDig()
			self.deviceRefs.broadcastEn=0
			
			if self.skipTxConfig==0:
				if self.systemParams.ducFactorTx[0]==self.systemParams.ducFactorTx[1]:
					self.deviceRefs.broadcastEn=15
					self.TX.DACDIG[0].configTxDig()
					self.deviceRefs.broadcastEn=0
				else:
					self.TX.DACDIG[0].configTxDig()
					self.TX.DACDIG[1].configTxDig()
		

		self.closePageAndNewStep('OvTDDpin')
		self.TOP.tddConfig()
		self.closePageAndNewStep('OvTDDpin')
		self.TOP.overrideTdd(0,0,0)
		self.closePageAndNewStep('OvTDDpin')
		self.TOP.overrideTdd(0,0,1)
		self.closePageAndNewStep('analogWrite')
		self.dacAnaWrites()
		self.closePageAndNewStep('analogWrite')
		self.TOP.overrideTdd(1,0,0)
		self.rxAnaWrites()
		self.jesdSwing(7)
		self.closePageAndNewStep('analogWrite')
		self.TOP.overrideTdd(0,1,0)
		self.fbAnaWrites()
		self.closePageAndNewStep('analogWrite')
		if self.systemParams.pllMuxModes in (0,1,2) and self.systemParams.mode2t2r!=0:
			self.anaWritesForTddMode2T2R()

		self.TOP.loadEfusePacketsPostAnaWrites()

		if self.systemParams.halfRateModeFb==1:
			self.regs.FB[0].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=4
			self.regs.FB[1].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=4		
		
		if (self.systemStatus.jesdConfigParams[0] == self.systemStatus.jesdConfigParams[1]):
			self.deviceRefs.broadcastEn=15
			self.closePageAndNewStep('jesdConfig')
			self.JESD.JESDTX[0].jesdConfig()
			self.closePageAndNewStep('jesdConfig')
			self.JESD.JESDRX[0].jesdConfig()
			self.deviceRefs.broadcastEn=0
		else:
			for i in range(2):
				if self.skipRxConfig==0 or self.skipFbConfig==0:
					self.closePageAndNewStep('jesdConfig')
					self.JESD.JESDTX[i].jesdConfig()
				if self.skipTxConfig==0:
					self.closePageAndNewStep('jesdConfig')
					self.JESD.JESDRX[i].jesdConfig()
		
		
		self.txIqLoCalibInit()
			
		self.TOP.enableSigGen(1)
		self.TOP.sendSysref(1)
		self.TOP.staggeredTddToggle()
		self.deviceRefs.broadcastEn=15
		self.TOP.DSA[0].setTxDsa(0,1)
		self.TOP.DSA[0].setTxDsa(1,1)
		self.TOP.DSA[0].setTxDsa(0,0)
		self.TOP.DSA[0].setTxDsa(1,0)
		self.deviceRefs.broadcastEn=0
		
		delayValue=self.txIqLoExtLpbkDlyChar(txChannel)
		self.regs.currentPageSelected.setValue(0)		# Closing the last Page		
		return delayValue
	#doTxIqmcExternalLoopack
	
	@funcDecorator	
	def txIqLoCalibInit(self,numDlySampToTrack=2):
		""" "Initializing TXIQMC" "Done initializing TXIQMC" """
		if self.systemStatus.useTxIqmcPatchVersion!=2:
			self.txIqLoCalibInitV2p4()
			return
		device=self.regs
		hardReadTemp = device.hardReadAlways
		device.hardReadAlways = True
		
		# Fb_Mux_Mode in steady state
		dual_fb_mode = (self.systemParams.txIqMcCalibMode==2)   			# 0 -Single Fb Mode ; 1- Dual Fb_Mode
		dual_fb_map = [0,1,2,3]	 # [0,1,2,3] -> TxAB to FbA  and TxCD to FbC   # Has effect only in Dual_Fb Mode 
		single_fb_ch = self.systemParams.txIqMcCalibMode%2   			# 0 - Fb A for Single Fb Mode ; 1 -  Fb C for Single Fb Mode  Has effect only in Single_Fb Mode
		
		Tx_IQMC_Full_Band_Estimation = self.systemParams.txIqmcFullBandEstimation
		
		# Power Up Delay Estimation - Nominal Delay
		Tx_Fb_Nominal_Delay = self.txIqLoDelayLutRead()
		for channel in range(4):
			Tx_Fb_Nominal_Delay[channel] = int(Tx_Fb_Nominal_Delay[channel])
				
		# Steady State Tx-Fb Map Programming 
		tx_fb_map_val = self.TOP.SYSCALIB.compute_tx_steady_sate_tx_fb_map(dual_fb_mode,single_fb_ch,dual_fb_map)	
		self.TOP.SYSCALIB.do_tx_rx_algo_config(0x80,Tx_IQMC_Full_Band_Estimation,tx_fb_map_val)
		
		# LO Leakage Changed Order Delta->0
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47818_15_15 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47546_14_0 = int(1163/2)
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47820_31_31 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47819_30_16 = int(1163/2)
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47822_15_15 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47821_14_0 = 0
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47824_31_31 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47823_30_16 = 0

		# Averaging of 2**23 Samples for LO Leakage
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47545_6_0 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47817_7_7 = 1
		
		# IQMC Target Performance
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47842_15_15 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47841_14_8 = 20

		# Powerup Nominal Delay
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48016_15_15 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48020_31_31 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48022_15_15 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48024_31_31 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47586_14_0 = Tx_Fb_Nominal_Delay[0]
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48019_30_16 = Tx_Fb_Nominal_Delay[1]
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48021_14_0 = Tx_Fb_Nominal_Delay[2]
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48023_30_16 = Tx_Fb_Nominal_Delay[3]

		# DSA-Dep IQMC Power-Up Calib - Single Tone based Correction
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48083_27_26 = 0
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48084_28_28 = 1
		
		# # Writes for Enabling Channel Tracking Feature
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47940_9_9 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47939_8_8 = 1			
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48043_1_1 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47584_0_0 = 1
				
		# Tx LO DSA Indep Tracking
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47922_8_8 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47921_9_9 = 1
		
		# Number of Delay Samples to be Tracked in Steady State # .2 Format
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47585_6_0 = numDlySampToTrack * 4
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47960_7_7 = 1	
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47961_14_8 = numDlySampToTrack * 4
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47962_15_15 = 1 

		# Write to Disable Channel Ratio Reset Upon Sudden Channel Change based Divg
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47896_7_7 = 1		
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47555_6_0 = 15
		
		# Change IQMC BGCE Threshold
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47882_15_15 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47881_14_8 = 20
		
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48056_31_31 = 1
		device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48055_30_24 = 19
		
		### !!! Start of Change - TxCM4_20_Apr_19_PATCH_1p1_V011 !!! ###	
		# Sig Power -58 dBFS per bin for Fullband
		if(self.systemParams.txIqmcFullBandEstimation == 1): 
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48101_28_16 = 5			
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48103_12_0 = 5
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48102_29_29 = 1
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property48104_13_13 = 1
						
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47846_30_16 = 3
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47844_12_0 = 3
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47845_13_13 = 1
			device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47847_31_31 = 1
		### !!! End of Change !!! ###	
		
		# Patching is to be done here
		self.TOP.loadTxIqMcPatch()
		
		#Tx CM4 bring out of  reset and Pass Sysconfig Message
		self.TOP.SYSCALIB.do_tune_and_enable(0,0,0,0,MACROConst.MACRO_TUNE_AND_ENABLE__CLK_CONFIG_AND_ENABLE_TXCM4)
		self.TOP.SYSCALIB.do_tune_and_enable(0,0,0,0,MACROConst.MACRO_TUNE_AND_ENABLE__TxCM4_BRINGUP)
		self.TOP.SYSCALIB.do_tune_and_enable(0,0,0,0,MACROConst.MACRO_TUNE_AND_ENABLE__SYSCONFIG_MSG_TO_TxCM4)
		
		# Check for Patch Validity
		if(device.TX.TXIQMC.tx_iqmc.Register47686_49Ch.Property47686_2_0 != 1):
			error("TxCm4 Patch Download Failed")
		
		# To Support High IQMC # I and Q -24 dBc support -  To be done for PU Also
		self.TOP.SYSCALIB.memWrite16("txiqmcDram",0x1195A,16580)			
		# Iterative Interpolation of 2 
		self.TOP.SYSCALIB.memWrite8("txiqmcDram",0x1194B,2)
		
		### !!! Start of Change - TxCM4_20_Apr_19_PATCH_1p1_V011 !!! ###	
		# Channel Hold 1 for Fullband
		if(self.systemParams.txIqmcFullBandEstimation == 1): 
			self.TOP.SYSCALIB.memWrite8("txiqmcDram",0x11B8C,1)
		### !!! End of Change !!! ###
		
		# Restore hardRead Status
		device.hardReadAlways = hardReadTemp
		
	#txIqLoCalibInit	
	
	@funcDecorator
	def txIqMcSteadyStateCalibPG1p1(self,usrDly=0,delayVal48xClk=[0,0,0,0]):
		
		device=self.regs
		if self.systemParams.txIqMcCalibMode==2:	# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
			dual_fb_mode=1
			single_fb_ch=0
		else:
			dual_fb_mode=0
			single_fb_ch=self.systemParams.txIqMcCalibMode&1
		
		dual_fb_map = [0,1,2,3]	 # [0,1,2,3] -> TxAB to FbA  and TxCD to FbC   # Has effect only in Dual_Fb Mode 
		if self.systemStatus.useTxIqmcPatchVersion==0:
			device.TX.TXIQMC.tx_iqmc.Register46507_74h.Property46507_23_0=int(round(10**(-35/10.)*2**24))
			device.TX.TXIQMC.tx_iqmc.Register46507_74h.Property46596_23_0=int(round(10**(-35/10.)*2**24))
		hardReadTemp = device.hardReadAlways
		device.hardReadAlways = True
		if self.systemParams.txIqMcCalibMode == 2:
			self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 1
			self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= 0xa
		else:
			self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 1
			self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= 4
		
		
		interface_rate = [int(round(self.systemParams.Fs/self.systemParams.ducFactorTx[0]/self.systemParams.X,6)),\
						  int(round(self.systemParams.Fs/self.systemParams.ducFactorTx[1]/self.systemParams.X,6))]
		#low_if_factor = [1,1]	
		#iqmc_rate	 = [low_if_factor[0]*interface_rate[0], low_if_factor[1]*interface_rate[1]]
		iqmc_rate	 = [self.systemStatus.txLowIfRate[0], self.systemStatus.txLowIfRate[1]]
						
		## Store User Specified Delay (from Char) in terms of 48X Clk   	
		Tx_Fb_Dly_48x_Clk = delayVal48xClk 
								
		## If User is not Passing the Delay (48x Clk), then Read the LUT to get Delay in terms of IQMC rate and convert it to 48x Clk Delay
		Tx_Fb_Delay_IQMC_Rate = self.txIqLoDelayLutRead()		
		if(usrDly == 0):
			for channel in range(4):												
				Tx_Fb_Dly_48x_Clk[channel] = self.TOP.SYSCALIB.convert_interface_rate_sample_delay_to_tx_fw_value(iqmc_rate[channel/2],Tx_Fb_Delay_IQMC_Rate[channel])   
		
		
		self.TOP.SYSCALIB.specify_tx_fw_tx_fb_loopback_delay(15,0,\
														 Tx_Fb_Dly_48x_Clk[0],\
														 Tx_Fb_Dly_48x_Clk[1],\
														 Tx_Fb_Dly_48x_Clk[2],\
														 Tx_Fb_Dly_48x_Clk[3])
														 
		# Tx-Fb Steady State - Initial Fb Mux Value should be Invalid 
		if(dual_fb_mode == 1):
			FbMuxSelInvConnection = 0xA  
		else:
			FbMuxSelInvConnection = 0x4
		
		# Timing Controller configuration for Tx-Fb Mapping												 
		self.TOP.TIMINGCTRL.configure_timing_controller_for_tx_steady_state_fb_mux_mode(1,FbMuxSelInvConnection,single_fb_ch,dual_fb_map[2],dual_fb_map[0],dual_fb_map[3],dual_fb_map[1],dual_fb_mode)

		# Remove Fb Mux Sel Override that is set by Top Cm4
		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44602_118h.Property44705_25_24 = 0
				
		# Steady State Macro Call								
		# self.TOP.SYSCALIB.start_tx_fw_steady_state(0xFF)
		# if self.systemParams.releaseTxMuxControlToPins==True:
			# self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 0
		# elif self.systemParams.txIqMcCalibMode == 2:
			# self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 1
			# self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= 0xa
		# else:
			# self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= 1
			# self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= 4

		# Restore hardRead Status
		device.hardReadAlways = hardReadTemp
	#txIqMcSteadyStateCalibPG1p1
	
	# Add below function to mAfeLibrary.py
	@funcDecorator
	def getTxIqLoConvgStatus(self,ch=0):
		# ch - {0,1,2,3} corresponds to Tx {A,B,C,D}		
		device=self.regs		
		hardReadTemp = device.hardReadAlways
		device.hardReadAlways = True
		
		# Error out for invalid channel index
		if (ch not in [0,1,2,3]):
			error("Wrong channel index. Valid channel index are 0,1,2 and 3")
			return
			
		# Function to return the convergence state for IQ/LO
		# #0:Not Converged #1:Converged #2:Out of Convergence #3:Diverged
		def getTxIqLoConvgState(ch=0):
			
			CONVG_STATE_MEANING = {0:"NOT CONVERGED" ,1:"CONVERGED" ,2:"NOT CONVERGED", 3:"NOT CONVERGED"}		
			if(ch==0):
				convgStateIQ = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property47663_3_0.getValue()
				convgStateLO = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48028_19_16.getValue()
			elif(ch==1):
				convgStateIQ = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48025_7_4.getValue()
				convgStateLO = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48029_23_20.getValue()
			elif(ch==2):
				convgStateIQ = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48026_11_8.getValue()
				convgStateLO = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48030_27_24.getValue()
			elif(ch==3):
				convgStateIQ = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48027_15_12.getValue()
				convgStateLO = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property48031_31_28.getValue()		
			else:
				error("Wrong channel index. Valid channel indices are 0,1,2 and 3")	
			
			# Decode Convg State for IQMC/LO. Default decode is "NOT CONVERGED" 
			convgStateDecodedIQ = CONVG_STATE_MEANING.get(convgStateIQ, "NOT CONVERGED")
			convgStateDecodedLO = CONVG_STATE_MEANING.get(convgStateLO, "NOT CONVERGED")
			
			return [convgStateDecodedIQ, convgStateDecodedLO]			
		# getTxIqLoConvgState
			
		# Function to return the BGCE state for IQ/LO
		# #0,1:NO_NEW_UNCALIBRATED_SIG_FOUND  #2,3,4,5:NEW_UNCALIBRATED_SIG_FOUND 
		def getTxIqLoBGCEState(ch=0):
		
			BGCE_STATE_MEANING = {0:"NO_NEW_UNCALIBRATED_SIG_FOUND", 1:"NO_NEW_UNCALIBRATED_SIG_FOUND", 2:"NEW_UNCALIBRATED_SIG_FOUND", 3:"NEW_UNCALIBRATED_SIG_FOUND", 4:"NEW_UNCALIBRATED_SIG_FOUND", 5:"NEW_UNCALIBRATED_SIG_FOUND"}
			BGCE_STATE_ADDR_IQMC = [0x200117BC, 0x200117E0, 0x20011804, 0x20011828]
			BGCE_STATE_ADDR_LO   = [0x20010A14, 0x20010A44, 0x20010A74, 0x20010AA4]		
			self.TOP.SYSCALIB.readTxIqmcLo(BGCE_STATE_ADDR_IQMC[ch],1)
			bgceStateIQ = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property47816_31_0.getValue() 
			self.TOP.SYSCALIB.readTxIqmcLo(BGCE_STATE_ADDR_LO[ch],1)
			bgceStateLO = device.TX.TXIQMC.tx_iqmc.Register47686_49Ch._Property47816_31_0.getValue()
			
			# Decode BGCE State for IQMC/LO. Default decode is "NEW_UNCALIBRATED_SIG_FOUND"
			bgceStateDecodedIQ = BGCE_STATE_MEANING.get(bgceStateIQ, "NEW_UNCALIBRATED_SIG_FOUND")
			bgceStateDecodedLO = BGCE_STATE_MEANING.get(bgceStateLO, "NEW_UNCALIBRATED_SIG_FOUND")
			return [bgceStateDecodedIQ,bgceStateDecodedLO]
			
		# getTxIqLoBGCEState

		# Read Convg,BGCE state for IQMC/LO
		convgStateTxIqLo = getTxIqLoConvgState(ch)
		bgceStateTxIqLo  = getTxIqLoBGCEState(ch)
		
		## Logic to decide binary convergence status for IQMC
		if((convgStateTxIqLo[0]=="CONVERGED") and (bgceStateTxIqLo[0]=="NO_NEW_UNCALIBRATED_SIG_FOUND")):
			convgStatusIQ = 1
		else:
			convgStatusIQ = 0

		## Logic to decide binary convergence status for LO
		if((convgStateTxIqLo[1]=="CONVERGED") and (bgceStateTxIqLo[1]=="NO_NEW_UNCALIBRATED_SIG_FOUND")):
			convgStatusLO = 1
		else:
			convgStatusLO = 0
		
		device.hardReadAlways = hardReadTemp	
		return [convgStatusIQ,convgStatusLO]	
		
	# getTxIqLoConvgStatus
		
	@funcDecorator
	def rxDsaCalibration(self,CHAIN_TO_CALIB=0xf):
		""" "Starting RX DSA Calibration" "Completed RX DSA Calibration" """
		device=self.regs
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2t_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2t_en_cd=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2r_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2r_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_1f_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_1f_en_cd=0
		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44440_504h.Property44471_8_8=1
		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44440_504h.Property44472_16_16=0
		
		self.deviceRefs.broadcastEn=15
		self.TOP.DSA[0].setGainControl(3)
		self.deviceRefs.broadcastEn=0
		
		temp=device.hardReadAlways
		device.hardReadAlways=True
		
		INIT_MACRO = 1
		CONTINUE_MACRO = 2
		DONE_MACRO = 15
		RX_DSA_CALIB = 2
		DSA_START = 0
		DSA_STOP = 28
		#CHAIN_TO_CALIB = 15
		TONE_ID = 0
		F_DEPEND_EN = 0
		INTERNAL_LOOOPBACK_EN = 0
	
		DSA_dsa_nd_vga_cal=1
		DSA_is_vga_or_lna=0
		DSA_dsa_idx_for_vga_cal=0
		DSA_vga_idx_for_dsa_cal=0
		DSA_vga_start=0
		DSA_vga_stop=0
		TONE_SCALE = 14
		TONE_TRANSMISSION = 0
		for chNo in range(2):
			device.RX.DIG_AB[chNo].RxDecSet.Register28414_402h.dsa_independent_dc_en=1
			device.RX.DIG_AB[chNo].RxDecSet.Register28418_802h.dsa_independent_dc_en=1
		if self.systemStatus.chipVersion>0x10:
			PHASE_TH=100
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=1
			device.writeReg(0x350d,PHASE_TH)
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=0
		
		
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=1
			TH_DB=25.0
			q_MultiToneMaxSpurLevel   = 10**(TH_DB/20.)*2**23
			device.writeReg32(0x3534,int(round(q_MultiToneMaxSpurLevel)))
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=0   
		
		for i in range(0,2):
			device.TOP.DSA_CNTRL[i].RX_DSA_CTRL.Register44985_2F8h.en_byp_dsa_code = 0 
			device.TOP.DSA_CNTRL[i].RX_DSA_CTRL.Register45002_658h.en_byp_dsa_code = 0	
		
		self.closePageAndNewStep('rxDsaCalibration')
		self.TOP.SYSCALIB.macro_factory_calibration_control(INIT_MACRO,\
										RX_DSA_CALIB,\
										0,\
										DSA_START,\
										DSA_STOP,\
										CHAIN_TO_CALIB,\
										TONE_TRANSMISSION,\
										F_DEPEND_EN,\
										0,\
										INTERNAL_LOOOPBACK_EN,\
										TONE_ID,\
										TONE_SCALE,\
										0)
		########### CONTINUE ############################
		for currChannel in range(4):
			if (self.systemParams.rxDsaCalibMode==1 and currChannel>=2) or (self.systemParams.rxDsaCalibMode==2 and currChannel>=1):
				continue
			elif (CHAIN_TO_CALIB>>currChannel)&1==1 and self.systemParams.rxDsaCalibMode==0:
				chainSelection=1<<currChannel
				self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Calibrating RX "+["A","B","C","D"][currChannel]+" DSA. Give input on a 128-point bin in Base Band.")
				info("EXTERNAL-ACTION: Calibrating RX "+["A","B","C","D"][currChannel]+" DSA. Give input.")
				if self.systemParams.simulationMode==False:
					pauseHereCustom("Calibrating RX "+["A","B","C","D"][currChannel]+" DSA. Give input.")
			elif (CHAIN_TO_CALIB>>currChannel)&0b101!=0 and self.systemParams.rxDsaCalibMode==1:
				chainSelection=(0b101<<currChannel)&CHAIN_TO_CALIB
				self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Calibrating RX "+["A&C","B&D"][currChannel]+" DSA. Give Input on a 128-point bin in Base Band.")
				info("EXTERNAL-ACTION: Calibrating RX "+["A&C","B&D"][currChannel]+" DSA. Give Input.")
				if self.systemParams.simulationMode==False:
					pauseHereCustom("Calibrating RX "+["A&C","B&D"][currChannel]+" DSA. Give Input.")
			elif self.systemParams.rxDsaCalibMode==2:
				chainSelection=CHAIN_TO_CALIB
				self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Calibrating all RX DSA. Give Input to all channels on a 128-point bin in Base Band.")
				info("EXTERNAL-ACTION: Calibrating all RX DSA. Give Input to all channels on a 128-point bin in Base Band.")
			else:
				continue
			self.closePageAndNewStep('rxDsaCalibration')

			self.TOP.SYSCALIB.macro_factory_calibration_control_continue(CONTINUE_MACRO,\
													RX_DSA_CALIB,\
													chainSelection,\
													DSA_START,\
													DSA_STOP,\
													chainSelection,\
													TONE_TRANSMISSION,\
													F_DEPEND_EN,\
													0,\
													INTERNAL_LOOOPBACK_EN,\
													DSA_dsa_nd_vga_cal,\
													DSA_is_vga_or_lna,\
													DSA_dsa_idx_for_vga_cal,\
													DSA_vga_idx_for_dsa_cal,\
													DSA_vga_start,\
													DSA_vga_stop,\
													TONE_ID,\
													TONE_SCALE,\
													0,\
													0,\
													0)
		self.closePageAndNewStep('rxDsaCalibration')
		self.TOP.SYSCALIB.macro_factory_calibration_control_done(15,\
											2,\
											1,\
											DSA_START,\
											DSA_STOP,\
											CHAIN_TO_CALIB,\
											TONE_TRANSMISSION,\
											F_DEPEND_EN,\
											0,\
											INTERNAL_LOOOPBACK_EN,\
											TONE_ID,\
											TONE_SCALE,\
											0)
		self.closePageAndNewStep('rxDsaCalibration')
		self.memRead32('macroMem', 0x00);
		self.TOP.SYSCALIB.packet_read_silicon(ASTERIX_DIR+DEVICES_DIR+"rxDsaGainPhaseCalibPacket.txt",990)
		self.closePageAndNewStep('rxDsaCalibration')
		################# PACKET APPLY ##############################
		self.TOP.SYSCALIB.set_factory_calibration_data(0);
		
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_cd=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_cd=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_cd=0
		
		device.hardReadAlways=temp
		
		if self.systemParams.agcRegConfigParams[0]['gainControl']!=3 or self.systemParams.agcRegConfigParams[1]['gainControl']!=3:
			self.TOP.DSA[0].setGainControl(self.systemParams.agcRegConfigParams[0]['gainControl'])
		 
		if self.systemParams.agcRegConfigParams[2]['gainControl']!=3 or self.systemParams.agcRegConfigParams[3]['gainControl']!=3:
 			self.TOP.DSA[1].setGainControl(self.systemParams.agcRegConfigParams[2]['gainControl'])

		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44440_504h.Property44471_8_8=0
		self.TOP.overrideTdd(1,0,0)
	#rxDsaCalibration
	
	@funcDecorator
	def txDsaCalibration(self,CHAIN_TO_CALIB=0xf):
		""" "Starting TX DSA Calibration" "Completed TX DSA Calibration" """
		device=self.regs
		#self.setSigGenTone(True,20,-2)
		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44602_118h.Property44602_0_0=1
		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44602_118h.Property44605_8_8=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2t_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2t_en_cd=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2r_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_2r_en_cd=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_1f_en_ab=1
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_intpi_tdd_1f_en_cd=1
		temp=device.hardReadAlways
		device.hardReadAlways=True
		
		if self.systemParams.txDsaCalibMode==0:	# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
			FB_CONNECTION = 0
		elif self.systemParams.txDsaCalibMode==1:	# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
			FB_CONNECTION = 0b1111
		else:
			FB_CONNECTION = 0b1100
		
		INIT_MACRO = 1 
		CONTINUE_MACRO = 2 
		DONE_MACRO = 15 
		TX_DSA_CALIB = 1 
		DSA_START = 0 
		DSA_STOP = 30
		REF_TRACKING_EN = 0 
		INTERNAL_LOOOPBACK_EN = 0 
		TONESCALE=11

		device.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=0
		device.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf2=0	
		self.closePageAndNewStep('txDsaCalibration')
		self.TOP.SYSCALIB.macro_factory_calibration_control(INIT_MACRO,\
										TX_DSA_CALIB,\
										0,\
										DSA_START,\
										DSA_STOP,\
										CHAIN_TO_CALIB,\
										0,\
										FB_CONNECTION,\
										INTERNAL_LOOOPBACK_EN,\
										TONESCALE,\
										REF_TRACKING_EN,\
										0,\
										0) 

		########### CONTINUE ############################ 
		for currChannel in range(4):
			if self.systemParams.txDsaCalibMode==2 and currChannel>=2:
				continue
			elif (CHAIN_TO_CALIB>>currChannel)&1==1 and self.systemParams.txDsaCalibMode!=2:
				chainSelection=1<<currChannel
				self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Calibrating TX "+["A","B","C","D"][currChannel]+". Connect it to FB "+["AB","CD"][self.systemParams.txDsaCalibMode])
				if self.systemParams.simulationMode==False:
					pauseHereCustom("Calibrating TX "+["A","B","C","D"][currChannel]+". Connect it to FB "+["AB","CD"][self.systemParams.txDsaCalibMode])
			elif (CHAIN_TO_CALIB>>currChannel)&0b101!=0 and self.systemParams.txDsaCalibMode==2:
				chainSelection=(0b101<<currChannel)&CHAIN_TO_CALIB
				self.deviceRefs.device.printCommentToLog("EXTERNAL-ACTION: Calibrating TX "+["A&C","B&D"][currChannel]+". Connect them to FB AB & FB CD, respectively.")
				if self.systemParams.simulationMode==False:
					pauseHereCustom("Calibrating TX "+["A&C","B&D"][currChannel]+". Connect them to FB AB & FB CD, respectively.")
			else:
				continue
			self.closePageAndNewStep('txDsaCalibration')
			self.TOP.SYSCALIB.macro_factory_calibration_control_continue(CONTINUE_MACRO,\
													TX_DSA_CALIB,\
													chainSelection,\
													DSA_START,\
													DSA_STOP,\
													chainSelection,\
													0,\
													FB_CONNECTION,\
													INTERNAL_LOOOPBACK_EN,\
													TONESCALE,\
													REF_TRACKING_EN,\
													0,\
													0,\
													0,\
													0,\
													0,\
													0,\
													0,\
													0,\
													0,\
													0) 
		self.closePageAndNewStep('txDsaCalibration')
		self.TOP.SYSCALIB.macro_factory_calibration_control_done(15,\
											TX_DSA_CALIB,\
											CHAIN_TO_CALIB,\
											DSA_START,\
											DSA_STOP,\
											CHAIN_TO_CALIB,\
											0,\
											FB_CONNECTION,\
											INTERNAL_LOOOPBACK_EN,\
											TONESCALE,\
											REF_TRACKING_EN,\
											0,\
											0) 
		
		self.closePageAndNewStep('txDsaCalibration')
		self.memRead32('macroMem', 0x00); 
		#MACRO_MEM_DATA=self.burstRead(0x20+0x8000,1020) 
		#info(MACRO_MEM_DATA) 
		self.TOP.SYSCALIB.packet_read_silicon(ASTERIX_DIR+DEVICES_DIR+"txDsaGainPhaseCalibPacket.txt",715) 
		self.closePageAndNewStep('txDsaCalibration')
		self.TOP.SYSCALIB.wait_for_macro_ready();
		device.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0=0x01
		device.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf1=0x00
		device.TOP.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand=((0x12)<<24) 
		self.TOP.SYSCALIB.wait_for_macro_ack(); 
		self.TOP.SYSCALIB.wait_for_macro_done();
		
		device.hardReadAlways=temp
		
		for i in range(2):
			val=device.TOP.DSA_CNTRL[i].TX_DSA_CTRL.Register45545_100h._Property45555_9_0.getValue()
			if val==0:
				device.TOP.DSA_CNTRL[i].TX_DSA_CTRL.Register45545_100h.Property45560_9_0=800
			else:
				device.TOP.DSA_CNTRL[i].TX_DSA_CTRL.Register45545_100h.Property45560_9_0=val
			
			val=device.TOP.DSA_CNTRL[i].TX_DSA_CTRL.Register45566_120h._Property45576_9_0.getValue()
			if val==0:
				device.TOP.DSA_CNTRL[i].TX_DSA_CTRL.Register45566_120h.Property45581_9_0=800
			else:
				device.TOP.DSA_CNTRL[i].TX_DSA_CTRL.Register45566_120h.Property45581_9_0=val
				
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2t_en_cd=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_2r_en_cd=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_ab=0
		device.TOP.TC_GPIO.digtop.IO_FUNCTION_CONTROL.ovr_sel_intpi_tdd_1f_en_cd=0
		#self.setSigGenTone(False,20,-10)
		device.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44602_118h.Property44602_0_0=0
	#txDsaCalibration
	
	@funcDecorator
	def rxIqMcSteadyState(self):
		""" "Doing RX IQMC Correction" "Did RX IQMC Correction" """
		self.rxIqMcSteadyStateConfig()
		# self.rxIqMcSteadyStateEnable()
	#rxIqMcSteadyState
	
	@funcDecorator
	def rxIqMcSteadyStateConfig(self):
		""" "Doing RX IQMC Correction Configuration" "Done configuring RX IQMC Correction" """		
		self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50593_2_2=1
		self.regs.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50596_6_6=1
		patch=True#False#
		device=self.deviceRefs.device
		device.hardReadAlways=True
		#self.TOP.requestPllSpiAccess(0)
		self.TOP.SYSCALIB.get_fw_version()
		if self.systemStatus.chipVersion>0x10:
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50678_3_3=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50190_2_0=2
			#Fw reg writes to be added.It is assumed that in fdd mode both rx and tx lo will be differnt.
			#These are the parameters for rxiqmc.Can remove all the parameter writes earlier.Closein patch loading is not required Now.
			# Writes should be done before removing fw out of reset.The tune sequence to remove fw out of reset,sysconfig messages remains same.
			#Is trim done or not done.#Update 24/09/2018
			if (self.systemParams.enableRxIqmcLolPowerUpCorr==True):
				TRIM_DONE_OR_TO_BE_DONE=1
			else:
				TRIM_DONE_OR_TO_BE_DONE=0
			##See what pll is used for rx_iqmc
			if (self.systemParams.pllMuxModes==0):
				PLL_USED_FOR_RX=self.systemParams.pllLo[0]
			else:
				PLL_USED_FOR_RX=self.systemParams.pllLo[2]
			#This defines the Maximum mismatch that can be corrected in Powerup.
			if (TRIM_DONE_OR_TO_BE_DONE==1):
				critical("TRIM_DONE_OR_TO_BE_DONE")
				MAX_MIS_CLIP_VALUE_PU_DB=-30.15#-35
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50200_6_0=2.0**12.0*10**(MAX_MIS_CLIP_VALUE_PU_DB/20.0)
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50728_15_15=1
			else:
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50728_15_15=0
			#WFI is Enabled will help in power save
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50588_8_8=0
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50589_9_9=1
			#Estimation will de done upto -50dBfs Signal levels.Different values with trim(-45dbfs) and without trim(-50dbfs).
			if (TRIM_DONE_OR_TO_BE_DONE==1):
				EST_SIG_LVL_CHK_DB=-55.0
			else:
				EST_SIG_LVL_CHK_DB=-60.0
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50168_11_0=2.0**12.0*10**(EST_SIG_LVL_CHK_DB/20.0)
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50564_30_30=1
			#Process noise defines how much weightage is given to new estimates. #For lower LO the prrocess noise can be -96. Switch at 3000.#Update 24/09/2018 based on histogram results.
			if (PLL_USED_FOR_RX>=3000):
				PROCESS_NOISE_DB=-90.0
			else:
				PROCESS_NOISE_DB=-96.0
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50162_6_0=10**((108+PROCESS_NOISE_DB)/20.0)
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50535_7_7=1
			#This defines the maximum mismatch that can be corrected in Steady State.The value is qithout trim(-30.15) with trim(-38.xx) can be kept high so that if a random LO is chosen.
			if (TRIM_DONE_OR_TO_BE_DONE==0):
				MAX_MIS_CLIP_VALUE_DB=-30.15
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50716_22_16=2.0**12.0*10**(MAX_MIS_CLIP_VALUE_DB/20.0)
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50198_23_23=1
			else:
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50198_23_23=0
			#The Estimates are used only after the following uncertainity is crosssed in KF. This is steady state value(-55). Wihout tim same value will be used because 
			#of dsa+freq+LO varaiation that will be present.
			KF_UNC_DB=-55
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50536_14_8=10**((84+KF_UNC_DB)/20.0)#127#
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50537_15_15=1
			#Min closein Frequency that will be used. 0x14*5=100KHz
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50509_6_0=0x14
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50513_7_7=1#
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50512_14_8=0x14
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50514_15_15=1#
			#Number of sets that will be used for closein. 5 sets.
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50154_2_0=4
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50519_3_3=1#
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50518_6_4=4
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50520_7_7=1#
			#Ratio Threshold is kept to 20dB.20 db and 10 db for wideband cases are similar. 10 db will give more estimates.
			RATIO_TH_DB=10.0
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50560_23_12=10**(RATIO_TH_DB/20.0)*4
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50565_31_31=1
			#Pg1p0 values
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50525_30_24=2
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50526_31_31=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50156_22_16=2
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50527_23_23=1
			#Closein estimation will happen upto 50dBc. Different values with trim(-45dbfs) and without trim(-50dbfs).
			if (TRIM_DONE_OR_TO_BE_DONE==1):
				CLSIN_PWR_THRESH_DB=-49.0
			else:
				CLSIN_PWR_THRESH_DB=-54.0
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50148_6_0=2.0**12.0*10**(CLSIN_PWR_THRESH_DB/20.0)
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50497_7_7=1
			#Corr tone check has to be enabled.
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50593_2_2=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50596_6_6=1
			#Enabling Closein always. With closein the performance is better in case of widebands.
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50150_5_0=0
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50504_7_7=1
			#Parameter for powerup. This should be close to -3dbfs. Check this.Set the default value for siggen setting used for calibration.SIG GEn value of 4
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50492_29_24=3#This is based on trim based feedback.
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50495_31_31=1
			#Defaults -36,-42 instead of -42,-48
			if (TRIM_DONE_OR_TO_BE_DONE==1):
				GINST_CORRTONE_FREQDEPTHRESH_NOPWRUP_DB=-48.0
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50176_6_0=2.0**11.0*10**(GINST_CORRTONE_FREQDEPTHRESH_NOPWRUP_DB/20.0)
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50610_7_7=1
				
				GINST_CORRTONE_FREQINDTHRESH_NOPWRUP_DB=-42.0
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50608_30_24=2.0**11.0*10**(GINST_CORRTONE_FREQINDTHRESH_NOPWRUP_DB/20.0)
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50609_31_31=1
			else:
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50610_7_7=0
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50609_31_31=0
			#Merge estimation after ericsson Debug.In case of better estimates we will drop the estimates with higher uncertainity.
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50625_14_10=15
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50627_22_16=1 #6 dB
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50628_30_24=2 #9 dB 
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50626_15_15=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50629_23_23=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50180_31_31=1
		else:
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50492_29_24=15
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50495_31_31=1

			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50142_5_0 = 30 # gives -80 dB SNR
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50486_7_7 = 1 #Validity
			
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50549_18_18=not patch#False
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50550_19_19=True
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50525_30_24=2
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50526_31_31=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50156_22_16=2
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50527_23_23=1
			
			if patch==True:
				###########Seting the min freq for closein to be 5 KHz#######
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50509_6_0=0x14 #5 KHz is the min freq
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50513_7_7=0
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50512_14_8=0x14 #5 KHz is the min freq
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50514_15_15=0

				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50154_2_0=4
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50519_3_3=0
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50518_6_4=4
				device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50520_7_7=0
				device.RX.RXIQMC.rx_iqmc.fw_spl_register.rx_iqmc_fw_spl_register_31 = 128+2 ##bit 7 is validity and bits6:0 is ratio of variance thresh in 8.-1,u format. Here we are giving 2, which means 10*log10(4)=6 dB 
		
		if not (self.systemStatus.chipVersion>0x10):
			self.RX.RXIQMCFW.STEADY_STATE_SET_GINST_SIGPWR_CHECK_PARAMS(-60,2,2)
		
		
		#self.deviceRefs.broadcastEn=0x0f
		#self.RX.RXDIG[0].dcOffsetCorrection(1)
		#self.deviceRefs.broadcastEn=0x00
		
		if patch==True and self.systemStatus.chipVersion==0x10:
			self.TOP.loadRxIqMcPatch()
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50625_14_10=7
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50627_22_16=1 #6 dB
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50628_30_24=2 #9 dB 

			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50626_15_15=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50629_23_23=1
			device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50180_31_31=1

		#########################################
		# self.TOP.SYSCALIB.do_tune_and_enable(0, \
							# 0,0, \
							# 0, \
							# MACROConst.MACRO_TUNE_AND_ENABLE__SYSCONFIG_MSG_TO_RxCM4 | \
							# MACROConst.MACRO_TUNE_AND_ENABLE__RxCM4_BRINGUP | \
							# MACROConst.MACRO_TUNE_AND_ENABLE__CLK_CONFIG_AND_ENABLE_RXCM4)

		# self.TOP.SYSCALIB.get_macro_status()
		# if patch==True and self.systemStatus.chipVersion==0x10:
			# if device.RX.RXIQMC.rx_iqmc.Register50136_300h.Property50452_3_0!=1 :
				# error("Patch is not downloaded properly into Rx CM4")
			# else:
				# info("Patch is loaded into Rx CM4")
		##########################################
		#self.TOP.requestPllSpiAccess(1)
		device.hardReadAlways=False
	#rxIqMcSteadyStateConfig	
	
	@funcDecorator
	def rxIqMcSteadyStateEnable(self):
		""" "Enabling RX IQMC Correction" "Done enabling RX IQMC Correction" """		
		## Start RXIQMC SS calibration
		self.regs.hardReadAlways=True
		self.TOP.SYSCALIB.do_mission_mode_init(0x20000, 0xF)
		self.TOP.SYSCALIB.get_macro_status()

		self.delay(0.5)
		self.deviceRefs.broadcastEn=0x0f
		self.RX.RXDIG[0].gainIQMCcorrBypass(0)
		self.RX.RXDIG[0].freqIQMCcorrBypass(0)
		self.deviceRefs.broadcastEn=0x00
		##########################################
		#debug('N. Interrupts after SSC='+str(self.RX.RXIQMCFWGETSTATUS.getCurrInterruptCount()))
		self.regs.hardReadAlways=False
	#rxIqMcSteadyStateEnable
	
	@funcDecorator
	def agcBasicConfig(self):
		""" "Doing AGC Config" "Completed AGC Config" """
		device=self.deviceRefs.device
		if self.systemParams.agcRegConfigParams[0]==self.systemParams.agcRegConfigParams[2] and self.systemParams.agcRegConfigParams[1]==self.systemParams.agcRegConfigParams[3]:
			loopcount=1
			self.deviceRefs.broadcastEn=15
		else:
			loopcount=2
			self.deviceRefs.broadcastEn=0
		for i in range(loopcount):
			agcRegConfigParams0=self.systemParams.agcRegConfigParams[2*i]
			agcRegConfigParams1=self.systemParams.agcRegConfigParams[(2*i)+1]
			self.RX.RXDIG[i].AGCDGC[0].intAgcBasicConfig()
			if agcRegConfigParams0['dgcEnable']==True:
				if agcRegConfigParams0['dgcMode'] in (0,):
					self.RX.RXDIG[i].AGCDGC[0].configDgcFloatingPoint(agcRegConfigParams0['dgcEnable'],agcRegConfigParams0['floatingPointMode'],agcRegConfigParams0['floatingPointFormat'])
				elif agcRegConfigParams0['dgcMode'] in (2,3,4,5):
					self.RX.RXDIG[i].AGCDGC[0].configDgcCoarseFine(agcRegConfigParams0['dgcEnable'],agcRegConfigParams0['coarseIndexBits'],agcRegConfigParams0['coarseStep'])
			if agcRegConfigParams0['enableSa']==True or agcRegConfigParams0['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[0].small_step_attack_en(agcRegConfigParams0['enableSa'],agcRegConfigParams0['stepSizeSa'],agcRegConfigParams0['thresholdSa'],agcRegConfigParams0['thresholdSa'],agcRegConfigParams0['windowLenSa'],agcRegConfigParams0['numHitsSa'])
			if agcRegConfigParams0['enableSd']==True or agcRegConfigParams0['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[0].small_step_decay_en(agcRegConfigParams0['enableSd'],agcRegConfigParams0['stepSizeSd'],agcRegConfigParams0['thresholdSd'],agcRegConfigParams0['thresholdSd'],agcRegConfigParams0['windowLenSd'],agcRegConfigParams0['numHitsSd'])
			if agcRegConfigParams0['enableBa']==1 or agcRegConfigParams0['phmOvrEn']==True or agcRegConfigParams0['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[0].big_step_attack_en(agcRegConfigParams0['enableBa'],agcRegConfigParams0['stepSizeBa'],agcRegConfigParams0['thresholdBa'],agcRegConfigParams0['thresholdBa'],agcRegConfigParams0['windowLenBa'],agcRegConfigParams0['numHitsBa'])
			if agcRegConfigParams0['enableBd']==True or agcRegConfigParams0['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[0].big_step_decay_en(agcRegConfigParams0['enableBd'],agcRegConfigParams0['stepSizeBd'],agcRegConfigParams0['thresholdBd'],agcRegConfigParams0['thresholdBd'],agcRegConfigParams0['windowLenBd'],agcRegConfigParams0['numHitsBd'])
			if agcRegConfigParams0['enableEl']==True and agcRegConfigParams0['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[0].ext_lna_ctrl(agcRegConfigParams0['enableEl'],agcRegConfigParams0['lnabypassGain'],agcRegConfigParams0['gainMargin'])
			if agcRegConfigParams0['phmOvrEn']==True and agcRegConfigParams0['enableIa']==False:
				self.RX.RXDIG[i].AGCDGC[0].ovrPhmConfig()
			

			self.RX.RXDIG[i].AGCDGC[1].intAgcBasicConfig()
			if agcRegConfigParams1['dgcEnable']==True:
				if agcRegConfigParams1['dgcMode'] in (0,):
					self.RX.RXDIG[i].AGCDGC[1].configDgcFloatingPoint(agcRegConfigParams1['dgcEnable'],agcRegConfigParams1['floatingPointMode'],agcRegConfigParams1['floatingPointFormat'])
				elif agcRegConfigParams1['dgcMode'] in (2,3,4,5):
					self.RX.RXDIG[i].AGCDGC[1].configDgcCoarseFine(agcRegConfigParams1['dgcEnable'],agcRegConfigParams1['coarseIndexBits'],agcRegConfigParams1['coarseStep'])
			if agcRegConfigParams1['enableSa']==True or agcRegConfigParams1['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[1].small_step_attack_en(agcRegConfigParams1['enableSa'],agcRegConfigParams1['stepSizeSa'],agcRegConfigParams1['thresholdSa'],agcRegConfigParams1['thresholdSa'],agcRegConfigParams1['windowLenSa'],agcRegConfigParams1['numHitsSa'])
			if agcRegConfigParams1['enableSd']==True or agcRegConfigParams1['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[1].small_step_decay_en(agcRegConfigParams1['enableSd'],agcRegConfigParams1['stepSizeSd'],agcRegConfigParams1['thresholdSd'],agcRegConfigParams1['thresholdSd'],agcRegConfigParams1['windowLenSd'],agcRegConfigParams1['numHitsSd'])
			if agcRegConfigParams1['enableBa']==1 or agcRegConfigParams1['phmOvrEn']==True or agcRegConfigParams1['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[1].big_step_attack_en(agcRegConfigParams1['enableBa'],agcRegConfigParams1['stepSizeBa'],agcRegConfigParams1['thresholdBa'],agcRegConfigParams1['thresholdBa'],agcRegConfigParams1['windowLenBa'],agcRegConfigParams1['numHitsBa'])
			if agcRegConfigParams1['enableBd']==True or agcRegConfigParams1['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[1].big_step_decay_en(agcRegConfigParams1['enableBd'],agcRegConfigParams1['stepSizeBd'],agcRegConfigParams1['thresholdBd'],agcRegConfigParams1['thresholdBd'],agcRegConfigParams1['windowLenBd'],agcRegConfigParams1['numHitsBd'])
			if agcRegConfigParams1['enableEl']==True and agcRegConfigParams1['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[1].ext_lna_ctrl(agcRegConfigParams1['enableEl'],agcRegConfigParams1['lnabypassGain'],agcRegConfigParams1['gainMargin'])
			if agcRegConfigParams1['phmOvrEn']==True and agcRegConfigParams1['enableIa']==False:
				self.RX.RXDIG[i].AGCDGC[1].ovrPhmConfig()
						
			if agcRegConfigParams0['enableIa']==True or agcRegConfigParams1['enableIa']==True:
				self.RX.RXDIG[i].AGCDGC[0].int_agc_en()
				self.RX.RXDIG[i].AGCDGC[1].int_agc_en()
				self.TOP.DSA[i].setGainControl(2)
			else:
				self.TOP.DSA[i].setGainControl(agcRegConfigParams0['gainControl'])
		self.deviceRefs.broadcastEn=0
		self.RX.RXDIG[0].AGCDGC[0].setupProcess()
	#agcBasicConfig

	@funcDecorator
	def dacAnaWrites(self):
		""" "Doing DAC Analog Writes" "Completed DAC Analog Writes" """
		device=self.regs
		device.hardReadAlways=True
		device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t=0xF
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43792_2_0= int('101',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43793_6_3= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43794_11_8= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43795_15_12= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43796_20_16= int('10100',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43797_28_24= int('11001',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43798_4_0= int('11001',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43710_20_18= int('101',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43711_23_21= int('101',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43714_3_0= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43715_12_8= int('10100',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43716_20_16= int('11001',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43717_28_24= int('11001',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43668_3_3= int('1',2) 
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43669_4_4= int('1',2) 
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43664_31_0= int('011',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43767_31_16 = int('0000001111111111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43768_23_8= int('0000001111111111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43769_15_0= int('0000001111111111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43770_15_0= int('0000001111111111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43771_15_0= 3
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43772_15_0= 3
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43773_15_0= int('0000000111111111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43759_78h.Property43774_15_0= int('0000000000011111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43799_15_8=30
		device.TX.DAC_ANA[0].TX_PAGE.Register43792_BCh.Property43800_23_16=50
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43754_19_16= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43755_23_20= int('1010',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43675_13_10= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43676_19_16= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43677_23_20= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43678_27_24= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43679_31_28= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43680_3_0= int('1010',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43756_27_24= int('1010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43681_15_8= int('00000011',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43682_23_16= int('00000011',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43737_19_16= int('1000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43738_23_20= int('1000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43739_27_24= int('1000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43740_31_28= int('1000',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43743_15_8= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43744_23_16= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43745_31_24= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43746_7_0= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43747_15_8= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43748_23_16= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43749_31_24= int('01000000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43750_7_0= int('01000000',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43741_3_0= int('0100',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43742_7_4= int('0100',2)

		#####Set the IF Filter capacitor for for best in-band droop

		device.TX.DAC_ANA[0].TX_PAGE.Register43802_C8h.Property43802_3_0= int('0101',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43802_C8h.Property43803_7_4= int('0101',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43802_C8h.Property43804_11_8= int('0010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43802_C8h.Property43805_15_12= int('0010',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43815_15_8= int('11100100',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43818_7_0= int('11100100',2)
		
		
		if self.systemStatus.txLoPllIndex[0]==self.systemStatus.txLoPllIndex[1] and abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-900)==500:
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x0D
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-900)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x3
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x0D
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[1]]-900)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xC
			device.TX.DAC_ANA[1].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x0D
			device.TX.DAC_ANA[1].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
			
		if self.systemStatus.txLoPllIndex[0]==self.systemStatus.txLoPllIndex[1] and abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-1950)==500:
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x12
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-1950)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x03
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x12
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[1]]-1950)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x0C
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x12
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		
		if self.systemStatus.txLoPllIndex[0]==self.systemStatus.txLoPllIndex[1] and abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-1950)==500:
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0xA
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-1950)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x03
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0xA
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[1]]-1950)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x0C
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0xA
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		
		if self.systemStatus.txLoPllIndex[0]==self.systemStatus.txLoPllIndex[1] and abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-1950)==500:
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x1F
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[0]]-1950)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x03
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x1F
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		elif abs(self.systemParams.pllLo[self.systemStatus.txLoPllIndex[1]]-1950)==500:
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0x0C
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43816_23_16 = 0x1F
			device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43817_31_24 = 0x1F
			device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t = 0xF
		

		device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43819_15_8= int('10100000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43820_23_16= int('10100000',2)

		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43784_31_24= int('10010010',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43781_11_8= int('1111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43785_7_0= int('00011111',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43780_31_0 = 0xFFFFFFFF			   #### 0dB
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43791_7_0 = 0xFF
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43783_19_16= int('0110',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43802_C8h.Property43808_31_24=0xff
		device.TX.DAC_ANA[0].TX_PAGE.Register43802_C8h.Property43809_7_0=0xff

		device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43815_15_8= int('10111000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43813_D4h.Property43818_7_0= int('10111000',2)
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43756_27_24=10
		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43757_31_28=10

		device.TX.DAC_ANA[0].TX_PAGE.Register43724_60h.Property43752_11_9= int('011',2)
		device.TX.DAC_ANA[1].TX_PAGE.Register43724_60h.Property43753_14_12= int('100',2)
		device.TX.DAC_ANA[2].TX_PAGE.Register43660_28h.Property43683_31_24= int('011',2)
		
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43778_1_1=1
		device.TX.DAC_ANA[0].TX_PAGE.Register43777_9Ch.Property43779_31_16=0x7800
		device.MASTER.MASTER_PAGE.PAGE_SEL.TX_ANALOG.dac_1t=0x0

				
		if self.systemParams.halfRateModeTx==1:
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0xF
			self.regs.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43669_4_4=0
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0x0
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=15
			self.regs.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43663_31_0=0b110	#halfRateMode<<2
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0
			self.regs.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property946_17_16=1
			self.regs.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49047_17_16=1
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0xF
			self.regs.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43669_4_4=1
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0x0
		#else:
		#	self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0xF
		#	self.regs.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43669_4_4=0
		#	self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0x0
		#	self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=15
		#	self.regs.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43663_31_0=0b000	#halfRateMode<<2
		#	self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0
		#	self.regs.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property946_17_16=1
		#	self.regs.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49047_17_16=1
		#	self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0xF
		#	self.regs.TX.DAC_ANA[0].TX_PAGE.Register43660_28h.Property43669_4_4=1
		#	self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0x0
		
		device.hardReadAlways=False
		device.MASTER.MASTER_PAGE.PAGE_SEL.DATAPATH_DIGITAL.tx_top=3
		device.TX.DAC_DIG_AB[0].tx_top.Register50982_830h.Property50982_0_0=0
		device.TX.DAC_DIG_AB[0].tx_top.Register50982_830h.Property51191_1_1=1
		device.TX.DAC_DIG_AB[0].tx_top.Register51226_890h.Property51226_0_0=0
		device.TX.DAC_DIG_AB[0].tx_top.Register51226_890h.Property51227_1_1=1
		device.TX.DAC_DIG_AB[0].tx_top.Register52232_1B0h.Property52233_1_1=1
		device.TX.DAC_DIG_AB[0].tx_top.Register50983_1B0h.Property50984_1_1=1
		device.TX.DAC_DIG_AB[0].tx_top.Register50982_830h.Property51195_13_8=0x28
		device.TX.DAC_DIG_AB[0].tx_top.Register51226_890h.Property51230_13_8=0x28
		device.TX.DAC_DIG_AB[0].tx_top.Register50982_830h.Property51192_16_16=1
		device.TX.DAC_DIG_AB[0].tx_top.Register51226_890h.Property51228_16_16=1
		
		device.TX.DAC_DIG_AB[0].tx_top.Register50982_830h.Property51197_24_24=0
		device.TX.DAC_DIG_AB[0].tx_top.Register51226_890h.Property51887_24_24=0
		device.TX.DAC_DIG_AB[0].tx_top.Register50982_830h.Property51192_16_16=0
		device.TX.DAC_DIG_AB[0].tx_top.Register51226_890h.Property51228_16_16=0
		device.MASTER.MASTER_PAGE.PAGE_SEL.DATAPATH_DIGITAL.tx_top=0
		
		
	#dacAnaWrites

	@funcDecorator
	def dither_mode(self,ch=4,mymode=0):
		device=self.regs
		if mymode > 4:
			mymode = 4
			
		if(ch < 4):
			ch_sel = ch
		else:
			ch_sel=15
			ch = 0
		
		if mymode == 0:
			
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = ch_sel
			device.RX_ANA_I[ch].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 1
			device.RX_ANA_I[ch].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 1
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = ch_sel
			device.RX_ANA_Q[ch].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 1
			device.RX_ANA_Q[ch].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 1
			
		else:
			
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = ch_sel
			device.RX_ANA_I[ch].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 0
			device.RX_ANA_I[ch].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 0
			device.RX_ANA_I[ch].channel_digital_ch.channel_dig_i.Register10753_50Ah.Property10495_17_16 = mymode-1
			device.RX_ANA_I[ch].channel_digital_ch.channel_dig_i.Register10465_501h.Property10486_17_16 = mymode-1
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = ch_sel
			device.RX_ANA_Q[ch].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 0
			device.RX_ANA_Q[ch].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 0
			device.RX_ANA_Q[ch].channel_digital_ch.channel_dig_q.Register5331_50Ah.Property5333_17_16 = mymode-1
			device.RX_ANA_Q[ch].channel_digital_ch.channel_dig_q.Register5342_501h.Property5343_17_16 = mymode-1
	#dither_mode
	
	@funcDecorator
	def flash_loop_conv(self, ph):
		device=self.regs
		channel = ph/2
		if((ph%2)== 0):
		# Signal should be switched off at this point
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10390_27_26 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10379_18_16 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10390_27_26 = 1
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10379_18_16 = 1
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10372_8_8 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 1
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10373_9_9 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 1
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 0
			#device.RX.DIG_IandQ[ph].Main_ADC_comp.block_modes.main_bis_inc_n_0 = 0
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 1
			self.delay(0.01)
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 0
			self.delay(0.05)
			device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10373_9_9 = 1
		else:
		# Signal should be switched off at this point
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5210_27_26 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5201_18_16 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5210_27_26 = 1
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5201_18_16 = 1
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5263_8_8 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 1
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5264_9_9 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 1
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 0
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 1
			self.delay(0.01)									   
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 0
			self.delay(0.05)									  
			device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5264_9_9 = 1

	@funcDecorator
	def rxDigNLCoeffWrites(self,mych,mycoeffs1,nl_disable,gated=1,scal=1):
		device=self.regs
		mycoeffs = np.zeros(8)
		mycoeffs[2] = round(-1*mycoeffs1[2]*(2**15))
		mycoeffs[3] = round(-1*mycoeffs1[3]*(2**15))
		mycoeffs[0] = round(-1*mycoeffs1[0]*(2**14))
		mycoeffs[1] = round(-1*mycoeffs1[1]*(2**14))
		mycoeffs[4] = round(-1*mycoeffs1[4]*(2**13))
		mycoeffs[5] = round(-1*mycoeffs1[5]*(2**13))
		mycoeffs[6] = round(-1*scal*mycoeffs1[6]*(2**13))
		mycoeffs[7] = round(-1*scal*mycoeffs1[7]*(2**13))
		if(nl_disable == 1):
			if(mych == 0) or (mych == 2):
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.Property27958_0_0 = 1
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_update_pulse_nl = 1
				self.delay(0.1)
				debug("delay(0.01)")
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_update_pulse_nl = 0
			else:
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.Property28059_0_0 = 1
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_update_pulse_nl = 1
				self.delay(0.1)
				debug("delay(0.01)")
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_update_pulse_nl = 0	
		else:
			device.RX.DIG_AB[mych/2].RxDecSet.RxNLcorrectorCommon.cfg_adc_nl_corr = 1		
			if(mych == 0) or (mych == 2):		
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.Property27904_7_0 = mycoeffs[2]  #mod(x).sq Real OR Xi.sq
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_c_21_img0  = mycoeffs[3]  #mod(x).sq Imag OR Xj.sq
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.Property27916_4_0 = mycoeffs[0]  #x.sq Real
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_c_22_img0  = mycoeffs[1]  #x.sq Imag
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.Property27940_5_0 = mycoeffs[4]  #mod(x).sq.X Real
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_c_31_img0  = mycoeffs[5]  #mod(x).sq.X Imag	
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.Property27928_3_0 = mycoeffs[6]  #x.cube Real
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_c_32_img0  = mycoeffs[7]  #x.cube Imag
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_gate_c_32 = gated #gate x.cube
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.Property27958_0_0 = 0
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_update_pulse_nl = 1
				self.delay(0.01)
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.coef_update_pulse_nl = 0
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.nl_input_delay_config=17
				self.delay(0.01)
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.prog_delay_update_signal=1
				self.delay(0.01)
				device.RX.DIG_AB[mych/2].RxDecSet.Register27859_C10h.prog_delay_update_signal=0
			else:
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.Property28005_7_0 = mycoeffs[2]  #mod(x).sq Real OR Xi.sq
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_c_21_img0  = mycoeffs[3]  #mod(x).sq Imag OR Xj.sq
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.Property28017_4_0 = mycoeffs[0]  #x.sq Real
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_c_22_img0  = mycoeffs[1]  #x.sq Imag
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.Property28041_5_0 = mycoeffs[4]  #mod(x).sq.X Real
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_c_31_img0  = mycoeffs[5]  #mod(x).sq.X Imag	
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.Property28029_3_0 = mycoeffs[6]  #x.cube Real
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_c_32_img0  = mycoeffs[7]  #x.cube Imag
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_gate_c_32 = gated #gate x.cube	
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.Property28059_0_0 = 0
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_update_pulse_nl = 1
				self.delay(0.01)
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.coef_update_pulse_nl = 0
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.nl_input_delay_config=17
				self.delay(0.01)
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.prog_delay_update_signal=1
				self.delay(0.01)
				device.RX.DIG_AB[mych/2].RxDecSet.Register27960_E10h.prog_delay_update_signal=0
			
	@funcDecorator
	def jesdSwing(self, jesd_swing=7):	# 3 for min swing, 4 for max
		device=self.regs
		device.JESD.SERDES[0].laneRegisters[0].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[0].laneRegisters[1].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[0].laneRegisters[2].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[0].laneRegisters[3].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[1].laneRegisters[0].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[1].laneRegisters[1].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[1].laneRegisters[2].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing
		device.JESD.SERDES[1].laneRegisters[3].SERDES_TX_PREPOSTMAINCURSOR.MAIN_CURSOR = jesd_swing	

	@funcDecorator
	def rxDsaImdWrites(self, en=1):
		""" "Doing RX IMD vs DSA improvement Analog Writes" "Completed RX IMD vs DSA improvement Analog Writes" """
		device=self.regs
		if(en):
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
			device.writeReg(0x11,0x0F)
			device.RX_ANA_I[0].DSA_TRIM_BITS.DSA.Register9033_B32h.Property9033_24_22 = 0
			device.RX_ANA_I[0].DSA_TRIM_BITS.DSA.Register9035_B33h.Property9035_27_25 = 4
			device.RX_ANA_I[0].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_COMMON.Register9314_C91h.Property9315_13_11 = 4
			device.writeReg(0x11,0x0);
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
		else:
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
			device.writeReg(0x11,0x0F)
			device.RX_ANA_I[0].DSA_TRIM_BITS.DSA.Register9033_B32h.Property9033_24_22 = 0
			device.RX_ANA_I[0].DSA_TRIM_BITS.DSA.Register9035_B33h.Property9035_27_25 = 0
			device.RX_ANA_I[0].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_COMMON.Register9314_C91h.Property9315_13_11 = 0
			device.writeReg(0x11,0x0);
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0

	@funcDecorator
	def rxFlashCalWrites(self, broadcastTo=15):
		device=self.regs
		self.dither_mode(4,0)
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = broadcastTo
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 1
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = broadcastTo
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 1
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0
		self.deviceRefs.broadcastEn=broadcastTo
		self.RX.pdnFrontEnd(0,1)
		self.deviceRefs.broadcastEn=0
		for ph in range(8):
			self.flash_loop_conv(ph)
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = broadcastTo
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 0
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = broadcastTo
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 0
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0
		self.dither_mode(4,2)
		self.deviceRefs.broadcastEn=broadcastTo
		self.RX.pdnFrontEnd(0,0)
		self.deviceRefs.broadcastEn=0

	@funcDecorator
	def enableReliabilityDetector(self, en=1):
		device=self.regs
		if(en):
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0xf
			device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25 = not en
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5861_31_29=7
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5857_15_15=1
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5862_25_8=13+(23<<6)+(3<<13)
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5858_9_0=7<<5
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0x0
		else:
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0xf
			device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25= not en
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0x0
	#enableReliabilityDetector
			
	@funcDecorator
	def rxNLTrim(self, nCh, ana_corr=1, dig_corr=1):
		device=self.regs
		if (ana_corr == 1):
			debug('RX HD3 optimized settings begins')
			if(self.systemParams.halfRateModeRx == 0):
				for ch in nCh:
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9112_103h.Property9114_30_28=7
					device.RX_ANA_I[ch].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_I.Register9387_1A1h.Property9387_10_8=4
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9131_112h.Property9131_18_16=5
					device.RX_ANA_I[ch].BB_FILTER_COMMON.BB_FILTER_TESTMODES.Register8999_BF3h.Property8999_26_24=3
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9106_101h.Property9106_10_8=2
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9102_100h.Property9103_5_3=5
				   
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2888_103h.Property2890_30_28=7
					device.RX_ANA_Q[ch].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_Q.Register2872_1A1h.Property2872_10_8=4
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_TRIM_BITS.Register2897_112h.Property2897_18_16=5
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2882_101h.Property2882_10_8=2
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2878_100h.Property2879_5_3=5
			elif(self.systemParams.halfRateModeRx == 1):
				for ch in nCh:
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9112_103h.Property9114_30_28=7
					device.RX_ANA_I[ch].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_I.Register9387_1A1h.Property9387_10_8=6
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9131_112h.Property9131_18_16=0
					device.RX_ANA_I[ch].BB_FILTER_COMMON.BB_FILTER_TESTMODES.Register8999_BF3h.Property8999_26_24=0
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9106_101h.Property9106_10_8=0
					device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9102_100h.Property9103_5_3=5

					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2888_103h.Property2890_30_28=7
					device.RX_ANA_Q[ch].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_Q.Register2872_1A1h.Property2872_10_8=6
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_TRIM_BITS.Register2897_112h.Property2897_18_16=0
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2882_101h.Property2882_10_8=0
					device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2878_100h.Property2879_5_3=5
			debug('RX HD3 optimized settings END')
		else:
			debug('RX HD3 default settings begins')
			for ch in nCh:
				device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9112_103h.Property9114_30_28=0
				device.RX_ANA_I[ch].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_I.Register9387_1A1h.Property9387_10_8=0
				device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9131_112h.Property9131_18_16=0
				device.RX_ANA_I[ch].BB_FILTER_COMMON.BB_FILTER_TESTMODES.Register8999_BF3h.Property8999_26_24=0
				device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9106_101h.Property9106_10_8=0
				device.RX_ANA_I[ch].BB_FILTER_I.BB_FILTER_MODES.Register9102_100h.Property9103_5_3=0
				
				device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2888_103h.Property2890_30_28=0
				device.RX_ANA_Q[ch].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_Q.Register2872_1A1h.Property2872_10_8=0
				device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_TRIM_BITS.Register2897_112h.Property2897_18_16=0
				device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2882_101h.Property2882_10_8=0
				device.RX_ANA_Q[ch].BB_FILTER_Q.BB_FILTER_MODES.Register2878_100h.Property2879_5_3=0
			debug('RX HD3 default settings END')
			
		if(dig_corr):
			debug("RX HD3 optimized dig-corr coeff begins")
			if(self.systemParams.halfRateModeRx == 1):
				new_outp1 = [ 1.75260332e-06, -3.74545990e-06, 1.88129283e-06, -7.72620858e-05, -1.51869016e-03, 9.62119349e-04, -1.06570988e-04, 3.84575579e-04]
			else:
				new_outp1 = [ -5.30058155e-06, -7.72774791e-06, 5.69587710e-05, -1.18388769e-05, -7.39439965e-04, 6.89468610e-05, 1.45512845e-04, -2.41829080e-04]
			for ch in nCh:
				self.rxDigNLCoeffWrites(ch, new_outp1, 0, 0)
			debug("RX HD3 dig-corr coeff ends")
		else:
			new_outp1=np.zeros(8)
			debug("RX HD3 default dig-corr begins")
			for ch in nCh:
				self.rxDigNLCoeffWrites(ch, new_outp1, 1, 0)
			debug("RX HD3 default dig-corr ends")
			
	@funcDecorator
	def rxAnaWrites(self):
		""" "Doing RX ADC Analog Writes" "Completed RX ADC Analog Writes" """
		if np.round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx), 2) == np.round(3317.76, 2):
			self.rxAnaWrites54x()
			self.rxLowLoWrites()
			return
		elif (np.round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx), 2) == np.round(3000/2.0,2) or np.round(self.systemParams.Fs/(1+self.systemParams.halfRateModeRx), 2) == np.round(3317.76/2.0, 2)):
			self.rxAnaWrites24x27x()
			self.rxLowLoWrites()
			return
		device=self.regs
		
		device.hardReadAlways=True
		for i in range(4):
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10381_0_0 = 0
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5203_0_0 = 0
		device.hardReadAlways=False		
		
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
		device.writeReg(0x11,0xFF);
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14412_10_8=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14139_13_11=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property9584_16_16 = (3&0x4)>>2
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property9585_15_14= (3&0x3)>>0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9569_299h.Property14398_10_8=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14415_22_20=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14141_28_26=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property9583_31_29=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14421_2_0=3
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14416_23_23 = 2&0x1
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14418_25_24 = (2&0x6)>>1
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14420_5_3=2
		# device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10381_0_0 = 0
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7 = 0	# 1 for 150M
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13180_281h.Property13533_15_15 = 0	# 1 for 150M
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13547_6_6 = 1	# 0 for 150M
		device.RX_ANA_I[0].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9814_338h.Property9814_5_0 = 43
		device.RX_ANA_I[0].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9130_111h.Property9130_14_8 = 9
		device.writeReg(0x11,0x0);
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
		
		self.rxDsaImdWrites()
		self.rxFlashCalWrites()
		self.rxLowLoWrites()
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x0f
		device.RX_ANA_IQ[0].channel_digital_ch.channel_dig_c.Register16435_4C4h.Property16442_5_5=1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x00
		
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2282_28_28 = 1
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2283_27_27 = 1
		
		if self.systemParams.halfRateModeRx==1:
			device.RX.ANA_AB.ANA_AB.Register8780_29h.Property8781_9_8=1
			#device.RX.ANA_CD.ANA_CD.po_to_rx_2r_rxab_config_0.SEL_DIV_RX_CLK_L_1P8=1
		self.enableReliabilityDetector(self.systemParams.enableReliabilityDetector)
		# self.jesdSwing(7)
	#rxAnaWrites
		
	@funcDecorator
	def rxAnaWrites24x27x(self):
		device=self.regs

		regVal=(1,1,1,1,1,4,4,3,1,5,1,7,5,3,7,4,5)
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
		device.writeReg(0x11,0xFF);
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9561_291h.Property14127_14_14=regVal[0]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14142_6_6=regVal[1]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9565_295h.Property14381_10_10=regVal[3]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9588_2A2h.Property14144_22_22=regVal[4]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14412_10_8=regVal[5]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14139_13_11=regVal[6]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property9585_15_14=regVal[7]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property9584_16_16=regVal[8]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14415_22_20=regVal[9]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14416_23_23=regVal[10]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property9583_31_29=regVal[11]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14141_28_26=regVal[12]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14418_25_24=regVal[13]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14420_5_3=regVal[14]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14421_2_0=regVal[15]
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9569_299h.Property14398_10_8=regVal[16]
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7 = 0
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13180_281h.Property13533_15_15 = 0
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13547_6_6 = 0
		device.writeReg(0x11,0x0);
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0

		self.rxDsaImdWrites()
		self.rxFlashCalWrites()
		
		### Half Rate related writes ---
		if self.systemParams.halfRateModeRx==1:
			device.RX.ANA_AB.ANA_AB.Register8780_29h.Property8781_9_8=1
			device.RX.ANA_CD.ANA_CD.Register46336_29h.Property46338_9_8=1
			for i in range(4):
				device.RX_ANA_IQ[i].ADC_LP_TESTMODES.ADC_LP_COMMON_TESTMODES.Register15383_28Dh.Property15383_8_8=regVal[2]

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x0f
		device.RX_ANA_IQ[0].channel_digital_ch.channel_dig_c.Register16435_4C4h.Property16442_5_5=1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x00

		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2282_28_28 = 1
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2283_27_27 = 1

		self.enableReliabilityDetector(self.systemParams.enableReliabilityDetector)
		# self.jesdSwing(7)
	#rxAnaWrites24x

	@funcDecorator
	def rxAnaWrites54x(self):
		""" "Doing RX ADC Analog Writes" "Completed RX ADC Analog Writes" """
		device=self.regs
		
		device.hardReadAlways=True
		for i in range(4):
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10381_0_0 = 0
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5203_0_0 = 0
		device.hardReadAlways=False
		
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
		device.writeReg(0x11,0xFF);
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14412_10_8=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14139_13_11=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property9584_16_16 = 0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property9585_15_14= 0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9569_299h.Property14398_10_8=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14415_22_20=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14141_28_26=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property9583_31_29=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14421_2_0=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14416_23_23 = 1
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14418_25_24 = 1
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14420_5_3=0
		#device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10381_0_0 = 0
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7 = 0
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13180_281h.Property13533_15_15 = 0
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13547_6_6 = 0
		device.RX_ANA_I[0].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9814_338h.Property9814_5_0 = 43
		device.RX_ANA_I[0].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9130_111h.Property9130_14_8 = 9
		device.writeReg(0x11,0x0);
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
		
		self.rxDsaImdWrites()
		self.rxFlashCalWrites()
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x0f
		device.RX_ANA_IQ[0].channel_digital_ch.channel_dig_c.Register16435_4C4h.Property16442_5_5=1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x00
		
		if self.systemParams.halfRateModeRx==1:
			device.RX.ANA_AB.ANA_AB.Register8780_29h.Property8781_9_8=1
			device.RX.ANA_CD.ANA_CD.Register46336_29h.Property46338_9_8=1
		
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2282_28_28 = 1
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2283_27_27 = 1
		
		self.enableReliabilityDetector(self.systemParams.enableReliabilityDetector)
		self.jesdSwing(7)
	#rxAnaWrites54x

	@funcDecorator
	def rxLowLoWrites(self):
		###
		# lo	 halfRate   ana_corr	dig_corr
		# >1800   0/1		   0		   0	
		# 1800	 0			1		   0
		# 800	  0			1		   1
		# 1800	 1			1		   0
		# 800	  1			0		   1
		
		LO1 = self.systemParams.pllLo[self.systemStatus.rxLoPllIndex[0]]
		LO2 = self.systemParams.pllLo[self.systemStatus.rxLoPllIndex[1]]
		
		if (LO1>2000):
			self.rxNLTrim([0,1], 0, 0)
		elif (LO1>900) :
			self.rxNLTrim([0,1], 1, 0)
		else:
			if(self.systemParams.halfRateModeRx == 0):
				self.rxNLTrim([0,1], 1, 0)
			else:
				self.rxNLTrim([0,1], 0, 1)

		if (LO2>2000):
			self.rxNLTrim([2,3], 0, 0)
		elif (LO2>900) :
			self.rxNLTrim([2,3], 1, 0)
		else:
			if(self.systemParams.halfRateModeRx == 0):
				self.rxNLTrim([2,3], 1, 0)
			else:
				self.rxNLTrim([2,3], 0, 1)
	#rxLowLoWrites
		
	
	
	@funcDecorator
	def rxAnaWritesOld(self):
		""" "Doing RX ADC Analog Writes" "Completed RX ADC Analog Writes" """
		if self.systemParams.Fs/(1+self.systemParams.halfRateModeRx)>3000:
			self.rxAnaWrites54xOld()
			self.rxLowLoWritesOld()
			return
		elif self.systemParams.Fs/(1+self.systemParams.halfRateModeRx)<=1500:
			self.rxAnaWrites24xOld()
			self.rxLowLoWritesOld()
			return
		device=self.regs
		device.hardReadAlways=True
		self.rxLowLoWritesOld()
		for i in range(4):
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14412_10_8=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14139_13_11=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property9584_16_16 = (3&0x4)>>2
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property9585_15_14= (3&0x3)>>0
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9569_299h.Property14398_10_8=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14415_22_20=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14141_28_26=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property9583_31_29=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14421_2_0=3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14416_23_23 = 2&0x1
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14418_25_24 = (2&0x6)>>1
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14420_5_3=2
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10381_0_0 = 0
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8128_10_8=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8127_13_11=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8107_16_16 = (3&0x4)>>2
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8126_15_14= (3&0x3)>>0
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8083_299h.Property8088_10_8=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8110_22_20=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7997_28_26=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7996_31_29=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8101_2_0=3
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8111_23_23 = 2&0x1
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7998_25_24 = (2&0x6)>>1
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8100_5_3=2
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5203_0_0 = 0
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 1
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 1
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 1
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 1
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25 = 1
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register14181_337h.Property14461_29_24 = 4 
			device.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7 = 1 
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13442_335h.Property13442_10_8 = 7 
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13440_334h.Property13594_7_6 = 2 
			device.RX_ANA_I[i].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9130_111h.Property9130_14_8 = 27^18
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9814_338h.Property9814_5_0 = 32^32		
			device.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13180_281h.Property13533_15_15=1
			device.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13547_6_6=1
			device.RX_ANA_I[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7=1
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13440_334h.Property13594_7_6=0
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13442_335h.Property13442_10_8=4
			device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8207_337h.Property8208_29_24 = 4 
			device.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8156_284h.Property8163_7_7 = 1 
			device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8197_335h.Property8197_10_8 = 7 
			device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8178_334h.Property8180_7_6 = 2 
			device.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8168_281h.Property8172_15_15=1
			device.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8156_284h.Property8162_6_6=1
			device.RX_ANA_Q[i].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8156_284h.Property8163_7_7=1
			device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8178_334h.Property8180_7_6=0
			device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8197_335h.Property8197_10_8=4
			device.RX_ANA_IQ[i].channel_digital_ch.channel_dig_c.Register16435_4C4h.Property16442_5_5=1

		device.hardReadAlways=False
		if self.systemParams.enableReliabilityDetector==True:
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0xf
			device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25=0
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5861_31_29=7
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5857_15_15=1
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5862_25_8=13+(23<<6)+(3<<13)
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5858_9_0=7<<5
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0x0
	#rxAnaWritesOld
		
	@funcDecorator
	def rxAnaWrites24xOld(self):
		device=self.regs
		temp=device.hardReadAlways
		device.hardReadAlways=True

		def flash_loop_conv(ph):
			channel = ph/2
			if((ph%2)== 0):
			# Signal should be switched off at this point
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10390_27_26 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10379_18_16 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10390_27_26 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10379_18_16 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10372_8_8 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10373_9_9 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 0
				#device.RX.DIG_IandQ[ph].Main_ADC_comp.block_modes.main_bis_inc_n_0 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 1
				self.delay(0.1)
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 0
				self.delay(0.5)
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10373_9_9 = 1
				
			else:
				
			# Signal should be switched off at this point
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5210_27_26 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5201_18_16 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5210_27_26 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5201_18_16 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5263_8_8 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5264_9_9 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 1
				self.delay(0.1)									   
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 0
				self.delay(0.5)									  
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5264_9_9 = 1


		regVal=(1,1,1,1,1,4,4,3,1,5,1,7,5,3,7,4,5)
		k_coeff = np.array([0,6,7,7,7,0])

		for i in range(4):
			
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
			device.writeReg(0x11,0xFF);

			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9556_28Dh.Property9556_8_8=0
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13440_334h.Property13441_5_3= k_coeff[0]
			device.RX_ANA_I[i].ADC_FBPATH_TRIMBITS.ADC_FBPATH_I_TRIMBITS.Register9656_308h.Property9656_5_0=((k_coeff[1])%64)^0x23
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13442_335h.Property13443_14_11= k_coeff[2]
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register13440_334h.Property13440_2_0= k_coeff[3]
			device.RX_ANA_I[i].ADC_FBPATH_TRIMBITS.ADC_FBPATH_I_TRIMBITS.Register9659_309h.Property9659_13_8=((k_coeff[4])%64)^0x19
			device.RX_ANA_I[i].ADC_FBPATH_TRIMBITS.ADC_FBPATH_I_TRIMBITS.Register9662_30Ah.Property9662_19_16=k_coeff[5]^0x3
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9557_28Eh.Property9557_20_16=22
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register14181_337h.Property14461_29_24=13
			
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9802_330h.Property9802_5_0=14#(20+7)^20  #7
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9804_331h.Property9804_13_8=23#(14+1)^14  #1
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9806_332h.Property9806_21_16=8#(17+0)^17  #0
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9561_291h.Property14366_9_9=0
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9818_339h.Property9819_15_12=13
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9814_338h.Property9814_5_0=47
			device.RX_ANA_I[i].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9130_111h.Property9130_14_8 = 27^18
			device.RX_ANA_I[i].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9814_338h.Property9814_5_0 = 32^32		
			
		# 	
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8201_28Dh.Property8201_8_8=0
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8178_334h.Property8179_5_3= k_coeff[0]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TRIMBITS.ADC_FBPATH_QTRIMBITS.Register3236_308h.Property3236_5_0=((k_coeff[1])%64)^0x23
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8197_335h.Property8198_14_11= k_coeff[2]
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8178_334h.Property8178_2_0= k_coeff[3]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TRIMBITS.ADC_FBPATH_QTRIMBITS.Register3239_309h.Property3239_13_8=((k_coeff[4])%64)^0x19
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TRIMBITS.ADC_FBPATH_QTRIMBITS.Register3242_30Ah.Property3242_19_16=k_coeff[5]^0x3
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8007_28Eh.Property8007_20_16=22
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8207_337h.Property8208_29_24=13
		# 	
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register3298_330h.Property3298_5_0=14#(20+7)^20  #7
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register3300_331h.Property3300_13_8=23#(14+1)^14  #1
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register3302_332h.Property3302_21_16=8#(17+0)^17  #0
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8047_291h.Property8052_9_9=0
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8194_339h.Property8195_15_12=13
		# 	device.RX_ANA_Q[i].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8165_338h.Property8165_5_0=47
		# 	
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9561_291h.Property14127_14_14=regVal[0]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14142_6_6=regVal[1]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9565_295h.Property14381_10_10=regVal[3]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9588_2A2h.Property14144_22_22=regVal[4]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14412_10_8=regVal[5]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14139_13_11=regVal[6]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property9585_15_14=regVal[7]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property9584_16_16=regVal[8]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14415_22_20=regVal[9]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14416_23_23=regVal[10]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property9583_31_29=regVal[11]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14141_28_26=regVal[12]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14418_25_24=regVal[13]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14420_5_3=regVal[14]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14421_2_0=regVal[15]
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9569_299h.Property14398_10_8=regVal[16]
			
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8047_291h.Property8048_14_14=regVal[0]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8099_6_6=regVal[1]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8113_295h.Property8118_10_10=regVal[3]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8055_2A2h.Property8056_22_22=regVal[4]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8128_10_8=regVal[5]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8127_13_11=regVal[6]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8126_15_14=regVal[7]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8107_16_16=regVal[8]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8110_22_20=regVal[9]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8111_23_23=regVal[10]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7996_31_29=regVal[11]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7997_28_26=regVal[12]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7998_25_24=regVal[13]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8100_5_3=regVal[14]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8101_2_0=regVal[15]
		# 	device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8083_299h.Property8088_10_8=regVal[16]
		# 		
			device.RX_ANA_IQ[i].ADC_LP_TESTMODES.ADC_LP_COMMON_TESTMODES.Register15383_28Dh.Property15383_8_8=regVal[2]
			
		for i in range(4):
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9556_28Dh.Property9556_8_8=0
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10610_3_3=0
			
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8201_28Dh.Property8201_8_8=0
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5213_3_3=0

		self.dither_mode(4,0)

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 1
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 15
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 1
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0

		for i in range(1):
			device.RX_ANA_I[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9556_28Dh.Property9556_8_8=0
			device.RX_ANA_I[i].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10610_3_3=0
			device.RX_ANA_Q[i].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8201_28Dh.Property8201_8_8=0
			device.RX_ANA_Q[i].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5213_3_3=0
			
		self.deviceRefs.broadcastEn=15
		self.RX.pdnFrontEnd(0,1)
		self.deviceRefs.broadcastEn=0
		flash_loop_conv(0)
		flash_loop_conv(1)
		flash_loop_conv(2)
		flash_loop_conv(3)
		flash_loop_conv(4)
		flash_loop_conv(5)
		flash_loop_conv(6)
		flash_loop_conv(7)

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 0
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 15
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 0
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0
		self.dither_mode(4,2)
		
		self.deviceRefs.broadcastEn=15
		self.RX.pdnFrontEnd(0,0)
		self.deviceRefs.broadcastEn=0
		device.hardReadAlways=temp
		if self.systemParams.enableReliabilityDetector==True:
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0xf
			device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25=0
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5861_31_29=7
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5857_15_15=1
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5862_25_8=13+(23<<6)+(3<<13)
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5858_9_0=7<<5
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0x0
	#rxAnaWrites24xOld
	
	@funcDecorator
	def get_flash_corrOld(self,ph):
		flash_corr = np.zeros(42)
		for x in range(32):
			if(x<16):
				if (ph%2) == 0:
					device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10626_0_0 = 0
					device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10625_5_1 = x
					self.delay(0.1)			
					flash_corr[x] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch._Property10627_13_8.getValue()
				else:
					device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5160_0_0 = 0
					device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5159_5_1 = x	
					self.delay(0.1)		
					flash_corr[x] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch._Property5161_13_8.getValue()
			else:
				if (ph%2) == 0:
					device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10626_0_0 = 1
					device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10625_5_1 = x-16			
					self.delay(0.1)
					flash_corr[x] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch._Property10627_13_8.getValue()
				else:
					device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5160_0_0 = 1
					device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5159_5_1 = x-16			
					self.delay(0.1)
					flash_corr[x] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch._Property5161_13_8.getValue()
				
		if (ph%2) == 0:
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10626_0_0 = 0
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10625_5_1 = 18			
			flash_corr[32] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch._Property10627_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10626_0_0 = 1
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch.Property10625_5_1 = 18			
			flash_corr[33] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10625_54Ch._Property10627_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10649_4_4 = 0
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 0
			flash_corr[34] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 1
			flash_corr[35] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 2
			flash_corr[36] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 3
			flash_corr[37] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10649_4_4 = 1
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 0
			flash_corr[38] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 1
			flash_corr[39] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 2
			flash_corr[40] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h.Property10636_1_0 = 3
			flash_corr[41] = device.RX_ANA_I[ph/2].channel_digital_ch.channel_dig_i.Register10636_564h._Property10638_13_8.getValue()
			
			
		else:
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5160_0_0 = 0
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5159_5_1 = 18			
			flash_corr[32] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch._Property5161_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5160_0_0 = 1
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch.Property5159_5_1 = 18			
			flash_corr[33] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5159_54Ch._Property5161_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5277_4_4 = 0
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 0
			flash_corr[34] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 1
			flash_corr[35] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 2
			flash_corr[36] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 3
			flash_corr[37] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5277_4_4 = 1
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 0
			flash_corr[38] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 1
			flash_corr[39] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 2
			flash_corr[40] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
			
			device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h.Property5267_1_0 = 3
			flash_corr[41] = device.RX_ANA_Q[ph/2].channel_digital_ch.channel_dig_q.Register5267_564h._Property5268_13_8.getValue()
		return flash_corr	
	#get_flash_corrOld
	
	@funcDecorator
	def rxAnaWrites54xOld(self):
		""" "Doing RX ADC Analog Writes" "Completed RX ADC Analog Writes" """
		device=self.regs
		device.hardReadAlways=True
		def flash_loop_conv(ph):
			
			channel = ph/2
			
			if((ph%2)== 0):
			
			# Signal should be switched off at this point
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10390_27_26 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10379_18_16 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10390_27_26 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10379_18_16 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10372_8_8 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10373_9_9 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 1
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10383_16_16 = 0
				#device.RX.DIG_IandQ[ph].Main_ADC_comp.block_modes.main_bis_inc_n_0 = 0
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 1
				self.delay(0.1)
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10371_0_0 = 0
				self.delay(0.5)
				device.RX_ANA_I[channel].channel_digital_ch.channel_dig_i.Register10371_49Ch.Property10373_9_9 = 1
				
			else:
				
			# Signal should be switched off at this point
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5210_27_26 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5201_18_16 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5210_27_26 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5201_18_16 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5263_8_8 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5264_9_9 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 1
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5265_16_16 = 0
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 1
				self.delay(0.1)									   
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5262_0_0 = 0
				self.delay(0.5)									  
				device.RX_ANA_Q[channel].channel_digital_ch.channel_dig_q.Register5262_49Ch.Property5264_9_9 = 1
				
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0xF

		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14412_10_8=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property14139_13_11=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property9584_16_16 = 0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9585_29Dh.Property9585_15_14= 0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9569_299h.Property14398_10_8=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14415_22_20=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14141_28_26=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property9583_31_29=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14421_2_0=0
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9584_29Eh.Property14416_23_23 = 1
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9583_29Fh.Property14418_25_24 = 1
		device.RX_ANA_I[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_I.Register9590_2A0h.Property14420_5_3=0

		device.RX_ANA_I[0].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register14181_337h.Property14461_29_24 = 3
		device.RX_ANA_I[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_I.Register13186_284h.Property13548_7_7 = 1

		device.RX_ANA_I[0].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9802_330h.Property9802_5_0 = 14
		device.RX_ANA_I[0].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9804_331h.Property9804_13_8 = 23
		device.RX_ANA_I[0].ADC_LP_TRIMBITS.ADC_LP_I_TRIMBITS.Register9806_332h.Property9806_21_16 = 8

		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10379_49Eh.Property10381_0_0 = 0
			
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0xF

		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8128_10_8=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8127_13_11=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8107_16_16 = 0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8126_29Dh.Property8126_15_14= 0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8083_299h.Property8088_10_8=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8110_22_20=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7997_28_26=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7996_31_29=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8101_2_0=0
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8107_29Eh.Property8111_23_23 = 1
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register7996_29Fh.Property7998_25_24 = 1
		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8098_2A0h.Property8100_5_3=0

		device.RX_ANA_Q[0].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register8207_337h.Property8208_29_24 = 3
		device.RX_ANA_Q[0].ADC_LP_TESTMODES.ADC_LP_TESTMODES_Q.Register8156_284h.Property8163_7_7 = 1

		device.RX_ANA_Q[0].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register3298_330h.Property3298_5_0 = 14
		device.RX_ANA_Q[0].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register3300_331h.Property3300_13_8 = 23
		device.RX_ANA_Q[0].ADC_LP_TRIMBITS.ADC_LP_Q_TRIMBITS.Register3302_332h.Property3302_21_16 = 8

		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5201_49Eh.Property5203_0_0 = 0

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 15
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10676_0_0 = 1
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10676_500h.Property10677_1_1 = 1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i = 0

		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 15
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5327_0_0 = 1
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5327_500h.Property5328_1_1 = 1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q = 0

		device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25 = 1
		device.RX_ANA_Q[1].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25 = 1
		device.RX_ANA_Q[2].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25 = 1
		device.RX_ANA_Q[3].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25 = 1

		self.deviceRefs.broadcastEn=15
		self.RX.pdnFrontEnd(0,1)
		self.deviceRefs.broadcastEn=0
		flash_loop_conv(0)
		flash_loop_conv(1)
		flash_loop_conv(2)
		flash_loop_conv(3)
		flash_loop_conv(4)
		flash_loop_conv(5)
		flash_loop_conv(6)
		flash_loop_conv(7)
		
		self.deviceRefs.broadcastEn=15
		self.RX.pdnFrontEnd(0,0)
		self.deviceRefs.broadcastEn=0
		
		self.dither_mode(4,2) # enable alll dithers
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x0f
		device.RX_ANA_IQ[0].channel_digital_ch.channel_dig_c.Register16435_4C4h.Property16442_5_5=1
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_common=0x00
		
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2282_28_28 = 1
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2283_27_27 = 1
		# enable_xor(4,0)
		device.hardReadAlways=False
		if self.systemParams.enableReliabilityDetector==True:
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0xf
			device.RX_ANA_Q[0].ADC_FBPATH_TESTMODES.ADC_FBPATH_TESTMODES_Q.Register8066_293h.Property8068_25_25=0
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5861_31_29=7
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5857_15_15=1
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5862_25_8=13+(23<<6)+(3<<13)
			device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5834_B7Ch.Property5858_9_0=7<<5
			device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0x0
	#rxAnaWrites54xOld
	
	@funcDecorator
	def rxLowLoWritesOld(self):
		pageSelect=0
		if self.systemParams.pllLo[self.systemStatus.rxLoPllIndex[0]]<2000:
			pageSelect=pageSelect|0x3
			firstInstance=0
		if self.systemParams.pllLo[self.systemStatus.rxLoPllIndex[1]]<2000:
			pageSelect=pageSelect|0xc
			firstInstance=2
		if pageSelect==0:
			return
		device=self.regs
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i=pageSelect
		cap = 7
		device.RX_ANA_I[firstInstance].BB_FILTER_I.BB_FILTER_MODES.Register9112_103h.Property9114_30_28=cap
		device.RX_ANA_I[firstInstance].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_I.Register9387_1A1h.Property9387_10_8=4
		device.RX_ANA_I[firstInstance].BB_FILTER_I.BB_FILTER_TRIM_BITS.Register9131_112h.Property9131_18_16=5
		device.RX_ANA_I[firstInstance].ADC_FBPATH_TRIMBITS.ADC_FBPATH_I_TRIMBITS.Register9637_304h.Property9637_3_0=0#4
		device.RX_ANA_I[firstInstance].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_COMMON.Register9298_C90h.Property9301_5_3=3
		device.RX_ANA_I[firstInstance].BB_FILTER_COMMON.BB_FILTER_TESTMODES.Register8999_BF3h.Property8999_26_24=3
		device.RX_ANA_I[firstInstance].BB_FILTER_I.BB_FILTER_MODES.Register9106_101h.Property9106_10_8=2
		device.RX_ANA_I[firstInstance].BB_FILTER_I.BB_FILTER_MODES.Register9102_100h.Property9103_5_3=5
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=pageSelect
		device.RX_ANA_Q[firstInstance].BB_FILTER_Q.BB_FILTER_MODES.Register2888_103h.Property2890_30_28=cap
		device.RX_ANA_Q[firstInstance].CHANNEL_IREFGEN_TESTMODES.CHANNEL_IREFGEN_TESTMODES_Q.Register2872_1A1h.Property2872_10_8=4
		device.RX_ANA_Q[firstInstance].BB_FILTER_Q.BB_FILTER_TRIM_BITS.Register2897_112h.Property2897_18_16=5
		device.RX_ANA_Q[firstInstance].ADC_FBPATH_TRIMBITS.ADC_FBPATH_QTRIMBITS.Register3228_304h.Property3228_3_0=0#4
		device.RX_ANA_Q[firstInstance].BB_FILTER_Q.BB_FILTER_MODES.Register2882_101h.Property2882_10_8=2
		device.RX_ANA_Q[firstInstance].BB_FILTER_Q.BB_FILTER_MODES.Register2878_100h.Property2879_5_3=5
	#rxLowLoWritesOld
		
	@funcDecorator
	def fbAnaWrites(self):
		""" "Doing FB ADC Analog Writes" "Completed FB ADC Analog Writes" """
		device=self.regs
		device.hardReadAlways=True
		for i in range(2):
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1139_B0h.Property1140_1_1 = 1 
			device.FB[i].FB_EC_DIG.ec_dac_loops.Register1418_188h.Property1421_3_3 = 1
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1312_140h.Property1315_3_3 = 1
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1301_138h.Property1304_3_3 = 1
			device.FB[i].FB_EC_DIG.ec_dac_loops.Register1427_190h.Property1430_3_3 = 1
			device.FB[i].FB_EC_DIG.ec_dac_loops.Register1370_168h.Property1373_3_3 = 1
			device.FB[i].FB_EC_DIG.ec_dac_loops.Register1358_160h.Property1361_3_3 = 1
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1257_118h.Property1265_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1268_120h.Property1276_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1279_128h.Property1287_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1290_130h.Property1298_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1257_118h.Property1265_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1268_120h.Property1276_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1279_128h.Property1287_11_8=2
			device.FB[i].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1290_130h.Property1298_11_8=2
			device.FB[i].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=2
			device.FB[i].FB_ANA.IDSA_BUF_TOP.Register48219_35h.Property48234_19_19=1
		
		#Ref clock buffer strength
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property945_18_18=1
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49046_18_18=1
		device.RX.ANA_AB.ANA_AB.Register8864_3Fh.Property8866_29_27=4
		device.RX.ANA_AB.ANA_AB.Register8864_3Fh.Property8867_26_25=3
		device.RX.ANA_CD.ANA_CD.Register46430_3Fh.Property46432_29_27=4
		device.RX.ANA_CD.ANA_CD.Register46430_3Fh.Property46433_26_25=3

		#Analog divider disable
		for i in range(2):
			device.FB[i].FB_ANA.IDSA_BUF_TOP.Register48219_35h.Property48243_4_4=1
			device.FB[i].FB_ANA.IDSA_BUF_TOP.Register48219_35h.Property48247_3_3=1
			device.FB[i].FB_ANA.ISTG1_TOP.Register48505_8Eh.Property48520_16_16 = 1
			device.FB[i].FB_ANA.ISTG1_TOP.Register48497_95h.Property48498_8_6 = 7
			
			if round(self.systemParams.Fs,5)==3317.76:
				device.FB[i].FB_EC_DIG.ec_misc.Register1046_74h.Property1058_27_24=8			 
				device.FB[i].FB_ANA.ISTG1_TOP.Register48422_92h.Property48457_17_15=7
			
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1334_150h.Property1334_0_0=1
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1334_150h.Property1338_4_4=1
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1334_150h.Property1339_5_5=1
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1235_108h.Property1235_0_0=0
			device.FB[i].FB_EC_DIG.ec_s12_g_m_loops.Register1235_108h.Property1240_5_5=1
			device.FB[i].FB_EC_DIG.ec_force_gain_dac_mem.Register1341_150h.Property1341_7_7=1
			device.FB[i].FB_EC_DIG.ec_force_gain_dac_mem.Register1341_150h.Property1477_23_15=128
			device.FB[i].FB_EC_DIG.ec_misc.Register962_28h.Property962_0_0=1
			device.FB[i].FB_EC_DIG.ec_misc.Register962_28h.Property962_0_0=0
			device.FB[i].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=1
			device.FB[i].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=0
		
		fb_nl_enable=1
		time=1
		device.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = (fb_nl_enable<<16)+(time&0xFFFF)
		device.TOP.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (0x14)<<24
		device.hardReadAlways=False
		self.TOP.GPIO.enableTempSensor(1)
	#fbAnaWrites		

	def fbAnaWritesPostLinkup(self):
		device=self.regs
		if (np.round(self.systemParams.Fs/(1+self.systemParams.halfRateModeFb), 2) == np.round(3317.76,2)):
			device.currentPageSelected.setValue(0)
			device.writeReg(0x10,0x10)
			device.writeReg(0xB0,0x03)
			device.writeReg(0x188,0x09)
			device.writeReg(0x140,0x28)
			device.writeReg(0x138,0x28)
			device.writeReg(0x190,0x09)
			device.writeReg(0x168,0x39)
			device.writeReg(0x160,0x39)
			device.writeReg(0x119,0x32)
			device.writeReg(0x121,0x32)
			device.writeReg(0x129,0x32)
			device.writeReg(0x131,0x32)
			device.writeReg(0x119,0x32)
			device.writeReg(0x121,0x32)
			device.writeReg(0x129,0x32)
			device.writeReg(0x131,0x32)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x20)
			device.writeReg(0x10,0x20)
			device.writeReg(0x85,0x08)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x40)
			device.writeReg(0xB0,0x03)
			device.writeReg(0x188,0x09)
			device.writeReg(0x140,0x28)
			device.writeReg(0x138,0x28)
			device.writeReg(0x190,0x09)
			device.writeReg(0x168,0x39)
			device.writeReg(0x160,0x39)
			device.writeReg(0x119,0x32)
			device.writeReg(0x121,0x32)
			device.writeReg(0x129,0x32)
			device.writeReg(0x131,0x32)
			device.writeReg(0x119,0x32)
			device.writeReg(0x121,0x32)
			device.writeReg(0x129,0x32)
			device.writeReg(0x131,0x32)
			device.writeReg(0x10,0x40)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x80)
			device.writeReg(0x85,0x08)
			device.writeReg(0x10,0xA0)
			device.writeReg(0x10,0x20)
			device.writeReg(0x102,0x08)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x80)
			device.writeReg(0x102,0x08)
			device.writeReg(0x10,0x80)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x20)
			device.writeReg(0x10,0x20)
			device.writeReg(0x80,0x10)
			device.writeReg(0x80,0x18)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x80)
			device.writeReg(0x80,0x10)
			device.writeReg(0x80,0x18)
			device.writeReg(0x10,0x80)
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0xA0)
			device.writeReg(0x95,0x01)
			device.writeReg(0x94,0xc0)
			#{FLVDD increased to 1.125V for FB} {changed on oct24}
			device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x50)
			device.writeReg(0x111,0x78)
			#{Reduce stg1 mem loop convergence time}device.writeReg(0x10,0x00)
			device.writeReg(0x10,0x50)
			#{EC reset}device.writeReg(0x28,0xA0)
			device.writeReg(0x28,0xA1)
			self.delay(0.1)
			device.writeReg(0x28,0xA0)
			device.writeReg(0x10,0x00)


			device.writeReg(0x10,0x50);
			device.writeReg(0x77,0x8); #{dither disable for FB}
			device.writeReg(0x10,0x00);
			device.writeReg(0x10,0xA0);
			##############
			device.writeReg(0xA2,0x03); #{Latp rise = 7 (most advanced)}
			device.writeReg(0xA1,0x80); #{Latp rise = 7 (most advanced)}
			#Nags Changed for IMD3 improvement across temp(110) and supply(VDDTx 1p2)
			# device.writeReg(0xA2,0x03);
			# device.writeReg(0xA1,0x00);#Latp rise =-1
			##############
			device.writeReg(0x10,0x00);


			device.FB[1].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48367_3_0=4
			device.FB[0].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48367_3_0=4

			device.FB[1].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=3
			device.FB[0].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=3


			## Overload Comparator Calibration
			device.FB[1].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=1
			self.delay(0.1)
			device.FB[1].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=0
			device.FB[0].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=1
			self.delay(0.1)
			device.FB[0].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=0
	#fbAnaWritesPostLinkup
	
	@funcDecorator
	def fbAnaWritesBroadCast(self):
		""" "Doing FB ADC Analog Writes" "Completed FB ADC Analog Writes" """
		device=self.regs
		device.hardReadAlways=True
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ec=3
		device.FB[0].FB_EC_DIG.ec_s12_g_m_loops.Register1139_B0h.Property1140_1_1 = 1 
		device.FB[0].FB_EC_DIG.ec_dac_loops.Register1418_188h.Property1421_3_3 = 1
		device.FB[0].FB_EC_DIG.ec_s12_g_m_loops.Register1312_140h.Property1315_3_3 = 1
		device.FB[0].FB_EC_DIG.ec_s12_g_m_loops.Register1301_138h.Property1304_3_3 = 1
		device.FB[0].FB_EC_DIG.ec_dac_loops.Register1427_190h.Property1430_3_3 = 1
		device.FB[0].FB_EC_DIG.ec_dac_loops.Register1370_168h.Property1373_3_3 = 1
		device.FB[0].FB_EC_DIG.ec_dac_loops.Register1358_160h.Property1361_3_3 = 1
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1257_118h.Property1265_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1268_120h.Property1276_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1279_128h.Property1287_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1290_130h.Property1298_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1257_118h.Property1265_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1268_120h.Property1276_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1279_128h.Property1287_11_8=2
		device.FB[0].FB_EC_DIG.ec_s1_ms_ad_s3_g_loops.Register1290_130h.Property1298_11_8=2
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ec=3
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ana=3
		device.FB[0].FB_ANA.ISTG1_AMP2.Register48364_89h.Property48376_12_10=2
		device.FB[1].FB_ANA.IDSA_BUF_TOP.Register48219_35h.Property48234_19_19=1
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ana=0
		
		#Ref clock buffer strength
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property945_18_18=1
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49046_18_18=1
		device.RX.ANA_AB.ANA_AB.Register8864_3Fh.Property8866_29_27=4
		device.RX.ANA_AB.ANA_AB.Register8864_3Fh.Property8867_26_25=3
		device.RX.ANA_CD.ANA_CD.Register46430_3Fh.Property46432_29_27=4
		device.RX.ANA_CD.ANA_CD.Register46430_3Fh.Property46433_26_25=3

		#Analog divider disable
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ana=3
		device.FB[0].FB_ANA.IDSA_BUF_TOP.Register48219_35h.Property48243_4_4=1
		device.FB[0].FB_ANA.IDSA_BUF_TOP.Register48219_35h.Property48247_3_3=1
		
		device.FB[0].FB_ANA.ISTG1_TOP.Register48505_8Eh.Property48520_16_16 = 1
		device.FB[0].FB_ANA.ISTG1_TOP.Register48497_95h.Property48498_8_6 = 7
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ana=0
		
		#if round(self.systemParams.Fs,5)==2949.12:
		#	device.FB[0].FB_ANA.ISTG1_TOP.Register48497_95h.Property48498_8_6 = 7
		#	device.FB[1].FB_ANA.ISTG1_TOP.Register48497_95h.Property48498_8_6 = 7
		#else:
		#	device.FB[0].FB_ANA.ISTG1_TOP.Register48497_95h.Property48498_8_6 = 2
		#	device.FB[1].FB_ANA.ISTG1_TOP.Register48497_95h.Property48498_8_6 = 2
		
		if round(self.systemParams.Fs,5)==3317.76:
			device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ec=3
			device.FB[0].FB_EC_DIG.ec_misc.Register1046_74h.Property1058_27_24=8			 
			device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ec=0
			device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ana=3
			device.FB[0].FB_ANA.ISTG1_TOP.Register48422_92h.Property48457_17_15=7
			device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ana=0
			
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ec=3
		device.FB[0].FB_EC_DIG.ec_misc.Register962_28h.Property962_0_0=1
		device.FB[0].FB_EC_DIG.ec_misc.Register962_28h.Property962_0_0=0
		device.FB[0].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=1
		device.FB[0].FB_EC_DIG.ec_misc.Register1111_93h.Property1129_21_0=0
		device.MASTER.MASTER_PAGE.PAGE_SEL.FB_EC_ANALOG.fb_ec=0

		fb_nl_enable=1
		time=1
		device.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = (fb_nl_enable<<16)+(time&0xFFFF)
		device.TOP.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = (0x14)<<24
		device.hardReadAlways=False
	#fbAnaWritesBroadCast

	@funcDecorator
	def setFbNcoWord(self,chNo,ncoFreq,bandNo=0,resync=0):
		""" "Setting FB NCO Word, doing the top level Mux and leaking Sysref." """
		if resync==0:
			self.regs.TOP.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44720_10_0=0x006
		nyqBand=int(ncoFreq*2.0/self.systemParams.Fs)
		if self.systemStatus.chipVersion>0x10:
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=1
			if chNo==0:
				self.regs.writeReg32(0x343C+(bandNo*4),int(round(ncoFreq*1000*self.systemParams.X/62.5)))
			else:
				self.regs.writeReg32(0x3444+(bandNo*4),int(round(ncoFreq*1000*self.systemParams.X/62.5)))
			self.regs.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=0
			temp=self.deviceRefs.device.hardReadAlways
			self.deviceRefs.device.hardReadAlways=True
			self.TOP.SYSCALIB.do_tune_and_enable(0,0,1,0,0)
			if(self.systemParams.halfRateModeFb==1):
				self.regs.FB[0].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=2
				self.regs.FB[1].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=2
			else:
				self.regs.FB[0].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=5
				self.regs.FB[1].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal=5
			self.deviceRefs.device.hardReadAlways=temp
		else:
			self.FBDIG[chNo&1].setNcoWord(ncoFreq)
		if resync==0:
			self.TOP.leakSysrefRxTxDig(0,0,1)
			self.regs.TOP.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44720_10_0=0x7ff
		else:
			self.adcDacSync(0)
	#setFbNcoWord
	
	@funcDecorator
	def setLowIfNco(self,chNo):
		#Paramters
		low_if_nco_tx=[0,0]
		x=self.systemParams.X/62.5
		if (self.systemParams.lowIfNcoTx[0]>=0):
						low_if_nco_tx[0]=int(2**32-61440*self.systemStatus.txLowIfRate[0]+(self.systemParams.lowIfNcoTx[0]*1000*x))#1Mhz
		else:
						low_if_nco_tx[0]=int(2**32+self.systemParams.lowIfNcoTx[0]*1000*x)#1Mhz
		if (self.systemParams.lowIfNcoTx[1]>=0):
						low_if_nco_tx[1]=int(2**32-61440*self.systemStatus.txLowIfRate[1]+(self.systemParams.lowIfNcoTx[1]*1000*x))#1Mhz
		else:
						low_if_nco_tx[1]=int(2**32+self.systemParams.lowIfNcoTx[1]*1000*x)#1Mhz
		low_if_nco_fb=[0,0]
		if (self.systemParams.lowIfNcoFb[0]>=0):
						low_if_nco_fb[0]=int(2**32-61440*self.systemStatus.fbLowIfRate[0]+(self.systemParams.lowIfNcoFb[0]*1000*x))#1Mhz
		else:
						low_if_nco_fb[0]=int(2**32+self.systemParams.lowIfNcoFb[0]*1000*x)#1Mhz
		if (self.systemParams.lowIfNcoFb[0]>=0):
						low_if_nco_fb[1]=int(2**32-61440*self.systemStatus.fbLowIfRate[1]+(self.systemParams.lowIfNcoFb[1]*1000*x))#1Mhz
		else:
						low_if_nco_fb[1]=int(2**32+self.systemParams.lowIfNcoFb[1]*1000*x)#1Mhz
		#parameters
		FBLowIFMode_ABCD_ADDR=0x3468
		TxNCO_AB_ADDR=0x3454
		FBNCO_AB_ADDR=0x346C
		self.regs.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=1
		self.regs.writeReg32(TxNCO_AB_ADDR,low_if_nco_tx[0])
		self.regs.writeReg32(TxNCO_AB_ADDR+4,low_if_nco_tx[1])
		self.regs.writeReg32(FBNCO_AB_ADDR,low_if_nco_fb[0])
		self.regs.writeReg32(FBNCO_AB_ADDR+4,low_if_nco_fb[1])
		self.regs.writeReg(FBLowIFMode_ABCD_ADDR,0x3)
		self.regs.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram=0
		self.TOP.SYSCALIB.do_tune_and_enable(1,0,1,0,0x800)
		self.adcDacSync(1)
	
	@funcDecorator
	def configPllMux(self):
		""" "Configuring PLL Mux" "Done configuring PLL Mux" """
		# L is AB, R is CD
		# Top is TX, Bot is RX
		if self.systemParams.pllMuxModes==0:
			### 4T4R Mode with PLL0 as Master. PLL 0 for all the LOs.
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2235_0_0=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2234_1_1=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2221_16_16=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2220_17_17=1

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2333_8_8=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2332_9_9=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2331_10_10=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2330_11_11=0

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2207_0_0=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2206_1_1=0

			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=1
			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.PDN_GBL_PLL5_CLKTOP=1
			#self.regs.RX.ANA_AB.ANA_AB.Register8839_3Bh.Property8845_25_25=0
			#self.regs.RX.ANA_CD.ANA_CD.Register46404_3Bh.Property46410_25_25=0

			self.regs.RX_ANA_Q[0].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[1].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[2].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[3].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
		elif self.systemParams.pllMuxModes==1:
			### 4T4R Mode with PLL2 as Master. PLL 2 for all the LOs.
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2235_0_0=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2234_1_1=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2221_16_16=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2220_17_17=0

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2333_8_8=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2332_9_9=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2331_10_10=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2330_11_11=1

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2207_0_0=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2206_1_1=1

			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=1
			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.PDN_GBL_PLL5_CLKTOP=1

			self.regs.RX_ANA_Q[0].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[1].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[2].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[3].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
		elif self.systemParams.pllMuxModes==2:
			### 4T4R FDD Mode. PLL0 for TX and PLL2 for RX.
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2235_0_0=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2234_1_1=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2221_16_16=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2220_17_17=0

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2333_8_8=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2332_9_9=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2331_10_10=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2330_11_11=0

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2207_0_0=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2206_1_1=0

			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=1
			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.PDN_GBL_PLL5_CLKTOP=1

			self.regs.RX_ANA_Q[0].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[1].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[2].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[3].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0

		elif self.systemParams.pllMuxModes==3:
			### 2*2T2R FDD Mode: PLL0 AB-TX;PLL3 AB-RX; PLL2 CD TX; PLL4 CD RX
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2235_0_0=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2234_1_1=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2221_16_16=1	# just for Isolation
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2220_17_17=1	# just for Isolation
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2319_70h.Property2323_2_2=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2319_70h.Property2322_3_3=1

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2333_8_8=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2332_9_9=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2331_10_10=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2330_11_11=1
			
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13=1

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2207_0_0=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2206_1_1=1

			self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=0
			self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.PDN_GBL_PLL5_CLKTOP=0

			self.regs.RX_ANA_Q[0].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=1
			self.regs.RX_ANA_Q[1].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=1
			self.regs.RX_ANA_Q[2].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=1
			self.regs.RX_ANA_Q[3].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=1

		elif self.systemParams.pllMuxModes==4:
			### 2T2R FDD - TDD Mode: PLL0 AB-TX; PLL3-AB-RX; PLL2 CD
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2235_0_0=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2232_64h.Property2234_1_1=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2221_16_16=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2218_62h.Property2220_17_17=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2319_70h.Property2323_2_2=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2319_70h.Property2322_3_3=0

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2333_8_8=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2332_9_9=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2331_10_10=0
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2330_11_11=1
			
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2327_71h.Property2328_13_13=1

			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2207_0_0=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2200_60h.Property2206_1_1=1

			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=0
			#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_right_spare_0.PDN_GBL_PLL5_CLKTOP=1

			self.regs.RX_ANA_Q[0].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=1
			self.regs.RX_ANA_Q[1].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=1
			self.regs.RX_ANA_Q[2].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
			self.regs.RX_ANA_Q[3].CLKGEN_2R.CLKGEN_2R.Register6487_F0Dh.Property6572_13_13=0
		#self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.SERDES_L_IP_REF_CLK_DIV=self.systemStatus.serdesConfig[0]['refClkIpDiv']-1
		#if self.systemStatus.serdesConfig[0]['refClkIpDiv']!=1:
		#	self.regs.TOP.TOP_ANA_CTRL.TOP_ANA_CTRL.po_common_to_pll45_left_spare_0.PDN_GBL_PLL4_CLKTOP=0
		
		if self.systemParams.pllMuxModes!=0:
			self.regs.TOP.TC_GPIO.digtop.Register41632_600h.use_register_values_for_refclk_trim=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2237_65h.Property2241_11_11=1
			self.regs.TOP.CLK_AB.ctl_2t_clktop_config.Register2237_65h.Property2240_12_12=1
	#configPllMux		
	
	@funcDecorator
	def getCaptureSettings(self,rxFbTx,chNo):
		if rxFbTx!=1:
			topno=chNo/2
			channelInTop=(chNo%2)&1
		else:
			topno=chNo&1
			channelInTop=(chNo&1)
			
		if rxFbTx==0:
			if self.systemParams.ddcFactorRx[topno]!=1:
				LMFSHd=self.systemParams.LMFSHdRx[topno]
			else:
				LMFSHd="48410"
				self.regs.JESD.ADC_TX[0].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=0
				self.regs.JESD.ADC_TX[1].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=0
		elif rxFbTx==1:
			if self.systemParams.ddcFactorFb[topno]!=1:
				LMFSHd=self.systemParams.LMFSHdFb[topno]
			else:
				LMFSHd="48410"
				self.regs.JESD.ADC_TX[0].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=1
				self.regs.JESD.ADC_TX[1].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=1
		elif rxFbTx==2:
			LMFSHd=self.systemParams.LMFSHdTx[topno]
		else:
			LMFSHd="44210"
		(L,M,F,S,Hd,resolution,numBands)=self.jesdModeFeatures(LMFSHd)
		if rxFbTx==1 and L==1 and (self.systemParams.dedicatedLaneMode[topno]==1 or self.systemParams.systemMode[topno]==1):
			laneSelOffset=2
		elif rxFbTx==1 and L==2 and (self.systemParams.dedicatedLaneMode[topno]==1 or self.systemParams.systemMode[topno]==1):
			laneSelOffset=2#1
		else:
			laneSelOffset=0
		
		if M==8 and rxFbTx==0 and 1 not in self.systemParams.ddcFactorFb+self.systemParams.ddcFactorRx:
			twoTNo=chNo/4
			chNo=chNo%4
		elif M==4 and rxFbTx==1:
			if int(LMFSHd[1])==4:
				chNo=chNo
			else:	  
				chNo=2*chNo
			twoTNo=chNo/2
			chNo=chNo%2
		elif M==2 and rxFbTx==1:
			twoTNo=chNo
		else:
			twoTNo=chNo/2
			chNo=chNo%2
			
		if 1 in self.systemParams.ddcFactorFb+self.systemParams.ddcFactorRx:
			converterOrder=range(8)
		else:
			converterOrder=(0+2*chNo,1+2*chNo)

		if L==3:
			L=4
		lanesToCapture=range((twoTNo*4)+laneSelOffset,(twoTNo*4)+laneSelOffset+L)
		lanesToCaptureReordered=lanesToCapture[:]
		for laneNo in range(len(lanesToCapture)):
			if rxFbTx==2:
				lanesToCaptureReordered[laneNo]=self.systemParams.jesdRxLaneMux[lanesToCapture[laneNo]]
			else:
				lanesToCaptureReordered[laneNo]=self.systemParams.jesdTxLaneMux.index(lanesToCapture[laneNo])

		return (LMFSHd,lanesToCaptureReordered,converterOrder)
	#getCaptureSettings
	
	@funcDecorator
	def selectCh(self,rxFbTx,chNo):
 		if setupParams.skipFpga==1 or setupParams.boardType in ("EVM-1Device",):
			error("FPGA Skipped (skipFpga=1).")
			return
		
		rxFbTx=int(round(rxFbTx))
		chNo=int(round(chNo))
		if rxFbTx==1:
			chNo=chNo%2
		if rxFbTx!=1:
			topno=chNo/2
			channelInTop=(chNo%2)&1
		else:
			topno=chNo&1
			channelInTop=(chNo&1)
		if setupParams.boardType=="BENCH":
			if setupParams.skipLmk==0:
				if self.LMK.laneRate<7500:
					byte_swap=1
				else:
					byte_swap=0
			else:
				byte_swap=0
		
			rxParams=self.jesdModeFeatures(self.systemParams.LMFSHdRx[topno])
			fbParams=list(self.jesdModeFeatures(self.systemParams.LMFSHdFb[topno]))
			#LMFSHdFb=str(fbParams[0])+str(fbParams[1])+str(fbParams[2])+str(fbParams[3])+str(fbParams[4])
			programmedFpgaRxF=self.FPGA.setJesdRxF[topno]
			if rxFbTx==2:
				self.LMK.lmkSysrefEn(1)
				self.LMK.lmkSelectCh(rxFbTx,topno)
				self.FPGA.resetQpllIpReset()
				self.adcDacSync()
				self.LMK.lmkSysrefEn(0)
				return
			elif rxFbTx==1:
				if fbParams[2]!=programmedFpgaRxF or self.systemStatus.laneRateFb[topno]!=self.LMK.laneRate:	# If F is same and lane rates for RX and FB are same. In this case single link is sufficient to be established.
					if self.systemStatus.laneRateFb[topno]!=self.LMK.laneRate:
						self.LMK.lmkSelectCh(rxFbTx,topno)
					self.LMK.lmkSysrefEn(1)
					self.FPGA.resetQpllIpReset()
					self.FPGA.fpgaRxConfig(1,1,0,self.systemStatus.dutNo)
					self.adcDacSync()
					self.LMK.lmkSysrefEn(0)
			elif rxFbTx==0:
				if rxParams[2]!=programmedFpgaRxF or self.systemStatus.laneRateRx[topno]!=self.LMK.laneRate:	# If F is same and lane rates for RX and FB are same. In this case single link is sufficient to be established.
					if self.systemStatus.laneRateFb[topno]!=self.LMK.laneRate:
						self.LMK.lmkSelectCh(rxFbTx,topno)
					self.LMK.lmkSysrefEn(1)
					self.FPGA.resetQpllIpReset()
					self.FPGA.fpgaRxConfig(0,0,0,self.systemStatus.dutNo)
					self.adcDacSync()
					self.LMK.lmkSysrefEn(0)
					
		#if rxFbTx==0 and self.systemParams.ddcFactorRx[topno]==1:
		#	self.regs.JESD.ADC_TX[0].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=0
		#	self.regs.JESD.ADC_TX[1].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=0
		#elif rxFbTx==1 and self.systemParams.ddcFactorFb[topno]==1:
		#	self.regs.JESD.ADC_TX[0].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=1
		#	self.regs.JESD.ADC_TX[1].ADC_TX.JESD_TX_CONFIG51.fb_all_lanes=1
		#############################
		(LMFSHd,lanesToCapture,converterOrder)=self.getCaptureSettings(rxFbTx,chNo)
		if setupParams.boardType!="BENCH":
			self.LMK.lmkSysrefEn(1)
			if rxFbTx==2:
				self.FPGA.fpgaTxConfig(topno,self.systemStatus.dutNo)
				self.FPGA.selectDrive(LMFSHd,lanesToCapture,converterOrder,self.systemStatus.dutNo)
			else:
				self.FPGA.fpgaRxConfig(rxFbTx,topno,self.systemStatus.dutNo)
				self.FPGA.selectCapture(LMFSHd,lanesToCapture,converterOrder,self.systemStatus.dutNo)
			if rxFbTx==1 or len(lanesToCapture)==1:
				self.FPGA.regs.doReorder=0
			else:
				self.FPGA.regs.doReorder=1
			if self.systemParams.syncLoopBack==False:
				if rxFbTx==2:
					self.FPGA.fpgaTxSendK([True,True])
					self.FPGA.fpgaTxSendK([False,False])
					self.JESD.JESDRX[topno].getJesdAlarms(1)
				else:
					self.deviceRefs.broadcastEn=15
					self.JESDTX[0].toggleSync()
					self.deviceRefs.broadcastEn=0
			self.LMK.lmkSysrefEn(0)
		else:
			self.FPGA.selectCapture(LMFSHd,lanesToCapture,converterOrder,self.systemStatus.dutNo,byte_swap)
		
		self.deviceRefs.process.ADCRes=16
		if rxFbTx==0:
			if (self.systemParams.LMFSHdFb[0])=="22210" or (self.systemParams.LMFSHdFb[1])=="22210":
				self.deviceRefs.process.bitFunctions.DataReorder=0
			if self.systemParams.ddcFactorRx[topno]==1:
				self.deviceRefs.engine.DDCConfig=0
				self.deviceRefs.process.ADCRes=5
				self.deviceRefs.engine.DDCNCOFreqWord=(self.systemParams.pllLo[self.systemStatus.rxLoPllIndex[topno]]%self.systemParams.Fs)*(2.0**32)/self.systemParams.Fs
				self.deviceRefs.engine.DDCDecim=1#self.systemParams.ddcFactorRx[topno]
				self.deviceRefs.engine.clockFrequency=self.systemParams.Fs*1e6
				self.JESD.SUBCHIP.configureDataMux(chNo,0)
			else:
				self.deviceRefs.engine.DDCConfig=1
				self.deviceRefs.engine.DDCNCOFreqWord=(self.systemParams.pllLo[self.systemStatus.rxLoPllIndex[topno]]%self.systemParams.Fs)*(2.0**32)/self.systemParams.Fs
				self.deviceRefs.engine.DDCDecim=self.systemParams.ddcFactorRx[topno]
				self.deviceRefs.engine.clockFrequency=self.systemParams.Fs*1e6
				self.RX.RXDIG[topno].AGCDGC[channelInTop].setupProcess()
		elif rxFbTx==1:
			# if(len(LMFSHd)==5 and LMFSHd=="22210"):
				# self.deviceRefs.process.bitFunctions.Data1=1
				# self.deviceRefs.process.bitFunctions.Data2=3
				# self.deviceRefs.process.bitFunctions.DataReorder=1
			# else:
				# self.deviceRefs.process.bitFunctions.DataReorder=0
			if self.systemParams.ddcFactorFb[topno]==1:
				self.deviceRefs.engine.DDCConfig=0
				self.JESD.SUBCHIP.configureDataMux(0,chNo)
			else:
				self.deviceRefs.engine.DDCConfig=1
			self.deviceRefs.engine.DDCNCOFreqWord=(self.systemParams.fbNco[topno]%self.systemParams.Fs)*(2.0**32)/self.systemParams.Fs
			self.deviceRefs.engine.DDCDecim=self.systemParams.ddcFactorFb[topno]									# Configuring the Mux as per nyquist
			self.deviceRefs.engine.clockFrequency=self.systemParams.Fs*1e6
			self.deviceRefs.process.floatingPointCoarseGain.dgcEn=0
		self.deviceRefs.process.complexfftParam.snrFreqBandUpper=0.4*self.deviceRefs.engine.clockFrequency/self.deviceRefs.engine.DDCDecim
	#selectCh
	
	@funcDecorator
	def clearSysrefFlags(self):
		""" "Clearing Sysref Flags" "Done clearing Sysref Flags" """
		device=self.regs
		device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.JESD_ADC_TX=3
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_rx_root_clk_monitor_flag=1
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_rx_root_sysref_monitor_flag=1
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_fb_root_clk_monitor_flag=1
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_fb_root_sysref_monitor_flag=1
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_rx_root_clk_monitor_flag=0
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_rx_root_sysref_monitor_flag=0
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_fb_root_clk_monitor_flag=0
		device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1.clear_fb_root_sysref_monitor_flag=0
		device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.JESD_ADC_TX=0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_q=0xf
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5353_53Ch.Property5354_31_16=0xffff
		device.RX_ANA_Q[0].channel_digital_ch.channel_dig_q.Register5353_53Ch.Property5354_31_16=0
		device.MASTER.MASTER_PAGE.PAGE_SEL.RX_ANALOG.rx_ec_i=0xf
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10593_53Ch.Property10594_31_16=0xffff
		device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10593_53Ch.Property10594_31_16=0
		
		device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0xF
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43701_7_7=0
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43701_7_7=1
		device.TX.DAC_ANA[0].TX_PAGE.Register43694_50h.Property43701_7_7=0
		device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.DAC_ANA=0x0
		
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property952_3_3=0
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property952_3_3=1
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property952_3_3=0
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49053_3_3=0
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49053_3_3=1
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49053_3_3=0
					

		device.RX.ANA_AB.ANA_AB.Register8788_2Bh.Property8790_27_27=0
		device.RX.ANA_AB.ANA_AB.Register8788_2Bh.Property8790_27_27=1
		device.RX.ANA_AB.ANA_AB.Register8788_2Bh.Property8790_27_27=0
		
		device.RX.ANA_CD.ANA_CD.Register46345_2Bh.Property46347_27_27=0
		device.RX.ANA_CD.ANA_CD.Register46345_2Bh.Property46347_27_27=1
		device.RX.ANA_CD.ANA_CD.Register46345_2Bh.Property46347_27_27=0

		device.RX.ANA_AB.ANA_AB.Register8803_2Eh.Property8804_19_19=0
		device.RX.ANA_AB.ANA_AB.Register8803_2Eh.Property8804_19_19=1
		device.RX.ANA_AB.ANA_AB.Register8803_2Eh.Property8804_19_19=0
		
		device.RX.ANA_CD.ANA_CD.Register46360_2Eh.Property46361_19_19=0
		device.RX.ANA_CD.ANA_CD.Register46360_2Eh.Property46361_19_19=1
		device.RX.ANA_CD.ANA_CD.Register46360_2Eh.Property46361_19_19=0
		device.writeReg(0x118,0x07)
		device.writeReg(0x119,0x7F)
		device.writeReg(0x117,0x10)
		device.writeReg(0x116,0x00)
		device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.ADC_ANA_2R=0
	#clearSysrefFlags
	
	@funcDecorator
	def sysrefCheck(self,clearAlarms=0):
		""" "Checking Sysref Flags" "Done checking Sysref Flags" """
		device=self.regs
		if(clearAlarms==1):
			self.clearSysrefFlags()
		
		self.deviceRefs.device.logClassInst.overrideMask=0x3
		self.deviceRefs.device.expectedReadValue=3
		RxAnaSysRefAB=device.RX.ANA_AB.ANA_AB.Register8881_49h._Property8881_15_8.getValue()&0x03
		self.deviceRefs.device.logClassInst.overrideMask=0x3
		self.deviceRefs.device.expectedReadValue=3
		RxAnaSysRefCD=device.RX.ANA_CD.ANA_CD.Register46454_49h._Property46454_15_8.getValue()&0x03
		self.deviceRefs.device.logClassInst.overrideMask=0x8
		self.deviceRefs.device.expectedReadValue=1<<3
		FbAnaSysRefAB=(device.RX.ANA_AB.ANA_AB.Register8881_49h._Property8881_15_8.getValue()&0x08)>>3
		self.deviceRefs.device.logClassInst.overrideMask=0x8
		self.deviceRefs.device.expectedReadValue=1<<3
		FbAnaSysRefCD=(device.RX.ANA_CD.ANA_CD.Register46454_49h._Property46454_15_8.getValue()&0x08)>>3
		self.deviceRefs.device.logClassInst.overrideMask=0x7
		self.deviceRefs.device.expectedReadValue=7
		TxdacSysRefAB=device.TX.DAC_ANA_AB.DAC_ANA_AB.Register957_3Ch._Property957_7_0.getValue()
		self.deviceRefs.device.logClassInst.overrideMask=0x7
		self.deviceRefs.device.expectedReadValue=7
		TxdacSysRefCD=device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49072_3Ch._Property49072_7_0.getValue()
		self.deviceRefs.device.logClassInst.overrideMask=0x0
		
		self.deviceRefs.device.expectedReadValue=1
		clkToDig=device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1._rx_root_clk_monitor_flag.getValue()
		self.deviceRefs.device.expectedReadValue=1
		sysrefToDig=device.JESD.ADC_TX[0].ADC_TX.CLOCK_MONITOR_CONFIG1._rx_root_sysref_monitor_flag.getValue()
		self.deviceRefs.device.logClassInst.overrideMask=0x7
		self.deviceRefs.device.expectedReadValue=7
		anaSysref=device.RX_ANA_I[0].channel_digital_ch.channel_dig_i.Register10593_53Ch._Property10593_15_0.getValue()
		self.deviceRefs.device.logClassInst.overrideMask=0x0
		
		readFlags=(RxAnaSysRefAB,RxAnaSysRefCD,FbAnaSysRefAB,FbAnaSysRefCD,TxdacSysRefAB,TxdacSysRefCD,clkToDig,sysrefToDig,anaSysref)
		expectedFlagValues=(3,3,1,1,7,7,1,1,7)
		flagDesc=("Sysref to RX AB","Sysref to RX CD","Sysref to FB A","Sysref to FB D","Sysref to TX AB","Sysref to TX CD","Digital Clock","Sysref to Digital","Sysref to Analog")
		failCount=0
		for i in range(len(readFlags)):
			if expectedFlagValues[i]!=readFlags[i]:
				error(flagDesc[i]+", Read: "+str(readFlags[i])+"; expected: "+str(expectedFlagValues[i]))
				failCount+=1
			else:
				info(flagDesc[i]+", Read: "+str(readFlags[i])+"; expected: "+str(expectedFlagValues[i]))
		if failCount==0:
			info("Sysref Read as expected")
	#sysrefCheck
		
	@funcDecorator
	def adcDacSync(self,pinSysref=False):
		""" "Resynching JESD RX and JESD TX" "Done resynching JESD RX and JESD TX" """
 		if self.systemParams.syncLoopBack==False:
			self.FPGA.fpgaTxSendK([False]*2)
		self.LMK.lmkSysrefEn(1)
		
		self.deviceRefs.broadcastEn=15
		self.JESDRX[0].reSync()	
		self.JESDTX[0].reSync()
		self.deviceRefs.broadcastEn=0
		
		if setupParams.boardType=="EVM-1DeviceJ58" and setupParams.skipFpga==0:
			self.FPGA.regs.interfaceHandle.fpgaSysref(pinSysref)
			self.FPGA.regs.interfaceHandle.resetJesdRx()
			self.FPGA.regs.interfaceHandle.resetJesdTx()
			self.FPGA.regs.interfaceHandle.fpgaSysref(pinSysref)			
			self.FPGA.regs.interfaceHandle.fpgaSysrefCheck(self.systemParams.jesdProtocol)

		if pinSysref==False:
			self.TOP.leakSysrefRxTxDig(1,1,1)
		else:
			self.TOP.sendSysref(self.systemParams.useSpiSysref)
			
		if self.systemParams.syncLoopBack==False:
			self.deviceRefs.broadcastEn=15
			self.JESDTX[0].toggleSync()
			self.deviceRefs.broadcastEn=0
		if self.systemParams.syncLoopBack==False:
			self.FPGA.fpgaTxSendK([True]*2)
			self.FPGA.fpgaTxSendK([False]*2)
		self.LMK.lmkSysrefEn(0)
		
		for i in range(2):
			self.JESDRX[i].getJesdAlarms(1)
		
		try:
			self.FPGA.checkRxSync()
		except:
			pass
	#adcDacSync
	
	@funcDecorator
	def serdesWrite(self,chNo,address,data):
		self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=chNo
		super(afeLibrary,self).serdesWrite(address,data)
	#serdesWrite
	
	@funcDecorator
	def serdesRead(self,chNo,address):
		self.regs.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=chNo
		return super(afeLibrary,self).serdesRead(address)
	#serdesRead
	
	@funcDecorator
	def putAllAlarmsInReset(self):
		device=self.regs
		device.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG27.alarms_clear=511
		device.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22348_2DCh.Property22367_13_13=1
		device.JESD.DAC_RX[0].DAC_RX.TXDUC_REG400.clear_all_alarms=1
		device.JESD.ADC_TX[0].ADC_TX.TXDUC_REG45.serdes_fifo_err_clear=1
		self.TOP.requestPllSpiAccess(1)
		self.deviceRefs.broadcastEn=0x1f
		self.TOP.PLL[0].resetLockLost()
		self.deviceRefs.broadcastEn=0
		self.TOP.requestPllSpiAccess(0)
	#putAllAlarmsInReset
	
	@funcDecorator
	def clearAllAlarms(self):
		""" "Clearing All Alarms" "Done clearing All Alarms" """
		device=self.regs
		device.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG27.alarms_clear=511
		device.MASTER.MASTER_PAGE.GLOBAL_REGS.GLOBAL_REG27.alarms_clear=0
		device.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22348_2DCh.Property22367_13_13=1
		device.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22348_2DCh.Property22367_13_13=0
		self.deviceRefs.broadcastEn=15
		self.JESDRX[0].clearDataAlarms()
		self.JESDTX[0].clearDataAlarms()
		self.deviceRefs.broadcastEn=0
		self.TOP.requestPllSpiAccess(1)
		self.deviceRefs.broadcastEn=0x1f
		self.TOP.PLL[0].resetLockLost()
		self.deviceRefs.broadcastEn=0
		self.TOP.requestPllSpiAccess(0)
		device.TOP.TC_GPIO.digtop.Register41632_600h.pap_alarm_clear=0xf
		device.TOP.TC_GPIO.digtop.Register41632_600h.pap_alarm_clear=0
	#clearAllAlarms
	
	@funcDecorator
	def rxPointerCheck(self):
		device=self.regs
		no_of_iterations = 25
		for q in range (0,2):
			ptr_diff_avg=[0 for i in range (0,8)]
			##Change Async FIFO read pointer offset
			for k in range (0,8):
				device.RX.DIG_AB[q].RxDecSet.Register27017_100h.Property27027_2_0 = k
				#Privide sys_ref
				self.TOP.leakSysrefRxTxDig(1,1,1)#sendSysref(self.systemParams.useSpiSysref)
				
				ptr_diff_sum=0
				for i in range (0,no_of_iterations):
					#Write Sample FIFO pointer 0-->1
					device.RX.DIG_AB[q].RxDecSet.Register27068_A45h.Property27069_0_0=0
					device.RX.DIG_AB[q].RxDecSet.Register27068_A45h.Property27069_0_0=1
					device.RX.DIG_AB[q].RxDecSet.Register27068_A45h.Property27069_0_0=0
				
					#Read the pointers
					wr_ptr_value = device.RX.DIG_AB[q].RxDecSet.Register27075_A14h._DigInpAsyncFIFOWrPtrRx2.getValue()
					rd_ptr_value = device.RX.DIG_AB[q].RxDecSet.Register27075_A14h._DigInpAsyncFIFORdPtrP1.getValue()
	# 				info("write pointer value is " +str(wr_ptr_value)+" and read pointer value is "+str(rd_ptr_value))
					ptr_diff_pre = wr_ptr_value - rd_ptr_value
					if (ptr_diff_pre<0):
						ptr_diff = ptr_diff_pre+8
					else:
						ptr_diff = ptr_diff_pre
					ptr_diff_sum+=ptr_diff
	# 				info("The running pointer difference sum is" +str(ptr_diff_sum/(i+1)))
				
				ptr_diff_avg[k]=ptr_diff_sum/no_of_iterations/1
				info("For Rx Channel "+str(q)+" the async FIFO average pointer difference for Read Pointer Offset Value of "+str(k)+" is "+str(ptr_diff_avg[k]))
	#rxPointerCheck
	
	def txPointerCheck(self):
		device=self.regs
		no_of_iterations = 10
		for q in (0,):#range(0,2):
			ptr_diff_avg=[0 for i in range (0,8)]
			##Change Async FIFO read pointer offset
			for k in range (0,8):
				device.TX.DAC_DIG_AB[q].tx_top.RegTxInterpCfg5.RdPtrOffDigOutAsyncFIFO=k
				self.TOP.overrideTdd(0,0,0)
				self.TOP.overrideTdd(1,1,1)
				#Privide sys_ref
				self.TOP.leakSysrefRxTxDig(1,1,1)#sendSysref(self.systemParams.useSpiSysref)
				
				ptr_diff_sum=0
				for i in range (0,no_of_iterations):
					#Write Sample FIFO pointer 0-->1
					device.TX.DAC_DIG_AB[q].tx_top.Register50853_630h.Property50858_13_13=0
					device.TX.DAC_DIG_AB[q].tx_top.Register50853_630h.Property50858_13_13=1
					device.TX.DAC_DIG_AB[q].tx_top.Register50853_630h.Property50858_13_13=0
					
					#Read the pointers
					
					wr_ptr_value = (device.TX.DAC_DIG_AB[q].tx_top.Register50840_9A4h._Property50840_15_0.getValue()&0x0000E0000000)>>29
					rd_ptr_value = (device.TX.DAC_DIG_AB[q].tx_top.Register50842_9ACh._Property50842_15_0.getValue()&0x0000E0000000)>>29
	# 				info("write pointer value is " +str(wr_ptr_value)+" and read pointer value is "+str(rd_ptr_value))
					ptr_diff_pre = wr_ptr_value - rd_ptr_value
					if (ptr_diff_pre<0):
						ptr_diff = ptr_diff_pre+8
					else:
						ptr_diff = ptr_diff_pre
					ptr_diff_sum+=ptr_diff
	# 				info( str(ptr_diff_sum)+"   "+str(ptr_diff))
	# 				info("The running pointer difference sum is" +str(ptr_diff_sum/(i+1)))
				
				ptr_diff_avg[k]=ptr_diff_sum/no_of_iterations/1.
				info("For tx Channel "+str(q)+" the async FIFO average pointer difference for Read Pointer Offset Value of "+str(k)+" is "+str(ptr_diff_avg[k]))
	#txPointerCheck

	def fbPointerCheck(self):
		device=self.regs
		no_of_iterations = 25
		for q in range (0,2):
			ptr_diff_avg=[0 for i in range (0,8)]
			##Change Async FIFO read pointer offset
			for k in range (0,8):
				device.FB[q].FB_DIG.FB_DIG.FBDigCfg4.FBAsyncFIFORdPtrVal = k
				#Privide sys_ref
				self.TOP.leakSysrefRxTxDig(1,1,1)#sendSysref(self.systemParams.useSpiSysref)
				ptr_diff_sum=0
				for i in range (0,no_of_iterations):
					#Write Sample FIFO pointer 0-->1
					device.FB[q].FB_DIG.FB_DIG.FBDigCfg9.DigInpAsyncFIFOSamplePtr=0
					device.FB[q].FB_DIG.FB_DIG.FBDigCfg9.DigInpAsyncFIFOSamplePtr=1
					device.FB[q].FB_DIG.FB_DIG.FBDigCfg9.DigInpAsyncFIFOSamplePtr=0
				
					#Read the pointers
					wr_ptr_value = device.FB[q].FB_DIG.FB_DIG.FBDigCfg8.DigInpAsyncFIFOSamplerWrPtrP0
					rd_ptr_value = device.FB[q].FB_DIG.FB_DIG.FBDigCfg8.DigInpAsyncFIFOSamplerRdPtrP0
					#info("write pointer value is " +str(wr_ptr_value))
					ptr_diff_pre = wr_ptr_value - rd_ptr_value
					if (ptr_diff_pre<0):
						ptr_diff = ptr_diff_pre+8
					else:
						ptr_diff = ptr_diff_pre
					ptr_diff_sum+=ptr_diff
					#info(ptr_diff_sum/(i+1))
				
				ptr_diff_avg[k]=ptr_diff_sum/no_of_iterations
				info("For FB Channel "+str(q)+" the async FIFO average pointer difference for Read Pointer Offset Value of "+str(k)+" is "+str(ptr_diff_avg[k]))
		#fbPointerCheck
	
	@funcDecorator
	def setSigGenTone(self,enable,freq,amp):	
		device=self.regs
		if enable==False:
			device.TOP.INTERNAL_MACRO.STREAMING.Register22233_110h.Property22233_3_0	=	0
			return
		# Switch Tx Input Mux for Siggen Data  : 15 - Siggen Data ;  0 - JESD Data
		device.TOP.INTERNAL_MACRO.STREAMING.Register22233_110h.Property22233_3_0	=	15

		# Control for Power
		Siggen_Power = int(round(16*10**(amp/20.)))									# If this val is 12 it means "20*np.log10(12/16.0) = -2.5 dBFS"   
															# 16*10**(-13.0/20)
		# Control for Frequency
		Siggen_Freq_MHz = freq#3.84*16
		Interface_Rate = 8				 # 8*62.5 = 491.52 MHz
					
					
					

		# Control for Tone Power
		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22103_11_10		=	3	 			# For I and Q Data
		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22102_22_17		=	Siggen_Power	# Tone Power = 20*np.log10(RegVal/16.0) dBFS

		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22215_13_12		=	3
		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22213_5_0		=	Siggen_Power

		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22222_20_19		=	3
		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22221_22_17		=	Siggen_Power

		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22229_27_26		=	3
		device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22228_22_17		=	Siggen_Power


		Freq_1_Bin_MHz = Interface_Rate * self.systemParams.X / (128)
		Freq_Bin = (Siggen_Freq_MHz)/(Freq_1_Bin_MHz)


		if (Freq_Bin <= 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22101_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22097_15_0	=	round(abs(Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22101_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22101_16_16		=	1
		elif(Freq_Bin > 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22101_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22097_15_0	=	round(65536 - (Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22101_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22101_16_16		=	1

		if (Freq_Bin <= 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22207_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22108_15_0	=	round(abs(Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22207_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22207_16_16		=	1
		elif(Freq_Bin > 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22207_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22108_15_0	=	round(65536 - (Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22207_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22207_16_16		=	1


		if (Freq_Bin <= 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22220_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22216_15_0	=	round(abs(Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22220_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22220_16_16		=	1
		elif(Freq_Bin > 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22220_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22216_15_0	=	round(65536 - (Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22220_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22220_16_16		=	1


		if (Freq_Bin <= 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22227_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22223_15_0	=	round(abs(Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22227_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22227_16_16		=	1
		elif(Freq_Bin > 0):
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22227_16_16		=	1
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22223_15_0	=	round(65536 - (Freq_Bin) * 512)
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22227_16_16		=	0
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22227_16_16		=	1

	#setSigGenTone
	
	
	@funcDecorator
	def anaWritesForTddMode2T2R(self):
		""" "Doing Writes to support AB and CD independent TDD" "Completed writes to support AB and CD independent TDD" """
		device=self.regs
		en=1
		en_mask_top=en
		en_mask_2t=en
		en_mask_t=en
		if self.systemParams.mode2t2r in (1,2):
			for i in range(2):
				device.RX_ANA_Q[i].PDN_2R.PDN_2R.Register6493_F05h.Property6493_8_8=en
				device.RX_ANA_Q[i].PDN_2R.PDN_2R.Register6493_F05h.Property6615_10_10=en
				device.RX_ANA_Q[i].PDN_MATRIX.PDN_MATRIX_FE.Register2656_C75h.Property2656_8_8=en
				device.RX_ANA_Q[i].PDN_MATRIX.PDN_MATRIX_FE.Register2656_C75h.Property2658_9_9=en
				device.RX_ANA_Q[i].PDN_MATRIX.PDN_MATRIX_FE.Register2656_C75h.Property2663_15_15=en
				device.TX.DAC_ANA[i].TX_PAGE.Register43694_50h.Property43718_29_29=1*en_mask_t
				device.TX.DAC_ANA[i].TX_PAGE.Register43724_60h.Property43751_8_8=1*en_mask_t
				device.TX.DAC_ANA[i].TX_PAGE.Register43694_50h.Property43696_2_2=1*en_mask_t			
				device.RX_ANA_I[i].PDN_MATRIX.PDN_MATRIX_FE.Register9163_C73h.Property13961_31_31=en
			
		if self.systemParams.mode2t2r in (1,3):
			for i in range(2):
				device.RX_ANA_Q[2+i].PDN_2R.PDN_2R.Register6493_F05h.Property6493_8_8=en
				device.RX_ANA_Q[2+i].PDN_2R.PDN_2R.Register6493_F05h.Property6615_10_10=en
				device.RX_ANA_Q[2+i].PDN_MATRIX.PDN_MATRIX_FE.Register2656_C75h.Property2656_8_8=en
				device.RX_ANA_Q[2+i].PDN_MATRIX.PDN_MATRIX_FE.Register2656_C75h.Property2658_9_9=en
				device.RX_ANA_Q[2+i].PDN_MATRIX.PDN_MATRIX_FE.Register2656_C75h.Property2663_15_15=en
				device.TX.DAC_ANA[2+i].TX_PAGE.Register43694_50h.Property43718_29_29=1*en_mask_t
				device.TX.DAC_ANA[2+i].TX_PAGE.Register43724_60h.Property43751_8_8=1*en_mask_t
				device.TX.DAC_ANA[2+i].TX_PAGE.Register43694_50h.Property43696_2_2=1*en_mask_t			
				device.RX_ANA_I[2+i].PDN_MATRIX.PDN_MATRIX_FE.Register9163_C73h.Property13961_31_31=en
			
		
		#RX CML buffers_30mA
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2281_29_29=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2282_28_28=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2283_27_27=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2284_26_26=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2285_25_25=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2280_6Bh.Property2286_24_24=en

		#TX CML buffers_50mA
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2289_5_5=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2290_4_4=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2291_3_3=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2292_2_2=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2293_1_1=en
		device.TOP.CLK_AB.ctl_2t_clktop_config.Register2288_6Ch.Property2294_0_0=en

		if self.systemParams.mode2t2r in (1,2):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2311_6Fh.Property2313_28_28=en
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2311_6Fh.Property2315_26_26=en
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2311_6Fh.Property2317_24_24=en
		if self.systemParams.mode2t2r in (1,3):
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2311_6Fh.Property2312_29_29=en
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2311_6Fh.Property2314_27_27=en
			device.TOP.CLK_AB.ctl_2t_clktop_config.Register2311_6Fh.Property2316_25_25=en
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49033_19_19=1*en_mask_2t
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property932_19_19=1*en_mask_2t
		device.TX.DAC_ANA_CD.DAC_ANA_CD.Register49014_28h.Property49036_22_22=1*en_mask_2t
		device.TX.DAC_ANA_AB.DAC_ANA_AB.Register913_28h.Property935_22_22=1*en_mask_2t
		#device.TOP.TIMING_CTRL.TG_TOP.Register44377_4C4h.Property44381_25_16=0xc   #Default: 0x3ff (2 bits for each PLL, 10 bits total)
	#anaWritesForTddMode2T2R
	
	@funcDecorator
	def freezeTxQec(self):
		""" "Freeze TX IQMC/LO" "Done Freeze TX IQMC/LO" """
	# 	self.regs.TOP.TIMING_CTRL.TDD_CONTROLLER.Register44488_554h.Property44506_11_8 =4   
		self.regs.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0xff06
		self.regs.TOP.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = 0x35000000
		self.delay(0.02)

	@funcDecorator
	def unFreezeTxQec(self):
		""" "Unfreeze TX IQMC/LO" "Done Unfreeze TX IQMC/LO" """
		self.regs.TOP.MACRO.FW_REGS.SPI_WR_CM4_REFLECT.spi_wr_cm4_rf0 = 0xff07
		self.regs.TOP.MACRO.SYS_CTRL_CUST.Control_Registers.macro_opcode_operand = 0x35000000
		# self.delay(0.02)

	@funcDecorator
	def freezeRxQec(self):
		""" "Freeze RX IQMC/LO" "Done Freeze RX IQMC/LO" """
		self.TOP.overrideTdd(1,0,0)
		self.delay(0.0001)
		chs=[1,1,1,1]
		opCode = 17
		mask = (chs[0]) | (chs[1] << 1) | (chs[2] << 2) | (chs[3] << 3)

		controlWord = (mask << 16)
		self.regs.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord

		controlWord = (opCode << 24) + (mask << 16)
		self.regs.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord

		self.delay(0.02)
		self.regs.RX.RXIQMC.rx_iqmc.Register49141_A0h.Property49155_0_0=0
		self.regs.RX.RXIQMC.rx_iqmc.Register49141_A0h.Property49157_8_8=0
		self.regs.RX.RXIQMC.rx_iqmc.Register49077_20h.Property49079_0_0=0
	# 	self.regs.RX.RXIQMC.rx_iqmc.Register49195_100h.Property49201_8_8=1
		self.regs.RX.RXIQMC.rx_iqmc.Register49077_20h.Property49089_0_0=1
		# self.delay(0.02)
		self.regs.RX.DIG_AB[0].RxDecSet.Register27131_A04h.op_clk_en_iqmc_clk_gen=0
		self.regs.RX.DIG_AB[1].RxDecSet.Register27131_A04h.op_clk_en_iqmc_clk_gen=0

	@funcDecorator
	def resetRxIqmc(self):
	# 	for channel in range(0,4):
	# 		for i in range(0,17):
	# 			exec("self.regs.RX.DIG_AB["+str(int(channel/2.0))+"].RxDecSet.RxIQMCCorrector"+str(int(channel%2.0))+".coef_reg_iq_"+str(i)+"=0")
	# 			exec("self.regs.RX.DIG_AB["+str(int(channel/2.0))+"].RxDecSet.RxIQMCCorrector"+str(int(channel%2.0))+".coef_reg_qq_"+str(i)+"=0")	
		chs=[1,1,1,1]
		opCode = 23
		mask = (chs[0]) | (chs[1] << 1) | (chs[2] << 2) | (chs[3] << 3)
		
		#Two writes needed for avoiding command trigger before operand write
		controlWord = (mask << 16)
		self.regs.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord	

		controlWord = (opCode << 24) + (mask << 16)
		self.regs.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord	

	@funcDecorator
	def unFreezeRxQec(self):
		""" "Unfreeze RX IQMC/LO" "Done Unfreeze RX IQMC/LO" """
		self.TOP.overrideTdd(1,0,0)
		self.delay(0.0001)
		chs=[1,1,1,1]
		self.regs.RX.DIG_AB[0].RxDecSet.Register27131_A04h.op_clk_en_iqmc_clk_gen=1
		self.regs.RX.DIG_AB[1].RxDecSet.Register27131_A04h.op_clk_en_iqmc_clk_gen=1
		self.resetRxIqmc()
		opCode = 18
		mask = (chs[0]) | (chs[1] << 1) | (chs[2] << 2) | (chs[3] << 3)

		controlWord = (mask << 16)
		self.regs.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord

		controlWord = (opCode << 24) + (mask << 16)
		self.regs.TOP.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord
	
	@funcDecorator
	def relinkJesd(self):
		"""	"Doing Link up Sequence" "Completed Link up Sequence" """
		# self.deviceRefs.device.printCommentToLog("Start of Link up Sequence")
		tddStatus=self.TOP.getTddStatus()
		self.freezeRxQec()
		self.freezeTxQec()
		
		self.closePageAndNewStep('jesdLinkUpInit')
		self.deviceRefs.broadcastEn=15
		self.JESD.JESDTX[0].clearInitStates()
		self.JESD.JESDRX[0].clearInitStates()
		self.deviceRefs.broadcastEn=0
		
		if (self.skipRxConfig==0 or self.skipFbConfig==0) and self.systemParams.jesdProtocol!=1 and setupParams.boardType not in ("EVM-1Device",):
			if setupParams.boardType=="BENCH":
				self.FPGA.fpgaRxConfig(0,0,0,self.systemStatus.dutNo)
			else:
				self.FPGA.fpgaRxConfig(0,0,self.systemStatus.dutNo)

		if self.systemParams.jesdProtocol==1 and 0 in [self.skipRxConfig, self.skipFbConfig, self.skipTxConfig] and setupParams.boardType=="BENCH":
			self.FPGA.fpgaHConfig()
			if self.systemParams.syncLoopBack==False:
				self.FPGA.fpgaTxSendK([False]*2)
		
		if setupParams.boardType not in ("BENCH","EVM-1Device"):
			self.FPGA.setLanePolarities()
		
		self.closePageAndNewStep('jesdLinkUpInit')
		self.clearSysrefFlags()
		self.closePageAndNewStep('jesdLinkUpInit')
		self.TOP.sendSysref(self.systemParams.useSpiSysref)
		self.TOP.staggeredTddToggle()
		self.closePageAndNewStep('jesdLinkUpInit')
		self.sysrefCheck(0)
		self.closePageAndNewStep('jesdLinkUpInit')
		# self.deviceRefs.broadcastEn=15
		# self.JESD.JESDTX[0].clearDataAlarms()
		# self.JESD.JESDRX[0].clearDataAlarms()
		# self.deviceRefs.broadcastEn=0
		
			
		if setupParams.skipFpga==0:
			if setupParams.boardType=="BENCH":
				if self.skipRxConfig==0 or self.skipFbConfig==0:
					if self.systemParams.syncLoopBack==False:
						self.deviceRefs.broadcastEn=15
						self.JESD.JESDTX[0].toggleSync()
						self.deviceRefs.broadcastEn=0
					#self.FPGA.checkRxSync()
				if self.skipTxConfig==0:
					if self.systemParams.syncLoopBack==False:
						self.FPGA.fpgaTxSendK([True]*2)
						self.FPGA.fpgaTxSendK([False]*2)
					#for i in range(2):
					#	self.JESD.JESDRX[i].getJesdAlarms(1)
			else:
				self.selectCh(2,0)
				self.selectCh(2,2)
				self.selectCh(0,0)
			try:
				self.FPGA.checkRxSync()
			except:
				pass
			
		self.closePageAndNewStep('dacJesdLinkUp')
		for i in range(2):
			if(self.systemParams.enableJesdRxLanesOfCredo[i]==True or self.systemParams.customerConfig==False): # changed on 27/10/2020
				self.JESD.JESDRX[i].getJesdAlarms(1)
		self.deviceRefs.broadcastEn=0
		
		self.closePageAndNewStep('dacJesdLinkUp')
		self.JESD.SERDES[0].postLinkupSerdesWrites()
		self.JESD.SERDES[1].postLinkupSerdesWrites()

		self.unFreezeTxQec()
		self.unFreezeRxQec()
		self.TOP.setTddStatus(tddStatus)
		self.clearAllAlarms()
		self.regs.currentPageSelected.setValue(0)
		#relinkJesd

	@funcDecorator
	def loadRawConfigFile(self,fileName,doPostInit=1,breakAtPollFail=1,breakAtReadCheckFail=1):
		
		#### Note that this will run only the device config. Ensure the following:
		#			1. All the writes are only of the AFE device.
		#			2. Run the basicBringupFunc file first with the exact configuration to do the LMK and FPGA settings. Then do the required selectCh.
		#			3. If the script is of external sysref, make sure external SYSREF works on your board.
		#			4. Note that the polarity of the lanes can be different between the EVM and the config. So, all the lanes may not sync.
		#			5. If all the settings are fine, just run the config and you should be able to capture.
		#			6. If you do any MACRO function after this config load, it MAY NOT WORK. For using MACROs, use only the basicBringupFunc.
		oldFormat=True
		adcregProg=self.deviceRefs.device.regProgDevice
		device=self.deviceRefs.device
		def runFile(fileName):
			configFile=open(fileName,'r')
			lines=configFile.readlines()
			delimiter='	'
			#device.gui.reset()
			startAddress=0
			dataArray=[]
			cnt=0
			skipFirmware=False
			for line in lines:
				if "Done loading Serdes Firmware" in line:
					skipFirmware=False
				elif "Loading Serdes Firmware" in line:
					skipFirmware=True
				if skipFirmware==True:
					continue
				cnt+=1
				if cnt%1000==0:
					adcregProg._controller.instrument.purge()
				line=line.strip()
				if "SPIWrite " == line[:len("SPIWrite ")] or "SPIRMW "== line[:len("SPIRMW ")]:
					line=line.replace('SPIWrite ','')
					line=line.replace('SPIRMW ','')
					if '//' in line:
						comment=line[line.find('//'):]
						line=line[:line.find('//')].strip()
					else:
						comment=""
					command=line.split(',')
					address=int(command[0],16)
					data=int(command[1],16)
					if len(command)<4:
						lsb=0
						msb=7
					else:
						lsb=int(command[2])
						msb=int(command[3])
					if not(lsb==0 and msb==7):
						mask=((1<<(msb-lsb+1))-1)<<msb
						data=(device.readReg(address) & (0xff ^ mask)) | (data & mask)
					device.writeReg(address,data)
				elif line[:5]==r"WAIT ":
					if "//" in line:
						line=line[:line.find("//")]
					delay(float(line[5:]))
				elif "SPIPoll " == line[:len("SPIPoll ")] and oldFormat==True:
					if "//" in line:
						comment=line[line.find("//"):]
						line=line[:line.find("//")]
					command=line[8:].split(',')
					address=int(command[0],16)
					lsb=int(command[1],16)
					msb=int(command[2],16)
					mask=((1<<(msb-lsb+1))-1)
					expectedValue=int(command[3],16)
					for i in range(50):
						if (device.readReg(address)>>lsb)&mask==expectedValue:
							break
						delay(0.002)
					if i==49:
						error("POLL FAIL: "+line+"; Expected: "+hex(expectedValue)+"; Read: "+hex(device.readReg(address)))
						if breakAtPollFail:
							raise
				elif "SPIPoll " == line[:len("SPIPoll ")] and oldFormat==False:
					if "//" in line:
						comment=line[line.find("//"):]
						line=line[:line.find("//")]
					command=line[8:].split(',')
					address=int(command[0],16)
					lsb=int(command[1],16)
					msb=int(command[2],16)
					mask=((1<<(msb-lsb+1))-1)<<lsb
					expectedValue=int(command[3],16)
					for i in range(50):
						if device.readReg(address)&mask==expectedValue:
							break
						delay(0.002)
					if i==49:
						error("POLL FAIL: "+line+"; Expected: "+hex(expectedValue)+"; Read: "+hex(device.readReg(address)))
						if breakAtPollFail:
							raise
				elif "SPIReadCheck " == line[:len("SPIReadCheck ")]:
					if "//" in line:
						comment=line[line.find("//"):]
						line=line[:line.find("//")]
					command=line[len("SPIReadCheck "):].split(',')
					address=int(command[0],16)
					lsb=int(command[1],16)
					msb=int(command[2],16)
					mask=((1<<(msb-lsb+1))-1)<<lsb
					expectedValue=int(command[3],16)
					if device.readReg(address)&mask!=expectedValue:
						error("Read Check FAIL: "+line+"; Expected: "+hex(expectedValue)+"; Read: "+hex(device.readReg(address)))
						if breakAtReadCheckFail:
							raise
				elif "SPIBurstWrite " == line[:len("SPIBurstWrite ")]:
					if "//" in line:
						comment=line[line.find("//"):]
						line=line[:line.find("//")]
					command=line[len("SPIBurstWrite "):].replace("[","").replace("]","").split(',')
					address=int(command[0],16)
					if 1:
						writeValues=[]
						for writeNo in range(1,len(command)):
							writeValues.append(int(command[writeNo],16))
						device.regProgDevice.burstWrite(address,writeValues)
						delay(0.1)
					else:
						for writeNo in range(1,len(command)):
							device.writeReg(address+writeNo-1,int(command[writeNo],16))
							delay(0.001)
					
				elif "//External-Action: Give Sysref" == line[:len("//External-Action: Give Sysref")]:
					info("Sysref given")
					self.LMK.lmkSysrefEn(1)
					self.LMK.lmkSysrefEn(0)
				elif r"STEP:" in line:
					info(line)
			configFile.close()
			for i in range(0x10,0x19):
				device.writeReg(i,0)
		device.currentPageSelected.setValue(0)
		for i in range(0x10,0x19):
			device.writeReg(i,0)
		runFile(fileName)
		device.hardReadAlways=1
		if doPostInit:
			self.LMK.lmkSysrefEn(1)
			self.TOP.overrideTdd(1,1,1)
			self.clearSysrefFlags()
			self.TOP.sendSysref(1)
			self.sysrefCheck(0)
			self.adcDacSync()	
	#loadRawConfigFile

#afeLibrary