from globalDefs import *
from mFuncDecorator import *
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus

class HWAccess(object):

	def updateDeviceRefsInHwAccessClass(self,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.deviceRefs.device=deviceRefs.device
	#updateDeviceRefsInHwAccessClass

	@funcDecorator
	def delay(self,secs):
		
		self.deviceRefs.device.printCommentToLog("WAIT "+str(secs))
		if self.systemParams.simulationMode==False:
			delay(secs)
	#delay
	
	### module to set base address of HW memory access
	@funcDecorator
	def writeReg(self,addr,val):
		self.deviceRefs.device.writeReg(addr,val)
	#writeReg
	
	@funcDecorator
	def readReg(self,addr):
		return self.deviceRefs.device.readReg(addr)
	#readReg
	
	@funcDecorator
	def serdesFirmwareWrite(self,addr,data,msb=15,lsb=0):
		if self.systemStatus.chipVersion!=0:
			addr=addr+0x2000
			offset=0x2000
		else:
			offset=0		
		self.serdesWrite(0x9816+offset,((addr&0xFF)<<8)+(msb<<4)+lsb)
		self.serdesWrite(0x9812+offset,data)
		self.serdesWrite(0x9815+offset,0xc020)

		count=0
		controlWord=self.serdesRead(0x9815+offset)
		while controlWord&0Xff!=0 and count<50:
			controlWord=self.serdesRead(0x9815+offset)
			self.delay(0.1)
			count+=1	
	#serdesFirmwareWrite
		
	@funcDecorator
	def serdesFirmwareRead(self,addr,msb=15,lsb=0):
		if self.systemStatus.chipVersion!=0:
			addr=addr+0x2000
			offset=0x2000
		else:
			offset=0
		self.serdesWrite(0x9816+offset,((addr&0xFF)<<8)+(msb<<4)+lsb)
		self.serdesWrite(0x9815+offset,0xc010)

		controlWord=self.serdesRead(0x9815+offset)
		while controlWord0!=0 and count<50:
			controlWord=self.serdesRead(0x9815+offset)
			self.delay(0.1)
			count+=1
		data=self.serdesRead(0x9812+offset)
		return data
		
	@funcDecorator
	def serdesWrite(self,address,data):
		if self.systemStatus.chipVersion!=0:
			address=address+0x2000
		if self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES==0:
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1
			#raise
		self.deviceRefs.device.writeReg((address*2+1)&0x7fff,data>>8)
		self.deviceRefs.device.writeReg((address*2)&0x7fff,data&0xFF)
		
	@funcDecorator
	def serdesRead(self,address):
		if self.systemStatus.chipVersion!=0:
			address=address+0x2000
		if self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES==0:
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1
			#raise
		data2=self.deviceRefs.device.readReg(address*2+1)&0x7fff
		data2=self.deviceRefs.device.readReg(address*2+1)&0x7fff
		data1=self.deviceRefs.device.readReg(address*2)&0x7fff
		data1=self.deviceRefs.device.readReg(address*2)&0x7fff
		return (data1+(data2<<8))


	### module to set base address of HW memory access
	def writeMem32(self,regAddress,regValue,debugInfoFlag=0):
		if(debugInfoFlag == 1):
			info("Inside writeMem32");
			info("Register Address : 0x%8x"%(regAddress));
			info("Register Value : 0x%8x"%(regValue));	
		self.writeMem8(regAddress,((regValue&0x000000FF)>>0))
		self.writeMem8(regAddress+1,((regValue&0x0000FF00)>>8))
		self.writeMem8(regAddress+2,((regValue&0x00FF0000)>>16))
		self.writeMem8(regAddress+3,((regValue&0xFF000000)>>24))
			
	def writeMem8(self,regAddress,regValue,debugInfoFlag=0):
		if(debugInfoFlag == 1):
			info("Inside writeMem8");
			info("Register Address : 0x%8x"%(regAddress));
			info("Register Value : 0x%8x"%(regValue));	
		offset = regAddress & 0xFFFF	
		device=self.deviceRefs.device
		if((regAddress>>16) == (MemConst.RX_IQMC_AGGRAGATOR_START_ADDRESS>>16)):	
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_memories=1
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc=0x4
		elif ((regAddress>>16) == (MemConst.RX_IQMC_PRAM_START_ADDRESS>>16)):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_pram=1
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc=0x2
		elif ((regAddress>>16) == (MemConst.RX_IQMC_DRAM_START_ADDRESS>>16)):
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc=0x1
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_dram=1
		elif ((regAddress>>16) == (MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS>>16)):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_memories=1
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc=0x4
		elif ((regAddress>>16) == (MemConst.TX_IQMC_PRAM_START_ADDRESS>>16)):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_pram=1
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc=0x2
		elif ((regAddress>>16) == (MemConst.TX_IQMC_DRAM_START_ADDRESS>>16)):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_dram=1
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc=0x1
		device.writeReg(offset,regValue)
		
	def readMem32(self,regAddress,debugInfoFlag=0):
		if(debugInfoFlag == 1):
			info("Inside readMem32");
			info("Register Address : 0x%8x"%(regAddress));
		rdVal1=self.readMem8(regAddress)
		rdVal2=self.readMem8(regAddress+1)
		rdVal3=self.readMem8(regAddress+2)
		rdVal4=self.readMem8(regAddress+3)
		rdVal = rdVal1<<0 | rdVal2<<8 |rdVal3<<16 |rdVal4<<24 
		return(rdVal)
		
	def readMem16(self,regAddress,debugInfoFlag=0):
		if(debugInfoFlag == 1):
			info("Inside readMem32");
			info("Register Address : 0x%8x"%(regAddress));
		rdVal1=self.readMem8(regAddress)
		rdVal2=self.readMem8(regAddress+1)
		rdVal = rdVal1<<0 | rdVal2<<8
		return(rdVal)
			
	def readMem8(self,regAddress,debugInfoFlag=0):
		if(debugInfoFlag == 1):
			info("Inside readMem8");
		
		offset = regAddress & 0xFFFF	
		device=self.deviceRefs.device
		if((regAddress>>16) == (MemConst.RX_IQMC_AGGRAGATOR_START_ADDRESS>>16)):		
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc=0x4
			#info("Inside RX_IQMC_AGGRAGATOR_START_ADDRESS");
			#info("rx_iqmc_memories="+str(1))
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_memories=1
		elif ((regAddress>>16) == (MemConst.RX_IQMC_PRAM_START_ADDRESS>>16)):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_pram=1
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc=0x2
			#info("Inside RX_IQMC_PRAM_START_ADDRESS");
		elif ((regAddress>>16) == (MemConst.RX_IQMC_DRAM_START_ADDRESS>>16)):
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc=0x1
			#info("Inside RX_IQMC_DRAM_START_ADDRESS");
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_dram=1
		elif ((regAddress>>16) == (MemConst.TX_IQMC_AGGRAGATOR_START_ADDRESS>>16)):
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc=0x4
			#info("Inside TX_IQMC_AGGRAGATOR_START_ADDRESS");
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_memories=1
		elif ((regAddress>>16) == (MemConst.TX_IQMC_PRAM_START_ADDRESS>>16)):
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc=0x2
			#info("Inside TX_IQMC_PRAM_START_ADDRESS");
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_pram=1
		elif ((regAddress>>16) == (MemConst.TX_IQMC_DRAM_START_ADDRESS>>16)):
			#device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc=0x1
			#info("Inside TX_IQMC_DRAM_START_ADDRESS");
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_dram=1
		regVal= device.readReg(offset)
		#info("Register Address : 0x%8x"%(regAddress));
		#info("Register offset : 0x%8x"%(offset));
		#info("Register regVal : 0x%8x"%(regVal));
		return(regVal)

	def memPageSel(self, page, addr_high):
		device = self.deviceRefs.device
		if(page == 'txiqmcDram'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41732_2_0 = addr_high;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_dram = 1;
		elif(page == 'txiqmcPram'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41732_2_0 = addr_high;
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41728_1_0 = 3;
			device.TOP.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_ram_sel = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_pram = 1;
		elif(page == 'txiqmcProm'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41732_2_0 = addr_high;
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41728_1_0 = 3;
			device.TOP.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_ram_sel = 0;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_pram = 1;
		elif(page == 'txiqmcPatchRam'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41732_2_0 = 4;
			device.TOP.TC_GPIO.digtop.Register41632_600h.Property41728_1_0 = 3;
			device.TOP.TC_GPIO.digtop.Register41632_600h.txiqmc_cm4_ram_sel = 0;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_pram = 1;
		elif(page == 'txiqmcMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.tx_iqmc_memories = 1;
		elif(page == 'rxiqmcDram'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_mem_addr_high = addr_high;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_dram = 1;
		elif(page == 'rxiqmcPram'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_mem_addr_high = addr_high;
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_spi_sel = 3;
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_ram_sel = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_pram = 1;
		elif(page == 'rxiqmcProm'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_mem_addr_high = addr_high;
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_spi_sel = 3;
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_ram_sel = 0;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_pram = 1;
		elif(page == 'rxiqmcPatchRam'):
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_mem_addr_high = 4;
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_spi_sel = 3;
			device.TOP.TC_GPIO.digtop.Register41632_600h.rxiqmc_cm4_ram_sel = 0;
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_pram = 1;
		elif(page == 'rxiqmcMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.IQMC.rx_iqmc_memories = 1;
		elif(page == 'macroMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.sys_calib_macro_memory = 1;
		elif(page == 'top2TxMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.mailbox_top2tx = 1;
		elif(page == 'tx2TopMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.mailbox_tx2top = 1;
		elif(page == 'top2RxMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.mailbox_top2rx = 1;
		elif(page == 'rx2TopMem'):
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.mailbox_rx2top = 1;
		elif(page == 'topCm4Dram'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 0;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_dram = 1;
		elif(page == 'topCm4Pram'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.ss_reset_reg = 0;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.spi_sel = 1;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel=1;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_prom = 1;
		elif(page == 'topCm4Prom'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.spi_sel = 1;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel=0;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_prom = 1;
		elif(page == 'topCm4PatchRam'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.cm4_ram_sel=0;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=6;
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.spi_sel = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.cm4top_prom = 1;
		elif(page == 'calibRxMem'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22023_4_4 = 1;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22024_5_5 = 0;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22025_6_6 = 0;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22026_7_7 = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.calib_memory = 1;
		elif(page == 'calibFbMem'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22023_4_4 = 0;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22024_5_5 = 1;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22025_6_6 = 0;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22026_7_7 = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.calib_memory = 1;
		elif(page == 'calibResultsMem'):
			device.TOP.MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22023_4_4 = 0;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22024_5_5 = 0;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22025_6_6 = 1;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register21955_9Ch.Property21970_6_6 = 	1;
			device.TOP.INTERNAL_MACRO.CALIB_TOP.Register22019_108h.Property22026_7_7 = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.calib_memory = 1;
		elif(page == 'txSigGenMem'):
			device.SYS_CALIB_TOP.CUSTOME3R_MACRO.FW_REGS.CM4_CONTROL.all_addr_high=addr_high;
			device.TOP.INTERNAL_MACRO.STREAMING.Register22210_13Fh.Property22212_31_31 = 1;
			device.TOP.INTERNAL_MACRO.STREAMING.LUT.LUTEnable = 1;
			device.TOP.INTERNAL_MACRO.STREAMING.Register22097_11Ch.Property22208_28_28 = 1;
			device.MASTER.MASTER_PAGE.PAGE_SEL.SYS_CALIB_TOP.tx_sig_gen_memory = 1;
		else:
			error("memory type not foud");
	#memPageSel

	def memAddrGen(self,page,addr):
		if(addr<0x7fe0):
			addr_high = 0;
			addr = addr + 0x20;
		elif(addr>=0x7fe0 and addr<0xffc0):
			addr_high = 1;
			addr = (addr-0x7fe0) + 0x20;
		elif(addr>=0xffc0 and addr<0x17fa0):
			addr_high = 2;
			addr = (addr-0xffc0) + 0x20;
		elif(addr>=0x17fa0 and addr<0x1ff80):
			addr_high = 3;
			addr = (addr-0x17fa0) + 0x20;
		elif(addr>=0x1ff80 and addr<0x27f60):
			addr_high = 4;
			addr = (addr-0x1ff80) + 0x20;
		elif(addr>=0x27f60 and addr<0x2ff40):
			addr_high = 5;
			addr = (addr-0x27f60) + 0x20;
		elif(addr>=0x2ff40 and addr<0x37f20):
			addr_high = 6;
			addr = (addr-0x2ff40) + 0x20;
		elif(addr>=0x37f20 and addr<0x3ff00):
			addr_high = 7;
			addr = (addr-0x37f20) + 0x20;
		else:
			addr_high=0
			addr=0
			error("Address read. Check if device DVDD voltage went low, or went into reset or script")
		self.memPageSel(page,addr_high);
		return(addr);
	#memAddrGen
	
	def memWrite(self,page,addr,data):
		memAddr=self.memAddrGen(page,addr);
		self.deviceRefs.device.writeReg(memAddr,data);
	#memWrite
	
	def memWrite8(self,page,addr,data):
		memAddr=self.memAddrGen(page,addr);
		self.deviceRefs.device.writeReg(memAddr,data);
	#memWrite8
	
	def memWrite16(self,page,addr,data):
		memAddr=self.memAddrGen(page,addr);
		self.deviceRefs.device.writeReg(memAddr,data&0xff);
		self.deviceRefs.device.writeReg(memAddr+1,(data>>8)&0xff);
	#memWrite16
	
	def memWrite32(self,page,addr,data):
		memAddr=self.memAddrGen(page,addr);
		self.deviceRefs.device.writeReg(memAddr,data&0xff);
		self.deviceRefs.device.writeReg(memAddr+1,(data>>8)&0xff);
		self.deviceRefs.device.writeReg(memAddr+2,(data>>16)&0xff);
		self.deviceRefs.device.writeReg(memAddr+3,(data>>24)&0xff);
	#memWrite32

	def memRead(self,page,addr):
		memAddr=self.memAddrGen(page,addr);		
		data = self.deviceRefs.device.readReg(memAddr);
		return(data);
	#memRead
	
	def memRead8(self,page,addr):
		memAddr=self.memAddrGen(page,addr);		
		data = self.deviceRefs.device.readReg(memAddr);
		return(data);
	#memRead8
	
	def memRead16(self,page,addr):
		memAddr=self.memAddrGen(page,addr);		
		data0 = self.deviceRefs.device.readReg(memAddr);
		data1 = self.deviceRefs.device.readReg(memAddr+1);
		data = data1<<8 | data0;
		return(data);
	#memRead16
	
	def memRead32(self,page,addr):
		memAddr=self.memAddrGen(page,addr);		
		data0 = self.deviceRefs.device.readReg(memAddr);
		data1 = self.deviceRefs.device.readReg(memAddr+1);
		data2 = self.deviceRefs.device.readReg(memAddr+2);
		data3 = self.deviceRefs.device.readReg(memAddr+3);
		data = data3<<24 | data2<<16 | data1<<8 | data0;
		return(data);
	#memRead32

	def burstRead(self,address,noOfBytes):
		for i in range(noOfBytes):
			self.deviceRefs.device.rawWriteLog(str("0x{:04x}".format((address+i)&0x7fff).lower().replace('l',''))+"    "+str("\t// Read "))
			if self.deviceRefs.device.logClassInst!=None and self.deviceRefs.device.rawWriteLogEn==True:
				self.deviceRefs.device.logClassInst.logRawWriteRead("AFE77xx",(address+i)&0x7fff,0,1,lsb=0,msb=7)
		
		if self.deviceRefs.device.regProgDevice:
			self.deviceRefs.device.regProgDevice._controller.purge()
			return self.deviceRefs.device.regProgDevice.burstRead(address,noOfBytes)
	#burstRead
		
	def burstWrite(self,address,writeValues): 
		#for i in range(len(writeValues)): 
		#	self.deviceRefs.device.rawWriteLog(str("0x{:04x}".format(address+i).lower().replace('l',''))+"    "+str("0x{:02x}".format(writeValues[i]).lower().replace('l',''))) 
		#	if self.deviceRefs.device.logClassInst!=None and self.deviceRefs.device.rawWriteLogEn==True: 
		#		self.deviceRefs.device.logClassInst.logRawWriteRead("AFE77xx",address+i,writeValues[i],0,lsb=0,msb=7) 
		if self.deviceRefs.device.logClassInst!=None and self.deviceRefs.device.rawWriteLogEn==True: 
			self.deviceRefs.device.logClassInst.logBurstWrite("AFE77xx",address,writeValues)
			
		if self.deviceRefs.device.regProgDevice: 
			self.deviceRefs.device.regProgDevice._controller.purge() 
			return self.deviceRefs.device.regProgDevice.burstWrite(address,writeValues)
	#burstWrite
#HWAccess
