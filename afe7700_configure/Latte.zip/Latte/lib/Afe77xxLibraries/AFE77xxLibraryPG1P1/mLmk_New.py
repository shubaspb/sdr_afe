from globalDefs import *
from mFuncDecorator import *
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
#from mAfeParameters import lmkParams

class lmkLib(object):
	""" self.regs=lmk """
	@initDecorator
	def __init__(self,regs,lmkParams):
		#self.deviceRefs=deviceRefs
		#self.systemParams=deviceRefs.systemParams
		#self.systemStatus=deviceRefs.systemStatus
		self.lmkParams=lmkParams
		self.regs=regs
		self.laneRate=0
	#__init__
	
	@funcDecorator
	def lmkSysrefEn(self,En=False):
		if setupParams.boardType in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
			if self.lmkParams.pllEn==True:
				if En==True:
					self.regs.writeReg(0x106,0xF0)
				else:
					self.regs.writeReg(0x106,0xF1)
			else:
				self.regs.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=not En
				if En==True:
					self.regs.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1
				else:
					self.regs.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
		else:
			if self.lmkParams.pllEn==True:
				if En==True:
					self.regs.writeReg(0x10e,0xF0)
					self.regs.writeReg(0x116,0xF0)
				else:
					self.regs.writeReg(0x10e,0xF1)
					self.regs.writeReg(0x116,0xF1)
			else:
				self.regs.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=not En
				self.regs.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=not En
				if En==True:
					self.regs.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1
					self.regs.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=1
				else:
					self.regs.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
					self.regs.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=0
			
	#lmkSysrefEn
	
	@funcDecorator
	def lmkConfig(self,rxFbTx=0,instanceNo=0):
		""""Doing LMK config" "Done with LMK Config"
			rxFbTx, instanceNo are needed when the lane rates are different for any case."""
		
		lmk=self.regs
		lmk.reset()
		lmk.gui.reset()
		lmk.head.page.System.Top_Modes.SW_RESET=1
		lmk.head.page.System.Top_Modes.SW_RESET=0

		if setupParams.boardType not in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
			deviceRefClk=[setupParams.dutInstances[0].systemParams.FRef,setupParams.dutInstances[1].systemParams.FRef]
		else:
			deviceRefClk=self.systemParams.FRef
		sysrefFreq=self.lmkParams.sysrefFreq
		instanceNo=instanceNo&1
		if setupParams.boardType not in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
			if rxFbTx==0:
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateRx[instanceNo]
			elif rxFbTx==1:                                                              
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateFb[instanceNo]
			else:                                                                        
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateTx[instanceNo]
			
		else:
			if rxFbTx==0:
				laneRate=self.systemStatus.laneRateRx[instanceNo]
			elif rxFbTx==1:
				laneRate=self.systemStatus.laneRateFb[instanceNo]
			else:
				laneRate=self.systemStatus.laneRateTx[instanceNo]
		if self.lmkParams.pllEn:
			self.lmkPllConfig(deviceRefClk,sysrefFreq,laneRate,False)
		else:
			if setupParams.boardType not in ("BENCH",):
				self.lmkEvmDivConfig(deviceRefClk,sysrefFreq,laneRate,False)
			else:
				self.lmkDivConfig(deviceRefClk,sysrefFreq,laneRate,False)
		self.laneRate=laneRate
	#lmkConfig
	
	
	@funcDecorator
	def lmkSelectCh(self,rxFbTx=0,instanceNo=0):
		if setupParams.boardType not in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
			deviceRefClk=[setupParams.dutInstances[0].systemParams.FRef,setupParams.dutInstances[1].systemParams.FRef]
		else:
			deviceRefClk=self.systemParams.FRef
		
		sysrefFreq=self.lmkParams.sysrefFreq
		instanceNo=instanceNo&1
		if setupParams.boardType in ("BENCH",):
			if rxFbTx==0:
				laneRate=self.systemStatus.laneRateRx[instanceNo]
			elif rxFbTx==1:
				laneRate=self.systemStatus.laneRateFb[instanceNo]
			else:
				laneRate=self.systemStatus.laneRateTx[instanceNo]
			if self.lmkParams.pllEn:
				self.lmkPllConfig(deviceRefClk,sysrefFreq,laneRate,True)
			else:
				self.lmkDivConfig(deviceRefClk,sysrefFreq,laneRate,True)
		else:
			if rxFbTx==0:
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateRx[instanceNo]
			elif rxFbTx==1:                                                              
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateFb[instanceNo]
			else:                                                                        
				laneRate=setupParams.dutInstances[setupParams.selectedDut].systemStatus.laneRateTx[instanceNo]
			self.lmkEvmDivConfig(deviceRefClk,sysrefFreq,laneRate,True)
		self.laneRate=laneRate
	#lmkSelectCh
	
	@funcDecorator
	def lmkDivConfig(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig):
		lmk=self.regs
		divInputClk=self.lmkParams.inputClk
		if not onlyDivConfig:
			deviceRefClkDiv=divInputClk/deviceRefClk
			if deviceRefClkDiv not in range(1,33):
				error("LMK Div factor from Input Frequency to device Ref "+str(deviceRefClkDiv)+" is not supported. Choose a different FRef to the Device or LMK input clock.")	
			sysrefDiv=int(round(divInputClk/sysrefFreq))
			if sysrefDiv>8191:
				error("Minimum sysref frequency = :" + str(sysrefDiv))
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=sysrefDiv
			
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_=int(round(deviceRefClkDiv))
			# 500 -- i/p to lmk
			lmk.writeReg(0x145,127)
			 
			#lmk_gui.System.Top_Modes.Power_Down=0
			#Reset

			#Clk0_1 (0=JESD Clk= 125MHz, 1= DUT_SYSREF= 31.25M)
			lmk.writeReg(256,0x0C) #Set dclk0 divider as Ext/4;
			delay(0.1)
			lmk.writeReg(260,0x20) #Enable Sysref out on clk1
			lmk.writeReg(262,0x10) #Disable output pdn(default set)
			lmk.writeReg(263,0x11) #Set outputs as LVDS
			lmk.writeReg(267,0x02) #Bypass divider
			lmk.writeReg(270,0x11) #Disable output pdn for clk2 (default set to 1)
			lmk.writeReg(271,0x01) #Set output as LVDS

			#qport_lmk.writeReg(256,0x02) #Set dclk0 divider as Ext/2;

			#qport_lmk.writeReg(259,0x00000002)
			#Clk2 (2= DUT_CLK= 500MHz)
			lmk.writeReg(278,0x19) #Disable output pdn for clk4 (default set to 1)
			lmk.writeReg(278,0x11) #Disable output pdn for clk4 (default set to 1)
			lmk.writeReg(279,0x01) #Set output as LVDS
			lmk.writeReg(286,0x00000019)
			lmk.writeReg(294,0x00000019)
			lmk.writeReg(302,0x00000019)

			#qport_lmk.writeReg(304,0x02) #Set dclk0 divider as Ext/2;
			lmk.writeReg(304,0x0C) #Set dclk0 divider as Ext/4;
			delay(0.1)
			lmk.writeReg(308,0x20) #Enable Sysref out on clk1
			#Clk12_13 (12=CLK_kintex_capture= 125MHz, 13= FPGA_SYSREF= 31.25M)
			lmk.writeReg(310,0x10) #Disable output pdn(default set)
			lmk.writeReg(311,0x11) #Set outputs as LVDS
			#Choose Ext clock(No PLL)
			lmk.writeReg(312,0x44)
			lmk.writeReg(313,0x03) #Enable continuous sysref
			lmk.writeReg(314,0x10) #Setting the Sysref divide to Ext/16= MSB 5bits
			lmk.writeReg(315,0x00) #Setting the Sysref divide to Ext/16= LSB 8bits
			#Select CLK input to MOS(Changes input Common mode)
			lmk.writeReg(320,0x03) #Disable sysref pdn
			lmk.writeReg(323,0x11) #clear Syref clear to enable sysref output
			lmk.writeReg(324,0xFF) #Disable sync event from diturbing sysref and clock outputs
			lmk.writeReg(326,0x10)
			 #Common setting for Sysref outputs

			#qport_lmk.writeReg(307,0x02) #Bypass Divider
			#PDN all other outputs

			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_mux_lt_2_0_gt_ = 6
			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_type_lt_2_0_gt_ = 5



			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1


			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0

			lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux = 1

			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0

			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 7
			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 8
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0

			lmk.head.page.Clkin_Control.Enable_Type.clkin1_type=1
		if self.systemParams.jesdProtocol ==0:
			if(laneRate<=7500):
				divFactor=round(2.0*20*divInputClk/laneRate,4)
				if divFactor not in range(1,33):
					error("LMK Div factor from Input Frequency to FPGA require clock "+str(divFactor)+" is not supported. Link will not be established.")
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor)
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor-1)		# This write is just to make sure the next write goes through
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor)
				#reProgramFPGA(0)
			else:
				divFactor1=round(2.0*20*divInputClk/laneRate,4)
				divFactor2=round(5.0*20*divInputClk/laneRate,4)
				if divFactor1 not in range(1,33):
					error("LMK Div factor1 from Input Frequency to FPGA required clock "+str(divFactor1)+" is not supported. Link will not be established.")
				if divFactor2 not in range(1,33):
					error("LMK Div factor2 from Input Frequency to FPGA required clock "+str(divFactor2)+" is not supported. Link will not be established.")
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor1)
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2-1)		# This write is just to make sure the next write goes through
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2)
		else:
			divFactor=0x1F&int(round(divInputClk/100,4))
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor-1		# This write is just to make sure the next write goes through
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor
				
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
	
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
		lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=False
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
		lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=False
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=False
		lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
		lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=768#3072
		
		if self.lmkParams.lmkFrefClk==False:
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0
		else:
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=4
				
		lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
		lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=True
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
		lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=True
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
		lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=True
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=True
	#lmkDivConfig

	
	@funcDecorator
	def lmkDivConfigOld(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig):
		lmk=self.regs
		divInputClk=self.lmkParams.inputClk
		if not onlyDivConfig:
			deviceRefClkDiv=divInputClk/deviceRefClk
			if deviceRefClkDiv not in range(1,33):
				error("LMK Div factor from Input Frequency to device Ref "+str(deviceRefClkDiv)+" is not supported. Choose a different FRef to the Device or LMK input clock.")	
			sysrefDiv=int(round(divInputClk/sysrefFreq))
			if sysrefDiv>8191:
				error("Minimum sysref frequency = :" + str(sysrefDiv))
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=sysrefDiv
			
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_=int(round(deviceRefClkDiv))
			# 500 -- i/p to lmk
			lmk.writeReg(0x145,127)
			 
			#lmk_gui.System.Top_Modes.Power_Down=0
			#Reset

			#Clk0_1 (0=JESD Clk= 125MHz, 1= DUT_SYSREF= 31.25M)
			lmk.writeReg(256,0x04) #Set dclk0 divider as Ext/4;
			lmk.writeReg(260,0x20) #Enable Sysref out on clk1
			lmk.writeReg(262,0x10) #Disable output pdn(default set)
			lmk.writeReg(263,0x11) #Set outputs as LVDS
			lmk.writeReg(267,0x02) #Bypass divider
			lmk.writeReg(270,0x11) #Disable output pdn for clk2 (default set to 1)
			lmk.writeReg(271,0x01) #Set output as LVDS

			#qport_lmk.writeReg(256,0x02) #Set dclk0 divider as Ext/2;

			#qport_lmk.writeReg(259,0x00000002)
			#Clk2 (2= DUT_CLK= 500MHz)
			lmk.writeReg(278,0x19) #Disable output pdn for clk4 (default set to 1)
			lmk.writeReg(278,0x11) #Disable output pdn for clk4 (default set to 1)
			lmk.writeReg(279,0x01) #Set output as LVDS
			lmk.writeReg(286,0x00000019)
			lmk.writeReg(294,0x00000019)
			lmk.writeReg(302,0x00000019)

			#qport_lmk.writeReg(304,0x02) #Set dclk0 divider as Ext/2;
			lmk.writeReg(304,0x04) #Set dclk0 divider as Ext/4;
			lmk.writeReg(308,0x20) #Enable Sysref out on clk1
			#Clk12_13 (12=CLK_kintex_capture= 125MHz, 13= FPGA_SYSREF= 31.25M)
			lmk.writeReg(310,0x10) #Disable output pdn(default set)
			lmk.writeReg(311,0x11) #Set outputs as LVDS
			#Choose Ext clock(No PLL)
			lmk.writeReg(312,0x44)
			lmk.writeReg(313,0x03) #Enable continuous sysref
			lmk.writeReg(314,0x10) #Setting the Sysref divide to Ext/16= MSB 5bits
			lmk.writeReg(315,0x00) #Setting the Sysref divide to Ext/16= LSB 8bits
			#Select CLK input to MOS(Changes input Common mode)
			lmk.writeReg(320,0x03) #Disable sysref pdn
			lmk.writeReg(323,0x11) #clear Syref clear to enable sysref output
			lmk.writeReg(324,0xFF) #Disable sync event from diturbing sysref and clock outputs
			lmk.writeReg(326,0x10)
			 #Common setting for Sysref outputs

			#qport_lmk.writeReg(307,0x02) #Bypass Divider
			#PDN all other outputs

			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_mux_lt_2_0_gt_ = 6
			lmk.head.page.Reset_Mux_Type.Reset_pin_controls.Reset_type_lt_2_0_gt_ = 5

			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=768#3072
			
						# Clkout_pdn_dis
			if self.lmkParams.lmkFrefClk==False:
				lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=0
			else:
				lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=4
				

			lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
			lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=True
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=True
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=True
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=True

			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1


			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0

			lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux = 1

			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0

			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 7
			lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = 8
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 1 
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 1
			lmk.head.page.DCLK8_SDCLK9_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_ = 0

			lmk.head.page.Clkin_Control.Enable_Type.clkin1_type=1
		if self.systemParams.jesdProtocol ==0:
			if(laneRate<=7500):
				divFactor=round(2.0*20*divInputClk/laneRate,4)
				if divFactor not in range(1,33):
					error("LMK Div factor from Input Frequency to FPGA require clock "+str(divFactor)+" is not supported. Link will not be established.")
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor)
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor-1)		# This write is just to make sure the next write goes through
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor)
				#reProgramFPGA(0)
			else:
				divFactor1=round(2.0*20*divInputClk/laneRate,4)
				divFactor2=round(5.0*20*divInputClk/laneRate,4)
				if divFactor1 not in range(1,33):
					error("LMK Div factor1 from Input Frequency to FPGA required clock "+str(divFactor1)+" is not supported. Link will not be established.")
				if divFactor2 not in range(1,33):
					error("LMK Div factor2 from Input Frequency to FPGA required clock "+str(divFactor2)+" is not supported. Link will not be established.")
				lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor1)
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2-1)		# This write is just to make sure the next write goes through
				lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2)
		else:
			divFactor=0x1F&int(round(divInputClk/100,4))
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor-1		# This write is just to make sure the next write goes through
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor
				
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
		lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
		lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0
	#lmkDivConfig
	
	@funcDecorator
	def lmkPllConfig(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig):
		lmk=self.regs
		divInputClk=2949.12
		#lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=0
		#lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.pdn_dclk_sdclk=0
		#lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=7
		#lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_=1
			
		if not onlyDivConfig:
			if setupParams.boardType in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
				deviceRefClkDiv=divInputClk/deviceRefClk
				if deviceRefClkDiv not in range(1,33):
					error("LMK Div factor from internal PLL to device Ref "+str(deviceRefClkDiv)+" is not supported. Choose a different FRef to the Device or use External FPGA clock.")	
			else:
				deviceRefClkDiv0=divInputClk/deviceRefClk[0]
				if deviceRefClkDiv0 not in range(1,33):
					error("LMK Div factor from internal PLL to device Ref "+str(deviceRefClkDiv0)+" is not supported. Choose a different FRef to the Device or use External FPGA clock.")	
				deviceRefClkDiv1=divInputClk/deviceRefClk[1]
				if deviceRefClkDiv1 not in range(1,33):
					error("LMK Div factor from internal PLL to device Ref "+str(deviceRefClkDiv1)+" is not supported. Choose a different FRef to the Device or use External FPGA clock.")	
				#lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[0]))
				#lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[1]))

			sysrefDiv=int(round(divInputClk/sysrefFreq))
			if sysrefDiv>8191:
				error("Minimum sysref frequency = :" + str(sysrefDiv))
			#LMK04828 4wire mode. Fref = 368.64MHz. FPGA_CLK = 100MHz
			#LMK04828 
			lmk.writeReg(0x14A,0x33) #four wire mode
			lmk.writeReg(0x00 ,0x00)
			lmk.writeReg(0x02 ,0x00)
			lmk.writeReg(0x100,0x08) #LMK04828 VCO = 2949.12MHz. FPGACLK = LMK04828VCO/12 = 100MHz. LVDS level for the FPGA
			lmk.writeReg(0x101,0x55)
			lmk.writeReg(0x103,0x01)
			lmk.writeReg(0x104,0x20)
			lmk.writeReg(0x105,0x00)
			lmk.writeReg(0x106,0xF0)
			lmk.writeReg(0x107,0x74)
			if setupParams.boardType in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
				lmk.writeReg(0x108,0x60+int(round(deviceRefClkDiv))) #Fref = LMK04828 VCO/6 = 491.52MHz. This is Fref to the AFE with LVPECL level.
			else:
				lmk.writeReg(0x108,0x60+int(round(deviceRefClkDiv0))) #Fref = LMK04828 VCO/6 = 491.52MHz. This is Fref to the AFE with LVPECL level.
			lmk.writeReg(0x109,0x55)
			lmk.writeReg(0x10B,0x01)
			lmk.writeReg(0x10C,0x20)
			lmk.writeReg(0x10D,0x00)
			lmk.writeReg(0x10E,0xF0)
			lmk.writeReg(0x10F,0x74)
			if setupParams.boardType in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
				lmk.writeReg(0x110,0x08)
			else:
				lmk.writeReg(0x108,0x60+int(round(deviceRefClkDiv1))) #Fref = LMK04828 VCO/6 = 491.52MHz. This is Fref to the AFE with LVPECL level.
			lmk.writeReg(0x111,0x55)
			lmk.writeReg(0x113,0x00)
			lmk.writeReg(0x114,0x00)
			lmk.writeReg(0x115,0x00)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x116,0xF9)
				lmk.writeReg(0x117,0x00)
			else:
				lmk.writeReg(0x116,0xF0)
				lmk.writeReg(0x117,0x44)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x118,0x18)
			else:
				lmk.writeReg(0x118,int(round(divInputClk/100)))		
			lmk.writeReg(0x119,0x55)
			lmk.writeReg(0x11B,0x00)
			lmk.writeReg(0x11C,0x20)
			lmk.writeReg(0x11D,0x00)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x11E,0xF9)
				lmk.writeReg(0x11F,0x00)
			else:
				lmk.writeReg(0x11E,0xF0)
				lmk.writeReg(0x11F,0x04)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x120,0x10)
			else:
				lmk.writeReg(0x120,0x60+int(round(divInputClk/100)))
			lmk.writeReg(0x121,0x55)
			lmk.writeReg(0x123,0x00)
			lmk.writeReg(0x124,0x00)
			lmk.writeReg(0x125,0x00)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x126,0xF9)
				lmk.writeReg(0x127,0x11)
			else:
				lmk.writeReg(0x126,0xF0)
				lmk.writeReg(0x127,0x04)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x128,0x08)
			else:
				lmk.writeReg(0x128,0x60+int(round(divInputClk/184.32)))
			lmk.writeReg(0x129,0x55)
			lmk.writeReg(0x12B,0x00)
			lmk.writeReg(0x12C,0x00)
			lmk.writeReg(0x12D,0x00)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x12E,0xF9)
				lmk.writeReg(0x12F,0x00)
			else:
				lmk.writeReg(0x12E,0xF0)
				lmk.writeReg(0x12F,0x44)
			if setupParams.boardType in ('EVM-1Device',"BENCH"):
				lmk.writeReg(0x130,0x14) # divide30
			else:
				lmk.writeReg(0x130,0x60+int(round(divInputClk/147.456)))
			
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=4
			lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_mux=1
			
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=12
			
			
		if self.systemParams.jesdProtocol==0 and setupParams.boardType in ('EVM-1Device',"BENCH","EVM-1DeviceJ58"):
			if(laneRate<=7500):
				if setupParams.boardType in ("BENCH",):
					divFactor=4#round(2.0*20*divInputClk/laneRate,4)
					if divFactor not in range(1,33):
						error("LMK Div factor from internal PLL to FPGA require clock "+str(divFactor)+" is not supported. Link will not be established.")
				else:
					divFactor=0x1F&int(round(divInputClk/100,4))#12		# to get 100M for the 58 board
				lmk.writeReg(0x100,0x1F&int(divFactor))#lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor)
				lmk.writeReg(0x130,0x1F&int(divFactor))#lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor)
				#reProgramFPGA(0)
			else:
				if setupParams.boardType in ("BENCH",):
					divFactor1=round(2.0*20*divInputClk/laneRate,4)
					divFactor2=round(5.0*20*divInputClk/laneRate,4)
					if divFactor1 not in range(1,33):
						error("LMK Div factor1 from internal PLL to FPGA required clock "+str(divFactor1)+" is not supported. Link will not be established.")
					if divFactor2 not in range(1,33):
						error("LMK Div factor2 from internal PLL to FPGA required clock "+str(divFactor2)+" is not supported. Link will not be established.")
				else:
					divFactor1=0x1F&int(round(divInputClk/100,4))#12		# to get 100M for the 58 board
					divFactor2=0x1F&int(round(divInputClk/100,4))#12		# to get 100M for the 58 board
				lmk.writeReg(0x100,0x1F&int(divFactor1))#lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor1)
				lmk.writeReg(0x130,0x1F&int(divFactor2))#lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0x1F&int(divFactor2)
				#reProgramFPGA(1)
		else:
			divFactor=0x1F&int(round(divInputClk/100,4))
			lmk.writeReg(0x100,0x1F&int(divFactor))#lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor
			#lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor-1		# This write is just to make sure the next write goes through
			lmk.writeReg(0x130,0x1F&int(divFactor))#lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=divFactor
		
		if not onlyDivConfig:	
			lmk.writeReg(0x131,0x55)
			lmk.writeReg(0x133,0x00)
			lmk.writeReg(0x134,0x20)
			lmk.writeReg(0x135,0x00)
			lmk.writeReg(0x136,0xF1) #enable
			lmk.writeReg(0x137,0x01)
			lmk.writeReg(0x138,0x20)
			lmk.writeReg(0x139,0x03) #pulsed sysref
			lmk.writeReg(0x13A,sysrefDiv>>8)
			lmk.writeReg(0x13B,sysrefDiv&0xff)
			lmk.writeReg(0x13C,0x00)
			lmk.writeReg(0x13D,0x08)
			lmk.writeReg(0x13E,0x03)
			lmk.writeReg(0x13F,0x00)
			lmk.writeReg(0x140,0x00)
			lmk.writeReg(0x141,0x00)
			lmk.writeReg(0x142,0x00)
			lmk.writeReg(0x143,0x32)
			lmk.writeReg(0x143,0x12)
			lmk.writeReg(0x144,0xFF)
			lmk.writeReg(0x145,0x00)
			lmk.writeReg(0x146,0x10)
			lmk.writeReg(0x147,0x1A)
			lmk.writeReg(0x148,0x02)
			lmk.writeReg(0x149,0x42)
			lmk.writeReg(0x14B,0x16)
			lmk.writeReg(0x14C,0x00)
			lmk.writeReg(0x14D,0x00)
			lmk.writeReg(0x14E,0xC0)
			lmk.writeReg(0x14F,0x7F)
			lmk.writeReg(0x150,0x03)
			lmk.writeReg(0x151,0x02)
			lmk.writeReg(0x152,0x00)
			lmk.writeReg(0x153,0x00)
			lmk.writeReg(0x154,0x78)
			lmk.writeReg(0x155,0x00)
			lmk.writeReg(0x156,0x7D)
			lmk.writeReg(0x157,0x00)
			lmk.writeReg(0x158,0x96)
			lmk.writeReg(0x159,0x06) ##0x6
			lmk.writeReg(0x15A,0x00)
			lmk.writeReg(0x15B,0xD4)
			lmk.writeReg(0x15C,0x20)
			lmk.writeReg(0x15D,0x00)
			lmk.writeReg(0x15E,0x00)
			lmk.writeReg(0x15F,0x0B)
			lmk.writeReg(0x160,0x00)
			lmk.writeReg(0x161,0x01)
			lmk.writeReg(0x162,0x44)
			lmk.writeReg(0x163,0x00)
			lmk.writeReg(0x164,0x00)
			lmk.writeReg(0x165,0x0C)
			lmk.writeReg(0x166,0x00)
			lmk.writeReg(0x167,0x00)
			lmk.writeReg(0x168,0x0C)
			lmk.writeReg(0x169,0x59)
			lmk.writeReg(0x16A,0x20)
			lmk.writeReg(0x16B,0x00)
			lmk.writeReg(0x16C,0x00)
			lmk.writeReg(0x16D,0x00)
			lmk.writeReg(0x16E,0x13)
			lmk.writeReg(0x17C,0x15)
			lmk.writeReg(0x17D,0x0F)
	#lmkPllConfig

			
	
	@funcDecorator
	def lmkEvmDivConfig(self,deviceRefClk,sysrefFreq,laneRate,onlyDivConfig):
		lmk = self.regs
		divInputClk=self.lmkParams.inputClk
		if onlyDivConfig==False:
			lmk.gui.reset()
			#lmk.reset()
			# 500 -- i/p to lmk
			 
			lmk.head.page.System.Top_Modes.SW_RESET=1
			lmk.head.page.System.Top_Modes.SW_RESET=0
			 
			 
			#lmk_gui.System.Top_Modes.Power_Down=0
			#Reset
			 
			#Choose Ext clock(No PLL)
			lmk.writeReg(312,0x44)
			 #Select CLK input to MOS(Changes input Common mode)
			lmk.writeReg(326,0x10)
			 #Common setting for Sysref outputs
			lmk.writeReg(313,0x03) #Enable continuous sysref
			lmk.writeReg(320,0x03) #Disable sysref pdn
			lmk.writeReg(323,0x11) #clear Syref clear to enable sysref output
			lmk.writeReg(324,0xFF) #Disable sync event from diturbing sysref and clock outputs
			lmk.writeReg(315,0x00) #Setting the Sysref divide to Ext/16= LSB 8bits
			lmk.writeReg(314,0x10) #Setting the Sysref divide to Ext/16= MSB 5bits

			 
			 
			#Clk0_1 (0=JESD Clk= 125MHz, 1= DUT_SYSREF= 31.25M)
			lmk.writeReg(262,0x10) #Disable output pdn(default set)
			lmk.writeReg(263,0x11) #Set outputs as LVDS

			#qport_lmk.writeReg(256,0x02) #Set dclk0 divider as Ext/2;
			lmk.writeReg(256,0x04) #Set dclk0 divider as Ext/4;
			#lmk.writeReg(256,0x06) #Set dclk0 divider as Ext/6 JBG;
			lmk.writeReg(260,0x20) #Enable Sysref out on clk1

			#qport_lmk.writeReg(259,0x00000002)
			 
			#Clk2 (2= DUT_CLK= 500MHz)
			lmk.writeReg(270,0x11) #Disable output pdn for clk2 (default set to 1)
			lmk.writeReg(271,0x01) #Set output as LVDS
			lmk.writeReg(267,0x02) #Bypass divider

			 
			 
			#Clk12_13 (12=CLK_kintex_capture= 125MHz, 13= FPGA_SYSREF= 31.25M)
			lmk.writeReg(310,0x10) #Disable output pdn(default set)
			lmk.writeReg(311,0x11) #Set outputs as LVDS

			#qport_lmk.writeReg(304,0x02) #Set dclk0 divider as Ext/2;
			lmk.writeReg(304,0x04) #Set dclk0 divider as Ext/4;
			lmk.writeReg(308,0x20) #Enable Sysref out on clk1

			#qport_lmk.writeReg(307,0x02) #Bypass Divider
			 
			#PDN all other outputs
			 
			lmk.writeReg(278,0x00000019)
			lmk.writeReg(286,0x00000019)
			lmk.writeReg(294,0x00000019)
			lmk.writeReg(302,0x00000019)

			 
			lmk.writeReg(278,0x11) #Disable output pdn for clk4 (default set to 1)
			lmk.writeReg(279,0x01) #Set output as LVDS
	 

			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK0_SDCLK1_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=0
			lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_=4

			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK12_SDCLK13_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=5
			lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			lmk.head.page.Config_Sysref_Sync_Device_.SYSREF_DIV.Div_lt_12_0_gt_=3072

			lmk.head.page.DCLK2_SDCLK3_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			if setupParams.boardType in ('EVM-1Device',"EVM-1DeviceJ58"):
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=True
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=True
			else:
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
				lmk.head.page.DCLK4_SDCLK5_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.sdclk_pdn=False
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
			lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=False

			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK0_SDCLK1_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK12_SDCLK13_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0


			lmk.head.page.DCLK2_SDCLK3_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 0
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK8_SDCLK9_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
			lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4


			lmk.head.page.DCLK0_SDCLK1_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK12_SDCLK13_controls.Analog_Dig_Delay.sdclk_mux = 1



			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_=2

			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=1
			lmk.head.page.DCLK2_SDCLK3_controls.Analog_Dig_Delay.dclk_mux_lt_1_0_gt_=0


			lmk.head.page.DCLK12_SDCLK13_controls.Out_control.dclkout_DIV_lt_4_0_gt_=10

			lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_=2
			lmk.head.page.DCLK4_SDCLK5_controls.Analog_Dig_Delay.sdclk_mux = 1
			lmk.head.page.DCLK4_SDCLK5_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 1
			if setupParams.boardType in ('EVM-1Device',"EVM-1DeviceJ58"):
				lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk))
				lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk))
			else:
				lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[0]))
				lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[1]))

		##################################	
		lmk.head.page.DCLK0_SDCLK1_controls.Out_control.dclkout_DIV_lt_4_0_gt_= int(round(self.lmkParams.inputClk/(125)))#round(divInputClk/(laneRate/40))#GTX_Clk #10Gbps = 100 #15Gbps = 368.74
		if setupParams.boardType in ('EVM-1Device',"EVM-1DeviceJ58"):
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk))
			lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk))
		else:
			lmk.head.page.DCLK2_SDCLK3_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[0]))
			lmk.head.page.DCLK4_SDCLK5_controls.Out_control.dclkout_DIV_lt_4_0_gt_ = int(round(self.lmkParams.inputClk/deviceRefClk[1]))

		lmk.head.page.DCLK6_SDCLK7_controls.Out_control.dclkout_DIV_lt_4_0_gt_= int(round((self.lmkParams.inputClk/125)))#round(divInputClk/100)#FPGA_RefClk1
		lmk.head.page.DCLK8_SDCLK9_controls.Out_control.dclkout_DIV_lt_4_0_gt_= int(round((self.lmkParams.inputClk/125)))#round(divInputClk/100)#FPGA_RefClk2
				
		# lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn
		
		# lmk.head.page.DCLK8_SDCLK9_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0
		# lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0
		

		# lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.pdn_dclk_sdclk = 0
		# lmk.head.page.DCLK6_SDCLK7_controls.Clkout_pdn_dis.sdclk_pdn = 0
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.dclk_format_lt_2_0_gt_ = 4
		lmk.head.page.DCLK6_SDCLK7_controls.Polarity_Format.sdclk_format_lt_2_0_gt_ = 4
		'''CPLD Clock'''
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.pdn_dclk_sdclk=False
		lmk.head.page.DCLK10_SDCLK11_controls.Clkout_pdn_dis.sdclk_pdn=False
		lmk.head.page.DCLK10_SDCLK11_controls.Polarity_Format.sdclk_format_lt_2_0_gt_=4
		lmk.head.page.DCLK10_SDCLK11_controls.Analog_Dig_Delay.sdclk_mux=1
	#lmkEvmDivConfig
		