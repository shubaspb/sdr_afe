class setupParams():
	selectedDut=0
	boardType="BENCH"#"HSC1320"
	dutInstances=[]
	fpgaLib=None
	lmkLib=None
	engine=None
	fpgaWriter=None
	process=None
	skipFpga=False
	skipLmk=False
	fpgaRefClk=125
	fpgaWriter='dummy'
	
class setupJesdParams():
	
	HSC1320Lanes={
					0:	{
							'tx_lanes'    : [1,9,2,0,8,3,7,4],
							'rx_lanes'    : [0,1,9,2,8,3,7,4],
						},
					1:	{
							'tx_lanes'    : [6,5,10,11,12,13,14,15],
							'rx_lanes'    : [6,5,15,14,10,11,12,13],
						},
		
					'rx_polarity' :  [1,0,1,0,1,0,0,0,1,0,1,0,0,0,0,0],
					'tx_polarity' :  [0,0,0,1,1,0,0,1,1,0,1,1,1,1,0,0]
				}
	
	HSC1373Lanes={ 
					0:  {
						'tx_lanes'    : [6,9,2,5,8,3,7,4],
						'rx_lanes'    : [5,6,9,2,8,3,7,4],
					},
					1:  {
						'tx_lanes'    : [1,0,10,11,12,13,14,15],
						'rx_lanes'    : [1,0,15,14,10,11,12,13],
					},
					'rx_polarity' :  [0,0,1,0,1,1,0,0,1,0,1,0,0,0,0,0],
					'tx_polarity' :  [0,0,0,1,1,0,0,1,1,0,1,1,1,1,0,1]
	}
	
	EVM1DeviceJ58={
					0:	{ 
							'tx_lanes'    : [1,0,2,3,7,4,6,5], 
							'rx_lanes'    : [0,1,2,3,7,4,6,5], 
						}, 

					'rx_polarity' :  [0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0], 
					'tx_polarity' :  [0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0]
				}
				
	boardLaneSettings={}
	boardLaneSettings['HSC1320']=HSC1320Lanes
	boardLaneSettings['HSC1373']=HSC1373Lanes
	boardLaneSettings["EVM-1DeviceJ58"]=EVM1DeviceJ58
#setupJesdParams
	
class fpgaParamsClass(object):
	captureType=None
	fpgaResetFtdi=None
	
class lmkParamsClass(object):
	pllEn			=	False
	inputClk		=	1500
	sysrefFreq		=	3000/1024
	lmkFrefClk		=	True
#lmkParamsClass
