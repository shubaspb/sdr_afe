from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class timingControlLib(projectBaseClass):
	"""Contains Timing Controller specific functions. self.regs=device.TOP.TIMING_CTRL """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
	
	#__init__


	
	@funcDecorator
	def sendSysrefToAll(self):
		self.regs.TG_TOP.Register44377_4C4h.Property44720_10_0=(2**10)-2
	#sendSysrefToAll
	
	@funcDecorator
	def sendSysrefToJesd(self,en=1):
		if en==0:
			self.regs.TG_TOP.general_configs.reg_subchip_sysref_enables=self.regs.TG_TOP.Register44377_4C4h.Property44720_10_0&((2**10-1)^(0x1<<0))
		else:
			self.regs.TG_TOP.general_configs.reg_subchip_sysref_enables=self.regs.TG_TOP.Register44377_4C4h.Property44720_10_0|(0x1<<0)
	#sendSysrefToJesd
		
	@funcDecorator
	def sendSysrefToRx(self,en=1):
		if en==1:
			self.regs.TG_TOP.general_configs.reg_subchip_sysref_enables=self.regs.TG_TOP.Register44377_4C4h.Property44720_10_0|(0x1<<0)
		else:
			self.regs.TG_TOP.general_configs.reg_subchip_sysref_enables=self.regs.TG_TOP.Register44377_4C4h.Property44720_10_0&((2**10-1)^(0x1<<0))
	#sendSysrefToJesd
	
	@funcDecorator
	def timingCntrlTddConfig(self):
		self.regs.TG_TOP.Register44386_4D0h.Property44436_24_24=0
		if self.systemParams.mode2t2r==0:#self.systemParams.pllMuxModes in (0,1,2) or self.systemParams.mode2t2r==False:
			self.regs.TG_TOP.Register44377_4C4h.Property44377_0_0=0
		else:
			self.regs.TG_TOP.Register44377_4C4h.Property44377_0_0=1
			
		self.regs.TG_TOP.Register44377_4C4h.Property44382_8_8=0
		self.regs.TG_TOP.Register44038_220h.Property44376_16_16=0
		self.regs.TG_TOP.Register44038_220h.Property44394_17_17=0
		self.regs.TG_TOP.Register44038_220h.Property44395_18_18=0
		self.regs.TG_TOP.Register44364_384h.Property44370_16_16=0
		self.regs.TG_TOP.Register44364_384h.Property44397_17_17=0
		self.regs.TG_TOP.Register44364_384h.Property44398_18_18=0	
		self.regs.TG_TOP.Register44386_4D0h.Property44406_6_6=0
		self.regs.TG_TOP.Register44386_4D0h.Property44409_9_9=0
		self.regs.TG_TOP.Register44386_4D0h.Property44407_7_7=0
		self.regs.TG_TOP.Register44386_4D0h.Property44410_10_10=0
		self.regs.TG_TOP.Register44386_4D0h.Property44408_8_8=0
		self.regs.TG_TOP.Register44386_4D0h.Property44411_11_11=0
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44501_0_0=0
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44503_8_8=0
		self.regs.TDD_CONTROLLER.Register44602_118h.Property44602_0_0=0
		self.regs.TDD_CONTROLLER.Register44602_118h.Property44628_0_0=1
		self.regs.TDD_CONTROLLER.Register44440_504h.Property44471_8_8=0
		self.regs.TDD_CONTROLLER.Register44440_504h.Property44475_19_16=15
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44514_0_0=0
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44517_8_8=0
		self.regs.TDD_CONTROLLER.Register44602_118h.Property44706_31_26=0b100100
		self.regs.TDD_CONTROLLER.Register44602_118h.Property44705_25_24=0b11
		self.regs.TG_TOP.Register44377_4C4h.Property44383_16_16=1
		self.regs.TDD_CONTROLLER.Register44440_504h.Property44463_16_16 = 0
		self.regs.TDD_CONTROLLER.Register44524_5DCh.Property44567_15_0=0x177
		self.regs.TDD_CONTROLLER.Register44524_5DCh.Property44587_15_0=0x177
	#timingCntrlTddConfig
		
	@funcDecorator
	def configure_timing_controller_for_tx_steady_state_fb_mux_mode(self,pin_bypass=0,bypass_val=0,singlefb_chc=0,ch0_msb=2,ch0_lsb=0,ch1_msb=3,ch1_lsb=1,dual_fbmode=0):
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= pin_bypass
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= bypass_val
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44507_24_24		= singlefb_chc
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44508_1_0		= ch0_msb
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44509_9_8		= ch0_lsb
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44510_17_16		= ch1_msb
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44511_25_24		= ch1_lsb
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44512_16_16			= dual_fbmode
	#	configure_timing_controller_for_tx_steady_state_fb_mux_mode

	
	@funcDecorator
	def txToFbSelectCh(self,overrideEn,channelSelect=0):
		""" overrideEn=True to override the Pins
			In single FB mode, channelSelect values of 0-3 selects channels A-D. 4 means No TX is connected to FB
			In dual FB mode, channelSelect values
						0 selects channels TXA to FBAB and TXC to FBCD
						1 selects channels TXB to FBAB and TXD to FBCD
						2/3 means no channel is connected to FB. """
		self.regs.TDD_CONTROLLER.Register44488_554h.Property44505_0_0	= overrideEn
		if self.systemParams.txIqMcCalibMode==2:	# 0 -Single Fb Mode FB AB ; 1 -Single Fb Mode FB CD ; 2- Dual Fb_Mode
			self.regs.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= channelSelect&3+(channelSelect<<2)
		else:
			self.regs.TDD_CONTROLLER.Register44488_554h.Property44506_11_8	= channelSelect
			
	#txToFbSelectCh
#timingControlLib