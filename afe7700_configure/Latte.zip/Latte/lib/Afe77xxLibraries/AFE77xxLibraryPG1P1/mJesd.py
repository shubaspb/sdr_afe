from globalDefs import *
import math
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
import mAfeConstants
reload(mAfeConstants)
from mAfeConstants import jesdConstants
from mFuncDecorator import *
import mJesdSubchip
reload(mJesdSubchip)
from mJesdSubchip import jesdSubchipLib
import mJesdSerdes
reload(mJesdSerdes)
from mJesdSerdes import serdesLib
import mJesdRx
reload(mJesdRx)
from mJesdRx import jesdRxLib
import mJesdTx
reload(mJesdTx)
from mJesdTx import jesdTxLib
from mSetupParams import setupParams
#import mAfeParameters
#reload(mAfeParameters)
#from mAfeParameters import systemParams
#from mAfeParameters import systemStatus
import os

class jesdLib(projectBaseClass):
	"""Contains DDC specific functions. self.regs=device.JESD """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.SUBCHIP=jesdSubchipLib(regs.SUBCHIP.SUBCHIP,deviceRefs)
		self.JESDTX=[]
		self.JESDRX=[]
		self.SERDES=[]
		for i in xrange(2):
			self.JESDTX.append(jesdTxLib(i,regs.ADC_TX[i],deviceRefs))
			self.JESDRX.append(jesdRxLib(i,regs.DAC_RX[i],deviceRefs))
			self.SERDES.append(serdesLib(i,regs.SERDES[i],deviceRefs))

		self.regs=regs
		self.fieldNameToRegisterList={}
		for register in self.regs.entities.keys():
			for field in self.regs.entities[register].stateVariables.keys():
				if field in self.fieldNameToRegisterList:
					error("In class: "+str(self.__class__.__name__)+"; Property "+field+" was already present in group"+self.fieldNameToRegisterList[field]+".")
				else:
					self.fieldNameToRegisterList[field]=register#self.regs.entities[register].stateVariables[field]
	
	#__init__

	@funcDecorator
	def serdesConfigLoadOld(self,fileName,pageEnable=3):
		""" "Configuring the SERDES" "Done configuring the SERDES" """  
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_refclk_div_ratio=5
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_refclk_en=1
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index=2
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index=2
		pageEnable=pageEnable&3
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable
		configFile = open(fileName,"r")
		for line in configFile:
			line=line.strip()
			if line!='':
				if line[0] in ('8','9'):
					address=int(line[0:4],16)
					data=int((line[4:].strip())[0:4],16)&0xffff
					if self.systemParams.jesdProtocol==0:
						if address==0x84f5:			#TX_PLL_N
							data1=(data&0xff)+((self.systemStatus.serdesConfig[0]['serdesTxPllN'])<<8)
							data2=(data&0xff)+((self.systemStatus.serdesConfig[1]['serdesTxPllN'])<<8)
						elif address==0x84f4:		#TX_PLL_VCO_Range
							data1=(data&0x1fff)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[0]['serdesTxVcoRange'])&0x7)<<13)
							data2=(data&0x1fff)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[1]['serdesTxVcoRange'])&0x7)<<13)
						elif address==0x84f3:		#TX_PLL_VCO_Range_MSB
							data1=(data&0xffef)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[0]['serdesTxVcoRange'])>>3)<<4)
							data2=(data&0xffef)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[1]['serdesTxVcoRange'])>>3)<<4)
							#if self.systemStatus.serdesConfig[0]['serdesTxVcoRange'][0]<20:
							#	data1=data1|0x100
							#if self.systemStatus.serdesConfig[1]['serdesTxVcoRange'][0]<20:
							#	data2=data2|0x100
						elif address==0x84fE:		#RX_PLL_N
							data1=(data&0xff)+((self.systemStatus.serdesConfig[0]['serdesRxPllN'])<<8)
							data2=(data&0xff)+((self.systemStatus.serdesConfig[1]['serdesRxPllN'])<<8)
						elif address==0x84fD:		#RX_PLL_VCO_Range
							data1=(data&0x1fff)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[0]['serdesRxVcoRange'])&0x7)<<13)
							data2=(data&0x1fff)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[1]['serdesRxVcoRange'])&0x7)<<13)
						elif address==0x84fc:		#RX_PLL_VCO_Range_MSB
							data1=(data&0xfffd)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[0]['serdesRxVcoRange'])>>3)<<1)
							data2=(data&0xfffd)+((jesdConstants.serdesSupportedVcoRatesMinMax.index(self.systemStatus.serdesConfig[1]['serdesRxVcoRange'])>>3)<<1)
							if self.systemStatus.serdesConfig[0]['serdesRxVcoRange'][0]<20:
								data1=data1|0x20
							if self.systemStatus.serdesConfig[1]['serdesRxVcoRange'][0]<20:
								data2=data2|0x20
						elif address in (0x804a,0x814a,0x824a,0x834a):		#RX_SPEED_SEL
							laneNumber=jesdConstants.jesdToSerdesLaneMapping.index((address>>8)&3)
							data1=(data&0xfc7f)+(jesdConstants.serdesSupportedSubRateDivs.index(self.systemStatus.serdesConfig[0]['subRateDivSerdesRx'][laneNumber])<<7)
							laneNumber=jesdConstants.jesdToSerdesLaneMapping.index(4+((address>>8)&3))
							data2=(data&0xfc7f)+(jesdConstants.serdesSupportedSubRateDivs.index(self.systemStatus.serdesConfig[1]['subRateDivSerdesRx'][laneNumber%4])<<7)
						elif address in (0x80a0,0x81a0,0x82a0,0x83a0):
							laneNumber=jesdConstants.jesdToSerdesLaneMapping.index((address>>8)&3)
							data1=(data&0xff8f)+(jesdConstants.serdesSupportedSubRateDivs.index(self.systemStatus.serdesConfig[0]['subRateDivSerdesTx'][laneNumber])<<4)
							data1=(data1&0xfffe)+(not self.systemParams.serdesTxLanePolarity[laneNumber])
							laneNumber=jesdConstants.jesdToSerdesLaneMapping.index(4+((address>>8)&3))
							data2=(data&0xff8f)+(jesdConstants.serdesSupportedSubRateDivs.index(self.systemStatus.serdesConfig[1]['subRateDivSerdesTx'][laneNumber%4])<<4)
							data2=(data2&0xfffe)+(not self.systemParams.serdesTxLanePolarity[laneNumber])
						else:
							data=int((line[4:].strip())[0:4],16)&0xffff
						if address in (0x84f5,0x84f4,0x84fE,0x84fD,0x804a,0x814a,0x824a,0x834a,0x80a0,0x81a0,0x82a0,0x83a0,0x84fc,0x84f3):
							if address&0xf0ff in (0x80A0,) and (self.systemParams.jesdProtocol!=0 or self.systemParams.customerConfig==True or setupParams.boardType!="BENCH"):
								laneNumber=jesdConstants.jesdToSerdesLaneMapping.index((address>>8)&3)
								data1=(data1&0xfffe)+(not self.systemParams.serdesTxLanePolarity[laneNumber])
								laneNumber=jesdConstants.jesdToSerdesLaneMapping.index(4+((address>>8)&3))
								data2=(data2&0xfffe)+(not self.systemParams.serdesTxLanePolarity[laneNumber])
							else:
								data1=data1
								data2=data2
								
							self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable&1
							self.serdesWrite(address,data1)
							self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable&2
							self.serdesWrite(address,data2)
							self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable
						elif address&0xf0ff in (0x8042,) and (self.systemParams.jesdProtocol!=0 or self.systemParams.customerConfig==True or setupParams.boardType!="BENCH"):
							laneNumber0=jesdConstants.jesdToSerdesLaneMapping.index((address>>8)&3)
							laneNumber1=jesdConstants.jesdToSerdesLaneMapping.index(4+((address>>8)&3))
							if self.systemParams.serdesRxLanePolarity[laneNumber0]==False and self.systemParams.serdesRxLanePolarity[laneNumber1]==False:
								self.serdesWrite(address,data&0xfffe)
							else:
								data1=(data&0xfffe)+(self.systemParams.serdesRxLanePolarity[laneNumber0])
								data2=(data&0xfffe)+(self.systemParams.serdesRxLanePolarity[laneNumber1])
								self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable&1
								self.serdesWrite(address,data1)
								self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable&2
								self.serdesWrite(address,data2)
								self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=pageEnable
						else:
							self.serdesWrite(address,data)
					else:
						if address&0xf0ff in (0x80A0,):
							data=data|1
						elif address&0xf0ff in (0x8042,):
							data=data&0xfffe
						self.serdesWrite(address,data)
						
		configFile.close()
		self.delay(0.1)
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE0=0
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE1=0
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE2=0
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE3=0
		
		#self.regs.SERDES[0].Common.BIST_CONTROL_1.SRAM_BIST_EN=1
		#self.regs.SERDES[0].Common.BIST_CONTROL_1.SRAM_BIST_START=1
		#self.delay(0.001)
		#self.regs.SERDES[0].Common.BIST_CONTROL_1.SRAM_BIST_EN=0
		#self.regs.SERDES[0].Common.BIST_CONTROL_1.SRAM_BIST_START=0
	#serdesConfigLoadOld
	
	@funcDecorator
	def serdesConfigLoad(self):
		""" "Configuring the SERDES" "Done configuring the SERDES" """  
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_refclk_div_ratio=5
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_refclk_en=1
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index=2
		self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index=2

		
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		self.SERDES[0].reloadFirmware()
		serdesConfig1Translated=self.systemStatus.serdesConfig[1].copy()
		serdesConfig1Translated['subRateDivSerdesTx']=list(reversed(serdesConfig1Translated['subRateDivSerdesTx']))
		serdesConfig1Translated['serdesRxLaneEna']=list(reversed(serdesConfig1Translated['serdesRxLaneEna']))
		serdesConfig1Translated['serdesTxLaneEna']=list(reversed(serdesConfig1Translated['serdesTxLaneEna']))
		serdesConfig1Translated['subRateDivSerdesRx']=list(reversed(serdesConfig1Translated['subRateDivSerdesRx']))
		if self.systemStatus.serdesConfig[0]==serdesConfig1Translated:
			self.SERDES[0].configSerdesCommon()
			for laneNo in range(4):
				self.SERDES[0].configSerdesLane(laneNo)
		else:
			for topNo in range(2):
				self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1<<topNo
				self.SERDES[topNo].configSerdesCommon()
				for laneNo in range(4):
					self.SERDES[topNo].configSerdesLane(laneNo)
		if (self.systemParams.serdesManualCTLE[:4]!=list(reversed(self.systemParams.serdesManualCTLE[4:]))) and self.systemStatus.serdesConfig[0]==serdesConfig1Translated:
			for laneNo in range(8):
				jesdToSerdesLaneMapping=self.deviceRefs.device.jesdToSerdesLaneMapping
				offset=jesdToSerdesLaneMapping[laneNo]*0x100
				self.serdesWrite(0x801D+offset,(self.systemParams.serdesManualCTLE[laneNo]<<4))
		
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE0=0
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE1=0
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE2=0
		self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE3=0
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=0


	@funcDecorator
	def serdesFirmwareLoad(self,fileName=ASTERIX_DIR+DEVICES_DIR+r"Afe77xxLibrary\resourceFiles\hpcp.fw.e86233.bin"):
		""" "Loading Serdes Firmware" "Done loading Serdes Firmware" Takes Bin file and does the required writes."""
		if fileName.strip()=="":
			return
		elif not (os.path.exists(fileName) and  os.path.isfile(fileName)):
			error("Firmware file Doesn't Exist. Please give path for a bin file.")
			return
		dataLoad= np.fromfile(fileName,dtype=np.uint8)
		def get32BitData(address):
			val=0
			for i in range(4):
				val=(val<<8)+int(dataLoad[address+i])
			return val
			
		def get16BitData(address):
			val=0
			for i in range(2):
				val=(val<<8)+int(dataLoad[address+i])
			return val
		startAddress=4096							# start address of the RAM in the file
		
		length=get32BitData(startAddress+12)		# length of firmware
		enterPoint=get32BitData(startAddress+8)		
		startAddr=get32BitData(startAddress+16)		# Start Address of the firmware
		info("length= "+str(hex(length)))
		info("enterPoint= "+str(hex(enterPoint)))
		info("startAddress= "+str(hex(startAddress)))
		dataAddr=startAddress+20
		ramAddr=startAddr
		checkSum=0
		
		section=int(math.ceil(length/24.0))+1		#since we can write only 12 words (24 bytes) at a time.
		progress=0
		info(section)
		dataLoad=np.concatenate([dataLoad,np.zeros((len(dataLoad)-4096-length))])
		#self.SERDES[0].serdesReset()
		#self.SERDES[1].serdesReset()
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		self.serdesWrite(0x9814,0xfff0)
		self.delay(1)
		#self.serdesWrite(0x980D,0x0aaa)
		#self.delay(1)
		#self.serdesWrite(0x980d,0x0000)
		#self.delay(1)
		self.serdesWrite(0x9814,0x0000)
		self.serdesWrite(0x9815,0x0000)
		
		for x in range(section):
			if x%30==0:
				info("Progress="+str(x*100/section))
			checkSum=0x800c
			
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
			self.deviceRefs.device.commentForWrite="// Start of Frame"
			self.serdesWrite(0x9f00+12,ramAddr>>16)			#RAM_ADDRESS_HIGH
			self.serdesWrite(0x9f00+13,ramAddr&0xffff)			#RAM_ADDRESS_LOW
			checkSum+=(ramAddr>>16)+(ramAddr&0xffff)
			for i in range(12):
				if dataAddr>=len(dataLoad):
					writeVal=0
				else:
					writeVal=get16BitData(dataAddr)
				self.serdesWrite(0x9f00+i,writeVal)
				checkSum=(checkSum+writeVal)&0xffff
				dataAddr+=2
				ramAddr+=2
			self.serdesWrite(0x9f00+14,(-checkSum)&0xffff)		#FIRMWARE_CHECKSUM
			self.serdesWrite(0x9f00+15,0x800C)							#FIRMWARE_CONTROL_WORD_STATUS
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1
			found=False
			for i in range(50):
				if self.serdesRead(0x9f00+15)==0:
					found=True	
					break
			if found==False:
				error("Firmware didn't take the write. CheckSum Error: "+str (hex(self.serdesRead(0x9f00+15))))
				checkSum=0x800c
				for i in range(14):
					a=self.serdesRead(0x9f00+i)
					checkSum=checkSum+a
				if (0xfffff^checkSum)&0xffff !=self.serdesRead(0x9f00+14):
					error("Somewrite didn't go through")
				else:
					info("CheckSum Computation is fine")
				return
				
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		for i in range(12):
			self.serdesWrite(0x9f00+i,0)	
		self.serdesWrite(0x9f00+12,enterPoint>>16)			#RAM_ADDRESS_HIGH
		self.serdesWrite(0x9f00+13,enterPoint&0xffff)		#RAM_ADDRESS_LOW
		checkSum=(enterPoint>>16)+(enterPoint&0xffff)+0x4000
		self.serdesWrite(0x9f00+14,(-checkSum)&0xffff)
		self.serdesWrite(0x9f00+15,0x4000)
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1
		found=False
		for i in range(100):
			if self.serdesRead(0x9f00+15)==0:
				found=True	
				break
		if found==False:
			error("Firmware didn't take the last write. CheckSum Error: "+str (hex(self.serdesRead(0x9f00+15))))
		else:
			info("Done writing")
		
		self.delay(1)
		if self.serdesRead(0x9814)==0:
			error("Firmware didn't get loaded")
		else:
			info(hex(self.serdesRead(0x9814)))
		self.serdesWrite(0x980D,0x0777)
		self.serdesWrite(0x980D,0x0000)
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		highSpeed=True
		for i in self.systemStatus.laneRateRx+self.systemStatus.laneRateTx+self.systemStatus.laneRateFb:
			if i>20000:
				highSpeed=True
			else:
				highSpeed=False
		val=0x106b
		self.serdesWrite(0x8000,val|0x8000)
		self.serdesWrite(0x8000,val)
		self.serdesWrite(0x8100,val|0x8000)
		self.serdesWrite(0x8100,val)
		self.serdesWrite(0x8200,val|0x8000)
		self.serdesWrite(0x8200,val)
		self.serdesWrite(0x8300,val|0x8000)
		self.serdesWrite(0x8300,val)
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=0
	#serdesFirmwareLoad
		
	@funcDecorator
	def serdesFirmwareLoad(self,fileName=ASTERIX_DIR+DEVICES_DIR+r"Afe77xxLibrary\resourceFiles\hpcp.fw.e86233.bin"):
		""" "Loading Serdes Firmware" "Done loading Serdes Firmware" Takes Bin file and does the required writes."""
		if fileName.strip()=="":
			return
		elif not (os.path.exists(fileName) and  os.path.isfile(fileName)):
			error("Firmware file Doesn't Exist. Please give path for a bin file.")
			return
		dataLoad= np.fromfile(fileName,dtype=np.uint8)
		def get32BitData(address):
			val=0
			for i in range(4):
				val=(val<<8)+int(dataLoad[address+i])
			return val
			
		def get16BitData(address):
			val=0
			for i in range(2):
				val=(val<<8)+int(dataLoad[address+i])
			return val
		startAddress=4096							# start address of the RAM in the file
		
		length=get32BitData(startAddress+12)		# length of firmware
		enterPoint=get32BitData(startAddress+8)		
		startAddr=get32BitData(startAddress+16)		# Start Address of the firmware
		info("length= "+str(hex(length)))
		info("enterPoint= "+str(hex(enterPoint)))
		info("startAddress= "+str(hex(startAddress)))
		dataAddr=startAddress+20
		ramAddr=startAddr
		checkSum=0
		
		section=int(math.ceil(length/24.0))+1		#since we can write only 12 words (24 bytes) at a time.
		progress=0
		info(section)
		dataLoad=np.concatenate([dataLoad,np.zeros((len(dataLoad)-4096-length))])
		#self.SERDES[0].serdesReset()
		#self.SERDES[1].serdesReset()
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		self.serdesWrite(0x9814,0xfff0)
		self.delay(1)
		#self.serdesWrite(0x980D,0x0aaa)
		#self.delay(1)
		#self.serdesWrite(0x980d,0x0000)
		#self.delay(1)
		self.serdesWrite(0x9814,0x0000)
		self.serdesWrite(0x9815,0x0000)
		
		for x in range(section):
			if x%30==0:
				info("Progress="+str(x*100/section))
			checkSum=0x800c
			
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
			self.deviceRefs.device.commentForWrite="// Start of Frame"
			self.serdesWrite(0x9f00+12,ramAddr>>16)			#RAM_ADDRESS_HIGH
			self.serdesWrite(0x9f00+13,ramAddr&0xffff)			#RAM_ADDRESS_LOW
			checkSum+=(ramAddr>>16)+(ramAddr&0xffff)
			for i in range(12):
				if dataAddr>=len(dataLoad):
					writeVal=0
				else:
					writeVal=get16BitData(dataAddr)
				self.serdesWrite(0x9f00+i,writeVal)
				checkSum=(checkSum+writeVal)&0xffff
				dataAddr+=2
				ramAddr+=2
			self.serdesWrite(0x9f00+14,(-checkSum)&0xffff)		#FIRMWARE_CHECKSUM
			self.serdesWrite(0x9f00+15,0x800C)							#FIRMWARE_CONTROL_WORD_STATUS
			self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1
			found=False
			for i in range(50):
				if self.serdesRead(0x9f00+15)==0:
					found=True	
					break
			if found==False:
				error("Firmware didn't take the write. CheckSum Error: "+str (hex(self.serdesRead(0x9f00+15))))
				checkSum=0x800c
				for i in range(14):
					a=self.serdesRead(0x9f00+i)
					checkSum=checkSum+a
				if (0xfffff^checkSum)&0xffff !=self.serdesRead(0x9f00+14):
					error("Somewrite didn't go through")
				else:
					info("CheckSum Computation is fine")
				return
				
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		for i in range(12):
			self.serdesWrite(0x9f00+i,0)	
		self.serdesWrite(0x9f00+12,enterPoint>>16)			#RAM_ADDRESS_HIGH
		self.serdesWrite(0x9f00+13,enterPoint&0xffff)		#RAM_ADDRESS_LOW
		checkSum=(enterPoint>>16)+(enterPoint&0xffff)+0x4000
		self.serdesWrite(0x9f00+14,(-checkSum)&0xffff)
		self.serdesWrite(0x9f00+15,0x4000)
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=1
		found=False
		for i in range(100):
			if self.serdesRead(0x9f00+15)==0:
				found=True	
				break
		if found==False:
			error("Firmware didn't take the last write. CheckSum Error: "+str (hex(self.serdesRead(0x9f00+15))))
		else:
			info("Done writing")
		
		self.delay(1)
		if self.serdesRead(0x9814)==0:
			error("Firmware didn't get loaded")
		else:
			info(hex(self.serdesRead(0x9814)))
		self.serdesWrite(0x980D,0x0777)
		self.serdesWrite(0x980D,0x0000)
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=3
		highSpeed=True
		for i in self.systemStatus.laneRateRx+self.systemStatus.laneRateTx+self.systemStatus.laneRateFb:
			if i>20000:
				highSpeed=True
			else:
				highSpeed=False
		#if highSpeed==True:
		#	val=0x106b
		#else:
		#	val=0x10Eb
		val=0x106b
		self.serdesWrite(0x8000,val|0x8000)
		self.serdesWrite(0x8000,val)
		self.serdesWrite(0x8100,val|0x8000)
		self.serdesWrite(0x8100,val)
		self.serdesWrite(0x8200,val|0x8000)
		self.serdesWrite(0x8200,val)
		self.serdesWrite(0x8300,val|0x8000)
		self.serdesWrite(0x8300,val)
		self.deviceRefs.device.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=0
	#serdesFirmwareLoad
	
	@funcDecorator
	def enableSerdesApb(self,en=1):
		""" "Enabling access to SERDES" "Done enabling access to SERDES" """ 
		if en==1:
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_cm4_clk_en=1
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_cm4_clk_div_ratio=3
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index=2
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index=2
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_mode_16b=1
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_mode_16b=1
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_pin_intf_en=0
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_pin_intf_en=0
			
			self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE3=0 #40x from credo
			self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE2=0
			self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE1=0
			self.regs.SERDES[0].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE0=0
			self.regs.SERDES[1].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE3=0 #40x from credo
			self.regs.SERDES[1].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE2=0
			self.regs.SERDES[1].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE1=0
			self.regs.SERDES[1].Common.IO_MODE_CONTROL.BUS_WIDTH_LANE0=0
		else:
			self.regs.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG32.apb_clk_from_cm4_clk_en=0
			
	#enableSerdesApb	
#jesdLib