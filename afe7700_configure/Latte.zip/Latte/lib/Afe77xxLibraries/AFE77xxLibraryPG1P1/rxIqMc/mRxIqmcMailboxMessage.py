import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *

import numpy as np
from globalDefs import *

class RxIqmcMailboxMessage(projectBaseClass):

	def __init__(self,regs,deviceRefs):
		""" self.regs=device.TOP """
		self.regs = regs #This should be the very top - usually called device
		self.deviceRefs=deviceRefs
	#_init_
	
	def msgSysConfig(self,valid2RFlag,interface_rate,dig_clk_rate):
		#info("Entered into msgSysConfig")
		interface_rate_list = np.array([0.5,1,1.5,2, 3, 4, 6 ])
		msgCode_interface_rate = np.array([1, 1, 2, 3, 4, 5, 6])
		dig_clk_rate_list = np.array([24, 27, 28])
		msgCode_dig_clk_rate = np.array([0, 1, 2])
				
		condition = dig_clk_rate_list == dig_clk_rate
		index = np.extract(condition,np.array(range(len(dig_clk_rate_list))))
		digClkRateCode = msgCode_dig_clk_rate[index]
				
		if valid2RFlag[0]==1:
			condition = interface_rate_list == interface_rate[0]
			index = np.extract(condition,np.array(range(len(interface_rate_list))))
			msgCodeAB = msgCode_interface_rate[index]
			abValidFlag = 1 
		else:
			abValidFlag = 0
			msgCodeAB = 0 # dont care
				
		if valid2RFlag[1]==1:
			condition = interface_rate_list == interface_rate[1]
			index = np.extract(condition,np.array(range(len(interface_rate_list))))
			msgCodeCD = msgCode_interface_rate[index]
			cdValidFlag = 1 
		else:
			cdValidFlag = 0
			msgCodeCD = 0 # dont care
		
		#info("In msgSysConfig. Computed msg codes")
		RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS = 0x00000
		data = msgCodeAB
		#info(data)
		self.memWrite8('top2RxMem',RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS,data)
		data = 0
		#info(data)
		self.memWrite8('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+1),data)
		data = msgCodeCD
		#info(data)		
		self.memWrite8('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+2),data)
		data = 0
		#info(data)		
		self.memWrite8('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+3),data)
		
		#info("In msgSysConfig. Written msg codes into memory")
		opCode = 1
		controlWord = (opCode<<24) + (abValidFlag<<16) + (cdValidFlag<<18) + (digClkRateCode<<8) + 0
		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord
		#info(controlWord)
	#msgSysConfig
	
	def msgStartSteadyStateCalib(self, calibOn):
		# calibOn is expected to be a 4 element tuple/list

		opCode = 16     # 16 is the opcode for start steady state message
		mask = (calibOn[0]) | (calibOn[1] << 1) | (calibOn[2] << 2) | (calibOn[3] << 3)
		
		controlWord = (opCode << 24) + (mask << 16)
		
		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord
		#info(controlWord)
		
	def msgStrtDsaDepPwrUp(self, calibOn, dsaId, binId):
		
		opcode = 2
		rcId = dsaId

		controlWord = (opcode << 24) + (calibOn[0] << 16) + (calibOn[1] << 17) + (calibOn[2] << 18) + (calibOn[3] << 19) + (dsaId)

		memoryCont = (rcId << 24) + binId

		# write the memory contents 4 times for the 4 channels
		#info("In msgSysConfig. Computed msg codes")
		RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS = 0x00000
		data = memoryCont
		#info(data)
		self.memWrite32('top2RxMem',RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS,data)
		#info(data)
		self.memWrite32('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+4),data)
		#info(data)		
		self.memWrite32('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+8),data)
		#info(data)		
		self.memWrite32('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+12),data)

		# write the control word
		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord 

	def msgStrtFreqDepPwrUp(self, calibOn, binId, calibDone):

		opcode = 3
		
		controlWord = (opcode << 24) + (calibOn[0] << 16) + (calibOn[1] << 17) + (calibOn[2] << 18) + (calibOn[3] << 19) + (calibDone[0] << 0) + (calibDone[1] << 1) + (calibDone[2] << 2) + (calibDone[3] << 3)

		memoryCont = binId

		#write the memory contents 4 times
		#info("In msgSysConfig. Computed msg codes")
		RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS = 0x00000
		data = memoryCont
		#info(data)
		self.memWrite32('top2RxMem',RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS,data)
		#info(data)
		self.memWrite32('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+4),data)
		#info(data)		
		self.memWrite32('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+8),data)
		#info(data)		
		self.memWrite32('top2RxMem',(RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+12),data)

		# write the control word

		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord 

	def msgRcMap(self, calibOn, dsaStrtId, dsaStopId, rcMapArr = [int(i) for i in range(0,37)]):

		import math

		opcode = 4
		NUM_DSA_ATTN = 37
		SIZE_PER_RX = 10        # 10 words

		controlWord = (opcode << 24) + (calibOn[0] << 16) + (calibOn[1] << 17) + (calibOn[2] << 18) + (calibOn[3] << 19)

		memoryCont = [0 for i in range(SIZE_PER_RX)]

		info(memoryCont)
		info(rcMapArr)
		for i in range(NUM_DSA_ATTN):
			
			idx = int(math.floor(i/4))
			byteOff = i%4 

			memoryCont[idx] = memoryCont[idx] + (rcMapArr[i] << (byteOff*8))

		info(memoryCont)

		# it will come here when it is done with all other dsa indices
		idx = int(math.floor(NUM_DSA_ATTN/4))
		byteOff = NUM_DSA_ATTN%4

		memoryCont[idx] = memoryCont[idx]  + (dsaStrtId << (byteOff*8))

		# it will come here when it is done with all other dsa indices
		idx = int(math.floor((NUM_DSA_ATTN+1)/4))
		byteOff = (NUM_DSA_ATTN+1)%4

		memoryCont[idx] = memoryCont[idx] + (dsaStopId << (byteOff*8))


		info(memoryCont)

		RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS = 0x00000
				
		# write the memory
		for chId in range(4):
			if(calibOn[chId] == 1):
				for memId in range(SIZE_PER_RX):
					
					addrId = chId*SIZE_PER_RX + memId
					data = memoryCont[memId]
					#info(data)
					self.memWrite32('top2RxMem',RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+(addrId*4),data)


		# write the control word

		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord 
			
##########################################################################################################################
	def msgRcMap_corrected(self, calibOn, dsaStrtId, dsaStopId, rcMapArr = [int(i) for i in range(0,37)]):

		import math

		opcode = 4
		NUM_DSA_ATTN = 37
		SIZE_PER_RX_IN_BYTES = 39

		controlWord = (opcode << 24) + (calibOn[0] << 16) + (calibOn[1] << 17) + (calibOn[2] << 18) + (calibOn[3] << 19)

		memoryCont = [0 for i in range(SIZE_PER_RX_IN_BYTES)]

		info(memoryCont)
		info(rcMapArr)
		for i in range(NUM_DSA_ATTN):
			
			memoryCont[i] = rcMapArr[i]

		memoryCont[NUM_DSA_ATTN] = dsaStrtId
		memoryCont[NUM_DSA_ATTN+1] = dsaStopId

		info(memoryCont)

		RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS = 0x00000
				
		# write the memory
		for chId in range(4):
			if(calibOn[chId] == 1):
				for memId in range(SIZE_PER_RX_IN_BYTES):
					addrId = chId*SIZE_PER_RX_IN_BYTES + memId
					data = memoryCont[memId]
					info('Data='+hex(data) + 'Addr='+hex(addrId))
					self.memWrite8('top2RxMem',RX_IQMC_MAILBOX_MESSAGE_SYS_CONFIG_ADDRESS+addrId,data)

		# write the control word

		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord 
###################################################################
	def write_read_rxcm4_macro(self,wr=1,access_size=1,address=0x20017C00,value=0,num_burst=0):
		
		#access_size= 0=> 1 byte, 1=>16b word, 2=>32b word
		rx_rw_opcode = 25
		
		controlWord =  	((access_size + (wr << 2))<<16) + (rx_rw_opcode<<24)	
		# Fill the operands
		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord 		
		
		# Populating MACRO Memory
		ANUPAM.memWrite32('top2RxMem', 0, address)
		ANUPAM.memWrite32('top2RxMem', 4, value)
		ANUPAM.memWrite32('top2RxMem', 8, num_burst)
		
		# Issue MACRO			
		err = self.execute_macro(nBytes=0,opcode=mMACROConst.MACROConst.MACRO_OPCODE_RX_IQMC_SS_CALIB)
		return (err)
	# write_read_rxcm4_macro
###################################################################
	def msgResetKF(self, chsToReset):
		# calibOn is expected to be a 4 element tuple/list

		opCode = 23     # 16 is the opcode for start steady state message
		mask = (chsToReset[0]) | (chsToReset[1] << 1) | (chsToReset[2] << 2) | (chsToReset[3] << 3)
		
		controlWord = (opCode << 24) + (mask << 16)
		
		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22068_198h.Property22070_31_0 = controlWord
		#info(controlWord)
		
###################################################################
	def wait_for_rx_cm4_calib_done(self):

		while(self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22236_254h.Property22246_15_8 != 1):
			""""""

		info("Received RX-calib_done")

	# wait_for_rx_cm4_calib_done()
###################################################################
	def reset_rx_cm4_calib_done(self):

		self.regs.INTERNAL_MACRO.SYS_CONTROL.Register22236_254h.Property22246_15_8 = 0

		info("Reseted the rx_cm4_calib_done to 0")

	# reset_rx_cm4_calib_done()
