import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
from mFuncDecorator import *
from mRxTopConst import *
from common.mDeviceConstants import *
import random
from globalDefs import *
import math
class RxIqmcEstim(projectBaseClass):
	"""Contains RXIQMC Estim specific functions"""
	@initDecorator
	def __init__(self,regs):
		self.regs=regs
		self.errorList=['','']
	#__init__
	
	@errorLevelLogDecorator
	@funcDecorator
	def function_name(self,parameters):
		"""Description"""
		"""Definition"""
	#function_name	

	@funcDecorator
	def configureIqmcEstimator(self,rxIqmcRegConfigSettings):
		"""Description"""
		"""Definition"""
		i=0
	#configureIqmcEstimator	

	@funcDecorator
	def waitForCalibrationSettling(self,calibrationTimeInMilliSec):
		"""Description"""
		"""Definition"""
		i=0
	#waitForCalibrationSettling	
	
	@funcDecorator
	def sequence_from_souvik(self):
		"""read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display( "read value of rx_iqmc_en val before spi write=%0d", rd_val_iqmc_en);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_num_bin",'d60);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",'d1);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_clken_dom_ab",'d1);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_reset_est",'d0);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_strt",'d1);
		#130us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_done",'d1);
		#100us;
		read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display("read value of rx_iqmc_en val after spi write=%0d", rd_val_iqmc_en);
		spi_helper_inst.do_32b_spi_read(15'h160,read_val);
		$display ("The memory read value from 0x3100_0140 is =%0x",read_val);
		#1us;
		spi_helper_inst.do_32b_spi_write(32'h40404040,15'h170);
		#1us;
		spi_helper_inst.do_32b_spi_read(15'h170,read_val);
		$display ("The memory read value from 0x3100_0150 is =%0x",read_val);"""
		memory_address1=0x31000120;
		memory_address2=0x31000100;
		value1=0x45454545;
		value2=0x37373737;
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#pauseHereCustom("Make ILA Active Now")
		self.regs.aggregator.rx_iqmc_num_bin = 60
		self.regs.data_collect.rx_iqmc_enable = 1
		self.regs.data_collect.rx_iqmc_clken_dom_ab = 1
		time.sleep(1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		#time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		#pauseHereCustom("Wait for the interrupt to come")
		self.writeMem32(memory_address1,value1)
		#pauseHereCustom("2nd spi write")
		self.writeMem32(memory_address2,value2)
		#pauseHereCustom("spi write done waiting for read")
		info("//memory_address1 = "+str(hex(memory_address1)))
		info("//memory_address2 = "+str(hex(memory_address2)))
		readmem1=self.readMem32(memory_address1);
		readmem2=self.readMem32(memory_address2);
		info("//readmem1 = "+hex(readmem1))
		info("//readmem2 = "+hex(readmem2))
		if (readmem1!=(0xFFFFF & value1)):
			error("//readback from memory1 not working")
		if (readmem2!=(0xFFFFF & value2)):
			error("//readback from memory2 not working")
	#sequence_from_souvik
	
	def rxiqmc_startup_sequence(self):
		"""read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display( "read value of rx_iqmc_en val before spi write=%0d", rd_val_iqmc_en);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_num_bin",'d60);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",'d1);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_clken_dom_ab",'d1);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_reset_est",'d0);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_strt",'d1);
		#130us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_done",'d1);
		#100us;
		read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display("read value of rx_iqmc_en val after spi write=%0d", rd_val_iqmc_en);
		spi_helper_inst.do_32b_spi_read(15'h160,read_val);
		$display ("The memory read value from 0x3100_0140 is =%0x",read_val);
		#1us;
		spi_helper_inst.do_32b_spi_write(32'h40404040,15'h170);
		#1us;
		spi_helper_inst.do_32b_spi_read(15'h170,read_val);
		$display ("The memory read value from 0x3100_0150 is =%0x",read_val);"""
		#memory_address1=0x31000120;
		#memory_address2=0x31000100;
		#value1=0x45454545;
		#value2=0x37373737;
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#pauseHereCustom("Make ILA Active Now")
		self.regs.aggregator.rx_iqmc_num_bin = 60
		#self.regs.data_collect.rx_iqmc_blklen_by4_ab = 320
		#self.regs.data_collect.rx_iqmc_blklen_by4_cd = 320
		
		self.regs.data_collect.rx_iqmc_enable = 1
		self.regs.data_collect.rx_iqmc_clken_dom_ab = 1 #move if before rx_iqmc_enable
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(0.1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		time.sleep(1)
		#pauseHereCustom("Wait for the interrupt to come")
		#self.writeMem32(memory_address1,value1)
		#pauseHereCustom("2nd spi write")
		#self.writeMem32(memory_address2,value2)
		#pauseHereCustom("spi write done waiting for read")
		#info("//memory_address1 = "+str(hex(memory_address1)))
		#info("//memory_address2 = "+str(hex(memory_address2)))
		#readmem1=self.readMem32(memory_address1);
		#readmem2=self.readMem32(memory_address2);
		#info("//readmem1 = "+hex(readmem1))
		#info("//readmem2 = "+hex(readmem2))
		#if (readmem1!=(0xFFFFF & value1)):
		#	error("//readback from memory1 not working")
		#if (readmem2!=(0xFFFFF & value2)):
		#	error("//readback from memory2 not working")
	#rxiqmc_startup_sequence
	
	def rxiqmc_startup_sequence_without_clk_en_domain(self,common_clock_domain):
		"""read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display( "read value of rx_iqmc_en val before spi write=%0d", rd_val_iqmc_en);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_num_bin",'d60);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",'d1);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_clken_dom_ab",'d1);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_reset_est",'d0);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_strt",'d1);
		#130us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_done",'d1);
		#100us;
		read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display("read value of rx_iqmc_en val after spi write=%0d", rd_val_iqmc_en);
		spi_helper_inst.do_32b_spi_read(15'h160,read_val);
		$display ("The memory read value from 0x3100_0140 is =%0x",read_val);
		#1us;
		spi_helper_inst.do_32b_spi_write(32'h40404040,15'h170);
		#1us;
		spi_helper_inst.do_32b_spi_read(15'h170,read_val);
		$display ("The memory read value from 0x3100_0150 is =%0x",read_val);"""
		#memory_address1=0x31000120;
		#memory_address2=0x31000100;
		#value1=0x45454545;
		#value2=0x37373737;
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#pauseHereCustom("Make ILA Active Now")
		#self.regs.aggregator.rx_iqmc_num_bin = 60
		#self.regs.data_collect.rx_iqmc_blklen_by4_ab = 320
		#self.regs.data_collect.rx_iqmc_blklen_by4_cd = 320
		self.regs.data_collect.rx_iqmc_enable = 1
		#self.regs.data_collect.rx_iqmc_clken_dom_ab = 1
		self.rx_iqmc_cmn_dom_sel(common_clock_domain)
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(0.1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		time.sleep(1)
		#pauseHereCustom("Wait for the interrupt to come")
		#self.writeMem32(memory_address1,value1)
		#pauseHereCustom("2nd spi write")
		#self.writeMem32(memory_address2,value2)
		#pauseHereCustom("spi write done waiting for read")
		#info("//memory_address1 = "+str(hex(memory_address1)))
		#info("//memory_address2 = "+str(hex(memory_address2)))
		#readmem1=self.readMem32(memory_address1);
		#readmem2=self.readMem32(memory_address2);
		#info("//readmem1 = "+hex(readmem1))
		#info("//readmem2 = "+hex(readmem2))
		#if (readmem1!=(0xFFFFF & value1)):
		#	error("//readback from memory1 not working")
		#if (readmem2!=(0xFFFFF & value2)):
		#	error("//readback from memory2 not working")
	#rxiqmc_startup_sequence_without_clk_en_domain
	
	def rxiqmc_startup_sequence_without_clk_en_domain_part1(self,common_clock_domain,rxiqmc_param):
		#Sequence for programming divider Estim clk cfg
		info("//---Sequence for programming divider Estim clk cfg---")
		self.regs.common.rx_iqmc_rd_clk_div_outclkgate=1
		self.regs.common.rx_iqmc_rd_clk_div_reset=1
		if (rxiqmc_param['estim_clk_div_dither_en']==1):
			self.regs.common.rx_iqmc_estim_clk_div_dither_en=1
		self.regs.common.rx_iqmc_estim_clk_div_sel=rxiqmc_param['rx_iqmc_estim_clk_div_sel']
		self.regs.common.rx_iqmc_rd_clk_div_reset=0
		self.regs.common.rx_iqmc_rd_clk_div_outclkgate=0
		
		#rxiqmc WR domain CFG
		info("//---rxiqmc WR domain CFG---")
		self.regs.common.rx_iqmc_estim_core_reset=1
		self.regs.data_collect.rx_iqmc_enable = 0
		self.rx_iqmc_chnl_off(rxiqmc_param['rx_iqmc_chnl_off'])
		self.configure_interface_rate_new\
		(rxiqmc_param['interface_rate_ab'],rxiqmc_param['interface_rate_cd'],rxiqmc_param['clk_dig'],rxiqmc_param['common_clk_domain'],rxiqmc_param['delta'],rxiqmc_param)
		self.rx_iqmc_cmn_dom_sel(rxiqmc_param['common_clk_domain'])
		if(rxiqmc_param['core_reset_enable']==1):
			self.regs.common.rx_iqmc_estim_core_reset=0
		self.regs.data_collect.rx_iqmc_enable = 1
		
		#rxiqmc RD domain CFG
		info("//---rxiqmc RD domain CFG---")
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		if (rxiqmc_param['reset_hw_autonomous']==1):
			self.regs.data_collect.rx_iqmc_reset_est_flag=1
		self.regs.aggregator.rx_iqmc_fw_done = 0
		self.regs.data_collect.rx_iqmc_reset_est = 1
		self.rx_iqmc_blklen_aggr(rxiqmc_param['rx_iqmc_blklen_aggr'])
		if(rxiqmc_param['rx_iqmc_blkrand_dis']==1):
			self.rx_iqmc_blkrand_dis()
		else:
			self.rx_iqmc_blkrand_en()
		self.rx_iqmc_input_scale(rxiqmc_param['rx_iqmc_inp_scale_A'],rxiqmc_param['rx_iqmc_inp_scale_B'],\
		rxiqmc_param['rx_iqmc_inp_scale_C'],rxiqmc_param['rx_iqmc_inp_scale_D'])
		self.rx_iqmc_dsa_setting_range(rxiqmc_param['rx_iqmc_min_dsa_val_A'],rxiqmc_param['rx_iqmc_max_dsa_val_A'],\
		rxiqmc_param['rx_iqmc_min_dsa_val_B'],rxiqmc_param['rx_iqmc_max_dsa_val_B'],rxiqmc_param['rx_iqmc_min_dsa_val_C'],\
		rxiqmc_param['rx_iqmc_max_dsa_val_C'],rxiqmc_param['rx_iqmc_min_dsa_val_D'],rxiqmc_param['rx_iqmc_max_dsa_val_D'])
		self.rx_iqmc_sat_thresh(rxiqmc_param['rx_iqmc_sat_thresh'])
		self.rx_iqmc_sat_cnt_thresh(rxiqmc_param['rx_iqmc_sat_cnt_thresh'])
		self.rx_iqmc_win_sel(rxiqmc_param['rx_iqmc_win_sel'])
		self.rx_iqmc_num_bin(rxiqmc_param['rx_iqmc_num_bin'])
		self.rx_iqmc_num_blk_drop(rxiqmc_param['rx_iqmc_num_blk_drop'])
		self.rx_iqmc_slope_thrsh(rxiqmc_param['rx_iqmc_slope_thrsh1'],rxiqmc_param['rx_iqmc_slope_thrsh2'])
		self.rx_iqmc_sig_lvl_thrsh(rxiqmc_param['rx_iqmc_sig_lvl_thrsh'])
		self.rx_iqmc_ratio_thresh(rxiqmc_param['rx_iqmc_ratio_thresh'])
		self.rx_iqmc_configure_power_save_features(rxiqmc_param['rx_iqmc_aggr_int_mem_dyn_sd_dis'],\
		rxiqmc_param['rx_iqmc_aggr_cm4_mem_dyn_sd_dis'],rxiqmc_param['rx_iqmc_aggr_int_pwr_ds'],\
		rxiqmc_param['rx_iqmc_aggr_int_pwr_sd'],rxiqmc_param['rx_iqmc_aggr_cm4_pwr_ds'],\
		rxiqmc_param['rx_iqmc_aggr_cm4_pwr_sd'],rxiqmc_param['rx_iqmc_aggr_int_mem_ds_dis'])
		if (rxiqmc_param['rx_iqmc_aggr_auto_cg_dis']==1):
			self.regs.aggregator.rx_iqmc_aggr_auto_cg_dis=1
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_A=rxiqmc_param['rx_iqmc_min_numvld_blk_thrsh_A']
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_B=rxiqmc_param['rx_iqmc_min_numvld_blk_thrsh_B']
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_C=rxiqmc_param['rx_iqmc_min_numvld_blk_thrsh_C']
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_D=rxiqmc_param['rx_iqmc_min_numvld_blk_thrsh_D']
		if (rxiqmc_param['reset_est_enable']==1):
			self.regs.data_collect.rx_iqmc_reset_est = 0
		
		"""This is the old sequence"""
		#self.regs.aggregator.rx_iqmc_fw_done = 0
		#time.sleep(0.1)
		#self.regs.data_collect.rx_iqmc_fw_strt = 0
		#time.sleep(0.1)
		#self.regs.data_collect.rx_iqmc_enable = 0
		#if (rxiqmc_param['rx_iqmc_enable_before_reset']==1):
		#	self.regs.common.rx_iqmc_rd_clk_div_outclkgate=1
		#	#self.regs.common.rx_iqmc_rd_clk_div_inclkgate=1
		#	self.regs.common.rx_iqmc_rd_clk_div_reset=1
		#	self.regs.data_collect.rx_iqmc_enable = 1
		#	self.regs.common.rx_iqmc_rd_clk_div_reset=0
		#	#self.regs.common.rx_iqmc_rd_clk_div_inclkgate=0
		#	self.regs.common.rx_iqmc_rd_clk_div_outclkgate=0
		#	info("//----providing iqmc enable before reset----");
		#self.regs.common.rx_iqmc_estim_core_reset=1
		#if (rxiqmc_param['core_reset_enable']==1):
		#	self.regs.common.rx_iqmc_estim_core_reset=0
		#self.regs.data_collect.rx_iqmc_reset_est = 1
		#time.sleep(0.1)
		#if (rxiqmc_param['rx_iqmc_enable_during_reset']==1):
		#	self.regs.data_collect.rx_iqmc_enable = 1
		#	info("//----providing iqmc enable during reset----");
		#self.rx_iqmc_cmn_dom_sel(common_clock_domain)
		#time.sleep(0.1)
		#if (rxiqmc_param['reset_est_enable']==1):
		#	self.regs.data_collect.rx_iqmc_reset_est = 0
		#if (rxiqmc_param['rx_iqmc_enable_after_reset']==1):
		#	self.regs.data_collect.rx_iqmc_enable = 1
		#	info("//----providing iqmc enable after reset----");
		#time.sleep(0.2)
				
	def rxiqmc_startup_sequence_without_clk_en_domain_part2(self,common_clock_domain,rxiqmc_param):
		if (rxiqmc_param['reset_access_errors']==1):
			info('//Clearing the access errors')
			if (rxiqmc_param['check_for_access_errors_before_clearing_before_fw_start']==1):
				info("////check_for_access_errors_before_clearing_before_fw_start")
				self.read_memory_error_status()
			self.regs.mem_pwr_wrap.rx_iqmc_pwr_err_stat_clr_int_mem = 31
			self.regs.mem_pwr_wrap.rx_iqmc_pwr_err_stat_clr_cm4_ho_mem = 31
			self.regs.mem_pwr_wrap.rx_iqmc_pwr_err_stat_clr_int_mem = 0
			self.regs.mem_pwr_wrap.rx_iqmc_pwr_err_stat_clr_cm4_ho_mem = 0
			if (rxiqmc_param['check_for_access_errors_after_clearing_after_fw_start']==1):
				info("////check_for_access_errors_after_clearing_after_fw_start")
				self.read_memory_error_status()
		self.regs.data_collect.rx_iqmc_fw_strt = 1
	
	def rxiqmc_startup_sequence_without_clk_en_domain_part3(self,common_clock_domain,rxiqmc_param):
		if (rxiqmc_param['fw_done_enable']==1):
			self.regs.aggregator.rx_iqmc_fw_done = 1
	
	def rxiqmc_repeat_sequence_without_clk_en_domain(self,common_clock_domain):
		"""rxiqmc_repeat_sequence_without_clk_en_domain"""
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#self.regs.data_collect.rx_iqmc_clken_dom_ab = 1
		#self.rx_iqmc_cmn_dom_sel(common_clock_domain)
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(0.1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		time.sleep(1)
	#rxiqmc_repeat_sequence_without_clk_en_domain
	
	def rxiqmc_startup_sequence_blk_rand(self):
		"""read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display( "read value of rx_iqmc_en val before spi write=%0d", rd_val_iqmc_en);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_num_bin",'d60);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",'d1);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_clken_dom_ab",'d1);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_reset_est",'d0);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_strt",'d1);
		#130us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_done",'d1);
		#100us;
		read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display("read value of rx_iqmc_en val after spi write=%0d", rd_val_iqmc_en);
		spi_helper_inst.do_32b_spi_read(15'h160,read_val);
		$display ("The memory read value from 0x3100_0140 is =%0x",read_val);
		#1us;
		spi_helper_inst.do_32b_spi_write(32'h40404040,15'h170);
		#1us;
		spi_helper_inst.do_32b_spi_read(15'h170,read_val);
		$display ("The memory read value from 0x3100_0150 is =%0x",read_val);"""
		#memory_address1=0x31000120;
		#memory_address2=0x31000100;
		#value1=0x45454545;
		#value2=0x37373737;
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#pauseHereCustom("Make ILA Active Now")
		self.regs.aggregator.rx_iqmc_num_bin = 60
		#self.regs.data_collect.rx_iqmc_blklen_by4_ab = 320
		#self.regs.data_collect.rx_iqmc_blklen_by4_cd = 320
		self.regs.data_collect.rx_iqmc_enable = 1
		self.regs.data_collect.rx_iqmc_clken_dom_ab = 1
		time.sleep(1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		#time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		#pauseHereCustom("Wait for the interrupt to come")
		#self.writeMem32(memory_address1,value1)
		#pauseHereCustom("2nd spi write")
		#self.writeMem32(memory_address2,value2)
		#pauseHereCustom("spi write done waiting for read")
		#info("//memory_address1 = "+str(hex(memory_address1)))
		#info("//memory_address2 = "+str(hex(memory_address2)))
		#readmem1=self.readMem32(memory_address1);
		#readmem2=self.readMem32(memory_address2);
		#info("//readmem1 = "+hex(readmem1))
		#info("//readmem2 = "+hex(readmem2))
		#if (readmem1!=(0xFFFFF & value1)):
		#	error("//readback from memory1 not working")
		#if (readmem2!=(0xFFFFF & value2)):
		#	error("//readback from memory2 not working")
	#rxiqmc_startup_sequence_blk_rand
	
	def rxiqmc_startup_sequence_without_num_bin(self):
		"""read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display( "read value of rx_iqmc_en val before spi write=%0d", rd_val_iqmc_en);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_num_bin",'d60);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",'d1);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_clken_dom_ab",'d1);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_reset_est",'d0);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_strt",'d1);
		#130us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_done",'d1);
		#100us;
		read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display("read value of rx_iqmc_en val after spi write=%0d", rd_val_iqmc_en);
		spi_helper_inst.do_32b_spi_read(15'h160,read_val);
		$display ("The memory read value from 0x3100_0140 is =%0x",read_val);
		#1us;
		spi_helper_inst.do_32b_spi_write(32'h40404040,15'h170);
		#1us;
		spi_helper_inst.do_32b_spi_read(15'h170,read_val);
		$display ("The memory read value from 0x3100_0150 is =%0x",read_val);"""
		#memory_address1=0x31000120;
		#memory_address2=0x31000100;
		#value1=0x45454545;
		#value2=0x37373737;
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#pauseHereCustom("Make ILA Active Now")
		#self.regs.aggregator.rx_iqmc_num_bin = 60
		#self.regs.data_collect.rx_iqmc_blklen_by4_ab = 320
		#self.regs.data_collect.rx_iqmc_blklen_by4_cd = 320
		self.regs.data_collect.rx_iqmc_enable = 1
		self.regs.data_collect.rx_iqmc_clken_dom_ab = 1
		time.sleep(1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		#time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		#pauseHereCustom("Wait for the interrupt to come")
		#self.writeMem32(memory_address1,value1)
		#pauseHereCustom("2nd spi write")
		#self.writeMem32(memory_address2,value2)
		#pauseHereCustom("spi write done waiting for read")
		#info("//memory_address1 = "+str(hex(memory_address1)))
		#info("//memory_address2 = "+str(hex(memory_address2)))
		#readmem1=self.readMem32(memory_address1);
		#readmem2=self.readMem32(memory_address2);
		#info("//readmem1 = "+hex(readmem1))
		#info("//readmem2 = "+hex(readmem2))
		#if (readmem1!=(0xFFFFF & value1)):
		#	error("//readback from memory1 not working")
		#if (readmem2!=(0xFFFFF & value2)):
		#	error("//readback from memory2 not working")
	#rxiqmc_startup_sequence
	
	def rxiqmc_startup_sequence_for_3x_mode(self):
		"""read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display( "read value of rx_iqmc_en val before spi write=%0d", rd_val_iqmc_en);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_num_bin",'d60);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",'d1);
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_clken_dom_ab",'d1);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_reset_est",'d0);
		#1us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_strt",'d1);
		#130us;
		write_reg_field(rx_iqmc_reg_bank,"rx_iqmc_fw_done",'d1);
		#100us;
		read_reg_field(rx_iqmc_reg_bank,"rx_iqmc_enable",rd_val_iqmc_en);
		$display("read value of rx_iqmc_en val after spi write=%0d", rd_val_iqmc_en);
		spi_helper_inst.do_32b_spi_read(15'h160,read_val);
		$display ("The memory read value from 0x3100_0140 is =%0x",read_val);
		#1us;
		spi_helper_inst.do_32b_spi_write(32'h40404040,15'h170);
		#1us;
		spi_helper_inst.do_32b_spi_read(15'h170,read_val);
		$display ("The memory read value from 0x3100_0150 is =%0x",read_val);"""
		#memory_address1=0x31000120;
		#memory_address2=0x31000100;
		#value1=0x45454545;
		#value2=0x37373737;
		self.regs.aggregator.rx_iqmc_fw_done = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_fw_strt = 0
		time.sleep(0.1)
		self.regs.data_collect.rx_iqmc_reset_est = 1
		time.sleep(0.1)
		#pauseHereCustom("Make ILA Active Now")
		self.regs.aggregator.rx_iqmc_num_bin = 60
		self.regs.data_collect.rx_iqmc_blklen_by4_ab = 320
		self.regs.data_collect.rx_iqmc_blklen_by4_cd = 320
		self.regs.data_collect.rx_iqmc_enable = 1
		self.regs.data_collect.rx_iqmc_clken_dom_ab = 1
		time.sleep(1)
		self.regs.data_collect.rx_iqmc_reset_est = 0
		time.sleep(1)
		#pauseHereCustom("wait before the fw start")
		self.regs.data_collect.rx_iqmc_fw_strt = 1
		#time.sleep(1)
		#pauseHereCustom("before fw done after fw start")
		self.regs.aggregator.rx_iqmc_fw_done = 1
		#pauseHereCustom("Wait for the interrupt to come")
		#self.writeMem32(memory_address1,value1)
		#pauseHereCustom("2nd spi write")
		#self.writeMem32(memory_address2,value2)
		#pauseHereCustom("spi write done waiting for read")
		#info("//memory_address1 = "+str(hex(memory_address1)))
		#info("//memory_address2 = "+str(hex(memory_address2)))
		#readmem1=self.readMem32(memory_address1);
		#readmem2=self.readMem32(memory_address2);
		#info("//readmem1 = "+hex(readmem1))
		#info("//readmem2 = "+hex(readmem2))
		#if (readmem1!=(0xFFFFF & value1)):
		#	error("//readback from memory1 not working")
		#if (readmem2!=(0xFFFFF & value2)):
		#	error("//readback from memory2 not working")
	#rxiqmc_startup_sequence_for_3x_mode
	
	@funcDecorator
	def rx_iqmc_enable(self,rx_iqmc_enable):
		"""Enable bit for rx_iqmc estimator.
		0 : disable : disable
		1 : enable : enable"""
		self.regs.data_collect.rx_iqmc_enable = rx_iqmc_enable
	#rx_iqmc_enable
	
	def rx_iqmc_enable_dis_mul_times(self,wait_time,number):
		for number_id in range (0,number):
			info("//***number_id***"+str(number_id))
			self.regs.data_collect.rx_iqmc_enable = 0
			self.regs.data_collect.rx_iqmc_enable = 1
			time.sleep(wait_time)
		
	@funcDecorator
	def rx_iqmc_fw_strt(self):
		"""Toggle this bit from 0 to 1 to start a fresh estimate.
		0 : don't start : 
		1 : start estim loop : """
		self.regs.data_collect.rx_iqmc_fw_strt = 0;
		self.regs.data_collect.rx_iqmc_fw_strt = 1;
	#rx_iqmc_fw_strt
	
	@funcDecorator
	def rx_iqmc_fw_strt_control(self,rx_iqmc_fw_strt):
		"""Toggle this bit from 0 to 1 to start a fresh estimate.
		0 : don't start : 
		1 : start estim loop : """
		self.regs.data_collect.rx_iqmc_fw_strt = rx_iqmc_fw_strt;
	#rx_iqmc_fw_strt_control
	
	@funcDecorator
	def rx_iqmc_cmn_dom_sel(self,rx_iqmc_cmn_dom_sel):
		"""0 AB , 1 CD is chosen as common domain
		After writing commonDomainSelect with the correct value, the appropriate clockEnable should be made 1"""
		#warning("inside function")
		self.regs.data_collect.rx_iqmc_cmn_dom_sel = rx_iqmc_cmn_dom_sel;
		if (rx_iqmc_cmn_dom_sel==1.0):
			self.regs.data_collect.rx_iqmc_clken_dom_ab = 0;
			self.regs.data_collect.rx_iqmc_clken_dom_cd = 1;
		else:
			#warning("inside else")
			self.regs.data_collect.rx_iqmc_clken_dom_ab = 1;
			self.regs.data_collect.rx_iqmc_clken_dom_cd = 0;
	#rx_iqmc_cmn_dom_sel
	
	@funcDecorator
	def rx_iqmc_reset(self,rx_iqmc_reset,rx_iqmc_reset_flag):
		"""1 reset HW autonomously. In this case resetEstimHW is unused. 
		0 reset HW based on FW writing resetEstimHW register below. 
		This reset enabled HW to start in the same state for every aggregation. 
		LFSR is not affected by this reset. So randomization will be different across aggregations.
		FW needs to make this reset 0 and then 1 and then 0 again. +ve edge on this is used by HW to reset all of the estimator 
		other than LFSR. This takes effect only if   resetEstimHWAutonomousFlag==0"""
		self.regs.data_collect.rx_iqmc_reset_est_flag = rx_iqmc_reset_flag;
		if (rx_iqmc_reset_flag==0):
			self.regs.data_collect.rx_iqmc_reset_est = 0;
			self.regs.data_collect.rx_iqmc_reset_est = 1;
			self.regs.data_collect.rx_iqmc_reset_est = 0;
	#rx_iqmc_reset
	
	@funcDecorator
	def rx_iqmc_configure_blklen(self,rx_iqmc_blklen_by4_ab,rx_iqmc_blklen_by4_cd):
		"""Block Length divided by 4 in terms of no of clocks of the AB domain input clock rates. 
		Default value corresponds to 4*80/(2*61.44MHz) = 2.6us for 2x Interface rate. 
		FW needs to program this number such that the BlockLengthDivBy4 is an integer for both clock rates. 
		For eg if the rates are 3x and 4x, then this blockLength is on 3x rate and the value should be such that BlockLengthDivBy4/3 * 4 is an integer. 
		For eg BlockLengthDivBy4 = 120 would work
		Block Length divided by 4 in terms of no of clocks of the CD domain input clock rates. 
		Default value corresponds to 4*80/(2*61.44MHz) = 2.6us for 2x Interface rate. 
		FW needs to program this number such that the BlockLengthDivBy4 is an integer for both clock rates. 
		For eg if the rates are 3x and 4x, then this blockLength is on 4x rate and the value should be such that BlockLengthDivBy4/4 * 3 is an integer. 
		For eg BlockLengthDivBy4 = 160 would work"""
		self.regs.data_collect.rx_iqmc_blklen_by4_ab = rx_iqmc_blklen_by4_ab;#the block length is present at the interface rate
		self.regs.data_collect.rx_iqmc_blklen_by4_cd = rx_iqmc_blklen_by4_cd;#the block length is present at the interface rate
	#rx_iqmc_configure_blklen
	
	@funcDecorator
	def rx_iqmc_configure_strt_offset(self):
		"""The offset of start of read from the start of the first block period in terms of number of clocks of the common clock domain rate. 
		This time should be Tblock/4 + Tw + margin, where Tblock is the block time and Tw is the time taken to write one block of data for one channel. 
		For 2x IF rate and Tblock=2.6us, Tw=2.1us and margin = 20 clocks, the reg value should be 338+20 = 358 clocks and make it 360 """
		#Tblock_by4=self.regs.data_collect.rx_iqmc_blklen_by4_ab/(61.44*2);
		#Tw=2.1*2/(Interface_rate);
		#margin=20;
		rx_iqmc_blklen_by4_ab=self.regs.data_collect.rx_iqmc_blklen_by4_ab;
		margin=20;
		Num_clocks=rx_iqmc_blklen_by4_ab+260+margin;
		self.regs.data_collect.rx_iqmc_rd_strt_offset = Num_clocks;
	#rx_iqmc_configure_strt_offset
	
	@funcDecorator
	def rx_iqmc_blkrand_dis(self):
		"""disable feature for block randomization"""
		self.regs.data_collect.rx_iqmc_blkrand_dis = 1;
	#rx_iqmc_blkrand_dis
	
	@funcDecorator
	def rx_iqmc_blkrand_en(self):
		"""disable feature for block randomization"""
		self.regs.data_collect.rx_iqmc_blkrand_dis = 0;
	#rx_iqmc_blkrand_en
	
	@funcDecorator
	def rx_iqmc_dsa_setting_range(self,min_dsa_val,max_dsa_val):
		"""If actual DSA setting is not within [min,max] DSA setting range, then the block of data collected is deemed invalid"""
		self.regs.validity.rx_iqmc_min_dsa_val = min_dsa_val;
		self.regs.validity.rx_iqmc_max_dsa_val = max_dsa_val;
	#rx_iqmc_dsa_setting_range
	
	@funcDecorator
	def rx_iqmc_sat_thresh(self,rx_iqmc_sat_thresh):
		"""If abs(I) > saturationThresh or abs(Q) >saturationThresh, then numSatCounter is incremented within a block. 
		This counter is reset for every block of data collected. Format is . Lowest threshold is -18 dBFs. Default corresponds to -0.137 dBFs"""
		self.regs.validity.rx_iqmc_sat_thresh = int(64.0*math.pow(10.0,rx_iqmc_sat_thresh/10.0));
	#rx_iqmc_sat_thresh
	
	@funcDecorator
	def rx_iqmc_sat_cnt_thresh(self,rx_iqmc_sat_cnt_thresh):
		"""If numSatCounter > saturationCountThresh, then we declare that block as invalid"""
		self.regs.validity.rx_iqmc_sat_cnt_thresh = rx_iqmc_sat_cnt_thresh;
	#rx_iqmc_sat_cnt_thresh
	
	@funcDecorator
	def rx_iqmc_num_sat_cnt(self,rx_iqmc_sat_cnt_thresh):
		"""No of blocks saturated in one aggregation cycle for each of channels A,B, C and D (READ ONLY)"""
		rx_iqmc_num_sat_cnt_a = self.regs.validity.rx_iqmc_num_sat_cnt_a;
		rx_iqmc_num_sat_cnt_b = self.regs.validity.rx_iqmc_num_sat_cnt_b;
		rx_iqmc_num_sat_cnt_c = self.regs.validity.rx_iqmc_num_sat_cnt_c;
		rx_iqmc_num_sat_cnt_d = self.regs.validity.rx_iqmc_num_sat_cnt_d;
		return (rx_iqmc_num_sat_cnt_a,rx_iqmc_num_sat_cnt_b,rx_iqmc_num_sat_cnt_c,rx_iqmc_num_sat_cnt_d);
	#rx_iqmc_num_sat_cnt
	
	@funcDecorator
	def rx_iqmc_win_sel(self,rx_iqmc_win_sel):
		"""0 Hanning window, 1 Averaging, 2 Blackman Harris, 3 invalid"""
		self.regs.fft_window.rx_iqmc_win_sel = rx_iqmc_win_sel;
	#rx_iqmc_win_sel
	
	@funcDecorator
	def rx_iqmc_num_bin(self,rx_iqmc_num_bin):
		"""Aggregation will happen for bins from [-negMinBin, maxBin]. Negative Bin Index m, is the same as 128-m in the actual FFT output. 
		Such an option enables us to optimize the Aggregation processing to be only for the required bins """
		self.regs.aggregator.rx_iqmc_num_bin = rx_iqmc_num_bin;
	#rx_iqmc_num_bin
	
	@funcDecorator
	def rx_iqmc_num_blk_drop(self,rx_iqmc_num_blk_drop):
		"""Disregard programmed no of FFT blocks after start of every aggregation. Actual no of blocks dropped = programmed value + 5 
		(4 blocks are taken for resetting internal aggregator memory and 1 more is taken extra)"""
		self.regs.aggregator.rx_iqmc_num_blk_drop = rx_iqmc_num_blk_drop;
	#rx_iqmc_num_blk_drop
	
	@funcDecorator
	def rx_iqmc_blklen_aggr(self,rx_iqmc_blklen_aggr):
		"""Num blocks of to be aggregated. Each channel will get 0.25 the programmed number. 
		Default corresponds to 250*2.6us = .65 ms for 2x i/f rate and 250 MHz Estimator Clock ."""
		self.regs.aggregator.rx_iqmc_blklen_aggr = rx_iqmc_blklen_aggr;
	#rx_iqmc_blklen_aggr
	
	@funcDecorator
	def rx_iqmc_slope_thrsh(self,rx_iqmc_slope_thrsh1,rx_iqmc_slope_thrsh2):
		"""slope threshold in linear domain in  format. Default corresponds to 1.875 (5.46 dB)
		slope threshold in linear domain in  format. Default corresponds to 1.25 (1.94 dB)"""
		self.regs.aggregator.rx_iqmc_slope_thrsh1 = int(8.0*math.pow(10.0,rx_iqmc_slope_thrsh1/20.0));
		self.regs.aggregator.rx_iqmc_slope_thrsh2 = int(8.0*math.pow(10.0,rx_iqmc_slope_thrsh2/20.0));
	#rx_iqmc_slope_thrsh
	
	@funcDecorator
	def rx_iqmc_sig_lvl_thrsh(self,rx_iqmc_sig_lvl_thrsh):
		"""Sig level threshold in linear domain upto -72 dBFS. Register value format is . 
		Check should be if |X|> reg_value/4096. Default corresponds to power of 20*log10(7/4096) =-55.3 dBFs
		(-52 dBFs/bin is the min signal to be detected + 2 dB loss due to window scaling)"""
		self.regs.aggregator.rx_iqmc_sig_lvl_thrsh = int(4096.0*math.pow(10.0,rx_iqmc_sig_lvl_thrsh/20.0));
	#rx_iqmc_num_blk_drop
	
	@funcDecorator
	def rx_iqmc_ratio_thresh(self,rx_iqmc_ratio_thresh):
		"""Signal to Image Ratio thresh in linear scale. Format is . Default of 13 corresponds to 10.2 dB threshold. 
		Check should be if |Xsig|>reg_value*|Ximage|. Two fractional bits increase resolution near the 0 dB thresh region"""
		self.regs.aggregator.rx_iqmc_ratio_thresh = int(4.0*math.pow(10.0,rx_iqmc_ratio_thresh/20.0));
	#rx_iqmc_ratio_thresh
	
	@funcDecorator
	def rx_iqmc_fw_done_ctrl(self,rx_iqmc_fw_done):
		"""fw done related controls"""
		self.regs.aggregator.rx_iqmc_fw_done = rx_iqmc_fw_done;
	#rx_iqmc_fw_done_ctrl
	
	@funcDecorator
	def rx_iqmc_xfer2sw_ctrl(self,rx_iqmc_xfer2sw):
		"""xfer flag related controls"""
		self.regs.aggregator.rx_iqmc_xfer2sw = rx_iqmc_xfer2sw;
	#rx_iqmc_xfer2sw_ctrl
	
	@funcDecorator
	def display_aggr_output(self,channel_id,bin_id):
		memory_base_address=0x31000000+0x20;
		"""For first bin
		16 h0000 {12 d0,Psig} unsigned 0 extended from 20 bits to 32 bits
		16 h0004: {12 d0,Pimg}  unsigned 0 extended from 20 bits to 32 bits
		16 h0008: {{2{CorrI[29]}},CorrI} signed sign extended from 30 bits to 32 bits
		16 h000C: {{2{CorrQ[29]}},CorrQ} signed sign extended from 30 bits to 32 bits
		16 h0010: {{16 d0,Var} Unsigned 0 extended from 16 bits to 32 bits
		16 h0014: {19 d0,N}unsigned 0 extended from 13 bits to 32 bits
		16 h0018 to 16 h001C is unused.
		For Nth bin the address is offset by N*32
		For Common Power the address is
		16 h4000{12 d0,Pcommon} unsigned 0 extended from 20 bits to 32 bits
		Nth bin  is offset by N*4"""
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		numBytesPerBin = numBytesPerField * numFields;
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin ;
		matrix = [0 for i in range(10)]
		for fieldId in range (0,numFields):
			matrix[fieldId] = self.readMem32(currAddr);
			info ("Addr = "+str(hex(currAddr))+" , Field "+str(fieldName[fieldId])+" = "+str(matrix[fieldId]));
			currAddr = currAddr + numBytesPerField;
		Psig	= matrix[0];
		Pimg	= matrix[1];
		#if (CorrI/pow(2,29)>=1):
		CorrI	= self.twos_comp(matrix[2],32);
		CorrQ	= self.twos_comp(matrix[3],32);
		Var		= matrix[4];
		N		= matrix[5];
		Pcommon	= matrix[6];
		Nvalid	= matrix[7];
		if (CorrI<0):
			beta_i_neg = 1
		else:
			beta_i_neg = 0
		if (CorrQ<0):
			beta_q_neg = 1
		else:
			beta_q_neg = 0
		if (Pcommon!=0):
			Pcommon = 10.0*math.log10(matrix[6]/2.0**20.0);
		else:
			Pcommon = -100.0;
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", N = "+str(N))
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Nvalid = "+str(Nvalid))
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Pcommon = "+str(Pcommon))
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Var = "+str(Var))
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", CorrI = "+str(CorrI))
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", CorrQ = "+str(CorrQ))
		#if (Psig!=0 or Pimg!=0 or CorrI!=0 or CorrQ!=0 or Var!=0 or N!=0 or Pcommon!=0 or Nvalid!=0):
			#warning("Non zero value observed")#Not needed now
		if (Psig!=0 and CorrI!=0 and CorrQ!=0):
			beta_i = 20*math.log10(math.fabs(CorrI/(Psig*2**9.0)));
			beta_q = 20*math.log10(math.fabs(CorrQ/(Psig*2**9.0)));
			beta = 20*math.log10(math.sqrt(math.pow(CorrI/(Psig*2**9.0),2)+math.pow(CorrQ/(Psig*2**9.0),2)));
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", beta_i = "+str(beta_i))
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", beta_q = "+str(beta_q))
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", beta = "+str(beta))
		else:
			#error("//Power is zero debug");
			beta_i=0;
			beta_q=0;
			beta=0;
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", beta_i is zero")
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", beta_q is zero")
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", beta is zero")
		#beta = beta_i+1j*beta_q;
		if (Psig!=0):
			#warning("Hurray non zero signal power observed")
			Psig=10*math.log10(matrix[0]/2.0**20)
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Psig = "+str(Psig))
		else:
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Psig is zero")
		if (Pimg!=0):
			Pimg=10*math.log10(matrix[1]/2.0**20)
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Pimg = "+str(Pimg))
		else:
			warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Pimg is zero")
		return(beta,beta_i,beta_q,beta_i_neg,beta_q_neg,Psig,N,Nvalid,Pcommon);
	#display_aggr_output
	
	def number_of_blocks(self,channel_id,bin_id):
		memory_base_address=0x31000000+0x20;
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		numBytesPerBin = numBytesPerField * numFields;
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		matrix = [0 for i in range(10)]
		fieldId = 5
		currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin + numBytesPerField * fieldId;
		matrix[fieldId] = self.readMem32(currAddr);
		fieldId = 7
		currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin + numBytesPerField * fieldId;
		matrix[fieldId] = self.readMem32(currAddr);
		N		= matrix[5];
		Nvalid	= matrix[7];
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", N = "+str(N))
		warning("channel_id = "+str(channel_id)+", bin_id = "+str(bin_id)+", Nvalid = "+str(Nvalid))
		return (N,Nvalid)
	
	@funcDecorator
	def display_aggr_output_all(self):
		memory_base_address=0x31000000+0x20;
		"""For first bin
		16 h0000 {12 d0,Psig} unsigned 0 extended from 20 bits to 32 bits
		16 h0004: {12 d0,Pimg}  unsigned 0 extended from 20 bits to 32 bits
		16 h0008: {{2{CorrI[29]}},CorrI} signed sign extended from 30 bits to 32 bits
		16 h000C: {{2{CorrQ[29]}},CorrQ} signed sign extended from 30 bits to 32 bits
		16 h0010: {{16 d0,Var} Unsigned 0 extended from 16 bits to 32 bits
		16 h0014: {19 d0,N}unsigned 0 extended from 13 bits to 32 bits
		16 h0018 to 16 h001C is unused.
		For Nth bin the address is offset by N*32
		For Common Power the address is
		16 h4000{12 d0,Pcommon} unsigned 0 extended from 20 bits to 32 bits
		Nth bin  is offset by N*4"""
		numBin = 128;
		numchannels = 4;
		for channel_id in range (0,numchannels):
			for bin_id in range (0,numBin):
				self.display_aggr_output(channel_id,bin_id);
	#display_aggr_output_all
	
	@funcDecorator
	def display_aggr_output_all_ch(self,channel_id):
		memory_base_address=0x31000000+0x20;
		"""For first bin
		16 h0000 {12 d0,Psig} unsigned 0 extended from 20 bits to 32 bits
		16 h0004: {12 d0,Pimg}  unsigned 0 extended from 20 bits to 32 bits
		16 h0008: {{2{CorrI[29]}},CorrI} signed sign extended from 30 bits to 32 bits
		16 h000C: {{2{CorrQ[29]}},CorrQ} signed sign extended from 30 bits to 32 bits
		16 h0010: {{16 d0,Var} Unsigned 0 extended from 16 bits to 32 bits
		16 h0014: {19 d0,N}unsigned 0 extended from 13 bits to 32 bits
		16 h0018 to 16 h001C is unused.
		For Nth bin the address is offset by N*32
		For Common Power the address is
		16 h4000{12 d0,Pcommon} unsigned 0 extended from 20 bits to 32 bits
		Nth bin  is offset by N*4"""
		numBin = 128;
		numchannels = 4;
		observed_bin_list = [];
		for bin_id in range (0,numBin):
			(beta,beta_i,beta_q,beta_i_neg,beta_q_neg,Psig,N,Nvalid)=self.display_aggr_output(channel_id,bin_id);
			if (Psig!=0):
				observed_bin_list.append(bin_id)
		warning(observed_bin_list)
		
	#display_aggr_output_all_ch
	
	def twos_comp(self, val, bits):
		"""compute the 2's complement of int value val"""
		if (val & (1 << (bits - 1))) != 0: # if sign bit is set e.g., 8bit: 128-255
			val = val - (1 << bits)        # compute negative value
		return (val)
	#twos_comp
	
	@funcDecorator
	def display_Numblocks_for_bins(self):
		"""Number of blocks for each bin and channel"""
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		numChannels = 4;
		field_No = 5;
		matrix = [[0 for i in xrange(128)] for i in xrange(4)]
		numBytesPerBin = numBytesPerField * numFields;
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		for channel_id in range (0,numChannels):
			for bin_id in range (0,numBin):
				currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin + field_No * numBytesPerField;
				matrix[channel_id][bin_id] = self.readMem32(currAddr);
				info ("Addr = "+str(hex(currAddr))+" , Field "+str(fieldName[field_No])+" = "+str(matrix[channel_id][bin_id])+" , channel_id = "+str(channel_id)+" , bin_id = "+str(bin_id));
		
	def twos_comp_rev(val, bits):
		"""compute the 2's complement rev of int value val"""
		if val < -(1 << (bits-1)):
			error("//Cannot be represented over here")
			val=0
		elif val < 0: # if sign bit is set e.g., 8bit: 128-255
			val = (1 << bits) + val        # compute negative value
		elif (val==(1 << (bits-1))):
			error("//Cannot be represented over here")
			val=0
		return ((val))
		
	def configure_interface_rate(self,interface_rate_ab,interface_rate_cd,clk_dig,common_clock_domain,delta_Nstart,delta_Nwby4):
		"""settings for configuring the interface rate"""
		#delta=8.0
		Nwby4 = [0 for i in range(6)]
		Nstart = [0 for i in range(6)]
		index_ab=self.int_rate_to_index(interface_rate_ab)
		index_cd=self.int_rate_to_index(interface_rate_cd)
		if (clk_dig==24.0 or clk_dig==48.0):
			Nwby4[0] 	= 84.0	#- 1.0			
			Nwby4[1] 	= 90.0	#- 1.0	
			Nwby4[2] 	= 96.0	#- 1.0	
			Nwby4[3] 	= 141.0	#- 1.0
			Nwby4[4] 	= 188.0	#- 1.0
			Nwby4[5] 	= 282.0	#- 1.0
			Nstart[0] 	= 606
			Nstart[1] 	= 630
			Nstart[2] 	= 654
			Nstart[3] 	= 834
			Nstart[4] 	= 1022
			Nstart[5] 	= 1398			
		elif (clk_dig==27.0 or clk_dig==54.0):
			Nwby4[0] 	= 83.0	#- 1.0
			Nwby4[1] 	= 90.0	#- 1.0
			Nwby4[2] 	= 94.0  #- 1.0
			Nwby4[3] 	= 126.0 #- 1.0
			Nwby4[4] 	= 168.0 #- 1.0
			Nwby4[5] 	= 252.0 #- 1.0
			Nstart[0] 	= 602	
			Nstart[1] 	= 630	
			Nstart[2] 	= 646	
			Nstart[3] 	= 774	
			Nstart[4] 	= 942	
			Nstart[5] 	= 1278
		elif (clk_dig==28.0 or clk_dig==56.0):
			Nwby4[0] 	= 82.0	#- 1.0
			Nwby4[1] 	= 87.0	#- 1.0
			Nwby4[2] 	= 92.0  #- 1.0
			Nwby4[3] 	= 120.0 #- 1.0
			Nwby4[4] 	= 160.0 #- 1.0
			Nwby4[5] 	= 240.0 #- 1.0
			Nstart[0] 	= 598	
			Nstart[1] 	= 618	
			Nstart[2] 	= 638	
			Nstart[3] 	= 750	
			Nstart[4] 	= 910	
			Nstart[5] 	= 1230
		if (index_ab==index_cd):
			self.rx_iqmc_configure_blklen(Nwby4[index_ab],Nwby4[index_ab])
			self.regs.data_collect.rx_iqmc_rd_strt_offset = Nstart[index_ab]
		else:
			Nwby4_chAB_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_ab)-1.0
			Nwby4_chCD_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_cd)-1.0
			self.rx_iqmc_configure_blklen(Nwby4_chAB_reg,Nwby4_chCD_reg)		
			#self.rx_iqmc_cmn_dom_sel(common_clock_domain)
			#self.regs.data_collect.rx_iqmc_clken_dom_ab = 0;
			#self.regs.data_collect.rx_iqmc_clken_dom_cd = 1;
			#self.regs.data_collect.rx_iqmc_cmn_dom_sel = common_clock_domain;
			if (common_clock_domain==0):
				Nstart = 4.0*(Nwby4_chAB_reg+1.0)+ 254.0 + 2.0*delta
				#self.regs.data_collect.rx_iqmc_clken_dom_ab = 1;
				#self.regs.data_collect.rx_iqmc_clken_dom_cd = 0;
			else:
				Nstart = 4.0*(Nwby4_chCD_reg+1.0)+ 254.0 + 2.0*delta
				#self.regs.data_collect.rx_iqmc_clken_dom_ab = 0;
				#self.regs.data_collect.rx_iqmc_clken_dom_cd = 1;
			self.regs.data_collect.rx_iqmc_rd_strt_offset = Nstart
		#configure_interface_rate
	
	def configure_interface_rate_new(self,interface_rate_ab,interface_rate_cd,clk_dig,common_clock_domain,delta,rxiqmc_param):
		"""settings for configuring the interface rate"""
		#delta=8.0
		Nwby4 = [0 for i in range(6)]
		Nstart_not_used = [0 for i in range(6)]
		index_ab=self.int_rate_to_index(interface_rate_ab)
		index_cd=self.int_rate_to_index(interface_rate_cd)
		
		if (clk_dig==24.0 or clk_dig==48.0):
			if (rxiqmc_param['estim_clk_div_dither_en']==0):
				Nwby4[0] 	= 84.0	#- 1.0			
				Nwby4[1] 	= 90.0	#- 1.0	
				Nwby4[2] 	= 96.0	#- 1.0	
				Nwby4[3] 	= 141.0	#- 1.0
				Nwby4[4] 	= 188.0	#- 1.0
				Nwby4[5] 	= 282.0	#- 1.0
			else:
				Nwby4[0] 	= 82.0	#- 1.0			
				Nwby4[1] 	= 87.0	#- 1.0	
				Nwby4[2] 	= 92.0	#- 1.0	
				Nwby4[3] 	= 120.0	#- 1.0
				Nwby4[4] 	= 160.0	#- 1.0
				Nwby4[5] 	= 240.0	#- 1.0
			Nstart_not_used[0] 	= 606
			Nstart_not_used[1] 	= 630
			Nstart_not_used[2] 	= 654
			Nstart_not_used[3] 	= 834
			Nstart_not_used[4] 	= 1022
			Nstart_not_used[5] 	= 1398	
			
		elif (clk_dig==27.0 or clk_dig==54.0):
			if (rxiqmc_param['estim_clk_div_dither_en']==0):
				Nwby4[0] 	= 84.0	#- 1.0 # earlier was 83
				Nwby4[1] 	= 90.0	#- 1.0
				Nwby4[2] 	= 94.0  #- 1.0
				Nwby4[3] 	= 126.0 #- 1.0
				Nwby4[4] 	= 168.0 #- 1.0
				Nwby4[5] 	= 252.0 #- 1.0
			else:
				Nwby4[0] 	= 84.0	#- 1.0 # earlier was 83
				Nwby4[1] 	= 90.0	#- 1.0
				Nwby4[2] 	= 94.0  #- 1.0
				Nwby4[3] 	= 126.0 #- 1.0
				Nwby4[4] 	= 168.0 #- 1.0
				Nwby4[5] 	= 252.0 #- 1.0
			Nstart_not_used[0] 	= 602	
			Nstart_not_used[1] 	= 630	
			Nstart_not_used[2] 	= 646	
			Nstart_not_used[3] 	= 774	
			Nstart_not_used[4] 	= 942	
			Nstart_not_used[5] 	= 1278
			
		elif (clk_dig==28.0 or clk_dig==56.0):
			if (rxiqmc_param['estim_clk_div_dither_en']==0):
				Nwby4[0] 	= 82.0	#- 1.0
				Nwby4[1] 	= 87.0	#- 1.0
				Nwby4[2] 	= 92.0  #- 1.0
				Nwby4[3] 	= 120.0 #- 1.0
				Nwby4[4] 	= 160.0 #- 1.0
				Nwby4[5] 	= 240.0 #- 1.0
			else:
				Nwby4[0] 	= 82.0	#- 1.0			
				Nwby4[1] 	= 87.0	#- 1.0	
				Nwby4[2] 	= 92.0	#- 1.0	
				Nwby4[3] 	= 120.0	#- 1.0
				Nwby4[4] 	= 160.0	#- 1.0
				Nwby4[5] 	= 240.0	#- 1.0
				
			Nstart_not_used[0] 	= 598
			Nstart_not_used[1] 	= 618	
			Nstart_not_used[2] 	= 638	
			Nstart_not_used[3] 	= 750	
			Nstart_not_used[4] 	= 910	
			Nstart_not_used[5] 	= 1230
			
		if (rxiqmc_param['delta_enable']==1):
			Nwby4_chAB_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_ab) - 1.0 + delta
			Nwby4_chCD_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_cd) - 1.0 + delta
			if (rxiqmc_param['ab_only_valid']==1):
				Nwby4_chAB_reg = (Nwby4[index_ab]) - 1.0 + delta
				Nwby4_chCD_reg = (Nwby4[index_ab]) - 1.0 + delta
			elif (rxiqmc_param['cd_only_valid']==1):
				Nwby4_chAB_reg = (Nwby4[index_cd]) - 1.0 + delta
				Nwby4_chCD_reg = (Nwby4[index_cd]) - 1.0 + delta
		else:
			Nwby4_chAB_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_ab) - 1.0
			Nwby4_chCD_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_cd) - 1.0
			if (rxiqmc_param['ab_only_valid']==1):
				Nwby4_chAB_reg = (Nwby4[index_ab]) - 1.0 
				Nwby4_chCD_reg = (Nwby4[index_ab]) - 1.0 
			elif (rxiqmc_param['cd_only_valid']==1):
				Nwby4_chAB_reg = (Nwby4[index_cd]) - 1.0 
				Nwby4_chCD_reg = (Nwby4[index_cd]) - 1.0
				
		self.rx_iqmc_configure_blklen(Nwby4_chAB_reg,Nwby4_chCD_reg)		
		#self.rx_iqmc_cmn_dom_sel(common_clock_domain)
		#self.regs.data_collect.rx_iqmc_clken_dom_ab = 0;
		#self.regs.data_collect.rx_iqmc_clken_dom_cd = 1;
		#self.regs.data_collect.rx_iqmc_cmn_dom_sel = common_clock_domain;
		if (common_clock_domain==0):
			Nstart = 4.0*(Nwby4_chAB_reg)+ 274.0 + 2.0*delta
			#self.regs.data_collect.rx_iqmc_clken_dom_ab = 1;
			#self.regs.data_collect.rx_iqmc_clken_dom_cd = 0;
		else:
			Nstart = 4.0*(Nwby4_chCD_reg)+ 274.0 + 2.0*delta
			#self.regs.data_collect.rx_iqmc_clken_dom_ab = 0;
			#self.regs.data_collect.rx_iqmc_clken_dom_cd = 1;
		self.regs.data_collect.rx_iqmc_rd_strt_offset = Nstart
		#configure_interface_rate_new
		
	def configure_interface_rate_for_blk_len_change(self,interface_rate_ab,interface_rate_cd,clk_dig,common_clock_domain,delta):
		"""configure_interface_rate_for_blk_len_change"""
		#delta=8.0
		Nwby4 = [0 for i in range(6)]
		Nstart_not_used = [0 for i in range(6)]
		index_ab=self.int_rate_to_index(interface_rate_ab)
		index_cd=self.int_rate_to_index(interface_rate_cd)
		if (clk_dig==24.0 or clk_dig==48.0):
			Nwby4[0] 	= 84.0	#- 1.0			
			Nwby4[1] 	= 90.0	#- 1.0	
			Nwby4[2] 	= 96.0	#- 1.0	
			Nwby4[3] 	= 141.0	#- 1.0
			Nwby4[4] 	= 188.0	#- 1.0
			Nwby4[5] 	= 282.0	#- 1.0
			Nstart_not_used[0] 	= 606
			Nstart_not_used[1] 	= 630
			Nstart_not_used[2] 	= 654
			Nstart_not_used[3] 	= 834
			Nstart_not_used[4] 	= 1022
			Nstart_not_used[5] 	= 1398			
		elif (clk_dig==27.0 or clk_dig==54.0):
			Nwby4[0] 	= 83.0	#- 1.0
			Nwby4[1] 	= 90.0	#- 1.0
			Nwby4[2] 	= 94.0  #- 1.0
			Nwby4[3] 	= 126.0 #- 1.0
			Nwby4[4] 	= 168.0 #- 1.0
			Nwby4[5] 	= 252.0 #- 1.0
			Nstart_not_used[0] 	= 602	
			Nstart_not_used[1] 	= 630	
			Nstart_not_used[2] 	= 646	
			Nstart_not_used[3] 	= 774	
			Nstart_not_used[4] 	= 942	
			Nstart_not_used[5] 	= 1278
		elif (clk_dig==28.0 or clk_dig==56.0):
			Nwby4[0] 	= 82.0	#- 1.0
			Nwby4[1] 	= 87.0	#- 1.0
			Nwby4[2] 	= 92.0  #- 1.0
			Nwby4[3] 	= 120.0 #- 1.0
			Nwby4[4] 	= 160.0 #- 1.0
			Nwby4[5] 	= 240.0 #- 1.0
			Nstart_not_used[0] 	= 598	
			Nstart_not_used[1] 	= 618	
			Nstart_not_used[2] 	= 638	
			Nstart_not_used[3] 	= 750	
			Nstart_not_used[4] 	= 910	
			Nstart_not_used[5] 	= 1230
		
		Nwby4_chAB_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_ab) - 1.0 + delta
		Nwby4_chCD_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_cd) - 1.0 + delta
		self.rx_iqmc_configure_blklen(Nwby4_chAB_reg,Nwby4_chCD_reg)		
		if (common_clock_domain==0):
			Nstart = 4.0*(Nwby4_chAB_reg)+ 274.0 + 2.0*delta
		else:
			Nstart = 4.0*(Nwby4_chCD_reg)+ 274.0 + 2.0*delta
		self.regs.data_collect.rx_iqmc_rd_strt_offset = Nstart
	#configure_interface_rate_for_blk_len_change
		
		
	@funcDecorator
	def settings_for_different_interface_rate(self,interface_rate):
		"""Settings that should be done for the rxiqmc to work for the different interface rates"""
		"""Delta	8										
		CLKDIG	24									CLKDIG	27							CLKDIG	28	
		Rx Rate	divRatio	margin	Nwby4	Nstart	divRatio	margin	Nwby4	Nstart	divRatio	margin	Nwby4	Nstart
		1		6			0		82 		354		7		0			83		355		7			0		82		354
		1.5		6			0		87 		359		7		2			90		362		7			0		87		359
		2		6			0		92 		364		7		1			94		366		7			0		92		364
		3		6			1		121		393		7		1			126		398		7			0		120		392
		4		6			4		164		436		7		2			168		440		7			0		160		432
		6		6			6		246		518		7		3			252		524		7			0		240		512"""
		"""The used value of T is T+4.
		So Nw =Nw_config+1

		The rd_start_delay to be configured = N_strat_doc+3*Nw-2

		For e.g if 96 is configured as T/4 we need to add 3*97-2=289 to the computed value.
		"""
		
		"""0.4 version table 
		Delta	8							
		CLKDIG	24					CLKDIG	27					CLKDIG	28	
		Rx Rate	margin	Nwby4	Nstart	margin	Nwby4	Nstart	margin	Nwby4	Nstart
		1		0		84		606		0		83		602		0		82		598
		1.5		0		90		630		2		90		630		0		87		618
		2		0		96		654		1		94		646		0		92		638
		3		1		141		834		1		126		774		0		120		750
		4		1		188		1022	2		168		942		0		160		910
		6		2		282		1398	3		252		1278	0		240		1230
		"""
		if (interface_rate==1.0):
			rx_iqmc_blklen_by4_ab = 84 
			N_strat_doc = 606
		elif (interface_rate==1.5):
			rx_iqmc_blklen_by4_ab = 90
			N_strat_doc = 630			
		elif (interface_rate==2.0):
			rx_iqmc_blklen_by4_ab = 96 
			N_strat_doc = 654
		elif (interface_rate==3.0):
			rx_iqmc_blklen_by4_ab = 141
			N_strat_doc = 834
		elif (interface_rate==4.0):
			rx_iqmc_blklen_by4_ab = 188
			N_strat_doc = 1022
		elif (interface_rate==6.0):
			rx_iqmc_blklen_by4_ab = 282
			N_strat_doc = 1398
		else:
			error("//Invalid interface rate")
		#rx_iqmc_rd_strt_offset = N_strat_doc + 3.0*(rx_iqmc_blklen_by4_ab+1.0)-2.0
		rx_iqmc_rd_strt_offset = N_strat_doc 
		info ("rx_iqmc_rd_strt_offset = "+str(rx_iqmc_rd_strt_offset))
		self.rx_iqmc_configure_blklen(rx_iqmc_blklen_by4_ab,rx_iqmc_blklen_by4_ab)
		self.regs.data_collect.rx_iqmc_rd_strt_offset = rx_iqmc_rd_strt_offset
	#settings_for_different_interface_rate
	
	def settings_for_diff_int_rate_between_2r(self,interface_rate_ab,interface_rate_cd,common_clock_domain,delta):
		"""settings_for_diff_int_rate_between_2r"""
		#delta=8.0
		Nwby4 = [0 for i in range(6)]
		Nwby4[0] = 84.0	
		Nwby4[1] = 90.0	
		Nwby4[2] = 96.0
		Nwby4[3] = 141.0
		Nwby4[4] = 188.0
		Nwby4[5] = 282.0
		index_ab=self.int_rate_to_index(interface_rate_ab)
		index_cd=self.int_rate_to_index(interface_rate_cd)
		Nwby4_chAB_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_ab)-1.0
		Nwby4_chCD_reg = (max(Nwby4[index_ab]/interface_rate_ab,Nwby4[index_cd]/interface_rate_cd)*interface_rate_cd)-1.0
		self.rx_iqmc_configure_blklen(Nwby4_chAB_reg,Nwby4_chCD_reg)		
		self.rx_iqmc_cmn_dom_sel(common_clock_domain)
		if (common_clock_domain==0):
			Nstart = 4.0*(Nwby4_chAB_reg+1.0)+ 254.0 + 2.0*delta
		else:
			Nstart = 4.0*(Nwby4_chCD_reg+1.0)+ 254.0 + 2.0*delta
		self.regs.data_collect.rx_iqmc_rd_strt_offset = Nstart
		
	#settings_for_diff_int_rate_between_2r
	
	def int_rate_to_index(self,interface_rate):
		if (interface_rate==1.0):
			index=0
		elif (interface_rate==1.5):
			index=1
		elif (interface_rate==2.0):
			index=2
		elif (interface_rate==3.0):
			index=3
		elif (interface_rate==4.0):
			index=4
		elif (interface_rate==6.0):
			index=5
		return(index)
	#int_rate_to_index
	
	@funcDecorator
	def display_aggr_output_raw(self,channel_id,bin_id):
		memory_base_address=0x31000000+0x20;
		"""For first bin
		16 h0000 {12 d0,Psig} unsigned 0 extended from 20 bits to 32 bits
		16 h0004: {12 d0,Pimg}  unsigned 0 extended from 20 bits to 32 bits
		16 h0008: {{2{CorrI[29]}},CorrI} signed sign extended from 30 bits to 32 bits
		16 h000C: {{2{CorrQ[29]}},CorrQ} signed sign extended from 30 bits to 32 bits
		16 h0010: {{16 d0,Var} Unsigned 0 extended from 16 bits to 32 bits
		16 h0014: {19 d0,N}unsigned 0 extended from 13 bits to 32 bits
		16 h0018 to 16 h001C is unused.
		For Nth bin the address is offset by N*32
		For Common Power the address is
		16 h4000{12 d0,Pcommon} unsigned 0 extended from 20 bits to 32 bits
		Nth bin  is offset by N*4"""
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		required_fields = [0,2,3,5]
		numBytesPerBin = numBytesPerField * numFields;
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		if (bin_id<0):
			bin_id=128+bin_id;
		currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin ;
		matrix = [0 for i in range(0,numFields)]
		for fieldId in required_fields:
			currAddr1 = currAddr + numBytesPerField * fieldId;
			matrix[fieldId] = self.readMem32(int(currAddr1));
			#info ("Addr = "+str(hex(currAddr))+" , Field "+str(fieldName[fieldId])+" = "+str(matrix[fieldId]));
		Psig	= matrix[0];
		N = matrix[5];
		info("//Number of blocks in display_aggr_output_raw="+str(N)+" channel_id="+str(channel_id)+" bin_id="+str(bin_id));
		#if (CorrI/pow(2,29)>=1):
		CorrI	= self.twos_comp(matrix[2],32);
		CorrQ	= self.twos_comp(matrix[3],32);
		return(Psig,CorrI,CorrQ,N);
	#display_aggr_output
	
	def compute_beta(self,Psig_raw,CorrI_raw,CorrQ_raw,Number_of_interrupts):
		number_of_channels=4;
		beta_i=[0 for i in range(number_of_channels)]
		beta_q=[0 for i in range(number_of_channels)]
		beta=[0 for i in range(number_of_channels)]
		Psig=[0 for i in range(number_of_channels)]
		CorrI=[0 for i in range(number_of_channels)]
		CorrQ=[0 for i in range(number_of_channels)]
		beta_i_neg=[0 for i in range(number_of_channels)]
		beta_q_neg=[0 for i in range(number_of_channels)]
		for channel_id in range (0,number_of_channels):
			for interrupt_number in range (0,Number_of_interrupts):
				Psig[channel_id] = Psig[channel_id]+ Psig_raw[channel_id][interrupt_number]
				CorrI[channel_id] = CorrI[channel_id]+ CorrI_raw[channel_id][interrupt_number]
				CorrQ[channel_id] = CorrQ[channel_id]+ CorrQ_raw[channel_id][interrupt_number]
			Psig[channel_id]=Psig[channel_id]/Number_of_interrupts
			CorrI[channel_id]=CorrI[channel_id]/Number_of_interrupts
			CorrQ[channel_id]=CorrQ[channel_id]/Number_of_interrupts
			if (CorrI[channel_id]<0):
				beta_i_neg[channel_id] = 1
			else:
				beta_i_neg[channel_id] = 0
			if (CorrQ[channel_id]<0):
				beta_q_neg[channel_id] = 1
			else:
				beta_q_neg[channel_id] = 0
			if (Psig[channel_id]!=0 and (CorrI[channel_id]!=0 or CorrQ[channel_id]!=0)):
				beta_i[channel_id] = 20*np.log10(math.fabs(CorrI[channel_id]/(Psig[channel_id]*2**9.0)));
				beta_q[channel_id] = 20*np.log10(math.fabs(CorrQ[channel_id]/(Psig[channel_id]*2**9.0)));
				beta[channel_id] = 20*np.log10(math.sqrt(math.pow(CorrI[channel_id]/(Psig[channel_id]*2**9.0),2)+math.pow(CorrQ[channel_id]/(Psig[channel_id]*2**9.0),2)));
				info("//channel_id = "+str(channel_id)+", beta_i = "+str(beta_i[channel_id]))
				info("//channel_id = "+str(channel_id)+", beta_q = "+str(beta_q[channel_id]))
				info("//channel_id = "+str(channel_id)+", beta = "+str(beta[channel_id]))
			if (Psig[channel_id]!=0):
				Psig[channel_id]=10*np.log10(Psig[channel_id]/2.0**20)
				info("//channel_id = "+str(channel_id)+", Psig = "+str(Psig[channel_id]))
		return(beta,beta_i,beta_q,beta_i_neg,beta_q_neg,Psig)

	def compute_beta_single_interrupt(self,Psig_raw,CorrI_raw,CorrQ_raw):
		number_of_channels=4;
		beta_i=[0 for i in range(number_of_channels)]
		beta_q=[0 for i in range(number_of_channels)]
		beta=[0 for i in range(number_of_channels)]
		Psig=[0 for i in range(number_of_channels)]
		CorrI=[0 for i in range(number_of_channels)]
		CorrQ=[0 for i in range(number_of_channels)]
		beta_i_neg=[0 for i in range(number_of_channels)]
		beta_q_neg=[0 for i in range(number_of_channels)]
		for channel_id in range (0,number_of_channels):
			Psig[channel_id] = Psig[channel_id]+ Psig_raw[channel_id]
			CorrI[channel_id] = CorrI[channel_id]+ CorrI_raw[channel_id]
			CorrQ[channel_id] = CorrQ[channel_id]+ CorrQ_raw[channel_id]
			if (CorrI[channel_id]<0):
				beta_i_neg[channel_id] = 1
			else:
				beta_i_neg[channel_id] = 0
			if (CorrQ[channel_id]<0):
				beta_q_neg[channel_id] = 1
			else:
				beta_q_neg[channel_id] = 0
			if (Psig[channel_id]!=0 and (CorrI[channel_id]!=0 or CorrQ[channel_id]!=0)):
				beta_i[channel_id] = 20*np.log10(math.fabs(CorrI[channel_id]/(Psig[channel_id]*2**9.0)));
				beta_q[channel_id] = 20*np.log10(math.fabs(CorrQ[channel_id]/(Psig[channel_id]*2**9.0)));
				beta[channel_id] = 20*np.log10(math.sqrt(math.pow(CorrI[channel_id]/(Psig[channel_id]*2**9.0),2)+math.pow(CorrQ[channel_id]/(Psig[channel_id]*2**9.0),2)));
				info("//channel_id = "+str(channel_id)+", beta_i = "+str(beta_i[channel_id]))
				info("//channel_id = "+str(channel_id)+", beta_q = "+str(beta_q[channel_id]))
				info("//channel_id = "+str(channel_id)+", beta = "+str(beta[channel_id]))
			if (Psig[channel_id]!=0):
				Psig[channel_id]=10*np.log10(Psig[channel_id]/2.0**20)
				info("//channel_id = "+str(channel_id)+", Psig = "+str(Psig[channel_id]))
		return(beta,beta_i,beta_q,beta_i_neg,beta_q_neg,Psig)
		
	"""def check_validity_of_bins(self,bin_number):
		pass_fail=1
		memory_base_address=0x31000000+0x20;
		number_of_channels=4
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		required_fields = [5]
		numBytesPerBin = numBytesPerField * numFields;
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		matrix = [0 for i in range(0,numFields)]
		for channel_id in range (0,number_of_channels):
			for bin_id in range (0,numBin):
				for fieldId in required_fields:
					currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin + numBytesPerField * fieldId;
					matrix[fieldId] = self.readMem32(int(currAddr));
					#info ("Addr = "+str(hex(currAddr))+" , Field "+str(fieldName[fieldId])+" = "+str(matrix[fieldId]));
				N = matrix[5]
				if (N==0 and bin_number[channel_id]==bin_id):
					error("//N does not have a valid value")
					pass_fail=0
				elif (N!=0 and bin_number[channel_id]!=bin_id):
					error("//Invalid bin present channel_id = "+str(channel_id)+", bin_id = "+str(bin_id))
					pass_fail=0
		return(pass_fail)
	#check_validity_of_bins"""
	
	def check_validity_of_bins(self,bin_number):
		memory_base_address=0x31000000+0x20;
		err_cnt=0
		number_of_channels=4
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		required_fields = [5]
		numBytesPerBin = numBytesPerField * numFields;
		N=[[0 for i in range(numBin)] for j in range(number_of_channels)]
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		matrix = [0 for i in range(0,numFields)]
		for channel_id in range (0,number_of_channels):
			for bin_id in range (0,numBin):
				for fieldId in required_fields:
					currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin + numBytesPerField * fieldId;
					matrix[fieldId] = self.readMem16(int(currAddr));
					#info ("Addr = "+str(hex(currAddr))+" , Field "+str(fieldName[fieldId])+" = "+str(matrix[fieldId]));
				N[channel_id][bin_id] = matrix[5]
				bin_valid=0
				for bin_number0 in bin_number[channel_id]:
					if (bin_id==bin_number0):
						bin_valid=1
				if (N[channel_id][bin_id]==0 and bin_valid==1):
					err_cnt=err_cnt+1
					error("//N does not have a valid value channel_id = "+str(channel_id)+", bin_id = "+str(bin_id))
				elif (N[channel_id][bin_id]!=0 and bin_valid==0):
					err_cnt=err_cnt+1
					error("//Invalid bin present channel_id = "+str(channel_id)+", bin_id = "+str(bin_id))
		return (err_cnt)
	#check_validity_of_bins
	
	def check_validity_of_bins_slope_thresh(self,bin_number,bin_offset_high,bin_offset_low):
		memory_base_address=0x31000000+0x20;
		number_of_channels=4
		numFields = 8;
		numBytesPerField = 4;
		numBin = 128;
		required_fields = [5]
		numBytesPerBin = numBytesPerField * numFields;
		fieldName = ("Psig","Pimg", "CorrI", "CorrQ", "Var", "N", "Pcommon", "Nvalid");
		matrix = [0 for i in range(0,numFields)]
		for channel_id in range (0,number_of_channels):
			for bin_id in range (0,numBin):
				for fieldId in required_fields:
					currAddr = memory_base_address + bin_id * numBytesPerBin + channel_id * numBytesPerBin * numBin + numBytesPerField * fieldId;
					matrix[fieldId] = self.readMem32(int(currAddr));
					#info ("Addr = "+str(hex(currAddr))+" , Field "+str(fieldName[fieldId])+" = "+str(matrix[fieldId]));
				N = matrix[5]
				if (N==0 and (bin_id <= bin_number[channel_id]+bin_offset_high) and (bin_id >= bin_number[channel_id]-bin_offset_low)):
					error("//N does not have a valid value channel_id = "+str(channel_id)+", bin_id = "+str(bin_id))
				elif (N!=0 and ((bin_id > bin_number[channel_id]+bin_offset_high) or (bin_id < bin_number[channel_id]-bin_offset_low))):
					error("//Invalid bin present channel_id = "+str(channel_id)+", bin_id = "+str(bin_id))
	#check_validity_of_bins
	
	def rx_iqmc_input_scale(self,rx_iqmc_inp_scale_A,rx_iqmc_inp_scale_B,rx_iqmc_inp_scale_C,rx_iqmc_inp_scale_D):
		"""rx_iqmc_input_scale"""
		self.regs.data_collect.rx_iqmc_inp_scale_A=rx_iqmc_inp_scale_A
		self.regs.data_collect.rx_iqmc_inp_scale_B=rx_iqmc_inp_scale_B
		self.regs.data_collect.rx_iqmc_inp_scale_C=rx_iqmc_inp_scale_C
		self.regs.data_collect.rx_iqmc_inp_scale_D=rx_iqmc_inp_scale_D
	#rx_iqmc_input_scale
	
	def rx_iqmc_dsa_setting_range(self,rx_iqmc_min_dsa_val_A,rx_iqmc_max_dsa_val_A,rx_iqmc_min_dsa_val_B,rx_iqmc_max_dsa_val_B,rx_iqmc_min_dsa_val_C,rx_iqmc_max_dsa_val_C,rx_iqmc_min_dsa_val_D,rx_iqmc_max_dsa_val_D):
		"""rx_iqmc_dsa_setting_range"""
		self.regs.validity.rx_iqmc_min_dsa_val_A = rx_iqmc_min_dsa_val_A;
		self.regs.validity.rx_iqmc_max_dsa_val_A = rx_iqmc_max_dsa_val_A;
		self.regs.validity.rx_iqmc_min_dsa_val_B = rx_iqmc_min_dsa_val_B;
		self.regs.validity.rx_iqmc_max_dsa_val_B = rx_iqmc_max_dsa_val_B;
		self.regs.validity.rx_iqmc_min_dsa_val_C = rx_iqmc_min_dsa_val_C;
		self.regs.validity.rx_iqmc_max_dsa_val_C = rx_iqmc_max_dsa_val_C;
		self.regs.validity.rx_iqmc_min_dsa_val_D = rx_iqmc_min_dsa_val_D;
		self.regs.validity.rx_iqmc_max_dsa_val_D = rx_iqmc_max_dsa_val_D;
	#rx_iqmc_dsa_setting_range
	
	def rx_iqmc_min_numvld_blk_thrsh(self,rx_iqmc_min_numvld_blk_thrsh_A,rx_iqmc_min_numvld_blk_thrsh_B,rx_iqmc_min_numvld_blk_thrsh_C,rx_iqmc_min_numvld_blk_thrsh_D):
		"""rx_iqmc_min_numvld_blk_thrsh"""
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_A
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_B
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_C
		self.regs.aggregator.rx_iqmc_min_numvld_blk_thrsh_D
	#rx_iqmc_min_numvld_blk_thrsh
	
	def rx_iqmc_configure_power_save_features(self,rx_iqmc_aggr_int_mem_dyn_sd_dis,rx_iqmc_aggr_cm4_mem_dyn_sd_dis,rx_iqmc_aggr_int_pwr_ds,rx_iqmc_aggr_int_pwr_sd,rx_iqmc_aggr_cm4_pwr_ds,rx_iqmc_aggr_cm4_pwr_sd,rx_iqmc_aggr_int_mem_ds_dis):
		"""rx_iqmc_configure_power_save_features"""
		self.regs.aggregator.rx_iqmc_aggr_int_mem_dyn_sd_dis = rx_iqmc_aggr_int_mem_dyn_sd_dis
		self.regs.aggregator.rx_iqmc_aggr_cm4_mem_dyn_sd_dis = rx_iqmc_aggr_cm4_mem_dyn_sd_dis
		self.regs.aggregator.rx_iqmc_aggr_int_pwr_ds = rx_iqmc_aggr_int_pwr_ds
		self.regs.aggregator.rx_iqmc_aggr_int_pwr_sd = rx_iqmc_aggr_int_pwr_sd
		self.regs.aggregator.rx_iqmc_aggr_cm4_pwr_ds = rx_iqmc_aggr_cm4_pwr_ds
		self.regs.aggregator.rx_iqmc_aggr_cm4_pwr_sd = rx_iqmc_aggr_cm4_pwr_sd
		self.regs.aggregator.rx_iqmc_aggr_int_mem_ds_dis = rx_iqmc_aggr_int_mem_ds_dis
	#rx_iqmc_configure_power_save_features
	
	def rx_iqmc_chnl_off(self,rx_iqmc_chnl_off):
		"""rx_iqmc_chnl_off"""
		self.regs.common.rx_iqmc_chnl_off=rx_iqmc_chnl_off
		
	def rx_iqmc_dsa_cnt_read(self,channel,dsa_index):
		"""rx_iqmc_dsa_cnt_read"""
		cha_start_value=304;
		chb_start_value=380;
		chc_start_value=456;
		chd_start_value=532;
		rx_iqmc_dsa_stats_clock_gate=self.regs.dsa_stats.rx_iqmc_dsa_stats_clock_gate
		if (channel==0):
			start_address	=	cha_start_value
		elif (channel==1):
			start_address	=	chb_start_value
		elif (channel==2):
			start_address	=	chc_start_value
		elif (channel==3):
			start_address	=	chd_start_value
		read_address=start_address+2*dsa_index
		#info("//read_address="+str(read_address))
		device=deviceRefs.device
		read_val0=device.readReg(read_address)&0xFF
		read_val1=device.readReg(read_address+1)&0xFF
		read_val=(read_val1<<8)+read_val0
		#info("//read_val0="+str(read_val0))
		#info("//read_val1="+str(read_val1))
		info("//dsa_cnt="+str(read_val)+" channel="+str(channel)+" dsa_index="+str(dsa_index))
		#if (read_val!=0):
			#warning("some finite read value is present")
		return(read_val)
	#rx_iqmc_dsa_cnt_read
	
	def display_all_dsa_cnts(self,channel):
		dsa_idx_max=36
		sum_of_all_dsa=0
		for dsa_index in range(0,dsa_idx_max+1):
			read_val=self.rx_iqmc_dsa_cnt_read(channel,dsa_index)
			sum_of_all_dsa=sum_of_all_dsa+read_val
		info("//channel="+str(channel)+" sum_of_all_dsa="+str(sum_of_all_dsa))
		switch_val=self.rx_iqmc_dsa_cnt_read(channel,dsa_idx_max+1)
		info("//channel="+str(channel)+" switch_val="+str(switch_val))
	
	def read_memory_error_status(self,sd_handoff_ok=0,rtl_ver_no=0.81):
		"""read_memory_error_status"""
		err_cnt=0
		if (rtl_ver_no<=0.8):
			rx_iqmc_ls_err=self.regs.mem_pwr_wrap.rx_iqmc_ls_err
			rx_iqmc_ds_err=self.regs.mem_pwr_wrap.rx_iqmc_ds_err
			rx_iqmc_sd_err=self.regs.mem_pwr_wrap.rx_iqmc_sd_err
			
			if (rx_iqmc_ls_err!=0):
				error("//wrong access rx_iqmc_ls_err="+str(hex(rx_iqmc_ls_err)))
				err_cnt=err_cnt+1
			else:
				info("//No wrong access rx_iqmc_ls_err="+str(hex(rx_iqmc_ls_err)))
			
			if (rx_iqmc_ds_err!=0):
				error("//wrong access rx_iqmc_ds_err="+str(hex(rx_iqmc_ds_err)))
				err_cnt=err_cnt+1
			else:
				info("//No wrong access rx_iqmc_ds_err="+str(hex(rx_iqmc_ds_err)))
				
			if (rx_iqmc_sd_err!=0):
				if (sd_handoff_ok==1):
					info("//wrong access rx_iqmc_sd_err="+str(hex(rx_iqmc_sd_err)))
				else:
					error("//wrong access rx_iqmc_sd_err="+str(hex(rx_iqmc_sd_err)))
					err_cnt=err_cnt+1
				"""The lsb 10 bits corresponds to the error bits for the 5 internal memories (each havin 2 bits). The next 10 bits corresponds to Handoff memories.The next 10 bits corresponds 				to Handoff memories.The next 2 bits for dram.The next 2 bits for pram.The next 2 bits for prom"""
				rx_iqmc_sd_err_Internal_memories=rx_iqmc_sd_err&0x3FF
				rx_iqmc_sd_err_Handoff_memories=(rx_iqmc_sd_err>>10)&0x3FF
				rx_iqmc_sd_err_dram=(rx_iqmc_sd_err>>20)&0x3
				rx_iqmc_sd_err_pram=(rx_iqmc_sd_err>>22)&0x3
				rx_iqmc_sd_err_prom=(rx_iqmc_sd_err>>24)&0x3
				info("//No wrong access rx_iqmc_sd_err_Internal_memories="+str(hex(rx_iqmc_sd_err_Internal_memories)))
				
				if (rx_iqmc_sd_err_Handoff_memories!=0):
					if (sd_handoff_ok==1):
						info("//No wrong access rx_iqmc_sd_err_Handoff_memories="+str(hex(rx_iqmc_sd_err_Handoff_memories)))
					else:
						error("//No wrong access rx_iqmc_sd_err_Handoff_memories="+str(hex(rx_iqmc_sd_err_Handoff_memories)))
						err_cnt=err_cnt+1
				info("//No wrong access rx_iqmc_sd_err_dram="+str(hex(rx_iqmc_sd_err_dram)))
				info("//No wrong access rx_iqmc_sd_err_pram="+str(hex(rx_iqmc_sd_err_pram)))
				info("//No wrong access rx_iqmc_sd_err_prom="+str(hex(rx_iqmc_sd_err_prom)))
				info("//------------------------------------------------------------------")
			else:
				info("//No wrong access rx_iqmc_sd_err="+str(hex(rx_iqmc_sd_err)))
		else:
			info("//Sequence has to be upgraded")
			##ls error
			rx_iqmc_ls_err_int_mem0	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_int_mem0
			rx_iqmc_ls_err_int_mem1	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_int_mem1
			rx_iqmc_ls_err_int_mem2	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_int_mem2
			rx_iqmc_ls_err_int_mem3	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_int_mem3
			rx_iqmc_ls_err_int_mem4	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_int_mem4
			rx_iqmc_ls_err_ho_mem0	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_ho_mem0
			rx_iqmc_ls_err_ho_mem1	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_ho_mem1
			rx_iqmc_ls_err_ho_mem2	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_ho_mem2
			rx_iqmc_ls_err_ho_mem3	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_ho_mem3
			rx_iqmc_ls_err_ho_mem4	=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_ho_mem4
			rx_iqmc_ls_err_dram		=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_dram
			rx_iqmc_ls_err_pram		=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_pram
			rx_iqmc_ls_err_prom		=	self.regs.mem_pwr_wrap.rx_iqmc_ls_err_prom
			##ds error
			rx_iqmc_ds_err_int_mem0	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_int_mem0
			rx_iqmc_ds_err_int_mem1	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_int_mem1
			rx_iqmc_ds_err_int_mem2	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_int_mem2
			rx_iqmc_ds_err_int_mem3	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_int_mem3
			rx_iqmc_ds_err_int_mem4	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_int_mem4
			rx_iqmc_ds_err_ho_mem0	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_ho_mem0
			rx_iqmc_ds_err_ho_mem1	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_ho_mem1
			rx_iqmc_ds_err_ho_mem2	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_ho_mem2
			rx_iqmc_ds_err_ho_mem3	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_ho_mem3
			rx_iqmc_ds_err_ho_mem4	=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_ho_mem4
			rx_iqmc_ds_err_dram		=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_dram
			rx_iqmc_ds_err_pram		=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_pram
			rx_iqmc_ds_err_prom		=	self.regs.mem_pwr_wrap.rx_iqmc_ds_err_prom
			##sd error
			rx_iqmc_sd_err_int_mem0	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_int_mem0
			rx_iqmc_sd_err_int_mem1	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_int_mem1
			rx_iqmc_sd_err_int_mem2	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_int_mem2
			rx_iqmc_sd_err_int_mem3	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_int_mem3
			rx_iqmc_sd_err_int_mem4	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_int_mem4
			rx_iqmc_sd_err_ho_mem0	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_ho_mem0
			rx_iqmc_sd_err_ho_mem1	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_ho_mem1
			rx_iqmc_sd_err_ho_mem2	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_ho_mem2
			rx_iqmc_sd_err_ho_mem3	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_ho_mem3
			rx_iqmc_sd_err_ho_mem4	=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_ho_mem4
			rx_iqmc_sd_err_dram		=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_dram
			rx_iqmc_sd_err_pram		=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_pram
			rx_iqmc_sd_err_prom		=	self.regs.mem_pwr_wrap.rx_iqmc_sd_err_prom
			
			if (rx_iqmc_ls_err_int_mem0!=0 or rx_iqmc_ls_err_int_mem1!=0 or rx_iqmc_ls_err_int_mem2!=0 or rx_iqmc_ls_err_int_mem3!=0 or rx_iqmc_ls_err_int_mem4!=0\
			or rx_iqmc_ls_err_ho_mem0!=0 or rx_iqmc_ls_err_ho_mem1!=0 or rx_iqmc_ls_err_ho_mem2!=0 or rx_iqmc_ls_err_ho_mem3!=0 or rx_iqmc_ls_err_ho_mem4!=0\
			or rx_iqmc_ls_err_dram!=0 or rx_iqmc_ls_err_pram!=0 or rx_iqmc_ls_err_prom!=0):
				error("//wrong access 	rx_iqmc_ls_err_int_mem0	="+str(hex(rx_iqmc_ls_err_int_mem0	))\
				+"						rx_iqmc_ls_err_int_mem1	="+str(hex(rx_iqmc_ls_err_int_mem1	))\
				+"						rx_iqmc_ls_err_int_mem2	="+str(hex(rx_iqmc_ls_err_int_mem2	))\
				+"						rx_iqmc_ls_err_int_mem3	="+str(hex(rx_iqmc_ls_err_int_mem3	))\
				+"						rx_iqmc_ls_err_int_mem4	="+str(hex(rx_iqmc_ls_err_int_mem4	))\
				+"						rx_iqmc_ls_err_ho_mem0	="+str(hex(rx_iqmc_ls_err_ho_mem0	))\
				+"						rx_iqmc_ls_err_ho_mem1	="+str(hex(rx_iqmc_ls_err_ho_mem1	))\
				+"						rx_iqmc_ls_err_ho_mem2	="+str(hex(rx_iqmc_ls_err_ho_mem2	))\
				+"						rx_iqmc_ls_err_ho_mem3	="+str(hex(rx_iqmc_ls_err_ho_mem3	))\
				+"						rx_iqmc_ls_err_ho_mem4	="+str(hex(rx_iqmc_ls_err_ho_mem4	))\
				+"						rx_iqmc_ls_err_dram		="+str(hex(rx_iqmc_ls_err_dram		))\
				+"						rx_iqmc_ls_err_pram		="+str(hex(rx_iqmc_ls_err_pram		))\
				+"						rx_iqmc_ls_err_prom		="+str(hex(rx_iqmc_ls_err_prom		))\
				)
				err_cnt=err_cnt+1
			else:
				info("//No wrong access 	rx_iqmc_ls_err_int_mem0	="+str(hex(rx_iqmc_ls_err_int_mem0	))\
				+"							rx_iqmc_ls_err_int_mem1	="+str(hex(rx_iqmc_ls_err_int_mem1	))\
				+"							rx_iqmc_ls_err_int_mem2	="+str(hex(rx_iqmc_ls_err_int_mem2	))\
				+"							rx_iqmc_ls_err_int_mem3	="+str(hex(rx_iqmc_ls_err_int_mem3	))\
				+"							rx_iqmc_ls_err_int_mem4	="+str(hex(rx_iqmc_ls_err_int_mem4	))\
				+"							rx_iqmc_ls_err_ho_mem0	="+str(hex(rx_iqmc_ls_err_ho_mem0	))\
				+"							rx_iqmc_ls_err_ho_mem1	="+str(hex(rx_iqmc_ls_err_ho_mem1	))\
				+"							rx_iqmc_ls_err_ho_mem2	="+str(hex(rx_iqmc_ls_err_ho_mem2	))\
				+"							rx_iqmc_ls_err_ho_mem3	="+str(hex(rx_iqmc_ls_err_ho_mem3	))\
				+"							rx_iqmc_ls_err_ho_mem4	="+str(hex(rx_iqmc_ls_err_ho_mem4	))\
				+"							rx_iqmc_ls_err_dram		="+str(hex(rx_iqmc_ls_err_dram		))\
				+"							rx_iqmc_ls_err_pram		="+str(hex(rx_iqmc_ls_err_pram		))\
				+"							rx_iqmc_ls_err_prom		="+str(hex(rx_iqmc_ls_err_prom		))\
				)
				
			if (rx_iqmc_ds_err_int_mem0!=0 or rx_iqmc_ds_err_int_mem1!=0 or rx_iqmc_ds_err_int_mem2!=0 or rx_iqmc_ds_err_int_mem3!=0 or rx_iqmc_ds_err_int_mem4!=0\
			or rx_iqmc_ds_err_ho_mem0!=0 or rx_iqmc_ds_err_ho_mem1!=0 or rx_iqmc_ds_err_ho_mem2!=0 or rx_iqmc_ds_err_ho_mem3!=0 or rx_iqmc_ds_err_ho_mem4!=0\
			or rx_iqmc_ds_err_dram!=0 or rx_iqmc_ds_err_pram!=0 or rx_iqmc_ds_err_prom!=0):
				error("//wrong access 	rx_iqmc_ds_err_int_mem0	="+str(hex(rx_iqmc_ds_err_int_mem0	))\
				+"						rx_iqmc_ds_err_int_mem1	="+str(hex(rx_iqmc_ds_err_int_mem1	))\
				+"						rx_iqmc_ds_err_int_mem2	="+str(hex(rx_iqmc_ds_err_int_mem2	))\
				+"						rx_iqmc_ds_err_int_mem3	="+str(hex(rx_iqmc_ds_err_int_mem3	))\
				+"						rx_iqmc_ds_err_int_mem4	="+str(hex(rx_iqmc_ds_err_int_mem4	))\
				+"						rx_iqmc_ds_err_ho_mem0	="+str(hex(rx_iqmc_ds_err_ho_mem0	))\
				+"						rx_iqmc_ds_err_ho_mem1	="+str(hex(rx_iqmc_ds_err_ho_mem1	))\
				+"						rx_iqmc_ds_err_ho_mem2	="+str(hex(rx_iqmc_ds_err_ho_mem2	))\
				+"						rx_iqmc_ds_err_ho_mem3	="+str(hex(rx_iqmc_ds_err_ho_mem3	))\
				+"						rx_iqmc_ds_err_ho_mem4	="+str(hex(rx_iqmc_ds_err_ho_mem4	))\
				+"						rx_iqmc_ds_err_dram		="+str(hex(rx_iqmc_ds_err_dram		))\
				+"						rx_iqmc_ds_err_pram		="+str(hex(rx_iqmc_ds_err_pram		))\
				+"						rx_iqmc_ds_err_prom		="+str(hex(rx_iqmc_ds_err_prom		))\
				)
				err_cnt=err_cnt+1
			else:
				info("//No wrong access 	rx_iqmc_ds_err_int_mem0	="+str(hex(rx_iqmc_ds_err_int_mem0	))\
				+"							rx_iqmc_ds_err_int_mem1	="+str(hex(rx_iqmc_ds_err_int_mem1	))\
				+"							rx_iqmc_ds_err_int_mem2	="+str(hex(rx_iqmc_ds_err_int_mem2	))\
				+"							rx_iqmc_ds_err_int_mem3	="+str(hex(rx_iqmc_ds_err_int_mem3	))\
				+"							rx_iqmc_ds_err_int_mem4	="+str(hex(rx_iqmc_ds_err_int_mem4	))\
				+"							rx_iqmc_ds_err_ho_mem0	="+str(hex(rx_iqmc_ds_err_ho_mem0	))\
				+"							rx_iqmc_ds_err_ho_mem1	="+str(hex(rx_iqmc_ds_err_ho_mem1	))\
				+"							rx_iqmc_ds_err_ho_mem2	="+str(hex(rx_iqmc_ds_err_ho_mem2	))\
				+"							rx_iqmc_ds_err_ho_mem3	="+str(hex(rx_iqmc_ds_err_ho_mem3	))\
				+"							rx_iqmc_ds_err_ho_mem4	="+str(hex(rx_iqmc_ds_err_ho_mem4	))\
				+"							rx_iqmc_ds_err_dram		="+str(hex(rx_iqmc_ds_err_dram		))\
				+"							rx_iqmc_ds_err_pram		="+str(hex(rx_iqmc_ds_err_pram		))\
				+"							rx_iqmc_ds_err_prom		="+str(hex(rx_iqmc_ds_err_prom		))\
				)
				
			if (rx_iqmc_sd_err_int_mem0!=0 or rx_iqmc_sd_err_int_mem1!=0 or rx_iqmc_sd_err_int_mem2!=0 or rx_iqmc_sd_err_int_mem3!=0 or rx_iqmc_sd_err_int_mem4!=0\
			or rx_iqmc_sd_err_dram!=0 or rx_iqmc_sd_err_pram!=0 or rx_iqmc_sd_err_prom!=0):
				error("//wrong access 	rx_iqmc_sd_err_int_mem0	="+str(hex(rx_iqmc_sd_err_int_mem0	))\
				+"						rx_iqmc_sd_err_int_mem1	="+str(hex(rx_iqmc_sd_err_int_mem1	))\
				+"						rx_iqmc_sd_err_int_mem2	="+str(hex(rx_iqmc_sd_err_int_mem2	))\
				+"						rx_iqmc_sd_err_int_mem3	="+str(hex(rx_iqmc_sd_err_int_mem3	))\
				+"						rx_iqmc_sd_err_int_mem4	="+str(hex(rx_iqmc_sd_err_int_mem4	))\
				+"						rx_iqmc_sd_err_dram		="+str(hex(rx_iqmc_sd_err_dram		))\
				+"						rx_iqmc_sd_err_pram		="+str(hex(rx_iqmc_sd_err_pram		))\
				+"						rx_iqmc_sd_err_prom		="+str(hex(rx_iqmc_sd_err_prom		))\
				)
				err_cnt=err_cnt+1
			else:
				info("//No wrong access 	rx_iqmc_sd_err_int_mem0	="+str(hex(rx_iqmc_sd_err_int_mem0	))\
				+"							rx_iqmc_sd_err_int_mem1	="+str(hex(rx_iqmc_sd_err_int_mem1	))\
				+"							rx_iqmc_sd_err_int_mem2	="+str(hex(rx_iqmc_sd_err_int_mem2	))\
				+"							rx_iqmc_sd_err_int_mem3	="+str(hex(rx_iqmc_sd_err_int_mem3	))\
				+"							rx_iqmc_sd_err_int_mem4	="+str(hex(rx_iqmc_sd_err_int_mem4	))\
				+"							rx_iqmc_sd_err_dram		="+str(hex(rx_iqmc_sd_err_dram		))\
				+"							rx_iqmc_sd_err_pram		="+str(hex(rx_iqmc_sd_err_pram		))\
				+"							rx_iqmc_sd_err_prom		="+str(hex(rx_iqmc_sd_err_prom		))\
				)
				
			if (rx_iqmc_sd_err_ho_mem0!=0 or rx_iqmc_sd_err_ho_mem1!=0 or rx_iqmc_sd_err_ho_mem2!=0 or rx_iqmc_sd_err_ho_mem3!=0 or rx_iqmc_sd_err_ho_mem4!=0):
				if (sd_handoff_ok==1):
					info("//wrong access 	rx_iqmc_sd_err_ho_mem0	="+str(hex(rx_iqmc_sd_err_ho_mem0	))\
					+"						rx_iqmc_sd_err_ho_mem1	="+str(hex(rx_iqmc_sd_err_ho_mem1	))\
					+"						rx_iqmc_sd_err_ho_mem2	="+str(hex(rx_iqmc_sd_err_ho_mem2	))\
					+"						rx_iqmc_sd_err_ho_mem3	="+str(hex(rx_iqmc_sd_err_ho_mem3	))\
					+"						rx_iqmc_sd_err_ho_mem4	="+str(hex(rx_iqmc_sd_err_ho_mem4	))\
					)
				else:
					error("//wrong access 	rx_iqmc_sd_err_ho_mem0	="+str(hex(rx_iqmc_sd_err_ho_mem0	))\
					+"						rx_iqmc_sd_err_ho_mem1	="+str(hex(rx_iqmc_sd_err_ho_mem1	))\
					+"						rx_iqmc_sd_err_ho_mem2	="+str(hex(rx_iqmc_sd_err_ho_mem2	))\
					+"						rx_iqmc_sd_err_ho_mem3	="+str(hex(rx_iqmc_sd_err_ho_mem3	))\
					+"						rx_iqmc_sd_err_ho_mem4	="+str(hex(rx_iqmc_sd_err_ho_mem4	))\
					)
					err_cnt=err_cnt+1
			else:
				if (sd_handoff_ok==1):
					error("//no wrong access 	rx_iqmc_sd_err_ho_mem0	="+str(hex(rx_iqmc_sd_err_ho_mem0	))\
					+"							rx_iqmc_sd_err_ho_mem1	="+str(hex(rx_iqmc_sd_err_ho_mem1	))\
					+"							rx_iqmc_sd_err_ho_mem2	="+str(hex(rx_iqmc_sd_err_ho_mem2	))\
					+"							rx_iqmc_sd_err_ho_mem3	="+str(hex(rx_iqmc_sd_err_ho_mem3	))\
					+"							rx_iqmc_sd_err_ho_mem4	="+str(hex(rx_iqmc_sd_err_ho_mem4	))\
					)
					err_cnt=err_cnt+1
				else:
					info("//no wrong access 	rx_iqmc_sd_err_ho_mem0	="+str(hex(rx_iqmc_sd_err_ho_mem0	))\
					+"							rx_iqmc_sd_err_ho_mem1	="+str(hex(rx_iqmc_sd_err_ho_mem1	))\
					+"							rx_iqmc_sd_err_ho_mem2	="+str(hex(rx_iqmc_sd_err_ho_mem2	))\
					+"							rx_iqmc_sd_err_ho_mem3	="+str(hex(rx_iqmc_sd_err_ho_mem3	))\
					+"							rx_iqmc_sd_err_ho_mem4	="+str(hex(rx_iqmc_sd_err_ho_mem4	))\
					)
				
		return(err_cnt)
#RxIqmcEstim