from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

from mFuncDecorator import *
from common.mDeviceConstants import *
from mTxTopConst import *
import random
import math
class TxIqmcFw(projectBaseClass):
	"""Contains TxFW specific functions self.regs=device.TX.TXIQMC.tx_iqmc """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.errorList=['','']
	#__init__
	
	@errorLevelLogDecorator
	@funcDecorator
	def function_name(self,parameters):
		"""Description"""
		"""Definition"""
	#function_name		
	
#TxIqmcFw