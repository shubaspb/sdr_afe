from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

from mFuncDecorator import *
import mTxIqmcEstim
reload(mTxIqmcEstim)
from mTxIqmcEstim import TxIqmcEstim

import mTxIqmcFw
reload(mTxIqmcFw)
from mTxIqmcFw import TxIqmcFw
from mTxTopConst import *
from common.mDeviceConstants import *
import random
class TxIqmc(projectBaseClass):
	"""Contains Tx Iqmc Corrector specific functions self.regs=device.TX.TXIQMC.tx_iqmc """
	@initDecorator
	def __init__(self,regs,deviceRefs):
		self.regs=regs
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.errorList=['','']
		self.TXIQMC_ESTIM = TxIqmcEstim(regs,deviceRefs)
		self.TXIQMC_FW = TxIqmcFw(regs,deviceRefs)
		#self.TXDISPLAY_FUNC = TxDisplayFunc(regs)
	#__init__

	@funcDecorator
	def function_name(self,parameters):
		"""Description"""
		"""Definition"""
	#function_name	

#TxIqmc	
	