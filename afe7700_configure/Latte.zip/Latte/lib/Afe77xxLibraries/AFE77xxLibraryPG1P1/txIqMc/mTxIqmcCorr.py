from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass

from mFuncDecorator import *
import random
class TxIqmcCorr(projectBaseClass):
	"""Contains TX IQMC Corrector specific functions self.regs=device.TX.TXIQMC.tx_iqmc"""
	@initDecorator
	def __init__(self,topno,chno,regs,deviceRefs):
		self.regs=regs
		self.topno=topno
		self.chno=chno
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.errorList=[topno,chno]
	#__init__
	

	
#TxIqmcCorr