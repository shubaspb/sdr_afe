from globalDefs import *
import mAfeBaseClass
reload(mAfeBaseClass)
from mAfeBaseClass import projectBaseClass
import mFuncDecorator
#reload(mFuncDecorator)
from mFuncDecorator import *
import random
import math

class dsaController(projectBaseClass):
	"""Contains DSA Controller specific functions. self.regs=device.TOP.DSA_CNTRL """
	@initDecorator
	def __init__(self,topno,regs,deviceRefs):
		self.deviceRefs=deviceRefs
		self.systemParams=deviceRefs.systemParams
		self.systemStatus=deviceRefs.systemStatus
		self.updateDeviceRefsInBaseClass(deviceRefs)
		self.regs=regs
		self.topno=topno
		self.rxDsaRcCodes=[32736,32545,32386,32291,32196,32133,32070,32039,30984,30953,31946,31915,31884,31885,31854,31855,29808,27761,24690,21619,18548,6261,2166,119,120,4185,90,91,92,19517,15422,15422,15422,15422,15422,15422,15422]
	#__init__


	@funcDecorator
	def setTxDsa(self,chNo,dsa_setting):
		""" "Setting TX DSA Attenuation" "Done setting TX DSA Attenuation" """
		if chNo==0:
			self.regs.TX_DSA_CTRL.Register45545_100h.spi_dsa=dsa_setting
			self.regs.TX_DSA_CTRL.Register45545_100h.index_update=0
			self.regs.TX_DSA_CTRL.Register45545_100h.index_update=1
			self.regs.TX_DSA_CTRL.Register45545_100h.index_update=0
		else:
			self.regs.TX_DSA_CTRL.Register45566_120h.spi_dsa=dsa_setting
			self.regs.TX_DSA_CTRL.Register45566_120h.index_update=0
			self.regs.TX_DSA_CTRL.Register45566_120h.index_update=1
			self.regs.TX_DSA_CTRL.Register45566_120h.index_update=0
	#setTxDsa
	
	@funcDecorator
	def setRxDsa(self,chNo,dsa_setting):
		if chNo==0:
			self.regs.RX_DSA_CTRL.Register44829_50h.spi_agc_dsa=dsa_setting
		else:
			self.regs.RX_DSA_CTRL.Register44846_B0h.spi_agc_dsa=dsa_setting
	#setRxDsa
	
	@funcDecorator
	def setFbDsa(self,dsa_setting):
		self.regs.FB_DSA_CTRL.Register45851_150h.spi_dsa=dsa_setting
	#setFbDsa
	
	@funcDecorator
	def rxDsaCodesPopulate(self):
		a=self.rxDsaRcCodes
		self.regs.RX_DSA_LUT.Register45058_671h.Property45059_27_0 = (a[0] & 0x3FF) + ((a[0] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45060_27_0 = (a[1] & 0x3FF) + ((a[1] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45061_27_0 = (a[2] & 0x3FF) + ((a[2] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45062_27_0 = (a[3] & 0x3FF) + ((a[3] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45063_27_0 = (a[4] & 0x3FF) + ((a[4] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45064_27_0 = (a[5] & 0x3FF) + ((a[5] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45065_27_0 = (a[6] & 0x3FF) + ((a[6] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45066_27_0 = (a[7] & 0x3FF) + ((a[7] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45067_27_0 = (a[8] & 0x3FF) + ((a[8] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45068_27_0 = (a[9] & 0x3FF) + ((a[9] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45069_27_0 = (a[10] & 0x3FF) + ((a[10] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45070_27_0 = (a[11] & 0x3FF) + ((a[11] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45071_27_0 = (a[12] & 0x3FF) + ((a[12] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45072_27_0 = (a[13] & 0x3FF) + ((a[13] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45073_27_0 = (a[14] & 0x3FF) + ((a[14] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45074_27_0 = (a[15] & 0x3FF) + ((a[15] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45075_27_0 = (a[16] & 0x3FF) + ((a[16] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45076_27_0 = (a[17] & 0x3FF) + ((a[17] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45077_27_0 = (a[18] & 0x3FF) + ((a[18] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45078_27_0 = (a[19] & 0x3FF) + ((a[19] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45079_27_0 = (a[20] & 0x3FF) + ((a[20] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45080_27_0 = (a[21] & 0x3FF) + ((a[21] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45081_27_0 = (a[22] & 0x3FF) + ((a[22] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45082_27_0 = (a[23] & 0x3FF) + ((a[23] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45083_27_0 = (a[24] & 0x3FF) + ((a[24] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45084_27_0 = (a[25] & 0x3FF) + ((a[25] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45085_27_0 = (a[26] & 0x3FF) + ((a[26] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45086_27_0 = (a[27] & 0x3FF) + ((a[27] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45087_27_0 = (a[28] & 0x3FF) + ((a[28] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45088_27_0 = (a[29] & 0x3FF) + ((a[29] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45089_27_0 = (a[30] & 0x3FF) + ((a[30] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45090_27_0 = (a[31] & 0x3FF) + ((a[31] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45091_27_0 = (a[32] & 0x3FF) + ((a[32] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45092_27_0 = (a[33] & 0x3FF) + ((a[33] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45093_27_0 = (a[34] & 0x3FF) + ((a[34] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45094_27_0 = (a[35] & 0x3FF) + ((a[35] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45058_671h.Property45095_27_0 = (a[36] & 0x3FF) + ((a[36] & 0x3FC00)<<10)
		
		self.regs.RX_DSA_LUT.Register45019_311h.Property45020_27_0 = (a[0] & 0x3FF) + ((a[0] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45021_27_0 = (a[1] & 0x3FF) + ((a[1] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45022_27_0 = (a[2] & 0x3FF) + ((a[2] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45023_27_0 = (a[3] & 0x3FF) + ((a[3] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45024_27_0 = (a[4] & 0x3FF) + ((a[4] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45025_27_0 = (a[5] & 0x3FF) + ((a[5] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45026_27_0 = (a[6] & 0x3FF) + ((a[6] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45027_27_0 = (a[7] & 0x3FF) + ((a[7] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45028_27_0 = (a[8] & 0x3FF) + ((a[8] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45029_27_0 = (a[9] & 0x3FF) + ((a[9] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45030_27_0 = (a[10] & 0x3FF) + ((a[10] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45031_27_0 = (a[11] & 0x3FF) + ((a[11] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45032_27_0 = (a[12] & 0x3FF) + ((a[12] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45033_27_0 = (a[13] & 0x3FF) + ((a[13] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45034_27_0 = (a[14] & 0x3FF) + ((a[14] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45035_27_0 = (a[15] & 0x3FF) + ((a[15] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45036_27_0 = (a[16] & 0x3FF) + ((a[16] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45037_27_0 = (a[17] & 0x3FF) + ((a[17] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45038_27_0 = (a[18] & 0x3FF) + ((a[18] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45039_27_0 = (a[19] & 0x3FF) + ((a[19] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45040_27_0 = (a[20] & 0x3FF) + ((a[20] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45041_27_0 = (a[21] & 0x3FF) + ((a[21] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45042_27_0 = (a[22] & 0x3FF) + ((a[22] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45043_27_0 = (a[23] & 0x3FF) + ((a[23] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45044_27_0 = (a[24] & 0x3FF) + ((a[24] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45045_27_0 = (a[25] & 0x3FF) + ((a[25] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45046_27_0 = (a[26] & 0x3FF) + ((a[26] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45047_27_0 = (a[27] & 0x3FF) + ((a[27] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45048_27_0 = (a[28] & 0x3FF) + ((a[28] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45049_27_0 = (a[29] & 0x3FF) + ((a[29] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45050_27_0 = (a[30] & 0x3FF) + ((a[30] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45051_27_0 = (a[31] & 0x3FF) + ((a[31] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45052_27_0 = (a[32] & 0x3FF) + ((a[32] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45053_27_0 = (a[33] & 0x3FF) + ((a[33] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45054_27_0 = (a[34] & 0x3FF) + ((a[34] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45055_27_0 = (a[35] & 0x3FF) + ((a[35] & 0x3FC00)<<10)
		self.regs.RX_DSA_LUT.Register45019_311h.Property45056_27_0 = (a[36] & 0x3FF) + ((a[36] & 0x3FC00)<<10)
	#rxDsaCodesPopulate
	
	@funcDecorator
	def setGainControl(self,gainCntrl):
		self.regs.RX_DSA_CTRL.Register44863_40h.gain_ctrl=gainCntrl
	#setGainControl
	
	@funcDecorator
	def rxDsaRegDefaults(self):
		self.regs.RX_DSA_CTRL.Register44863_40h.Property44872_0_0=1
		self.regs.RX_DSA_CTRL.Register44985_2F8h.en_byp_dsa_code=0
		self.regs.RX_DSA_CTRL.Register45002_658h.en_byp_dsa_code=0
		self.regs.RX_DSA_CTRL.Register44985_2F8h.en_byp_dsa_idx=0
		self.regs.RX_DSA_CTRL.Register45002_658h.en_byp_dsa_idx=0
		self.regs.RX_DSA_CTRL.Register44985_2F8h.en_bypass_gainphase_fi=0
		self.regs.RX_DSA_CTRL.Register44985_2F8h.en_bypass_gain_gaincorr=0
		self.regs.RX_DSA_CTRL.Register44985_2F8h.en_bypass_coefs_fd=0
		self.regs.RX_DSA_CTRL.Register45002_658h.en_bypass_gainphase_fi=0
		self.regs.RX_DSA_CTRL.Register45002_658h.en_bypass_gain_gaincorr=0
		self.regs.RX_DSA_CTRL.Register45002_658h.en_bypass_coefs_fd=0
		self.regs.RX_DSA_CTRL.Register44863_40h.gain_ctrl=3
		self.regs.RX_DSA_LUT.Register45019_311h.sel10msb=0
		self.regs.RX_DSA_LUT.Register45058_671h.sel10msb=0
		self.regs.RX_DSA_CTRL.Register44863_40h.Property44873_0_0=1
		self.regs.RX_DSA_CTRL.Register44829_50h.Property44834_0_0=1
		self.regs.RX_DSA_CTRL.Register44846_B0h.Property44851_0_0=1
		self.regs.RX_DSA_CTRL.Register44829_50h.fdsa_offset=self.systemParams.agcRegConfigParams[self.topno*2]['fdsaOffset']
		self.regs.RX_DSA_CTRL.Register44846_B0h.fdsa_offset=self.systemParams.agcRegConfigParams[(self.topno*2)+1]['fdsaOffset']
	#rxDsaRegDefaults
	
	@funcDecorator	
	def fbDsaCodesPopulate(self):
	
		if((self.systemParams.fbNco[self.topno]>2100) & (self.systemParams.fbNco[self.topno]<3000)):
		# #PG1P1 2.6G
			log("FB DSA 2.6G Band")
			#CshuntCode=[0, 1, 4, 6, 8, 9, 10, 12, 12, 13, 14, 16, 18, 18, 20, 21, 22, 23, 24, 25, 26, 26, 23, 24, 25, 26, 26, 24, 25, 26, 26, 26]
			#Rcode=[0, 1, 2, 5, 8, 12, 17, 22, 30, 43, 65, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74, 74]
			#CserCode=[0, 164, 168, 207, 259, 318, 367, 391, 446, 451, 771, 737, 755, 791, 805, 827, 843, 861, 876, 891, 901, 915, 935, 944, 951, 959, 965, 976, 979, 983, 989, 989]
			#Rcode=[	0,	1,	2,	5,	8,	12,	17,	22,	30,	43,	65,	74,	74,	74,	74,	74,	74,	74,	74,	74,	74]+[74]*11
			#CserCode=[0,	136,	160,	171,	203,	252,	291,	310,	366,	358,	744,	706,	730,	770,	789,	811,	832,	851,	868,	884,	897]+[897]*11
			#CshuntCode=[0,	1,	4,	6,	8,	9,	10,	12,	12,	13,	14,	16,	18,	18,	20,	21,	22,	23,	24,	25,	26]+[26]*11
			
			CserCode=[0, 32, 76, 116, 164, 216, 268, 320, 372, 424, 476, 528, 580, 624, 660, 696, 728, 756, 784, 804, 832, 852, 872, 892, 904, 920, 932, 944, 952, 960, 968, 976]
			Rcode=[0, 2, 6, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, 48, 51, 54, 57, 59, 61, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63]
			CshuntCode=[0, 2, 3, 4, 5, 7, 8, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25]
		elif((self.systemParams.fbNco[self.topno]>4500) & (self.systemParams.fbNco[self.topno]<5500)):	
		# #PG1P1 4.9G
			log("FB DSA 4.9G Band")
			Rcode	=[0,	1,	2,	5,	8,	12,	17,	22,	30,	43,	65,	74,	74,	74,	74,	74,	74,	74,	74,	74,	74]+[74]*11
			CserCode	=[0,	86,	110,	135,	183,	242,	295,	326,	390,	414,	650,	654,	682,	730,	755,	785,	810,	831,	852,	870,	887]+[887]*11
			CshuntCode	=[0,	1,	4,	6,	8,	9,	10,	12,	12,	13,	14,	16,	18,	18,	20,	21,	22,	23,	24,	25,	26]+[26]*11
		else:#if((self.systemParams.fbNco[self.topno]>3000) & (self.systemParams.fbNco[self.topno]<4000)):
			#PG1P1 3.5G
			log("FB DSA 3.5G Band")
			Rcode=[	0,	1,	2,	5,	8,	12,	17,	22,	30,	43,	65,	74,	74,	74,	74,	74,	74,	74,	74,	74,	74]+[74]*11
			CserCode=[0,	136,	160,	185,	223,	274,	321,	350,	402,	408,	734,	704,	728,	768,	789,	811,	832,	851,	868,	884,	897]+[897]*11
			CshuntCode=[0,	1,	4,	6,	8,	9,	10,	12,	12,	13,	14,	16,	18,	18,	20,	21,	22,	23,	24,	25,	26]+[26]*11

		
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45868_22_0 	= CserCode[0 ]+(CshuntCode[0 ]<<10)+(Rcode[0 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45869_22_0 	= CserCode[1 ]+(CshuntCode[1 ]<<10)+(Rcode[1 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45870_22_0 	= CserCode[2 ]+(CshuntCode[2 ]<<10)+(Rcode[2 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45871_22_0 	= CserCode[3 ]+(CshuntCode[3 ]<<10)+(Rcode[3 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45872_22_0 	= CserCode[4 ]+(CshuntCode[4 ]<<10)+(Rcode[4 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45873_22_0 	= CserCode[5 ]+(CshuntCode[5 ]<<10)+(Rcode[5 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45874_22_0 	= CserCode[6 ]+(CshuntCode[6 ]<<10)+(Rcode[6 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45875_22_0 	= CserCode[7 ]+(CshuntCode[7 ]<<10)+(Rcode[7 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45876_22_0 	= CserCode[8 ]+(CshuntCode[8 ]<<10)+(Rcode[8 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45877_22_0 	= CserCode[9 ]+(CshuntCode[9 ]<<10)+(Rcode[9 ]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45878_22_0	= CserCode[10]+(CshuntCode[10]<<10)+(Rcode[10]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45879_22_0	= CserCode[11]+(CshuntCode[11]<<10)+(Rcode[11]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45880_22_0	= CserCode[12]+(CshuntCode[12]<<10)+(Rcode[12]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45881_22_0	= CserCode[13]+(CshuntCode[13]<<10)+(Rcode[13]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45882_22_0	= CserCode[14]+(CshuntCode[14]<<10)+(Rcode[14]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45883_22_0	= CserCode[15]+(CshuntCode[15]<<10)+(Rcode[15]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45884_22_0	= CserCode[16]+(CshuntCode[16]<<10)+(Rcode[16]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45885_22_0	= CserCode[17]+(CshuntCode[17]<<10)+(Rcode[17]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45886_22_0	= CserCode[18]+(CshuntCode[18]<<10)+(Rcode[18]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45887_22_0	= CserCode[19]+(CshuntCode[19]<<10)+(Rcode[19]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45888_22_0	= CserCode[20]+(CshuntCode[20]<<10)+(Rcode[20]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45889_22_0	= CserCode[21]+(CshuntCode[21]<<10)+(Rcode[21]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45890_22_0	= CserCode[22]+(CshuntCode[22]<<10)+(Rcode[22]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45891_22_0	= CserCode[23]+(CshuntCode[23]<<10)+(Rcode[23]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45892_22_0	= CserCode[24]+(CshuntCode[24]<<10)+(Rcode[24]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45893_22_0	= CserCode[25]+(CshuntCode[25]<<10)+(Rcode[25]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45894_22_0	= CserCode[26]+(CshuntCode[26]<<10)+(Rcode[26]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45895_22_0	= CserCode[27]+(CshuntCode[27]<<10)+(Rcode[27]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45896_22_0	= CserCode[28]+(CshuntCode[28]<<10)+(Rcode[28]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45897_22_0	= CserCode[29]+(CshuntCode[29]<<10)+(Rcode[29]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45898_22_0	= CserCode[30]+(CshuntCode[30]<<10)+(Rcode[30]<<15)
		self.regs.FB_DSA_LUT.Register45868_DF0h.Property45899_22_0	= CserCode[31]+(CshuntCode[31]<<10)+(Rcode[31]<<15)
			                               
												 
		self.regs.FB_DSA_CTRL.Register45851_150h.gate_tdd_on_off = 1
	#fbDsaCodesPopulate
	
	@funcDecorator
	def txDsaCodesPopulate(self):
			
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45607_7_0  = (((1<<40)-(1<<0 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45608_7_0  = (((1<<40)-(1<<1 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45609_7_0  = (((1<<40)-(1<<2 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45610_7_0  = (((1<<40)-(1<<3 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45611_7_0  = (((1<<40)-(1<<4 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45612_7_0  = (((1<<40)-(1<<5 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45613_7_0  = (((1<<40)-(1<<6 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45614_7_0  = (((1<<40)-(1<<7 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45615_7_0  = (((1<<40)-(1<<8 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45616_7_0  = (((1<<40)-(1<<9 ))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45617_7_0 = (((1<<40)-(1<<10))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45618_7_0 = (((1<<40)-(1<<11))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45619_7_0 = (((1<<40)-(1<<12))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45620_7_0 = (((1<<40)-(1<<13))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45621_7_0 = (((1<<40)-(1<<14))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45622_7_0 = (((1<<40)-(1<<15))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45623_7_0 = (((1<<40)-(1<<16))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45624_7_0 = (((1<<40)-(1<<17))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45625_7_0 = (((1<<40)-(1<<18))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45626_7_0 = (((1<<40)-(1<<19))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45627_7_0 = (((1<<40)-(1<<20))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45628_7_0 = (((1<<40)-(1<<21))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45629_7_0 = (((1<<40)-(1<<22))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45630_7_0 = (((1<<40)-(1<<23))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45631_7_0 = (((1<<40)-(1<<24))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45632_7_0 = (((1<<40)-(1<<25))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45633_7_0 = (((1<<40)-(1<<26))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45634_7_0 = (((1<<40)-(1<<27))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45635_7_0 = (((1<<40)-(1<<28))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45636_7_0 = (((1<<40)-(1<<29))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45637_7_0 = (((1<<40)-(1<<30))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45638_7_0 = (((1<<40)-(1<<31))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45639_7_0 = (((1<<40)-(1<<32))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45640_7_0 = (((1<<40)-(1<<33))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45641_7_0 = (((1<<40)-(1<<34))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45642_7_0 = (((1<<40)-(1<<35))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45643_7_0 = (((1<<40)-(1<<36))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45644_7_0 = (((1<<40)-(1<<37))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45645_7_0 = (((1<<40)-(1<<38))>>32)
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45646_7_0 = (((1<<40)-(1<<39))>>32)
		
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45647_31_0  = (((1<<40)-(1<<0 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45648_31_0  = (((1<<40)-(1<<1 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45649_31_0  = (((1<<40)-(1<<2 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45650_31_0  = (((1<<40)-(1<<3 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45651_31_0  = (((1<<40)-(1<<4 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45652_31_0  = (((1<<40)-(1<<5 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45653_31_0  = (((1<<40)-(1<<6 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45654_31_0  = (((1<<40)-(1<<7 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45655_31_0  = (((1<<40)-(1<<8 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45656_31_0  = (((1<<40)-(1<<9 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45657_31_0 = (((1<<40)-(1<<10))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45658_31_0 = (((1<<40)-(1<<11))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45659_31_0 = (((1<<40)-(1<<12))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.tdsa_code_lb_13 = (((1<<40)-(1<<13))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45661_31_0 = (((1<<40)-(1<<14))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45662_31_0 = (((1<<40)-(1<<15))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45663_31_0 = (((1<<40)-(1<<16))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45664_31_0 = (((1<<40)-(1<<17))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45665_31_0 = (((1<<40)-(1<<18))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45666_31_0 = (((1<<40)-(1<<19))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45667_31_0 = (((1<<40)-(1<<20))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45668_31_0 = (((1<<40)-(1<<21))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45669_31_0 = (((1<<40)-(1<<22))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45670_31_0 = (((1<<40)-(1<<23))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45671_31_0 = (((1<<40)-(1<<24))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45672_31_0 = (((1<<40)-(1<<25))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45673_31_0 = (((1<<40)-(1<<26))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45674_31_0 = (((1<<40)-(1<<27))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45675_31_0 = (((1<<40)-(1<<28))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45676_31_0 = (((1<<40)-(1<<29))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45677_31_0 = (((1<<40)-(1<<30))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45678_31_0 = (((1<<40)-(1<<31))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45679_31_0 = (((1<<40)-(1<<32))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45680_31_0 = (((1<<40)-(1<<33))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45681_31_0 = (((1<<40)-(1<<34))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45682_31_0 = (((1<<40)-(1<<35))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45683_31_0 = (((1<<40)-(1<<36))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45684_31_0 = (((1<<40)-(1<<37))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45685_31_0 = (((1<<40)-(1<<38))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45607_9A8h.Property45686_31_0 = (((1<<40)-(1<<39))&((1<<32)-1))
		
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45688_7_0  = (((1<<40)-(1<<0 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45689_7_0  = (((1<<40)-(1<<1 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45690_7_0  = (((1<<40)-(1<<2 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45691_7_0  = (((1<<40)-(1<<3 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45692_7_0  = (((1<<40)-(1<<4 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45693_7_0  = (((1<<40)-(1<<5 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45694_7_0  = (((1<<40)-(1<<6 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45695_7_0  = (((1<<40)-(1<<7 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45696_7_0  = (((1<<40)-(1<<8 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45697_7_0  = (((1<<40)-(1<<9 ))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45698_7_0 = (((1<<40)-(1<<10))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45699_7_0 = (((1<<40)-(1<<11))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45700_7_0 = (((1<<40)-(1<<12))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45701_7_0 = (((1<<40)-(1<<13))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45702_7_0 = (((1<<40)-(1<<14))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45703_7_0 = (((1<<40)-(1<<15))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45704_7_0 = (((1<<40)-(1<<16))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45705_7_0 = (((1<<40)-(1<<17))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45706_7_0 = (((1<<40)-(1<<18))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45707_7_0 = (((1<<40)-(1<<19))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45708_7_0 = (((1<<40)-(1<<20))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45709_7_0 = (((1<<40)-(1<<21))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45710_7_0 = (((1<<40)-(1<<22))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45711_7_0 = (((1<<40)-(1<<23))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45712_7_0 = (((1<<40)-(1<<24))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45713_7_0 = (((1<<40)-(1<<25))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45714_7_0 = (((1<<40)-(1<<26))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45715_7_0 = (((1<<40)-(1<<27))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45716_7_0 = (((1<<40)-(1<<28))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45717_7_0 = (((1<<40)-(1<<29))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45718_7_0 = (((1<<40)-(1<<30))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45719_7_0 = (((1<<40)-(1<<31))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45720_7_0 = (((1<<40)-(1<<32))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45721_7_0 = (((1<<40)-(1<<33))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45722_7_0 = (((1<<40)-(1<<34))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45723_7_0 = (((1<<40)-(1<<35))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45724_7_0 = (((1<<40)-(1<<36))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45725_7_0 = (((1<<40)-(1<<37))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45726_7_0 = (((1<<40)-(1<<38))>>32)
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45727_7_0 = (((1<<40)-(1<<39))>>32)
		
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45728_31_0  = (((1<<40)-(1<<0 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45729_31_0  = (((1<<40)-(1<<1 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45730_31_0  = (((1<<40)-(1<<2 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45731_31_0  = (((1<<40)-(1<<3 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45732_31_0  = (((1<<40)-(1<<4 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45733_31_0  = (((1<<40)-(1<<5 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45734_31_0  = (((1<<40)-(1<<6 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45735_31_0  = (((1<<40)-(1<<7 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45736_31_0  = (((1<<40)-(1<<8 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45737_31_0  = (((1<<40)-(1<<9 ))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45738_31_0 = (((1<<40)-(1<<10))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45739_31_0 = (((1<<40)-(1<<11))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45740_31_0 = (((1<<40)-(1<<12))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45741_31_0 = (((1<<40)-(1<<13))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45742_31_0 = (((1<<40)-(1<<14))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45743_31_0 = (((1<<40)-(1<<15))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45744_31_0 = (((1<<40)-(1<<16))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45745_31_0 = (((1<<40)-(1<<17))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45746_31_0 = (((1<<40)-(1<<18))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45747_31_0 = (((1<<40)-(1<<19))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45748_31_0 = (((1<<40)-(1<<20))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45749_31_0 = (((1<<40)-(1<<21))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45750_31_0 = (((1<<40)-(1<<22))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45751_31_0 = (((1<<40)-(1<<23))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45752_31_0 = (((1<<40)-(1<<24))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45753_31_0 = (((1<<40)-(1<<25))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45754_31_0 = (((1<<40)-(1<<26))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45755_31_0 = (((1<<40)-(1<<27))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45756_31_0 = (((1<<40)-(1<<28))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45757_31_0 = (((1<<40)-(1<<29))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45758_31_0 = (((1<<40)-(1<<30))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45759_31_0 = (((1<<40)-(1<<31))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45760_31_0 = (((1<<40)-(1<<32))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45761_31_0 = (((1<<40)-(1<<33))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45762_31_0 = (((1<<40)-(1<<34))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45763_31_0 = (((1<<40)-(1<<35))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45764_31_0 = (((1<<40)-(1<<36))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45765_31_0 = (((1<<40)-(1<<37))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45766_31_0 = (((1<<40)-(1<<38))&((1<<32)-1))
		self.regs.TX_DSA_LUT.Register45688_BC8h.Property45767_31_0 = (((1<<40)-(1<<39))&((1<<32)-1))
		
		self.regs.TX_DSA_CTRL.Register45587_9A3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register45587_9A3h.fw_update_gpec_lut=1
		self.regs.TX_DSA_CTRL.Register45587_9A3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register45597_BC3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register45597_BC3h.fw_update_gpec_lut=1
		self.regs.TX_DSA_CTRL.Register45597_BC3h.fw_update_gpec_lut=0
		self.regs.TX_DSA_CTRL.Register45545_100h.dig_gain=24
		self.regs.TX_DSA_CTRL.Register45566_120h.dig_gain=24
		self.regs.TX_DSA_CTRL.Register45545_100h.en_idx_update=1
		self.regs.TX_DSA_CTRL.Register45566_120h.en_idx_update=1
		self.regs.TX_DSA_CTRL.Register45545_100h.spi_dsa=1
		self.regs.TX_DSA_CTRL.Register45545_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register45545_100h.index_update=1
		self.regs.TX_DSA_CTRL.Register45545_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register45545_100h.spi_dsa=0
		self.regs.TX_DSA_CTRL.Register45545_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register45545_100h.index_update=1
		self.regs.TX_DSA_CTRL.Register45545_100h.index_update=0
		self.regs.TX_DSA_CTRL.Register45566_120h.spi_dsa=1
		self.regs.TX_DSA_CTRL.Register45566_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register45566_120h.index_update=1
		self.regs.TX_DSA_CTRL.Register45566_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register45566_120h.spi_dsa=0
		self.regs.TX_DSA_CTRL.Register45566_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register45566_120h.index_update=1
		self.regs.TX_DSA_CTRL.Register45566_120h.index_update=0
		self.regs.TX_DSA_CTRL.Register45545_100h.en_idx_update=0
		self.regs.TX_DSA_CTRL.Register45566_120h.en_idx_update=0
		self.regs.TOP_CFG.Register45901_DE0h.map_to_txgswap=15
		
		# Writes for Tx DSA
		self.regs.TX_DSA_CTRL.Register45545_100h.Property45552_0_0 = 1
		self.regs.TX_DSA_CTRL.Register45566_120h.Property45573_0_0 = 1
	#txDsaCodesPopulate
		
		
		

#dsaController