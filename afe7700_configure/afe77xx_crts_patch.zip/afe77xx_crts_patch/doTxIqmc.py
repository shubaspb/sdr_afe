

tx_channel=3

if (tx_channel==0) :   					# TXA to FBAB (Dual FB mode)
	device.writeReg(0x0108,0x01,0,0)
	device.writeReg(0x0109,0x00,0,3)
elif (tx_channel==1) :   				# TXB to FBAB (Dual FB mode)
	device.writeReg(0x0108,0x01,0,0)
	device.writeReg(0x0109,0x01,0,3)
elif (tx_channel==2) :   				# TXC to FBCD (Dual FB mode)
	device.writeReg(0x0108,0x01,0,0)
	device.writeReg(0x0109,0x02,0,3)
elif (tx_channel==3) :   				# TXD to FBCD (Dual FB mode)
	device.writeReg(0x0108,0x01,0,0)
	device.writeReg(0x0109,0x03,0,3)
else : 									# No TX is connected to FB 
	device.writeReg(0x0108,0x01,0,0)
	device.writeReg(0x0109,0x04,0,3)





# TI command
#AFE.TOP.TIMINGCTRL.txToFbSelectCh(1,0) 