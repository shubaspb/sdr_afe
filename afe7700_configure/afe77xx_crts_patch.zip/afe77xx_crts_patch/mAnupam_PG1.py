all_path= "C:\\Users\\d.shubin\\Documents\\Texas Instruments\\Latte\\"


from HSCDevices import *
from mConnect import *
import globalDefs as Globals
import os
import time
class ANUPAM(Device):
	delay_time=0.01
	logEn = Object(typ = Boolean, label = "log Enable")
	metalFix=1
	
	rawWriteLogEn=0
	rawWriteLogsFile=r"C:/rawWriteLogs1.txt"
	commentForWrite=""
	rewriteFile=0
	prevAddress=0
	extTesterLog=1
	ignoreLogComments=0
	expectedReadValue=-1
	
	logClassInst=None
	jesdToSerdesLaneMapping=(3,2,0,1,1,0,2,3)
	optimizeWrites=0
	hardReadAlways = False#Object(typ = Boolean, label = "Hard Read Always", desc='Ignores the rawRegisters data and does a register read everytime during a register write.')
	def __init__(self,*args,**kwargs):
		super(ANUPAM,self).__init__(*args,**kwargs)
		self.lastSelectGroup = None
		self.currentPageSelected = None
		self.currentPageSelectedValue = None
		self.dualDsaPage=False		# When this is True, the DSA AB and CD are in different pages. Else it is in single page.
		self.dsaPageSelect=0
	
	def writeProperty(self,prop,value,soft=False):
				
		propertyString=str(prop.fqn).replace('CREDO','SERDES')
		self.nameFqn=propertyString[:propertyString.find('.')]
		
		if (not soft) and self.extTesterLog&0x4!=0 and self.rawWriteLogEn==1 and (prop.value!=value or (self.optimizeWrites==0 and prop.parent.parent is not self.MASTER.MASTER_PAGE.PAGE_SEL)):
			logFileName=self.rawWriteLogsFile[:-4]+"_dmlWrites.txt"
			if not os.path.exists(logFileName) or self.rewriteFile==True:
				text_file = open(logFileName, "w")
			else:
				text_file = open(logFileName, "a")
			
			text_file.write(prop.fqn[:prop.fqn.rfind(r"._")]+"."+prop.fqn[prop.fqn.rfind(r"._")+2:]+"="+str(value)+"\n")
			text_file.close()
		
		if not soft:
			if self.MASTER.MASTER_PAGE.PAGE_SEL.Miscenallous._dsa==prop:
				self.dsaPageSelect=value
				
		if not soft:
			if prop==self.currentPageSelected and value==self.currentPageSelectedValue:
				return
			if isinstance(prop.parent,(RegEntity,RegEntityList)):
				prop.parent.selectPage(prop,prop)
			if hasattr(prop.parent,'parent') and (prop.parent.parent is self.MASTER.MASTER_PAGE.PAGE_SEL):
				currentGroup = prop
				if currentGroup != self.lastSelectGroup:
					if self.lastSelectGroup is not None: self.lastSelectGroup.reset()
					self.lastSelectGroup = currentGroup
					
			if (prop.parent.parent is self.MASTER.MASTER_PAGE.PAGE_SEL):
				self.currentPageSelected=prop
				self.currentPageSelectedValue=value
				

		offset=0
		if prop.rawRegIndex is None: return
		if not soft and '_dsa_abcd_addr_range' in dir(self.TOP.TC_GPIO.digtop.Register41632_600h):
			if self.TOP.TC_GPIO.digtop.Register41632_600h._dsa_abcd_addr_range==prop:
				self.dualDsaPage=value
			if prop.parent.parent.parent.name in ["DSA_CNTRL[1]","DSA_CNTRL[0]"] and  self.dsaPageSelect!=3 and self.dualDsaPage==False:
				self.MASTER.MASTER_PAGE.PAGE_SEL.Miscenallous.dsa=3
				
		count=0
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			address=r.address
			if not soft:
				if self.dualDsaPage==False and prop.parent.parent.parent.name in ["DSA_CNTRL[1]",]:
					address+=0x1000
			if self.nameFqn+".JESD.SERDES[0].laneRegisters[" in propertyString:
				address=(address+(0x100*self.jesdToSerdesLaneMapping[int(propertyString[len(self.nameFqn+".JESD.SERDES[0].laneRegisters[")])]))
			elif self.nameFqn+".JESD.SERDES[1].laneRegisters[" in propertyString:
				address=(address+(0x100*self.jesdToSerdesLaneMapping[int(propertyString[len(self.nameFqn+".JESD.SERDES[1].laneRegisters[")])+4]))
				
				
			if self.nameFqn+".JESD.SERDES[" in propertyString:
				SERDESPageSel=self.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES
				if SERDESPageSel&1==1 and self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index!=((address)>>14)&0x3:
					#self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index=((address)>>14)&0x3
					self.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=SERDESPageSel
				if SERDESPageSel&2==2 and self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index!=((address)>>14)&0x3:
					#self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index=((address)>>14)&0x3
					self.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=SERDESPageSel
				if self.metalFix==1:
					address=2*((address+0x2000)&0x3fff)
				else:
					address=2*((address)&0x3fff)
			if self.hardReadAlways and not soft and prop.parent.parent.parent is not self.MASTER.MASTER_PAGE:
				#print "Check 1"
				temp=self.rawWriteLogEn
				self.rawWriteLogEn=0
				val=0
				if self.nameFqn+".JESD.SERDES[" not in propertyString:
					#self.readReg(address+offset+3)				# This dummy read is needed for reading SERDES registers
					val=val+(self.readReg(address+offset+3)<<24)
					#self.readReg(address+offset+2)				# This dummy read is needed for reading SERDES registers
					val=val+(self.readReg(address+offset+2)<<16)
				if (not (r.lsb>=16 or r.msb<8)) or self.nameFqn+".JESD.SERDES[" in propertyString:
					if self.nameFqn+".JESD.SERDES[" in propertyString:
						self.readReg(address+offset+1)		# This dummy read is needed for reading SERDES registers
					val=val+(self.readReg(address+offset+1)<<8)
				if r.lsb<8 or self.nameFqn+".JESD.SERDES[" in propertyString:
					if self.nameFqn+".JESD.SERDES[" in propertyString:
						self.readReg(address+offset)		# This dummy read is needed for reading SERDES registers
					val=val+(self.readReg(address+offset)<<0)
				mask=(2**32-1)^((2**(r.msb+1-r.lsb)-1)<<r.lsb)
				regVal=(val&mask)|(value<<r.lsb)
				self.rawWriteLogEn=temp
			else:
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
				regVal = (regVal & r.zeros()) | (r.shift(value) & r.ones())
			if (self.hardReadAlways and prop.parent.parent.parent is not self.MASTER.MASTER_PAGE) or self.optimizeWrites==0 or (regVal != self._rawRegisters[(prop.rawRegIndex,r.address)]) or self.nameFqn+".JESD.SERDES[" in propertyString:#or True:#
				#print "Write 1"
				if(count==0):
					if r.address!=self.prevAddress and self.logClassInst!=None:
						self.logClassInst.commentForWrite=""
					if not soft and self.logClassInst!=None and self.rawWriteLogEn and (prop.parent.parent.parent.name in ("DIG_AB[0]","DIG_AB[1]","FB_DIG","CLK_AB","CLK_CD","PLL[0]","PLL[1]","PLL[2]","PLL[3]","PLL[4]","TIMING_CTRL","TC_GPIO","DAC_DIG_AB[0]","DAC_DIG_AB[1]","MASTER_PAGE") or prop.parent.parent.parent.parent.parent.name in ("JESD","CREDO","SERDES")):
						self.logClassInst.logPropertyWriteRead("AFE77xx",prop,value,0)

					if r.address!=self.prevAddress:
						self.commentForWrite=""
					self.prevAddress=r.address
					if self.rawWriteLogEn and (prop.parent.parent.parent.name in ("DIG_AB[0]","DIG_AB[1]","FB_DIG","CLK_AB","CLK_CD","PLL[0]","PLL[1]","PLL[2]","PLL[3]","PLL[4]","TIMING_CTRL","TC_GPIO","DAC_DIG_AB[0]","DAC_DIG_AB[1]","MASTER_PAGE") or prop.parent.parent.parent.parent.parent.name in ("JESD","CREDO","SERDES")):
						if str(prop.name)+"="+str(hex(value).lower().replace('l','')) not in self.commentForWrite:
							if prop.parent.parent.name == "PAGE_SEL":
								self.commentForWrite+="\t// PAGE:" +str(prop.name)+"="+str(hex(value).lower().replace('l',''))
							else:
								self.commentForWrite+="\t// " +str(prop.name)+"="+str(hex(value).lower().replace('l',''))
							if len(prop.valueList)>value:
								self.commentForWrite+="(Meaning: "+str(prop.valueList[value].desc)+");"
					count+=1
				self._rawRegisters[(prop.rawRegIndex,r.address)]=regVal
				if not soft:
					if self.nameFqn+".JESD.SERDES[" not in propertyString:
						if not (r.msb<24):
							if self.hardReadAlways:
								msb=r.msb-24
								if r.lsb<24:
									lsb=0
								else:
									lsb=r.lsb-24
							else:
								msb=7
								lsb=0
							self.writeReg((address+offset+3),(regVal>>24)&0xff,lsb,msb)
						if not (r.lsb>=24 or r.msb<16):
							if self.hardReadAlways:
								if r.msb>=24:
									msb=7
								else:
									msb=r.msb-16
								if r.lsb<16:
									lsb=0
								else:
									lsb=r.lsb-16
							else:
								msb=7
								lsb=0
							self.writeReg((address+offset+2),(regVal>>16)&0xff,lsb,msb)
					if (not (r.lsb>=16 or r.msb<8))  or self.nameFqn+".JESD.SERDES[" in propertyString:
						if self.hardReadAlways:
							if r.msb>15 or self.nameFqn+".JESD.SERDES[" in propertyString:
								msb=7
							else:
								msb=r.msb-8
							if self.nameFqn+".JESD.SERDES[" in propertyString or r.lsb<8:
								lsb=0
							else:
								lsb=r.lsb-8
						else:
							msb=7
							lsb=0
						self.writeReg((address+offset+1),(regVal>>8)&0xff,lsb,msb)
					if r.lsb<8 or self.nameFqn+".JESD.SERDES[" in propertyString:
						if self.hardReadAlways:
							if r.msb >7 or self.nameFqn+".JESD.SERDES[" in propertyString:
								msb=7
							else:
								msb=r.msb
							if self.nameFqn+".JESD.SERDES[" in propertyString:
								lsb=0
							else:
								lsb=r.lsb
						else:
							msb=7
							lsb=0
						self.writeReg((address+offset),(regVal>>0)&0xff,lsb,msb)
							
			value = value >> r.size()

	def readProperty(self,prop,soft=False):
		propertyString=str(prop.fqn).replace('CREDO','SERDES')
		self.nameFqn=propertyString[:propertyString.find('.')]
		val = 0
		lsb = 0
		lsbProp=0
		offset=0
		bitsToShift=0
		for r in reversed(prop.rangeList): #The range list is reversed because it is listed MSB first
			address=r.address
			
			if self.expectedReadValue==-1 or address in (0x0f,0x1a):
				expectedReadValueReg=-1
			else:
				expectedReadValueReg=(r.shift(self.expectedReadValue>>bitsToShift) & r.ones())
				bitsToShift+=r.size()
			
			if self.nameFqn+".JESD.SERDES[0].laneRegisters[" in propertyString:
				address=(address+(0x100*self.jesdToSerdesLaneMapping[int(propertyString[len(self.nameFqn+".JESD.SERDES[0].laneRegisters[")])]))
			elif self.nameFqn+".JESD.SERDES[1].laneRegisters[" in propertyString:
				address=(address+(0x100*self.jesdToSerdesLaneMapping[int(propertyString[len(self.nameFqn+".JESD.SERDES[1].laneRegisters[")])+4]))
			#if self.nameFqn+".JESD.SERDES[0].laneRegisters[" in propertyString:
			#	address=(address+(0x100*int(propertyString[len(self.nameFqn+".JESD.SERDES[0].laneRegisters[")])))
			#elif self.nameFqn+".JESD.SERDES[1].laneRegisters[" in propertyString:
			#	address=(address+(0x100*int(propertyString[len(self.nameFqn+".JESD.SERDES[1].laneRegisters[")])))
				
				
			if self.nameFqn+".JESD.SERDES[" in propertyString:
				SERDESPageSel=self.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES
				if SERDESPageSel&1==1 and self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index!=((address)>>14)&0x3:
					self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG33.serdesab_apb_page_addr_index=((address)>>14)&0x3
				if SERDESPageSel&2==2 and self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index!=((address)>>14)&0x3:
					self.JESD.SUBCHIP.SUBCHIP.JESD_SUBCHIP_REG34.serdescd_apb_page_addr_index=((address)>>14)&0x3
				self.MASTER.MASTER_PAGE.PAGE_SEL.PAGE_SEL.SERDES=SERDESPageSel
				if self.metalFix==1:
					address=2*((address+0x2000)&0x3fff)
				else:
					address=2*((address)&0x3fff)
			
			if (not soft) or (self.hardReadAlways and prop.parent.parent.parent is not self.MASTER.MASTER_PAGE):
				if isinstance(prop.parent,(RegEntity,RegEntityList)):
					prop.parent.selectPage(prop,prop,disableBroadcast=True)
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
				
				if self.nameFqn+".JESD.SERDES[" not in propertyString:
					if not (r.msb<24):
						msb=r.msb-24
						if r.lsb<24:
							lsb=0
						else:
							lsb=r.lsb-24
						regVal=(regVal&0x00ffffff)|self.readReg((address+offset+3),lsb,msb,expectedReadValueReg>>24)<<24
					if not (r.lsb>=24 or r.msb<16):
						if r.msb>=24:
							msb=7
						else:
							msb=r.msb-16
						if r.lsb<16:
							lsb=0
						else:
							lsb=r.lsb-16
						regVal=(regVal&0xff00ffff)|self.readReg((address+offset+2),lsb,msb,expectedReadValueReg>>16)<<16
				if (not (r.lsb>=16 or r.msb<8))  or self.nameFqn+".JESD.SERDES[" in propertyString:
					if r.msb>15 or self.nameFqn+".JESD.SERDES[" in propertyString:
						msb=7
					else:
						msb=r.msb-8
					if self.nameFqn+".JESD.SERDES[" in propertyString or r.lsb<8:
						lsb=0
					else:
						lsb=r.lsb-8
					regVal=(regVal&0xffff00ff)|self.readReg((address+offset+1),lsb,msb,expectedReadValueReg>>8)<<8
					if self.nameFqn+".JESD.SERDES[" in propertyString:
						regVal=(regVal&0xffff00ff)|self.readReg((address+offset+1),lsb,msb,expectedReadValueReg>>8)<<8
				if r.lsb<8 or self.nameFqn+".JESD.SERDES[" in propertyString:
					if r.msb >7 or self.nameFqn+".JESD.SERDES[" in propertyString:
						msb=7
					else:
						msb=r.msb
					if self.nameFqn+".JESD.SERDES[" in propertyString:
						lsb=0
					else:
						lsb=r.lsb
					regVal=(regVal&0xffffff00)|(self.readReg((address+offset),lsb,msb,expectedReadValueReg))
					if self.nameFqn+".JESD.SERDES[" in propertyString:
						regVal=(regVal&0xffffff00)|(self.readReg((address+offset),lsb,msb,expectedReadValueReg))
							
				#regVal = self.readReg(r.address)
				self._rawRegisters[(prop.rawRegIndex,r.address)] = regVal
			else:
				regVal = self._rawRegisters[(prop.rawRegIndex,r.address)]
			regVal &= r.ones()
			val |= r.unshift(regVal)<<lsbProp
			lsbProp += r.size()
		
		
		if self.expectedReadValue!=-1 and address not in (0x0f,0x1a):
			self.expectedReadValue=-1
		if (not soft) or (self.hardReadAlways and prop.parent.parent.parent is not self.MASTER.MASTER_PAGE):
			if self.rawWriteLogEn==True and self.logClassInst!=None :
				self.logClassInst.logPropertyWriteRead("AFE77xx",prop,val,1)
			if self.rawWriteLogEn==True and prop.parent.parent.name not in ("PAGE_SEL",):
				if str(prop.name)+": "+str(hex(val).lower().replace('l','')) not in self.commentForWrite:
					self.commentForWrite+="\t// " +str(prop.name)+": "+str(hex(val).lower().replace('l',''))
					if len(prop.valueList)>val:
						self.commentForWrite=self.commentForWrite+"(Meaning: "+str(prop.valueList[val].desc)+")"
			self.rawWriteLog("// Read ")
		if prop.signed:
			val=prop.get2sComplement(val)		
		return val
		
	def printCommentToLog(self,msg):
		debug(msg)
		self.commentForWrite=""
		self.rawWriteLog("// "+str(msg))
		self.rawWriteLog("AFE77xx_GLOBAL")
		if self.logClassInst!=None:
			self.logClassInst.logComment("AFE77xx",msg)

	#printCommentToLog
	
	def writeReg(self,addr,val,lsb=0,msb=7):
		addr=addr&0x7fff
		print "writing into ","0x{:04x}".format(addr), "value ", "0x{:02x}".format(val)
		
		curr_time=time.time()
		str_nn = "W " + "0x{:04x}".format(addr) + " " + "0x{:02x}".format(val) + " " + "0x{:01x}".format(lsb) + " " + "0x{:01x}".format(msb) + "\n"
		with open(all_path+"lib\\"+"afe_conf_log.txt", 'a') as file: file.write(str_nn) 
		
		
		self.log("%s.writeReg(0x%02X,0x%02X)"%(self.fqn,addr,val))
		if self.logClassInst!=None and self.rawWriteLogEn==True:
			self.logClassInst.logRawWriteRead("AFE77xx",addr,val,0,lsb,msb)

		self.rawWriteLog(str("0x{:04x}".format(addr).lower().replace('l',''))+"    "+str("0x{:02x}".format(val).lower().replace('l','')))
		if self.regProgDevice:
			self.regProgDevice.writeReg(addr,val&0xFF)
			Globals.delay(self.delay_time)
		elif self.logEn==1:
			debug("No Reg Programmer Connected.")
		
	def writeReg32(self,addr,val):
		addr=addr&0x7fff
		print "writing into ",hex(addr), "value ", hex(val)
		
		curr_time=time.time()
		str_nn = "W32 " + str(hex(addr)) + " " + str(hex(val)) + "\n" 
		with open(all_path+"lib\\"+"afe_conf_log.txt", 'a') as file: file.write(str_nn) 

		
		self.log("%s.writeReg(0x%08X,0x%08X)"%(self.fqn,addr,val))
		self.writeReg(addr,val&0xFF)
		self.writeReg(addr+1,(val&0xFF00)>>8)
		self.writeReg(addr+2,(val&0xFF0000)>>16)
		self.writeReg(addr+3,(val&0xFF000000)>>24)
		#Globals.delay(self.delay_time)
			
	def readReg(self,addr,lsb=0,msb=7,expectedReadValueReg=-1):
		addr=addr&0x7fff
		Globals.delay(self.delay_time)
		if self.regProgDevice:
			try:
				data = self.regProgDevice.readReg(0x8000 + addr)
			except:
				try:
					data = self.regProgDevice.readReg(0x8000 + addr)
				except:
					error("Error Reading. Please clear the session, reconnect the board USB, and start again.")
					data=0
					
			print "Read from ",hex(addr), "value ", hex(data)
			
			curr_time=time.time()
			str_nn = "R " + hex(addr) + " " + hex(data)  + " " + hex(lsb) + " " + hex(msb) + "\n"
			with open(all_path+"lib\\"+"afe_conf_log.txt", 'a') as file: file.write(str_nn)
			
			
			self.log("%s.readReg(0x%08X,0x%08X)"%(self.fqn,addr,data))
		else:
			data=0
			debug("No Reg Programmer Connected.")
			print "Read from ",hex(addr)
			
		if self.logClassInst!=None and self.rawWriteLogEn==True:
			if expectedReadValueReg==-1:
				self.logClassInst.logRawWriteRead("AFE77xx",addr,data,1,lsb=lsb,msb=msb)
			else:
				self.logClassInst.logRawWriteRead("AFE77xx",addr,data,1,lsb=lsb,msb=msb,expectedReadValue=expectedReadValueReg)
				

		self.rawWriteLog(str("0x{:04x}".format(addr).lower().replace('l',''))+"    "+str("\t// Read "))
		return data&0xff 
					
	def readReg32(self,addr):
		addr=addr&0x7fff
		Globals.delay(self.delay_time)
		data1 = self.readReg(0x8000 + addr)
		data2 = self.readReg(0x8000 + addr + 1)
		data3 = self.readReg(0x8000 + addr + 2)
		data4 = self.readReg(0x8000 + addr + 3)
		data = (data4 << 24) + (data3 << 16) + (data2 << 8) + data1
		
		curr_time=time.time()
		str_nn = "R32 " + hex(addr) + " " + hex(data) + "\n"
		with open(all_path+"lib\\"+"afe_conf_log.txt", 'a') as file: file.write(str_nn)
		
		return data 
		

	def RecursiveSearchAndReset(self,entity):
		#log(entity.name)
		for childEntity in entity.entityList:
			childEntity.setDepth()
			if childEntity.depth==1:
				if childEntity.name.startswith('TP__TM'):
					for prop in childEntity.stateVariableList:
						if prop.value:
							prop.setValue(0)
			else:
				self.RecursiveSearchAndReset(childEntity)
			
	def resetTP(self):
		self.RecursiveSearchAndReset(self)
#########################################
		
##################### log all TP which are enabled
	def findTPon(self):
		self.RecursiveSearchAndReturn(self)
	 
	def RecursiveSearchAndReturn(self,entity):
		#log(entity.name)
		for childEntity in entity.entityList:
			childEntity.setDepth()
			if childEntity.depth==1:
				if childEntity.name.startswith('TP__TM'):
					for TPStateVariable in childEntity.stateVariableList:
						if TPStateVariable.value:
							log(TPStateVariable.fqn)
						
			else:
				self.RecursiveSearchAndReturn(childEntity)
##############################################
	def log(self,msg):
		if self.logEn:
			log(msg)
	
	def rawWriteLog(self,msg):
		rawWriteLogsFile=self.rawWriteLogsFile
		msg=msg.replace("CREDO","SERDES")
		msg=msg.replace("api","macro")
		msg=msg.replace("API","MACRO")
		if self.extTesterLog==0:
			testerLogsFile=self.rawWriteLogsFile.replace(".txt","Tester.txt")
		elif self.extTesterLog>=1:
			testerLogsFile=self.rawWriteLogsFile.replace(".txt","Custom.txt")
			testerLogsFile2=self.rawWriteLogsFile.replace(".txt","Custom2.txt")
		if not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')]) and not os.path.exists(rawWriteLogsFile[:rawWriteLogsFile.rfind('\\')]):
			self.rawWriteLogsFile=Globals.ASTERIX_DIR+"test.txt"
			error(r"Path "+str(rawWriteLogsFile[:rawWriteLogsFile.rfind(r'/')])+" doesn't exist. Writing into file: "+str(self.rawWriteLogsFile))
			rawWriteLogsFile=self.rawWriteLogsFile
		if self.rawWriteLogEn:
			printNewSection=False
			if (not os.path.exists(rawWriteLogsFile)) or self.rewriteFile==True:
				text_file = open(rawWriteLogsFile, "w")
				testerLog = open(testerLogsFile, "w")
				if self.extTesterLog>=1:
					testerLog2 = open(testerLogsFile2, "w")
				self.rewriteFile=False
				printNewSection=True
			else:
				text_file = open(rawWriteLogsFile, "r")
				for line in reversed(text_file.readlines()):
					if not ((line.strip()[0:2].lower() == "0x") or (line.strip() == "AFE77xx_GLOBAL") or line.strip()[0:4]=="WAIT"):
						printNewSection=True
					elif line.strip() == "AFE77xx_GLOBAL" or line.strip()[0:4]=="WAIT":
						break
				text_file.close()
				text_file = open(rawWriteLogsFile, "a")
				testerLog = open(testerLogsFile, "a")
				if self.extTesterLog>=1:
					testerLog2 = open(testerLogsFile2, "a")
			if printNewSection:		
				text_file.write('AFE77xx_GLOBAL\n')
			msg=msg+self.commentForWrite.replace("CREDO","SERDES").replace("api","macro").replace("API","MACRO")
			if re.match("(0x[0-9a-fA-F]+)(.*)",msg.replace('//','')) and "// Read" in msg:
				reMatch=re.match("(0x[0-9a-fA-F]+)(.*)",msg.replace('//',''))
				if self.extTesterLog==0:
					if reMatch.group(2).replace("// Read","").strip()=='':
						testerLog.write("ReadSPI"+"("+reMatch.group(1)+","+"SPI_READBACK"+");\n")
					else:
						testerLog.write("ReadSPI"+"("+reMatch.group(1)+","+"SPI_READBACK"+");\t{"+reMatch.group(2).replace("// Read","").strip()+"}\n")
				elif self.extTesterLog==1:
					testerLog.write("AFE77xx_RegRead 2,"+reMatch.group(1)+"\n")
					testerLog2.write("SPIRead "+reMatch.group(1).replace('0x','')+"\n")
					if reMatch.group(2).replace("// Read","").strip()=='' and self.ignoreLogComments==0:
						testerLog.write(r"//"+reMatch.group(2).strip()+"\n")
						testerLog2.write(r"//"+reMatch.group(2).replace('0x','').strip()+"\n")
			elif re.match("(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)(.*)",msg.replace('//','')):
				reMatch=re.match("(0x[0-9a-fA-F]+)\s+(0x[0-9a-fA-F]+)(.*)",msg.replace('//',''))
				if self.extTesterLog==0:
					if reMatch.group(3).strip()=='':
						testerLog.write("WriteSPI"+"("+reMatch.group(1)+","+reMatch.group(2)+");\n")
					else:
						testerLog.write("WriteSPI"+"("+reMatch.group(1)+","+reMatch.group(2)+");\t{"+reMatch.group(3).strip()+"}\n")
				elif self.extTesterLog==1:
					testerLog.write("AFE77xx_RegWrite 2,"+reMatch.group(1)+","+reMatch.group(2)+"\n")
					testerLog2.write("SPIWrite "+reMatch.group(1).replace('0x','')+","+reMatch.group(2).replace('0x','')+"\n")
					if reMatch.group(3).strip()!='' and self.ignoreLogComments==0:
						testerLog.write(r"//"+reMatch.group(3).strip()+"\n")
						testerLog2.write(r"//"+reMatch.group(3).replace('0x','').strip()+"\n")
			else:
				if self.extTesterLog==0:
					testerLog.write("{"+msg.replace('//','')+"}"+'\n')
				elif self.extTesterLog==1 and self.ignoreLogComments==0:
					testerLog.write('\n\n'+msg+'\n')
					testerLog2.write('\n\n'+msg+'\n')
			testerLog.close()
			if self.extTesterLog>=1:
				testerLog2.close()
			text_file.write(msg+"\n")
			self.commentForWrite=""
			text_file.close()
	#rawWriteLog
	
class Supply(Entity):
	on = Object(typ=Boolean,label='Power on')
	v = Object(typ=Voltage,label = 'Voltage')
	iLimit = Object(typ=Current,label = 'Current limit')
	iMeas = Object(typ=Current,label = 'Meas. current',readOnly=True)
	power = Object(typ=Power,label = 'Meas. power',readOnly=True)
	refresh = Object(typ=Trigger,label = 'Refresh values',function='updateValues')

	def updateValues(self):
		self._power.getValue()

	def connect(self):
		device = self
		function = self.__class__.computePower
		args = []
		self._power._get = (device,function,args)

	def computePower(self):
		voltage = self.v
		iMeas = self._iMeas.getValue()
		power = voltage*iMeas
		return power

	def connectWith(self,other):
		try:
			self.onConnect = Connect(self._on,other._on,1,1)
		except:
			log('Cannot connect on variable of %s to %s'%(other.fqn,self.fqn))

		try:
			self.vConnect = Connect(self._v,other._v,1,1)
		except:
			log('Cannot connect v variable of %s to %s'%(other.fqn,self.fqn))
		
		try:
			self.iLimitConnect = Connect(self._iLimit,other._iLimit,1,1)
		except:
			log('Cannot connect iLimit variable of %s to %s'%(other.fqn,self.fqn))
		
		try:
			self._iMeas._get = other._i._get			# Fix because readOnly vars don't have connect implemented correctly.
			self.iMeasConnect = other._i._get
		except:
			log('Cannot connect iMeas variable of %s to %s'%(other.fqn,self.fqn))

	def setInstrumentStatus(self,val):
		pass

class DualSupply(Supply):
	iMeas2 = Object(typ=Current,label = 'Meas. current 2',readOnly=True)

	def computePower(self):
		voltage = self.v
		iMeas = self._iMeas.getValue()
		iMeas2 = self._iMeas2.getValue()
		power = voltage*(iMeas+iMeas2)
		return power

	def connectWith2(self,other):
		try:
			self.onConnect2 = Connect(self._on,other._on,1,1)
		except:
			log('Cannot connect on variable of %s to %s'%(other.fqn,self.fqn))

		try:
			self.vConnect2 = Connect(self._v,other._v,1,1)
		except:
			log('Cannot connect v variable of %s to %s'%(other.fqn,self.fqn))
		
		try:
			self.iLimitConnect2 = Connect(self._iLimit,other._iLimit,1,1)
		except:
			log('Cannot connect iLimit variable of %s to %s'%(other.fqn,self.fqn))
		
		try:
			self._iMeas2._get = other._i._get			# Fix because readOnly vars don't have connect implemented correctly.
			self.iMeasConnect2 = other._i._get
		except:
			log('Cannot connect iMeas variable of %s to %s'%(other.fqn,self.fqn))

class ANUPAMSupplies(Entity):
	refresh = Object(typ=Trigger,label = 'Refresh All',function='updateValues')
	on = Object(typ=Boolean,label = 'Power on All')

	vFpga = Object(typ=Supply,label='vFpga')
	vclk = Object(typ=Supply,label='vclk')
	vddRx1p2 = Object(typ=Supply,label='vddRx1p2')
	vddRx1p8 = Object(typ=Supply,label='vddRx1p8')
	veeTx = Object(typ=Supply,label='veeTx')
	vddA1p8 = Object(typ=Supply,label='vddA1p8')
	avdd1p0 = Object(typ=DualSupply,label='avdd1p0')
	dvdd = Object(typ=DualSupply,label='dvdd')

	def setLimits(self):
		pass

	def updateValues(self):
		for entity in self.entityList:
			entity.refresh = 1

	def connect(self):
		for entity in self.entityList:
			Connect(self._on,entity._on,1)

