log0 = open ( "D:\\WORK\\afe_conf_log.txt", "r" )
log1 = open ( "D:\\WORK\\afe_conf_log_origin.txt", "r" )
path_compare = "D:\\WORK\\afe_conf_log_compare.txt"
open(path_compare, 'w').close()


cnt=0
for line in log0.readlines():
    cnt=cnt+1
    #print(line[0:13])

    i_end = line.find("\n")
    i0 = line.find("0x",4,i_end)
    i1 = line.find(" ", i0, i_end)

    line1 = log1.readline()
    #print(line1[0:13])
    if (line[0:i1]==line1[0:i1]) :
        cnt = cnt
    else :
        if (line[0:i0-1]==line1[0:i0-1]):
            lg = str(cnt) + " " + line[0:i0-1] + " " + line1[i0:i1] + " " + line[i0:i1] + "\n"
        else :
            lg = str(cnt) + " !!!!!!!!!!!! ERROR ADDR !!!!!!!!!!!!!!! " + line1[0:i1] + " " + line[0:i1] + "\n"
        with open(path_compare, 'a') as file:
            file.write(lg)
        #print(str(cnt), " ", line[0:13], " ", line1[0:13])